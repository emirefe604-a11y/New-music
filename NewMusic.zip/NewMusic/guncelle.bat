@echo off
chcp 65001 >nul
echo NewMusic GitHub Guncelleme Araci
echo ===================================

if exist NewMusic.zip (
    echo [1/3] NewMusic.zip arsivi bulundu, dosyalar cikariliyor...
    tar -xf NewMusic.zip
)

echo [2/3] Degisiklikler Git'e ekleniyor...
git add .
git commit -m "Uygulama guncellendi (otomatik senkronizasyon)"

echo [3/3] GitHub'a push ediliyor...
git push

echo.
echo Tamamlandi! Degisiklikler dogrudan GitHub'a aktarildi.
pause
