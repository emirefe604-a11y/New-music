# Sounddeep — iOS Kurulum ve Kullanım Rehberi (Mac Olmadan, %100 Ücretsiz)

Bu rehber sayesinde **Mac bilgisayar satın almadan** ve **Apple'a 99$ yıllık geliştirici ücreti ödemeden**, GitHub'ın ücretsiz bulut Mac sunucularını ve Windows bilgisayarını kullanarak Sounddeep'i iPhone'una kolayca kurabilirsin.

---

## 🚀 Adım 1: Kodları GitHub'a Yükleme

1. İndirdiğin `NewMusic.zip` içerisindeki tüm dosyaları GitHub repository'ne yükle (commit & push).
2. Projede `.github/workflows/build_ios.yml` dosyasının bulunduğundan emin ol.

---

## ☁️ Adım 2: GitHub Actions ile Bulutta IPA Üretme

1. GitHub'da projene gir ve üstteki **Actions** sekmesine tıkla.
2. Sol tarafta listelenen **"Build iOS App (.ipa)"** iş akışını seç.
3. Sağ taraftaki **"Run workflow"** butonuna tıkla ve başlat.
4. GitHub'ın bulut Mac sunucusu projeyi yaklaşık 2 dakika içinde derleyecektir.
5. İşlem bittiğinde yeşil tik işaretine tıkla ve sayfanın en altındaki **Artifacts** başlığı altında yer alan **`NewMusic-iOS-IPA`** dosyasını bilgisayarına indir. (İnen zip içinden `NewMusic.ipa` dosyası çıkar).

---

## 📲 Adım 3: Sideloadly ile iPhone'a Yükleme (Windows)

1. Windows bilgisayarına ücretsiz ve güvenli olan **[Sideloadly](https://sideloadly.io/)** programını indirip kur.
2. iPhone'unu USB şarj kablosuyla bilgisayarına bağla. Telefon ekranında *"Bu Bilgisayara Güvenilsin mi?"* uyarısı çıkarsa **Güven** de ve şifreni gir.
3. Sideloadly uygulamasını aç:
   * **IPA:** İndirdiğin `NewMusic.ipa` dosyasını Sideloadly penceresindeki büyük IPA kutusuna sürükleyip bırak.
   * **Apple ID:** Kendi kullandığın normal Apple kimliği e-postanı yaz (ücretsiz hesap yeterlidir).
   * **Start:** Büyük **Start** butonuna tıkla.
4. Sideloadly, Apple ile iletişim kurarak uygulamayı telefonun için ücretsiz imzalayacak ve birkaç saniye içinde iPhone'una yükleyecektir.

---

## 🔒 Adım 4: iPhone'da İlk İzni Verme

Apple, dışarıdan yüklenen uygulamalarda ilk açılışta güvenlik onayı ister:

1. iPhone'unda **Ayarlar > Genel > VPN ve Aygıt Yönetimi** (veya *Sertifikalar / Profiller*) menüsüne git.
2. *"Geliştirici Uygulaması"* altında kendi Apple kimliğini göreceksin; üzerine dokun.
3. **"Güven"** butonuna bas ve onayla.
4. Artık ana ekrandaki **Sounddeep** simgesine dokunarak uygulamayı açabilirsin!

---

## ✨ Neler Kullanabileceksin?

* **Arka Planda ve Ekran Kapalıyken Çalma:** Telefon ekranını kilitlesen bile müzik kesintisiz çalmaya devam eder.
* **Kilit Ekranı Kumandası:** Kilit ekranında canlı albüm kapağı, şarkı/sanatçı ismi, ilerleme çubuğu ve ileri/geri kontrolleri.
* **Akan Şarkı Sözleri:** Sağ üstteki söz butonuna dokunarak şarkıyla eş zamanlı akan sözleri takip edebilirsin.
* **Aşağı Kaydırarak Küçültme:** Büyük oynatıcıyı üstten aşağı kaydırarak mini oynatıcıya dönüştürebilirsin.
* **Arkadaşlar ve Sosyal Özellikler:** Canlı dinleme durumu, ortak Blend listeleri ve arkadaş profilleri tam uyumlu çalışır.
