#!/bin/bash
set -e
echo "NewMusic GitHub Güncelleme Aracı"
echo "==================================="

if [ -f "NewMusic.zip" ]; then
    echo "[1/3] NewMusic.zip arşivi bulundu, dosyalar çıkarılıyor..."
    unzip -o NewMusic.zip
fi

echo "[2/3] Değişiklikler Git'e ekleniyor..."
git add .
git commit -m "Uygulama güncellendi (otomatik senkronizasyon)" || true

echo "[3/3] GitHub'a push ediliyor..."
git push

echo "Tamamlandı! Değişiklikler doğrudan GitHub'a aktarıldı."
