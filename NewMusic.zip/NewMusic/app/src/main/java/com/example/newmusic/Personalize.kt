package com.example.newmusic

/**
 * Günlük listeleri (Top 50, ana sayfa karışıkları, Keşfet) kullanıcının kaydedilen zevkine göre kişiselleştirir.
 * Zevk verisi yoksa (yeni kullanıcı) hiçbir şeyi değiştirmez. Sonuç gün içinde sabittir, zevk değişince ve gün
 * değişince güncellenir.
 */
object Personalize {
    /** Liste sırası büyük ölçüde korunur; zevkine uyan şarkılar öne çıkar, beğenmediklerin elenir. */
    fun rank(songs: List<Song>, strength: Float = 1f): List<Song> {
        if (!TasteProfile.hasData || songs.isEmpty()) return songs
        val n = songs.size.toFloat()
        return songs.withIndex()
            .filter { TasteProfile.tasteScore(it.value) > -50f }
            .sortedByDescending { (1f - it.index / n) * 3f + TasteProfile.tasteScore(it.value) * strength }
            .map { it.value }
    }

    /** Top listelerini zevke göre sıralar ve en başa "Senin İçin" kişisel listesini ekler. */
    fun topLists(lists: List<TopList>): List<TopList> {
        if (!TasteProfile.hasData || lists.isEmpty()) return lists
        val ranked = lists.map { TopList(it.label, rank(it.songs)) }.filter { it.songs.isNotEmpty() }
        if (ranked.isEmpty()) return lists
        fun listScore(t: TopList) = t.songs.take(15).map { TasteProfile.tasteScore(it) }.average()
        val ordered = ranked.sortedByDescending { listScore(it) }

        // Tüm listelerden, zevkine en uygun şarkılarla bugüne özel kişisel Top 50
        val pool = ranked.flatMap { it.songs }.distinctBy { it.url }
        val mine = dailyShuffle(pool, 11)
            .sortedByDescending { TasteProfile.tasteScore(it) }
            .take(50)
        val liked = mine.count { TasteProfile.tasteScore(it) > 0.5f }
        return if (liked >= 8) listOf(TopList("🎧 Senin İçin · Günün Top 50", mine)) + ordered else ordered
    }

    /** İçerik dili ayarına uyan bölümlerden zevke yakın olanları öne alır; kalanlar bugüne göre karışır. */
    fun <T> sections(all: List<T>, text: (T) -> String, favCount: Int = 6, keepFirst: Int = 1): List<T> {
        if (!TasteProfile.hasData) return all
        val head = all.take(keepFirst)
        val rest = all.drop(keepFirst)
        val fav = dailyShuffle(rest, 5)
            .filter { TasteProfile.textAffinity(text(it)) > 0.3f }
            .sortedByDescending { TasteProfile.textAffinity(text(it)) }
            .take(favCount)
        val others = dailyShuffle(rest.filter { it !in fav }, 9)
        return (head + fav + others).distinct()
    }
}
