package com.example.newmusic

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ShareTarget { WHATSAPP, INSTAGRAM, OTHER }

/**
 * Şarkı paylaşma: albüm kapaklı bir kart görseli + şarkı bağlantısı oluşturur,
 * WhatsApp, Instagram veya herhangi bir uygulamaya gönderir.
 */
object ShareSong {
    private const val W = 1080
    private const val H = 1350

    fun canShare(s: Song) = !Uploads.isLocal(s) && s.url.startsWith("http")

    /** Paylaşılan metin: şarkı adı, sanatçı ve dinleme bağlantısı. */
    fun text(s: Song): String =
        "🎵 ${s.title}" + (if (s.artist.isNotBlank()) " – ${s.artist}" else "") +
            "\n${s.url}\n\nSounddeep ile dinle"

    /** Albüm kapağı + başlık + sanatçı içeren paylaşım görseli (PNG). Kapak inmezse renkli bir kart çizilir. */
    suspend fun card(ctx: Context, s: Song): File? = withContext(Dispatchers.IO) {
        try {
            var cover: Bitmap? = null
            for (u in listOf(hiRes(s.thumb, 800), hiRes(s.thumb, 480), s.thumb)) {
                if (u == null || cover != null) continue
                val res = ctx.imageLoader.execute(ImageRequest.Builder(ctx).data(u).allowHardware(false).build())
                cover = (res as? SuccessResult)?.drawable?.toBitmap()
            }
            val bg = cover?.let { b -> val pal = Palette.from(b).generate(); pal.getDarkMutedColor(pal.getDominantColor(0xFF1B1B2F.toInt())) } ?: 0xFF1B1B2F.toInt()

            val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), bg, AColor.BLACK, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
            p.shader = null

            // Kapak: ortadan kare kırpılır, yuvarlak köşeli çizilir
            val size = 880f
            val left = (W - size) / 2f
            val top = 110f
            val box = RectF(left, top, left + size, top + size)
            val path = Path().apply { addRoundRect(box, 36f, 36f, Path.Direction.CW) }
            c.save()
            c.clipPath(path)
            if (cover != null) {
                val side = minOf(cover.width, cover.height)
                val src = android.graphics.Rect((cover.width - side) / 2, (cover.height - side) / 2, (cover.width + side) / 2, (cover.height + side) / 2)
                c.drawBitmap(cover, src, box, p)
            } else {
                p.color = AColor.argb(60, 255, 255, 255)
                c.drawRect(box, p)
            }
            c.restore()

            val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.WHITE; textSize = 58f; typeface = Typeface.DEFAULT_BOLD }
            val artist = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.argb(220, 255, 255, 255); textSize = 42f }
            val brand = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.argb(150, 255, 255, 255); textSize = 34f; typeface = Typeface.DEFAULT_BOLD }
            val maxW = size
            c.drawText(TextUtils.ellipsize(s.title, title, maxW, TextUtils.TruncateAt.END).toString(), left, top + size + 100f, title)
            c.drawText(TextUtils.ellipsize(s.artist, artist, maxW, TextUtils.TruncateAt.END).toString(), left, top + size + 164f, artist)
            c.drawText("Sounddeep", left, H - 70f, brand)

            val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 60 * 60_000L }?.forEach { it.delete() }
            val f = File(dir, "song_${(s.url.hashCode().toLong() and 0xffffffffL)}.png")
            f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            f
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    /** Kartı + metni seçilen uygulamaya gönderir. Görsel hazırlanamadıysa yalnızca metin gider. */
    fun send(ctx: Context, target: ShareTarget, s: Song, card: File?) {
        val text = text(s)
        val intent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_SUBJECT, s.title)
            if (card != null) {
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.shareprovider", card)
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("Sounddeep", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else type = "text/plain"
        }
        try {
            when (target) {
                ShareTarget.WHATSAPP -> {
                    val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(ctx, it) }
                    if (pkg == null) { toast(ctx, "WhatsApp yüklü değil"); return }
                    ctx.startActivity(intent.setPackage(pkg))
                }
                ShareTarget.INSTAGRAM -> {
                    if (!installed(ctx, "com.instagram.android")) { toast(ctx, "Instagram yüklü değil"); return }
                    // Instagram metni almaz; bağlantı panoya kopyalanır, mesaja yapıştırılabilir
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
                        ?.setPrimaryClip(ClipData.newPlainText("Şarkı bağlantısı", s.url))
                    toast(ctx, "Kapak hazır. Bağlantı da kopyalandı, mesaja yapıştırabilirsin")
                    ctx.startActivity(intent.setPackage("com.instagram.android"))
                }
                ShareTarget.OTHER -> ctx.startActivity(Intent.createChooser(intent, "Şarkıyı paylaş"))
            }
        } catch (e: ActivityNotFoundException) {
            toast(ctx, "Uygulama açılamadı")
        }
    }

    private fun installed(ctx: Context, pkg: String) = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }

    private fun toast(ctx: Context, m: String) = Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()
}

/** Paylaşım penceresi: kapak önizlemesi ve WhatsApp / Instagram / Diğer tuşları. */
@Composable
fun ShareSongDialog(song: Song, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    fun go(t: ShareTarget) {
        if (busy) return
        busy = true
        scope.launch {
            val card = ShareSong.card(ctx, song)
            ShareSong.send(ctx, t, song, card)
            busy = false
            onDismiss()
        }
    }
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Card).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AsyncImage(
                hiRes(song.thumb, 600), null,
                Modifier.size(170.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x22FFFFFF)),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(14.dp))
            Text(song.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            if (song.artist.isNotBlank()) Text(song.artist, color = Color(0xFF9A9A9A), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(20.dp))
            if (busy) {
                Box(Modifier.height(78.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent, strokeWidth = 3.dp) }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ShareOption("WhatsApp", Brush.linearGradient(listOf(Color(0xFF25D366), Color(0xFF128C7E))), { go(ShareTarget.WHATSAPP) }) {
                        WhatsAppLogo()
                    }
                    ShareOption("Instagram", Brush.linearGradient(listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCB045))), { go(ShareTarget.INSTAGRAM) }) {
                        InstagramLogo()
                    }
                    ShareOption("Kopyala", Brush.linearGradient(listOf(Color(0xFF4D8DFF), Color(0xFF2962FF))), {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
                            ?.setPrimaryClip(ClipData.newPlainText("Şarkı bağlantısı", song.url))
                        Toast.makeText(ctx, "Şarkı bağlantısı kopyalandı!", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    }) {
                        Icon(Icons.Filled.ContentCopy, null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    ShareOption("Diğer", Brush.linearGradient(listOf(Color(0xFF4A4A5A), Color(0xFF2E2E3A))), { go(ShareTarget.OTHER) }) {
                        Icon(Icons.Filled.MoreHoriz, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun WhatsAppLogo(modifier: Modifier = Modifier) {
    Box(modifier.size(28.dp), contentAlignment = Alignment.Center) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val stroke = 2.2.dp.toPx()
            val path = androidx.compose.ui.graphics.Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height * 0.94f))
                moveTo(size.width * 0.22f, size.height * 0.76f)
                lineTo(size.width * 0.04f, size.height * 0.96f)
                lineTo(size.width * 0.26f, size.height * 0.86f)
            }
            drawPath(path, color = Color.White, style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke))
        }
        Icon(Icons.Filled.Call, null, tint = Color.White, modifier = Modifier.size(15.dp))
    }
}

@Composable
fun InstagramLogo(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier.size(28.dp)) {
        val stroke = 2.4.dp.toPx()
        val corner = 8.dp.toPx()
        drawRoundRect(
            color = Color.White,
            topLeft = androidx.compose.ui.geometry.Offset(stroke / 2, stroke / 2),
            size = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
        )
        drawCircle(
            color = Color.White,
            radius = size.width * 0.24f,
            center = center,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
        )
        drawCircle(
            color = Color.White,
            radius = 2.2.dp.toPx(),
            center = androidx.compose.ui.geometry.Offset(size.width * 0.74f, size.height * 0.26f)
        )
    }
}

@Composable
private fun ShareOption(label: String, brush: Brush, onClick: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(brush), contentAlignment = Alignment.Center) {
            content()
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
