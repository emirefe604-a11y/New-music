package com.example.newmusic

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** Sounddeep logosu: derin mavi gradyanlı yuvarlak zemin üzerinde beyaz ses dalgası çubukları. */
@Composable
fun AppLogo(logoSize: Dp = 88.dp) {
    Canvas(Modifier.size(logoSize)) {
        val w = this.size.width
        val h = this.size.height
        val s = this.size.minDimension / 108f
        drawCircle(Brush.linearGradient(listOf(Color(0xFF3D8BFF), Color(0xFF0A3FD0)), start = Offset(0f, 0f), end = Offset(w, h)))
        drawCircle(Color(0x33FFFFFF), radius = this.size.minDimension * 0.46f, style = Stroke(width = this.size.minDimension * 0.012f))
        val half = floatArrayOf(9f, 19f, 28f, 19f, 9f)
        val k = 1.15f
        for (i in half.indices) {
            val x = (54f + (i - 2) * 11f * k) * s
            drawLine(
                Color.White, Offset(x, (54f - half[i] * k) * s), Offset(x, (54f + half[i] * k) * s),
                strokeWidth = 7f * k * s, cap = StrokeCap.Round
            )
        }
    }
}

/** Tek profil fotoğrafı: Ayarlar'daki profil ve Arkadaşlar sekmesi aynı fotoğrafı kullanır (cihaza ve sunucuya birlikte yazılır). */
object ProfilePhoto {
    suspend fun set(ctx: android.content.Context, uri: android.net.Uri): String? {
        val local = AuthStore.setPhoto(ctx, uri)
        val remote = if (Social.joined) Social.setAvatar(ctx, uri) else null
        return if (!local && (!Social.joined || remote != null)) (remote ?: "Fotoğraf eklenemedi.") else null
    }

    suspend fun clear(): String? {
        AuthStore.clearPhoto()
        return if (Social.joined) Social.clearAvatar() else null
    }

    /** Yalnızca cihazda olan fotoğraf sunucuya da yüklenir (arkadaşlar da aynısını görsün). */
    suspend fun syncUp(ctx: android.content.Context) {
        val p = AuthStore.photo.value ?: return
        if (!Social.joined || Social.myAvatar.value != null) return
        Social.setAvatar(ctx, android.net.Uri.fromFile(File(p)))
    }
}

/** Profil resmi: fotoğraf varsa onu, yoksa adın baş harfini (giriş yoksa kişi simgesini) gösterir. */
@Composable
fun Avatar(avatarSize: Dp, modifier: Modifier = Modifier) {
    val photo by AuthStore.photo.collectAsState()
    val name by AuthStore.name.collectAsState()
    val email by AuthStore.email.collectAsState()
    val serverPhoto by Social.myAvatar.collectAsState()   // yeniden kurulumdan sonra fotoğraf sunucudan gelir
    val p = photo
    val remote = Social.avatarUrl(serverPhoto)
    Box(
        modifier.size(avatarSize).clip(CircleShape).background(Accent.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center
    ) {
        when {
            p != null -> AsyncImage(File(p), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            remote != null -> AsyncImage(remote, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            email != null -> Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (avatarSize.value * 0.42f).sp)
            else -> Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(avatarSize * 0.6f))
        }
    }
}

@Composable
private fun AuthField(
    value: String, onValue: (String) -> Unit, placeholder: String, icon: ImageVector,
    keyboardType: KeyboardType, imeAction: ImeAction, onDone: () -> Unit,
    secret: Boolean = false, shown: Boolean = false, onToggle: () -> Unit = {},
    textStyle: TextStyle = TextStyle(fontSize = 16.sp)
) {
    val muted = Color(0xFF9A9A9A)
    TextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(placeholder, color = muted) },
        leadingIcon = { Icon(icon, null, tint = muted) },
        trailingIcon = if (secret) {
            { IconButton(onToggle) { Icon(if (shown) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Göster/gizle", tint = muted) } }
        } else null,
        visualTransformation = if (secret && !shown) PasswordVisualTransformation() else VisualTransformation.None,
        singleLine = true, shape = RoundedCornerShape(28.dp), textStyle = textStyle,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Card, unfocusedContainerColor = Card, disabledContainerColor = Card,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = Accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White
        ),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }, onGo = { onDone() })
    )
}

/**
 * Giriş / hesap oluşturma.
 * - Giriş: e-posta + şifre (kod istenmez, oturum açık kalır).
 * - Hesap oluştur: e-posta > 6 haneli kod > ad ve şifre belirle.
 * - Şifremi unuttum: e-posta > kod > yeni şifre.
 */
@Composable
fun AuthScreen(onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf("login") } // login | email | code | password
    var reset by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var password2 by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cooldown by remember { mutableIntStateOf(0) }
    LaunchedEffect(cooldown) { if (cooldown > 0) { delay(1000); cooldown -= 1 } }

    fun mail() = email.trim().lowercase()
    fun go(s: String) { screen = s; error = null }
    fun close() { AuthStore.markPrompted(); onClose() }
    BackHandler {
        when (screen) {
            "login" -> close()
            "email" -> go("login")
            "code" -> go("email")
            else -> go("email")
        }
    }

    fun validEmail(): Boolean {
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(mail()).matches()) { error = "Geçerli bir e-posta adresi yaz."; return false }
        return true
    }

    fun login() {
        if (!validEmail()) return
        if (password.isEmpty()) { error = "Şifreni yaz."; return }
        busy = true; error = null
        scope.launch {
            val m = mail()
            val r = AuthApi.login(m, password)
            if (r.error == null) { AuthStore.signIn(m, r); busy = false; onClose() }
            else { error = r.error; busy = false }
        }
    }

    fun sendCode() {
        if (!validEmail()) return
        busy = true; error = null
        scope.launch {
            // Hesap var/yok kontrolü sunucuda yapılır (hesaplar artık her cihazda aynı)
            val err = AuthApi.sendCode(mail(), reset)
            busy = false
            if (err == null) { email = mail(); code = ""; screen = "code"; cooldown = 30 } else error = err
        }
    }

    fun verify() {
        if (code.length != 6) { error = "6 haneli kodu yaz."; return }
        busy = true; error = null
        scope.launch {
            val err = AuthApi.verify(mail(), code)
            busy = false
            if (err == null) { password = ""; password2 = ""; go("password") } else error = err
        }
    }

    fun savePassword() {
        if (!reset && name.isBlank()) { error = "Adını yaz."; return }
        if (password.length < 6) { error = "Şifre en az 6 karakter olmalı."; return }
        if (password != password2) { error = "Şifreler aynı değil."; return }
        busy = true; error = null
        scope.launch {
            val m = mail()
            val r = if (reset) AuthApi.reset(m, password) else AuthApi.register(m, password, name.trim())
            busy = false
            if (r.error == null) { AuthStore.signIn(m, r); onClose() } else error = r.error
        }
    }

    val title = when (screen) {
        "login" -> "Giriş yap"
        "email" -> if (reset) "Şifreni sıfırla" else "Hesap oluştur"
        "code" -> "Kodu gir"
        else -> if (reset) "Yeni şifre belirle" else "Profilini tamamla"
    }
    val subtitle = when (screen) {
        "login" -> ""
        "email" -> "E-posta adresine 6 haneli bir doğrulama kodu göndereceğiz."
        "code" -> "${mail()} adresine gönderdiğimiz kodu yaz. Kod 10 dakika geçerli."
        else -> if (reset) "Yeni şifreni iki kez yaz." else "Adını ve şifreni belirle. Sonraki girişlerde kod gerekmez."
    }
    val action: () -> Unit = {
        when (screen) { "login" -> login(); "email" -> sendCode(); "code" -> verify(); else -> savePassword() }
    }

    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))
            AppLogo()
            Spacer(Modifier.height(14.dp))
            Text("Sounddeep", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(18.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            if (subtitle.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(subtitle, color = Color(0xFF9A9A9A), textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(24.dp))

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (screen) {
                    "login" -> {
                        AuthField(email, { email = it; error = null }, "@gmail.com", Icons.Filled.Email,
                            KeyboardType.Email, ImeAction.Next, {})
                        AuthField(password, { password = it; error = null }, "Şifre", Icons.Filled.Lock,
                            KeyboardType.Password, ImeAction.Go, { if (!busy) action() },
                            secret = true, shown = shown, onToggle = { shown = !shown })
                    }
                    "email" -> AuthField(email, { email = it; error = null }, "@gmail.com", Icons.Filled.Email,
                        KeyboardType.Email, ImeAction.Go, { if (!busy) action() })
                    "code" -> AuthField(code, { code = it.filter(Char::isDigit).take(6); error = null }, "000000", Icons.Filled.Lock,
                        KeyboardType.Number, ImeAction.Done, { if (!busy) action() },
                        textStyle = TextStyle(fontSize = 22.sp, letterSpacing = 6.sp))
                    else -> {
                        if (!reset) AuthField(name, { name = it; error = null }, "Adın", Icons.Filled.Person,
                            KeyboardType.Text, ImeAction.Next, {})
                        AuthField(password, { password = it; error = null }, "Şifre (en az 6 karakter)", Icons.Filled.Lock,
                            KeyboardType.Password, ImeAction.Next, {},
                            secret = true, shown = shown, onToggle = { shown = !shown })
                        AuthField(password2, { password2 = it; error = null }, "Şifre tekrar", Icons.Filled.Lock,
                            KeyboardType.Password, ImeAction.Done, { if (!busy) action() },
                            secret = true, shown = shown, onToggle = { shown = !shown })
                    }
                }
            }
            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Accent, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = action, enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(
                    when (screen) { "login" -> "Giriş yap"; "email" -> "Kod gönder"; "code" -> "Doğrula"; else -> "Kaydet ve devam et" },
                    fontWeight = FontWeight.SemiBold
                )
            }
            when (screen) {
                "login" -> {
                    TextButton({ reset = false; go("email") }) { Text("Hesap oluştur", color = Color.White) }
                    TextButton({ reset = true; go("email") }) { Text("Şifremi unuttum", color = Color(0xFF9A9A9A)) }
                    TextButton({ close() }) { Text("Şimdilik atla", color = Color(0xFF9A9A9A)) }
                }
                "code" -> {
                    TextButton({ sendCode() }, enabled = !busy && cooldown == 0) {
                        Text(if (cooldown > 0) "Kodu tekrar gönder ($cooldown sn)" else "Kodu tekrar gönder", color = if (cooldown > 0) Color.Gray else Accent)
                    }
                    TextButton({ go("email") }) { Text("E-posta adresini değiştir", color = Color.White) }
                }
                "email" -> TextButton({ go("login") }) { Text("Zaten hesabım var", color = Color.White) }
                else -> {}
            }
        }
    }
}

/** Ayarlar > Profil: fotoğraf seç, adı değiştir, çıkış yap. */
@Composable
fun ProfilePage(onSignedOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val handle by Social.username.collectAsState()
    val currentName by AuthStore.name.collectAsState()
    var name by remember(currentName) { mutableStateOf(currentName) }
    var msg by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            msg = ProfilePhoto.set(ctx, uri) ?: "Profil fotoğrafı güncellendi."
        }
    }
    val pick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.clickable { pick() }) {
            Avatar(112.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(36.dp).clip(CircleShape).background(Accent),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        }
        Spacer(Modifier.height(10.dp))
        TextButton({ pick() }) { Text("Fotoğraf seç", color = Accent) }
        // Kullanıcı adı rastgele bir kimliktir; e-posta adresi gösterilmez
        Text(handle?.let { "@$it" } ?: "", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it.take(30) }, label = { Text("Ad") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { if (name.isNotBlank()) { AuthStore.setName(name); msg = "Kaydedildi." } },
            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
        ) { Text("Kaydet", fontWeight = FontWeight.SemiBold) }
        msg?.let { Text(it, color = Accent, modifier = Modifier.padding(top = 12.dp)) }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = { AuthStore.signOut(); onSignedOut() },
            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
        ) { Text("Çıkış yap", color = Color.White) }
    }
}
