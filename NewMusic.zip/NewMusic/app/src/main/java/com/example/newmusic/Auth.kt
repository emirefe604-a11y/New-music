package com.example.newmusic

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/** Sounddeep logosu: derin mavi gradyanlı yuvarlak zemin üzerinde beyaz ses dalgası çubukları. */
@Composable
fun AppLogo(logoSize: Dp = 88.dp) {
    Canvas(Modifier.size(logoSize)) {
        val w = this.size.width
        val h = this.size.height
        val s = this.size.minDimension / 108f
        drawCircle(Brush.linearGradient(listOf(Color(0xFF3D8BFF), Color(0xFF0A3FD0)), start = Offset(0f, 0f), end = Offset(w, h)))
        drawCircle(Color(0x33FFFFFF), radius = this.size.minDimension * 0.46f, style = Stroke(width = this.size.minDimension * 0.012f))
        val half = floatArrayOf(9f, 19f, 28f, 19f, 9f)
        val k = 1.15f
        for (i in half.indices) {
            val x = (54f + (i - 2) * 11f * k) * s
            drawLine(
                Color.White, Offset(x, (54f - half[i] * k) * s), Offset(x, (54f + half[i] * k) * s),
                strokeWidth = 7f * k * s, cap = StrokeCap.Round
            )
        }
    }
}

/** Hesabın profil resmi: resim varsa onu, yoksa adın baş harfini (hesap yoksa kişi simgesini) gösterir. */
@Composable
fun Avatar(avatarSize: Dp, modifier: Modifier = Modifier) {
    val name by Social.username.collectAsState()
    val version by Social.myAvatarV.collectAsState()
    val n = name
    if (n != null) Avatar(n, version, avatarSize, modifier)
    else Box(
        modifier.size(avatarSize).clip(CircleShape).background(Accent.copy(alpha = 0.35f)),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(avatarSize * 0.6f)) }
}

@Composable
private fun AuthField(
    value: String, onValue: (String) -> Unit, placeholder: String, icon: ImageVector,
    keyboardType: KeyboardType, imeAction: ImeAction, onDone: () -> Unit,
    secret: Boolean = false, shown: Boolean = false, onToggle: () -> Unit = {},
    textStyle: TextStyle = TextStyle(fontSize = 16.sp)
) {
    val muted = Color(0xFF9A9A9A)
    TextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(placeholder, color = muted) },
        leadingIcon = { Icon(icon, null, tint = muted) },
        trailingIcon = if (secret) {
            { IconButton(onToggle) { Icon(if (shown) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Göster/gizle", tint = muted) } }
        } else null,
        visualTransformation = if (secret && !shown) PasswordVisualTransformation() else VisualTransformation.None,
        singleLine = true, shape = RoundedCornerShape(28.dp), textStyle = textStyle,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Card, unfocusedContainerColor = Card, disabledContainerColor = Card,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = Accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White
        ),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }, onGo = { onDone() })
    )
}

/**
 * Hesap oluştur / giriş yap: kullanıcı adı + e-posta + şifre.
 * E-posta, şifreni unutursan sıfırlama kodu göndermek içindir. Hesap sunucuda durur; uygulamayı silsen bile
 * aynı bilgilerle girince listelerin ve beğendiklerin geri gelir.
 */
@Composable
fun AuthScreen(onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    // create | verify (hesap kodu) | login | forgot (kullanıcı adı) | reset (kod + yeni şifre)
    var screen by remember { mutableStateOf("create") }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var password2 by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    val muted = Color(0xFF9A9A9A)

    fun close() { Social.markPrompted(); onClose() }
    fun go(to: String) { screen = to; error = null; info = null; code = "" }
    BackHandler {
        when (screen) {
            "verify" -> go("create")
            "forgot", "reset" -> go("login")
            else -> close()
        }
    }

    fun sendSignupCode(next: Boolean) {
        busy = true; error = null
        scope.launch {
            val (skip, err) = Social.signupCode(username, email)
            if (err != null) { busy = false; error = err; return@launch }
            if (skip) {   // sunucuda e-posta kapalı: kodsuz aç
                val e = Social.join(username.trim(), password)
                busy = false
                if (e == null) close() else error = e
            } else {
                busy = false
                if (next) go("verify")
                info = "Kod ${email.trim()} adresine gönderildi."
            }
        }
    }

    fun sendResetCode() {
        busy = true; error = null
        scope.launch {
            val (masked, err) = Social.resetCode(username)
            busy = false
            if (err != null) error = err
            else { val m = masked; go("reset"); info = "Kod $m adresine gönderildi." }
        }
    }

    fun submit() {
        val u = username.trim()
        val mail = email.trim()
        when (screen) {
            "create" -> when {
                u.length < 3 -> error = "Kullanıcı adı en az 3 karakter olmalı."
                !Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$").matches(mail) -> error = "Geçerli bir e-posta adresi yaz."
                password.length < 6 -> error = "Şifre en az 6 karakter olmalı."
                password != password2 -> error = "Şifreler aynı değil."
                else -> sendSignupCode(true)
            }
            "verify" -> {
                if (code.length != 6) { error = "6 haneli kodu yaz."; return }
                busy = true; error = null
                scope.launch {
                    val e = Social.join(u, password, mail, code)
                    busy = false
                    if (e == null) close() else error = e
                }
            }
            "login" -> {
                if (u.length < 3) { error = "Kullanıcı adını yaz."; return }
                if (password.isEmpty()) { error = "Şifreni yaz."; return }
                busy = true; error = null
                scope.launch {
                    val e = Social.login(u, password)
                    busy = false
                    if (e == null) close() else error = e
                }
            }
            "forgot" -> if (u.length < 3) error = "Kullanıcı adını yaz." else sendResetCode()
            "reset" -> when {
                code.length != 6 -> error = "6 haneli kodu yaz."
                password.length < 6 -> error = "Yeni şifre en az 6 karakter olmalı."
                password != password2 -> error = "Şifreler aynı değil."
                else -> {
                    busy = true; error = null
                    scope.launch {
                        val e = Social.resetPassword(u, code, password)
                        if (e != null) { busy = false; error = e; return@launch }
                        val l = Social.login(u, password)   // yeni şifreyle doğrudan gir
                        busy = false
                        if (l == null) close() else { go("login"); info = "Şifren yenilendi. Giriş yap." }
                    }
                }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            AppLogo()
            Spacer(Modifier.height(14.dp))
            Text("Sounddeep", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(20.dp))

            // Hesap oluştur | Giriş yap
            if (screen == "create" || screen == "login") {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Card).padding(4.dp)) {
                    listOf("create" to "Hesap oluştur", "login" to "Giriş yap").forEach { (key, label) ->
                        val sel = screen == key
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(22.dp))
                                .background(if (sel) Accent else Color.Transparent)
                                .clickable { go(key) }.padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(label, fontWeight = FontWeight.SemiBold, color = if (sel) Color.White else muted) }
                    }
                }
                Spacer(Modifier.height(18.dp))
            }
            Text(
                when (screen) {
                    "create" -> "Bir kullanıcı adı, e-posta ve şifre seç. E-postan yalnızca şifreni unutursan sıfırlama kodu göndermek için kullanılır."
                    "verify" -> "E-postana gelen 6 haneli kodu yaz."
                    "login" -> "Uygulamayı silmiş ya da telefon değiştirmiş olsan bile kullanıcı adın ve şifrenle gir; listelerin ve beğendiklerin geri gelir."
                    "forgot" -> "Kullanıcı adını yaz; hesabına bağlı e-postaya bir kod göndereceğiz."
                    else -> "E-postana gelen kodu ve yeni şifreni yaz."
                },
                color = muted, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (screen == "create" || screen == "login" || screen == "forgot")
                    AuthField(username, { username = it.filter(::validChar).take(20); error = null }, "Kullanıcı adı", Icons.Filled.Person,
                        KeyboardType.Ascii, ImeAction.Next, {})
                if (screen == "create")
                    AuthField(email, { email = it.trim().take(100); error = null }, "E-posta", Icons.Filled.Email,
                        KeyboardType.Email, ImeAction.Next, {})
                if (screen == "verify" || screen == "reset")
                    AuthField(code, { code = it.filter(Char::isDigit).take(6); error = null }, "6 haneli kod", Icons.Filled.VpnKey,
                        KeyboardType.NumberPassword, if (screen == "verify") ImeAction.Go else ImeAction.Next, { if (!busy && screen == "verify") submit() },
                        textStyle = TextStyle(fontSize = 20.sp, letterSpacing = 6.sp))
                if (screen == "create" || screen == "login" || screen == "reset")
                    AuthField(password, { password = it.take(64); error = null },
                        when (screen) { "create" -> "Şifre (en az 6 karakter)"; "reset" -> "Yeni şifre (en az 6 karakter)"; else -> "Şifre" }, Icons.Filled.Lock,
                        KeyboardType.Password, if (screen == "login") ImeAction.Go else ImeAction.Next, { if (!busy && screen == "login") submit() },
                        secret = true, shown = shown, onToggle = { shown = !shown })
                if (screen == "create" || screen == "reset")
                    AuthField(password2, { password2 = it.take(64); error = null }, if (screen == "reset") "Yeni şifre tekrar" else "Şifre tekrar", Icons.Filled.Lock,
                        KeyboardType.Password, ImeAction.Go, { if (!busy) submit() },
                        secret = true, shown = shown, onToggle = { shown = !shown })
            }
            if (screen == "login") {
                TextButton({ go("forgot") }, Modifier.align(Alignment.End)) { Text("Şifremi unuttum", color = Accent) }
            }
            info?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Color(0xFF3DDC84), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
            }
            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Accent, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { submit() }, enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(
                    when (screen) {
                        "create" -> "Kod gönder"; "verify" -> "Hesabı oluştur"; "login" -> "Giriş yap"
                        "forgot" -> "Kod gönder"; else -> "Şifreyi yenile"
                    }, fontWeight = FontWeight.SemiBold
                )
            }
            when (screen) {
                "verify" -> {
                    TextButton({ if (!busy) sendSignupCode(false) }) { Text("Kodu tekrar gönder", color = Accent) }
                    TextButton({ go("create") }) { Text("Geri", color = muted) }
                }
                "reset" -> {
                    TextButton({ if (!busy) sendResetCode() }) { Text("Kodu tekrar gönder", color = Accent) }
                    TextButton({ go("login") }) { Text("Geri", color = muted) }
                }
                "forgot" -> TextButton({ go("login") }) { Text("Geri", color = muted) }
                else -> TextButton({ close() }) { Text("Şimdilik atla", color = muted) }
            }
        }
    }
}

/** Hesaba e-posta bağlar: e-posta → gelen kod. (Eski hesaplar ve e-postayı değiştirmek için.) */
@Composable
fun EmailDialog(onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var email by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() }, containerColor = Card,
        title = { Text(if (sent) "Kodu yaz" else "E-posta bağla") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!sent) {
                    Text("Şifreni unutursan bu adrese sıfırlama kodu göndeririz.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9A9A9A))
                    OutlinedTextField(email, { email = it.trim().take(100); error = null }, label = { Text("E-posta") }, singleLine = true,
                        shape = RoundedCornerShape(14.dp), isError = error != null, supportingText = error?.let { { Text(it) } },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
                } else {
                    Text("${email} adresine 6 haneli bir kod gönderdik.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9A9A9A))
                    OutlinedTextField(code, { code = it.filter(Char::isDigit).take(6); error = null }, label = { Text("Kod") }, singleLine = true,
                        shape = RoundedCornerShape(14.dp), isError = error != null, supportingText = error?.let { { Text(it) } },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    busy = true; error = null
                    if (!sent) {
                        val e = Social.emailCode(email)
                        if (e == null) sent = true else error = e
                    } else {
                        val e = Social.emailSet(email, code)
                        if (e == null) { android.widget.Toast.makeText(ctx, "E-postan bağlandı", android.widget.Toast.LENGTH_SHORT).show(); onDismiss() }
                        else error = e
                    }
                    busy = false
                }
            }, enabled = !busy && (if (!sent) email.contains("@") else code.length == 6)) { Text(if (sent) "Doğrula" else "Kod gönder") }
        },
        dismissButton = { TextButton(onDismiss, enabled = !busy) { Text("Vazgeç") } }
    )
}

/** Şifre belirle (şifresi olmayan eski hesaplar) veya değiştir. */
@Composable
fun PasswordDialog(onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val hasPassword by Social.hasPassword.collectAsState()
    var old by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var shown by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val vt = if (shown) VisualTransformation.None else PasswordVisualTransformation()
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() }, containerColor = Card,
        title = { Text(if (hasPassword) "Şifreyi değiştir" else "Şifre belirle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hasPassword) OutlinedTextField(old, { old = it.take(64); error = null }, label = { Text("Mevcut şifre") }, singleLine = true,
                    visualTransformation = vt, shape = RoundedCornerShape(14.dp))
                OutlinedTextField(pw, { pw = it.take(64); error = null }, label = { Text("Yeni şifre (en az 6 karakter)") }, singleLine = true,
                    visualTransformation = vt, shape = RoundedCornerShape(14.dp))
                OutlinedTextField(pw2, { pw2 = it.take(64); error = null }, label = { Text("Yeni şifre tekrar") }, singleLine = true,
                    visualTransformation = vt, shape = RoundedCornerShape(14.dp), isError = error != null,
                    supportingText = error?.let { { Text(it) } })
                Row(Modifier.clickable { shown = !shown }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(shown, { shown = it })
                    Text("Şifreleri göster", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton({
                when {
                    hasPassword && old.isEmpty() -> error = "Mevcut şifreni yaz."
                    pw.length < 6 -> error = "Yeni şifre en az 6 karakter olmalı."
                    pw != pw2 -> error = "Şifreler aynı değil."
                    else -> scope.launch {
                        busy = true
                        val e = Social.setPassword(if (hasPassword) old else null, pw)
                        busy = false
                        error = e
                        if (e == null) { android.widget.Toast.makeText(ctx, "Şifren kaydedildi", android.widget.Toast.LENGTH_SHORT).show(); onDismiss() }
                    }
                }
            }, enabled = !busy) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onDismiss, enabled = !busy) { Text("Vazgeç") } }
    )
}

/** Ayarlar > Profil: resim, kullanıcı adı, şifre ve çıkış. */
@Composable
fun ProfilePage(onSignedOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val username by Social.username.collectAsState()
    val hasPassword by Social.hasPassword.collectAsState()
    val avatarV by Social.myAvatarV.collectAsState()
    var name by remember(username) { mutableStateOf(username ?: "") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val maskedEmail by Social.maskedEmail.collectAsState()
    var showPassword by remember { mutableStateOf(false) }
    var showEmail by remember { mutableStateOf(false) }
    var confirmOut by remember { mutableStateOf(false) }
    var forceOut by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { msg = Social.setAvatar(ctx, uri) ?: "Profil resmi güncellendi." }
    }
    val pick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.clickable { pick() }) {
            Avatar(112.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(36.dp).clip(CircleShape).background(Accent),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        }
        Spacer(Modifier.height(10.dp))
        Row {
            TextButton({ pick() }) { Text(if (avatarV > 0) "Resmi değiştir" else "Resim seç", color = Accent) }
            if (avatarV > 0) TextButton({ scope.launch { msg = Social.removeAvatar() ?: "Profil resmi kaldırıldı." } }) { Text("Kaldır", color = Color(0xFF9A9A9A)) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CloudDone, null, tint = Color(0xFF3DDC84), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Listelerin ve beğendiklerin hesabında yedekleniyor", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it.filter(::validChar).take(20) }, label = { Text("Kullanıcı adı") }, singleLine = true,
            prefix = { Text("@") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { scope.launch { busy = true; msg = Social.rename(name) ?: "Kullanıcı adın değişti."; busy = false } },
            enabled = !busy && name.length >= 3 && name != username,
            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
        ) { Text("Adı kaydet", fontWeight = FontWeight.SemiBold) }
        msg?.let { Text(it, color = Accent, modifier = Modifier.padding(top = 12.dp), textAlign = TextAlign.Center) }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(
            onClick = { showPassword = true },
            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
        ) {
            Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (hasPassword) "Şifreyi değiştir" else "Şifre belirle", color = Color.White)
        }
        if (!hasPassword) Text("Şifre koymazsan uygulamayı silince bu hesaba geri dönemezsin.", color = Accent,
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { showEmail = true },
            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
        ) {
            Icon(Icons.Filled.Email, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (maskedEmail != null) "E-posta: $maskedEmail (değiştir)" else "E-posta bağla", color = Color.White)
        }
        if (maskedEmail == null) Text("E-posta bağlı değil: şifreni unutursan hesabını kurtaramazsın.", color = Accent,
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp), textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { confirmOut = true },
            modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)
        ) { Text("Çıkış yap", color = Color.White) }
    }

    if (showPassword) PasswordDialog { showPassword = false }
    if (showEmail) EmailDialog { showEmail = false }

    if (confirmOut) AlertDialog(
        onDismissRequest = { confirmOut = false }, containerColor = Card, title = { Text("Çıkış yapılsın mı?") },
        text = { Text("Listelerin ve beğendiklerin hesabında kalır; tekrar giriş yapınca geri gelir. Bu cihazdaki kopyaları silinir.") },
        confirmButton = {
            TextButton({
                confirmOut = false
                scope.launch { if (CloudSync.signOut(false)) onSignedOut() else forceOut = true }
            }) { Text("Çıkış yap") }
        },
        dismissButton = { TextButton({ confirmOut = false }) { Text("Vazgeç") } }
    )

    if (forceOut) AlertDialog(
        onDismissRequest = { forceOut = false }, containerColor = Card, title = { Text("Yedeklenemedi") },
        text = { Text("Son değişikliklerin sunucuya yazılamadı (internet yok olabilir). Şimdi çıkarsan bu değişiklikler kaybolur. Yine de çıkmak istiyor musun?") },
        confirmButton = { TextButton({ forceOut = false; scope.launch { CloudSync.signOut(true); onSignedOut() } }) { Text("Yine de çık") } },
        dismissButton = { TextButton({ forceOut = false }) { Text("Vazgeç") } }
    )
}
