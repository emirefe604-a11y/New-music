package com.example.newmusic

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Uygulama logosu: mavi zemin üzerinde NM. */
@Composable
fun NmLogo(size: androidx.compose.ui.unit.Dp = 88.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(Color(0xFF1565FF)),
        contentAlignment = Alignment.Center
    ) {
        Text("NM", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = (size.value * 0.4f).sp)
    }
}

@Composable
private fun AuthField(
    value: String, onValue: (String) -> Unit, placeholder: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
    keyboardType: KeyboardType, imeAction: ImeAction, onDone: () -> Unit, textStyle: TextStyle = TextStyle(fontSize = 16.sp)
) {
    val muted = Color(0xFF9A9A9A)
    TextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(placeholder, color = muted) },
        leadingIcon = { Icon(icon, null, tint = muted) },
        singleLine = true, shape = RoundedCornerShape(28.dp), textStyle = textStyle,
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Card, unfocusedContainerColor = Card, disabledContainerColor = Card,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = Accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White
        ),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }, onGo = { onDone() })
    )
}

/**
 * Hesap oluştur / giriş yap: e-posta adresi girilir, adrese 6 haneli kod gönderilir,
 * kod doğrulanınca hesap bu cihazda açılır.
 */
@Composable
fun AuthScreen(onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var step by remember { mutableIntStateOf(0) }
    var email by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cooldown by remember { mutableIntStateOf(0) }
    LaunchedEffect(cooldown) { if (cooldown > 0) { delay(1000); cooldown -= 1 } }

    fun close() { AuthStore.markPrompted(); onClose() }
    BackHandler { if (step == 1) { step = 0; error = null } else close() }

    fun send() {
        val mail = email.trim().lowercase()
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) { error = "Geçerli bir e-posta adresi yaz."; return }
        busy = true; error = null
        scope.launch {
            val err = AuthApi.sendCode(mail)
            busy = false
            if (err == null) { email = mail; code = ""; step = 1; cooldown = 30 } else error = err
        }
    }

    fun verify() {
        if (code.length != 6) { error = "6 haneli kodu yaz."; return }
        busy = true; error = null
        scope.launch {
            val err = AuthApi.verify(email.trim().lowercase(), code)
            busy = false
            if (err == null) { AuthStore.signIn(email.trim().lowercase()); onClose() } else error = err
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            NmLogo()
            Spacer(Modifier.height(24.dp))
            Text(
                if (step == 0) "Hesap oluştur veya giriş yap" else "Kodu gir",
                style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (step == 0) "Gmail adresini yaz, sana 6 haneli bir doğrulama kodu gönderelim."
                else "$email adresine gönderdiğimiz 6 haneli kodu yaz. Kod 10 dakika geçerli.",
                color = Color(0xFF9A9A9A), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
            if (step == 0) {
                AuthField(email, { email = it; error = null }, "ornek@gmail.com", Icons.Filled.Email,
                    KeyboardType.Email, ImeAction.Go, { if (!busy) send() })
            } else {
                AuthField(code, { code = it.filter(Char::isDigit).take(6); error = null }, "000000", Icons.Filled.Lock,
                    KeyboardType.Number, ImeAction.Done, { if (!busy) verify() },
                    TextStyle(fontSize = 22.sp, letterSpacing = 6.sp))
            }
            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = Accent, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { if (step == 0) send() else verify() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(if (step == 0) "Kod gönder" else "Doğrula ve devam et", fontWeight = FontWeight.SemiBold)
            }
            if (step == 1) {
                TextButton({ send() }, enabled = !busy && cooldown == 0) {
                    Text(if (cooldown > 0) "Kodu tekrar gönder ($cooldown sn)" else "Kodu tekrar gönder", color = if (cooldown > 0) Color.Gray else Accent)
                }
                TextButton({ step = 0; error = null }) { Text("E-posta adresini değiştir", color = Color.White) }
            } else {
                TextButton({ close() }) { Text("Şimdilik atla", color = Color(0xFF9A9A9A)) }
            }
        }
    }
}
