package com.example.newmusic

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow

/** Uygulama teması: arka plan, kart yüzeyi ve vurgu rengi sabittir (albüm kapağına göre değişmez). */
data class AppPalette(val name: String, val bg: Color, val card: Color, val accent: Color)

val Palettes = listOf(
    AppPalette("YouTube Kırmızı", Color(0xFF0A0A0A), Color(0xFF1E1E1E), Color(0xFFFF3D3D)),
    AppPalette("Zümrüt", Color(0xFF030303), Color(0xFF1F1F1F), Color(0xFF1ED760)),
    AppPalette("Gece Mavisi", Color(0xFF070B14), Color(0xFF151E33), Color(0xFF4D8DFF)),
    AppPalette("Gül", Color(0xFF0E070B), Color(0xFF261520), Color(0xFFFF4D8D)),
    AppPalette("Mor", Color(0xFF0B0712), Color(0xFF1E1535), Color(0xFFB388FF))
)

/** Seçilen tema kalıcı olarak saklanır. */
object ThemeStore {
    val index = MutableStateFlow(0)
    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        index.value = (prefs?.getInt("theme", 0) ?: 0).coerceIn(Palettes.indices)
    }

    fun set(i: Int) {
        index.value = i
        prefs?.edit()?.putInt("theme", i)?.apply()
    }
}

val LocalPalette = staticCompositionLocalOf { Palettes[0] }

val Bg: Color
    @Composable get() = LocalPalette.current.bg
val Card: Color
    @Composable get() = LocalPalette.current.card
val Accent: Color
    @Composable get() = LocalPalette.current.accent

private val tints = listOf(0xFFE91E63, 0xFF7C4DFF, 0xFFFF9800, 0xFF00BCD4, 0xFFFF5252, 0xFF26A69A)

/** Bir başlıktan sabit bir renk üretir; kartlar her zaman aynı tonda görünür. */
fun tintFor(text: String): Color =
    Color(tints[(text.hashCode() and 0x7fffffff) % tints.size])
