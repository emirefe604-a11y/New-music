@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import org.json.JSONArray
import java.io.File
import java.io.IOException

/**
 * Şarkıları cihaza indirir ve çevrimdışı çalmak için saklar.
 * Dosyalar uygulamanın özel klasörüne (files/offline) kaydedilir.
 */
object Downloads {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient()
    private val jobs = HashMap<String, Job>()
    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    private var ready = false

    /** İndirilmiş şarkılar (en yeni başta). */
    val songs = MutableStateFlow<List<Song>>(emptyList())

    /** Şarkı url'si -> ilerleme (0..100). -1 = hata. Listede yoksa indirilmiyor demektir. */
    val progress = MutableStateFlow<Map<String, Int>>(emptyMap())

    fun init(ctx: Context) {
        if (ready) return
        val app = ctx.applicationContext
        dir = File(app.filesDir, "offline").apply { mkdirs() }
        prefs = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        songs.value = load().filter { fileFor(it).exists() }
        ready = true
    }

    private fun key(s: Song): String =
        Regex("v=([A-Za-z0-9_-]{11})").find(s.url)?.groupValues?.get(1)
            ?: Integer.toHexString(s.url.hashCode())

    private fun fileFor(s: Song) = File(dir, key(s) + ".audio")

    /** Şarkı indirilmişse yerel dosyasını verir, yoksa null. */
    fun localFile(s: Song): File? {
        if (!ready) return null
        val f = fileFor(s)
        return if (f.exists() && f.length() > 0) f else null
    }

    fun download(s: Song) {
        if (!ready || localFile(s) != null || jobs.containsKey(s.url)) return
        progress.update { it + (s.url to 0) }
        jobs[s.url] = scope.launch {
            val part = File(dir, key(s) + ".part")
            try {
                val urls = MusicRepository.audioUrls(s.url)
                if (urls.isEmpty()) throw IOException("Ses akışı bulunamadı")
                var ok = false
                var last: Exception? = null
                for (u in urls.take(3)) {
                    try { fetch(u, part, s); ok = true; break }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) { last = e; part.delete() }
                }
                if (!ok) throw (last ?: IOException("İndirilemedi"))
                if (!part.renameTo(fileFor(s))) throw IOException("Dosya kaydedilemedi")
                songs.update { listOf(s) + it.filter { x -> x.url != s.url } }
                save()
                progress.update { it - s.url }
            } catch (e: CancellationException) {
                part.delete()
                progress.update { it - s.url }
                throw e
            } catch (e: Exception) {
                part.delete()
                progress.update { it + (s.url to -1) }
            } finally {
                jobs.remove(s.url)
            }
        }
    }

    /** Devam eden indirmeyi iptal eder. */
    fun cancel(s: Song) { jobs[s.url]?.cancel() }

    /** İndirilmiş dosyayı siler. */
    fun remove(s: Song) {
        if (!ready) return
        jobs[s.url]?.cancel()
        fileFor(s).delete()
        songs.update { it.filter { x -> x.url != s.url } }
        progress.update { it - s.url }
        save()
    }

    private fun fetch(url: String, out: File, s: Song) {
        val src = ChunkedDataSource(client)
        try {
            val len = src.open(DataSpec(Uri.parse(url)))
            val total = if (len == C.LENGTH_UNSET.toLong()) -1L else len
            val buf = ByteArray(64 * 1024)
            var done = 0L
            var lastPct = -1
            out.outputStream().buffered().use { os ->
                while (true) {
                    val n = src.read(buf, 0, buf.size)
                    if (n == C.RESULT_END_OF_INPUT) break
                    os.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 100 / total).toInt().coerceAtMost(99)
                        if (p != lastPct) { lastPct = p; progress.update { it + (s.url to p) } }
                    }
                }
            }
            if (done == 0L) throw IOException("Boş dosya indirildi")
        } finally {
            src.close()
        }
    }

    private fun save() {
        prefs.edit().putString("downloads", songs.value.toJsonArray().toString()).apply()
    }

    private fun load(): List<Song> = try {
        JSONArray(prefs.getString("downloads", "[]")).toSongs()
    } catch (e: Exception) { emptyList() }
}
