@file:OptIn(UnstableApi::class)

package com.example.newmusic

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Arka planda kesintisiz çalma + bildirim/kilit ekranı kontrolleri. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        val client = Http.client
        val baseFactory = DefaultDataSource.Factory(this, DataSource.Factory { ChunkedDataSource(client) })
        // Modern : Çalınan her bayt yerel SSD disk önbelleğine yazılır, tekrar açılışlar 0 ms'de çalar
        val cache = AudioCache.get(this)
        val cachedFactory = androidx.media3.datasource.cache.CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(baseFactory)
            .setFlags(androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cachedFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            // Modern  çalma tamponu: 100 ms veri geldiği anda ses çalmaya başlar
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(
                        4_000,   // minimum tampon (4 sn)
                        25_000,  // maksimum tampon (25 sn)
                        30,      // anında ses başlatma eşiği (30 ms)
                        100      // yeniden tamponlama eşiği (100 ms)
                    )
                    .setBackBuffer(30_000, true)
                    .setPrioritizeTimeOverSizeThresholds(true).build()
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        exo = player

        // Şarkı geçişlerinde bildirim metadata'sının gecikmeksizin güncellenmesini sağla
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                super.onMediaItemTransition(mediaItem, reason)
            }
        })

        val openIntent = android.app.PendingIntent.getActivity(
            this, 0,
            android.content.Intent(this, MainActivity::class.java).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, QueuePlayer(player))
            .setSessionActivity(openIntent)
            .build()
        setMediaNotificationProvider(DefaultMediaNotificationProvider.Builder(this).build())
    }

    override fun onGetSession(info: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        session?.release(); session = null
        exo?.release(); exo = null
        super.onDestroy()
        QuickLaunch.hide(this)
    }
}

/** Bildirimdeki ileri/geri tuşları uygulamanın kuyruğunu yönetsin. */
private class QueuePlayer(p: Player) : ForwardingPlayer(p) {
    private val extra = intArrayOf(
        Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_PREVIOUS,
        Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM, Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
        Player.COMMAND_SET_VOLUME, Player.COMMAND_GET_VOLUME
    )
    override fun getAvailableCommands(): Player.Commands =
        super.getAvailableCommands().buildUpon().addAll(*extra).build()
    override fun isCommandAvailable(command: Int) = command in extra || super.isCommandAvailable(command)
    override fun hasNextMediaItem() = true
    override fun hasPreviousMediaItem() = true
    override fun seekToNext() { PlayerManager.next() }
    override fun seekToNextMediaItem() { PlayerManager.next() }
    override fun seekToPrevious() { PlayerManager.prev() }
    override fun seekToPreviousMediaItem() { PlayerManager.prev() }
}
