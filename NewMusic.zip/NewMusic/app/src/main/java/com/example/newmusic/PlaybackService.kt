@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Arka planda kesintisiz calan muzik servisi.
 *
 * Android Auto (Car auto) destegi iceren MediaLibraryService altyapisi:
 * - Arac ekraninda Sounddeep logolu tam ozel muzik arayuzu sunar (baska uygulamaya yonlendirmez).
 * - Arac ekranindan sarki, begenilenler, calma listeleri, trendler ve indirilenleri secmeyi saglar.
 * - Arac direksiyonundan / ekranindan 10 saniye ileri/geri sarma, parca degistirme ve seekbar destegi sunar.
 */
class PlaybackService : MediaLibraryService() {
    private var librarySession: MediaLibrarySession? = null
    private var exo: ExoPlayer? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        // Calinan her bayt yerel disk onbellegine yazilir; onden indirme de ayni fabrikayi kullanir
        val cachedFactory = AudioCache.factory(this)

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cachedFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(
                        4_000,   // minimum tampon (4 sn)
                        35_000,  // maksimum tampon (35 sn)
                        80,      // baslatma esigi (80 ms - aninda ses baslatir)
                        400      // yeniden tamponlama sonrasi devam esigi (400 ms)
                    )
                    .setBackBuffer(30_000, true)
                    .setPrioritizeTimeOverSizeThresholds(true).build()
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setSeekForwardIncrementMs(10_000L) // Arac ici 10 sn ileri sarma
            .setSeekBackIncrementMs(10_000L)    // Arac ici 10 sn geri sarma
            .build()
        exo = player

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        librarySession = MediaLibrarySession.Builder(this, QueuePlayer(player), CarLibraryCallback())
            .setSessionActivity(openIntent)
            .build()

        setMediaNotificationProvider(DefaultMediaNotificationProvider.Builder(this).build())
    }

    override fun onGetSession(info: MediaSession.ControllerInfo): MediaLibrarySession? = librarySession

    override fun onDestroy() {
        serviceScope.cancel()
        librarySession?.release()
        librarySession = null
        exo?.release()
        exo = null
        super.onDestroy()
        QuickLaunch.hide(this)
    }

    /** Bildirim, kilit ekrani ve Android Auto ileri/geri sarma ile parca gecislerini yoneten oynatici */
    private class QueuePlayer(p: Player) : ForwardingPlayer(p) {
        private val extra = intArrayOf(
            Player.COMMAND_PLAY_PAUSE,
            Player.COMMAND_PREPARE,
            Player.COMMAND_STOP,
            Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM,
            Player.COMMAND_SEEK_BACK,
            Player.COMMAND_SEEK_FORWARD,
            Player.COMMAND_SEEK_TO_DEFAULT_POSITION,
            Player.COMMAND_SEEK_TO_NEXT,
            Player.COMMAND_SEEK_TO_PREVIOUS,
            Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
            Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
            Player.COMMAND_SET_REPEAT_MODE,
            Player.COMMAND_SET_SHUFFLE_MODE,
            Player.COMMAND_GET_CURRENT_MEDIA_ITEM,
            Player.COMMAND_GET_TIMELINE,
            Player.COMMAND_SET_VOLUME,
            Player.COMMAND_GET_VOLUME
        )

        override fun getAvailableCommands(): Player.Commands =
            super.getAvailableCommands().buildUpon().addAll(*extra).build()

        override fun isCommandAvailable(command: Int) = command in extra || super.isCommandAvailable(command)
        override fun hasNextMediaItem() = true
        override fun hasPreviousMediaItem() = true

        override fun seekToNext() { PlayerManager.next() }
        override fun seekToNextMediaItem() { PlayerManager.next() }
        override fun seekToPrevious() { PlayerManager.prev() }
        override fun seekToPreviousMediaItem() { PlayerManager.prev() }

        // Arac ekranindan veya direksiyondan 10 sn ileri sarma
        override fun seekForward() {
            val cur = currentPosition
            val dur = duration
            val target = (cur + 10_000L).coerceAtMost(if (dur > 0L) dur else cur + 10_000L)
            seekTo(target)
        }

        // Arac ekranindan veya direksiyondan 10 sn geri sarma
        override fun seekBack() {
            val cur = currentPosition
            val target = (cur - 10_000L).coerceAtLeast(0L)
            seekTo(target)
        }
    }

    /** Android Auto (Car auto) icin medya kutuphanesi gezinti ve secim kancasi */
    private inner class CarLibraryCallback : MediaLibrarySession.Callback {

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val root = MediaItem.Builder()
                .setMediaId(ROOT_ID)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("Sounddeep")
                        .setDisplayTitle("Sounddeep Müzik")
                        .setIsBrowsable(true)
                        .setIsPlayable(false)
                        .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                        .build()
                )
                .build()
            return Futures.immediateFuture(LibraryResult.ofItem(root, params))
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            return when (parentId) {
                ROOT_ID -> {
                    // Arac ekranindaki ana kategori sekmeleri
                    val categories = listOf(
                        createCategory(ID_QUEUE, "Şu An Çalan & Sıradakiler", "Kuyruktaki şarkılar", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED),
                        createCategory(ID_LIKED, "Beğenilen Şarkılar", "Favori parçalarınız", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED),
                        createCategory(ID_PLAYLISTS, "Çalma Listelerim", "Oluşturduğunuz müzik listeleri", MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS),
                        createCategory(ID_TOP, "Trendler & Top 50", "En çok dinlenen hit parçalar", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED),
                        createCategory(ID_DAILY, "Günün Karışımı", "Size özel seçilen parçalar", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED),
                        createCategory(ID_DOWNLOADS, "İndirilenler", "Çevrimdışı müzikler", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                    )
                    Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(categories), params))
                }

                ID_QUEUE -> {
                    val q = PlayerManager.queue.value
                    val items = q.map { it.toCarMediaItem() }
                    Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                }

                ID_LIKED -> {
                    val liked = Library.liked.value
                    val items = liked.map { it.toCarMediaItem() }
                    Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                }

                ID_PLAYLISTS -> {
                    val playlists = Library.playlists.value
                    val items = playlists.map { pl ->
                        MediaItem.Builder()
                            .setMediaId("$PREFIX_PLAYLIST${pl.id}")
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(pl.title)
                                    .setDisplayTitle(pl.title)
                                    .setSubtitle("${pl.songs.size} şarkı")
                                    .setArtist(pl.author.ifBlank { "Özel Liste" })
                                    .setIsBrowsable(true)
                                    .setIsPlayable(false)
                                    .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS)
                                    .build()
                            )
                            .build()
                    }
                    Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                }

                ID_TOP -> {
                    val future = SettableFuture.create<LibraryResult<ImmutableList<MediaItem>>>()
                    serviceScope.launch(Dispatchers.IO) {
                        try {
                            val cached = MusicRepository.cachedSearch("Türkiye Top 50")
                            val songs = if (!cached.isNullOrEmpty()) cached
                            else MusicRepository.search("Türkiye Top 50", persist = false).take(30)
                            val items = songs.map { it.toCarMediaItem() }
                            future.set(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                        } catch (e: Exception) {
                            future.set(LibraryResult.ofItemList(ImmutableList.of(), params))
                        }
                    }
                    future
                }

                ID_DAILY -> {
                    val future = SettableFuture.create<LibraryResult<ImmutableList<MediaItem>>>()
                    serviceScope.launch(Dispatchers.IO) {
                        try {
                            val cached = MusicRepository.cachedSearch("Türkçe Pop 2026")
                            val songs = if (!cached.isNullOrEmpty()) cached
                            else MusicRepository.search("Türkçe Pop", persist = false).take(25)
                            val clean = Personalize.rank(songs).take(25)
                            val items = clean.map { it.toCarMediaItem() }
                            future.set(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                        } catch (e: Exception) {
                            future.set(LibraryResult.ofItemList(ImmutableList.of(), params))
                        }
                    }
                    future
                }

                ID_DOWNLOADS -> {
                    val dl = Downloads.list.value
                    val items = dl.map { it.toCarMediaItem() }
                    Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                }

                else -> {
                    if (parentId.startsWith(PREFIX_PLAYLIST)) {
                        val plId = parentId.removePrefix(PREFIX_PLAYLIST)
                        val pl = Library.playlists.value.firstOrNull { it.id == plId }
                        val items = (pl?.songs ?: emptyList()).map { it.toCarMediaItem() }
                        Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
                    } else {
                        Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.of(), params))
                    }
                }
            }
        }

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val song = findSong(mediaId)
            return if (song != null) {
                Futures.immediateFuture(LibraryResult.ofItem(song.toCarMediaItem(), null))
            } else {
                Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE))
            }
        }

        override fun onSearch(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<Void>> {
            serviceScope.launch(Dispatchers.IO) {
                try {
                    val results = MusicRepository.search(query, persist = false).take(25)
                    lastSearchResults = results
                    session.notifySearchResultChanged(browser, query, results.size, params)
                } catch (_: Exception) {}
            }
            return Futures.immediateFuture(LibraryResult.ofVoid())
        }

        override fun onGetSearchResult(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            val songs = lastSearchResults ?: emptyList()
            val items = songs.map { it.toCarMediaItem() }
            return Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(items), params))
        }

        // Surucu aracta bir sarkiya bastiginda aninda calar
        override fun onAddMediaItems(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>
        ): ListenableFuture<MutableList<MediaItem>> {
            val first = mediaItems.firstOrNull()
            if (first != null) {
                val song = findSong(first.mediaId) ?: Song(
                    first.mediaMetadata.title?.toString() ?: "Bilinmeyen Parça",
                    first.mediaMetadata.artist?.toString() ?: "",
                    first.mediaId,
                    first.mediaMetadata.artworkUri?.toString()
                )
                // Sarkiyi calmaya basla
                serviceScope.launch(Dispatchers.Main) {
                    PlayerManager.playSong(song)
                }
            }
            return Futures.immediateFuture(mediaItems)
        }

        override fun onSetMediaUri(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            uri: Uri,
            extras: Bundle?
        ): Int {
            val url = uri.toString()
            val song = findSong(url) ?: Song("Parça", "", url, null)
            serviceScope.launch(Dispatchers.Main) {
                PlayerManager.playSong(song)
            }
            return SessionResult.RESULT_SUCCESS
        }
    }

    private fun Song.toCarMediaItem(): MediaItem {
        val artworkUri = hiRes(thumb, 500)?.let { Uri.parse(it) }
            ?: Uri.parse("android.resource://$packageName/drawable/ic_stat_music")
        return MediaItem.Builder()
            .setMediaId(url)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setDisplayTitle(title)
                    .setArtist(artist.ifBlank { "Sounddeep" })
                    .setAlbumArtist(artist.ifBlank { "Sounddeep" })
                    .setArtworkUri(artworkUri)
                    .setIsBrowsable(false)
                    .setIsPlayable(true)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                    .build()
            )
            .build()
    }

    private fun findSong(url: String): Song? {
        PlayerManager.queue.value.firstOrNull { it.url == url }?.let { return it }
        Library.liked.value.firstOrNull { it.url == url }?.let { return it }
        Downloads.list.value.firstOrNull { it.url == url }?.let { return it }
        lastSearchResults?.firstOrNull { it.url == url }?.let { return it }
        for (pl in Library.playlists.value) {
            pl.songs.firstOrNull { it.url == url }?.let { return it }
        }
        return null
    }

    private fun createCategory(
        id: String,
        title: String,
        subtitle: String,
        mediaType: Int
    ): MediaItem {
        return MediaItem.Builder()
            .setMediaId(id)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setDisplayTitle(title)
                    .setSubtitle(subtitle)
                    .setIsBrowsable(true)
                    .setIsPlayable(false)
                    .setMediaType(mediaType)
                    .build()
            )
            .build()
    }

    companion object {
        private const val ROOT_ID = "[root]"
        private const val ID_QUEUE = "[section_queue]"
        private const val ID_LIKED = "[section_liked]"
        private const val ID_PLAYLISTS = "[section_playlists]"
        private const val ID_TOP = "[section_top]"
        private const val ID_DAILY = "[section_daily]"
        private const val ID_DOWNLOADS = "[section_downloads]"
        private const val PREFIX_PLAYLIST = "[pl_"
        @Volatile private var lastSearchResults: List<Song>? = null
    }
}
