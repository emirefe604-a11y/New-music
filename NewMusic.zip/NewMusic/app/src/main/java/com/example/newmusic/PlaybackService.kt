@file:OptIn(UnstableApi::class)

package com.example.newmusic

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Arka planda kesintisiz çalma + bildirim/kilit ekranı kontrolleri. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var exo: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        val client = Http.client
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, DataSource.Factory { ChunkedDataSource(client) })))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA).build(), true
            )
            // Optimize edilmiş tampon ayarları: 1 sn tamponla anında başlar,
            // 25-90 sn aralığında önden doldurarak ses cızırtı ve bozulmalarını tamamen engeller.
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(25_000, 90_000, 1_000, 2_500)
                    .setBackBuffer(30_000, true)
                    .setPrioritizeTimeOverSizeThresholds(true).build()
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        exo = player

        // Şarkı geçişlerinde bildirim metadata'sının gecikmeksizin güncellenmesini sağla
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                super.onMediaItemTransition(mediaItem, reason)
            }
        })

        session = MediaSession.Builder(this, QueuePlayer(player))
            .build()
    }

    override fun onGetSession(info: MediaSession.ControllerInfo) = session

    override fun onDestroy() {
        session?.release(); session = null
        exo?.release(); exo = null
        super.onDestroy()
        QuickLaunch.hide(this)
    }
}

/** Bildirimdeki ileri/geri tuşları uygulamanın kuyruğunu yönetsin. */
private class QueuePlayer(p: Player) : ForwardingPlayer(p) {
    private val extra = intArrayOf(
        Player.COMMAND_SEEK_TO_NEXT, Player.COMMAND_SEEK_TO_PREVIOUS,
        Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM, Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
    )
    override fun getAvailableCommands(): Player.Commands =
        super.getAvailableCommands().buildUpon().addAll(*extra).build()
    override fun isCommandAvailable(command: Int) = command in extra || super.isCommandAvailable(command)
    override fun hasNextMediaItem() = true
    override fun hasPreviousMediaItem() = true
    override fun seekToNext() { PlayerManager.next() }
    override fun seekToNextMediaItem() { PlayerManager.next() }
    override fun seekToPrevious() { PlayerManager.prev() }
    override fun seekToPreviousMediaItem() { PlayerManager.prev() }
}
