package com.example.newmusic

import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject

/**
 * Blend: iki kişinin müzik zevkini tek listede birleştirir.
 * Herkesin kısa bir "Blend kodu" vardır (en çok dinlediği sanatçılar). Arkadaşın kodunu yapıştırınca
 * iki zevkten karışık bir çalma listesi oluşur. Sunucu gerekmez.
 */
object Blend {
    class Friend(val name: String, val artists: List<String>)

    private const val FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

    /** Kullanıcının kodu. Yeterli dinleme geçmişi yoksa null. */
    fun myCode(): String? {
        val artists = TasteProfile.topArtists(12)
        if (artists.size < 3) return null
        val json = JSONObject().put("v", 1)
            .put("n", AuthStore.name.value.ifBlank { "Ben" })
            .put("a", JSONArray(artists))
        return "SD-" + Base64.encodeToString(json.toString().toByteArray(), FLAGS)
    }

    fun parse(code: String): Friend? = try {
        val raw = code.trim().removePrefix("SD-")
        val json = JSONObject(String(Base64.decode(raw, FLAGS)))
        val arr = json.getJSONArray("a")
        val list = (0 until arr.length()).map { arr.getString(it) }.filter { it.isNotBlank() }.take(12)
        if (list.isEmpty()) null else Friend(json.optString("n", "Arkadaş").ifBlank { "Arkadaş" }.take(30), list)
    } catch (e: Exception) { null }

    fun common(mine: List<String>, theirs: List<String>): List<String> =
        mine.filter { m -> theirs.any { it.equals(m, ignoreCase = true) } }

    /** İki zevkten sırayla şarkı seçerek karışık liste üretir. */
    suspend fun make(mine: List<String>, theirs: List<String>): List<Song> = coroutineScope {
        val gate = Semaphore(3)
        suspend fun songsOf(artist: String): List<Song> = gate.withPermit {
            try { MusicRepository.search("$artist şarkılar").take(5) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { emptyList() }
        }
        val a = mine.take(6).map { async { songsOf(it) } }
        val b = theirs.take(6).map { async { songsOf(it) } }
        val mineSongs = rounds(a.awaitAll())
        val theirSongs = rounds(b.awaitAll())
        val out = ArrayList<Song>()
        for (i in 0 until maxOf(mineSongs.size, theirSongs.size)) {
            mineSongs.getOrNull(i)?.let { out += it }
            theirSongs.getOrNull(i)?.let { out += it }
        }
        out.distinctBy { it.url }.take(50)
    }

    /** Her sanatçıdan sırayla birer şarkı al. */
    private fun rounds(lists: List<List<Song>>): List<Song> {
        val out = ArrayList<Song>()
        val max = lists.maxOfOrNull { it.size } ?: 0
        for (i in 0 until max) lists.forEach { l -> l.getOrNull(i)?.let { out += it } }
        return out
    }
}
