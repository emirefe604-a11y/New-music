package com.example.newmusic

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** Blend sonucu: başarılıysa [playlist] dolu, değilse [error] dolu. */
class BlendOutcome(val friend: String, val playlist: UserPlaylist? = null, val common: List<String> = emptyList(), val error: String? = null)

/**
 * Blend: iki kişinin müzik zevkini tek listede birleştirir.
 * Uygulama, en çok dinlenen sanatçılarını hesabına (sunucuya) bildirir; arkadaşını seçince onun sanatçıları
 * çekilir ve iki zevkten karışık bir çalma listesi oluşur. Kod yapıştırmaya gerek yok, tek dokunuş yeter.
 */
object Blend {
    /** Arkadaşınla Blend yapar ve sonucu "Listelerim"e kaydeder. */
    suspend fun create(friend: String): BlendOutcome {
        val mine = TasteProfile.topArtists(12)
        if (mine.size < 3) return BlendOutcome(friend, error = "Önce birkaç şarkı dinle veya beğen; sonra tekrar dene.")
        Social.pushTaste()   // benim zevkim de güncel olsun (arkadaşım da Blend yapabilsin)
        val (theirs, err) = Social.friendTaste(friend)
        if (theirs == null) return BlendOutcome(friend, error = err ?: "Blend yapılamadı.")
        if (theirs.size < 2) return BlendOutcome(friend, error = "@$friend henüz yeterince müzik dinlemedi. Biraz sonra tekrar dene.")
        val songs = make(mine, theirs)
        if (songs.isEmpty()) return BlendOutcome(friend, error = "Şarkı bulunamadı. İnternetini kontrol edip tekrar dene.")
        val me = Social.username.value ?: "Sen"
        val pl = Playlists.create("Blend: $me + $friend", songs)
        return BlendOutcome(friend, pl, common(mine, theirs))
    }

    fun common(mine: List<String>, theirs: List<String>): List<String> =
        mine.filter { m -> theirs.any { it.equals(m, ignoreCase = true) } }

    /** İki zevkten sırayla şarkı seçerek karışık liste üretir. */
    suspend fun make(mine: List<String>, theirs: List<String>): List<Song> = coroutineScope {
        val gate = Semaphore(3)
        suspend fun songsOf(artist: String): List<Song> = gate.withPermit {
            try { MusicRepository.search("$artist şarkılar", warm = false).take(5) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { emptyList() }
        }
        val a = mine.take(6).map { async { songsOf(it) } }
        val b = theirs.take(6).map { async { songsOf(it) } }
        val mineSongs = rounds(a.awaitAll())
        val theirSongs = rounds(b.awaitAll())
        val out = ArrayList<Song>()
        for (i in 0 until maxOf(mineSongs.size, theirSongs.size)) {
            mineSongs.getOrNull(i)?.let { out += it }
            theirSongs.getOrNull(i)?.let { out += it }
        }
        out.distinctBy { it.url }.take(50)
    }

    /** Her sanatçıdan sırayla birer şarkı al. */
    private fun rounds(lists: List<List<Song>>): List<Song> {
        val out = ArrayList<Song>()
        val max = lists.maxOfOrNull { it.size } ?: 0
        for (i in 0 until max) lists.forEach { l -> l.getOrNull(i)?.let { out += it } }
        return out
    }
}
