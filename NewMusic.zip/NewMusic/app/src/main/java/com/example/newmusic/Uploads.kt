package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID

/** Kullanıcının cihazından yüklediği müzikler. Dosyalar uygulamanın özel klasörüne kopyalanır. */
object Uploads {
    val songs = MutableStateFlow<List<Song>>(emptyList())
    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        val app = ctx.applicationContext
        dir = File(app.filesDir, "uploads").apply { mkdirs() }
        prefs = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        ready = true
        songs.value = load().filter { file(it) != null }
    }

    fun isLocal(s: Song) = s.url.startsWith("local://")

    /** Yüklenen şarkının cihazdaki dosyası. */
    fun file(s: Song): File? {
        if (!ready || !isLocal(s)) return null
        return File(dir, s.url.removePrefix("local://") + ".audio").takeIf { it.exists() }
    }

    /** Seçilen ses dosyalarını içeri alır; kaç şarkı eklendiğini döner. */
    suspend fun importFiles(ctx: Context, uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        var count = 0
        for (uri in uris) {
            try {
                val s = importOne(ctx, uri)
                songs.update { listOf(s) + it }
                count++
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { }
        }
        save()
        count
    }

    private fun importOne(ctx: Context, uri: Uri): Song {
        val id = UUID.randomUUID().toString().take(12)
        val out = File(dir, "$id.audio")
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Dosya açılamadı")
        input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        var title: String? = null
        var artist: String? = null
        var thumb: String? = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(out.absolutePath)
            title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            val pic = r.embeddedPicture
            if (pic != null) {
                val img = File(dir, "$id.jpg")
                img.writeBytes(pic)
                thumb = Uri.fromFile(img).toString()
            }
        } catch (e: Exception) {
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
        val name = if (title.isNullOrBlank()) displayName(ctx, uri) else title
        val by = if (artist.isNullOrBlank()) "Yüklenen müzik" else artist
        return Song(name, by, "local://$id", thumb)
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        var name: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (e: Exception) { }
        return (name ?: "Adsız şarkı").substringBeforeLast('.')
    }

    fun remove(s: Song) {
        if (!ready || !isLocal(s)) return
        val id = s.url.removePrefix("local://")
        File(dir, "$id.audio").delete()
        File(dir, "$id.jpg").delete()
        songs.update { list -> list.filter { it.url != s.url } }
        save()
    }

    private fun save() {
        val arr = JSONArray()
        songs.value.forEach {
            arr.put(JSONObject().put("t", it.title).put("a", it.artist).put("u", it.url).put("h", it.thumb ?: ""))
        }
        prefs.edit().putString("uploads", arr.toString()).apply()
    }

    private fun load(): List<Song> = try {
        val arr = JSONArray(prefs.getString("uploads", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Song(o.optString("t"), o.optString("a"), o.optString("u"), o.optString("h").ifBlank { null })
        }
    } catch (e: Exception) { emptyList() }
}
