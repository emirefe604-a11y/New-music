package com.example.newmusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.util.Locale

/**
 * Şarkı açıldığında sıradaki müzikleri çalan sanatçının parçalarından ve
 * o şarkının müzik türüne/tarzına en yakın sanatçılardan (ör. Lvbel C5 -> Ati242, Blok3, Wegh, Motive, Uzi)
 * akıllıca seçer. Alakasız pop/tür kaymalarını engeller.
 */
object GenreRecommender {

    private val clusters = listOf(
        // Türkçe Trap / Drill / Yeni Nesil Hip-Hop (Lvbel C5, Blok3, Ati242, Wegh, Motive, UZI, Cakal, Batuflex...)
        listOf("Lvbel C5", "Blok3", "Ati242", "Wegh", "Motive", "UZI", "Cakal", "Batuflex", "Reckol", "Critical", "Organize", "Jeff Redd", "Era7capone", "Poizi", "AKDO", "Alizade", "Heijan", "Muti", "Cash Flow", "Mero", "Murda", "Khontkar", "Baneva", "Güneş"),

        // Türkçe Sözlü Rap / Old School
        listOf("Ceza", "Sagopa Kajmer", "Şanışer", "Defkhan", "Allame", "Hidra", "No.1", "Şehinşah", "Contra", "Anıl Piyancı", "Joker", "Norm Ender", "Server Uraz", "Saian", "Kayra", "Rota"),

        // Türkçe Alternatif / Bağımsız / Indie Rock
        listOf("Madrigal", "Yüzyüzeyken Konuşuruz", "Dolu Kadehi Ters Tut", "Adamlar", "Duman", "Mor ve Ötesi", "Yaşlı Amca", "Son Feci Bisiklet", "Canozan", "Sedef Sebüktekin", "Nova Norda", "Perdenin Ardındakiler", "Dedublüman", "Kaan Boşnak", "Büyük Ev Ablukada", "Mavi Gri", "Pera", "Gripin", "Manga", "Model", "Emre Aydın", "Kolpa", "Zakkum"),

        // Türkçe Pop / Dans
        listOf("Tarkan", "Edis", "Simge", "Hande Yener", "Gülşen", "Hadise", "Zeynep Bastık", "İrem Derici", "Murat Boz", "Kenan Doğulu", "Mustafa Sandal", "Merve Özbey", "Buray", "Derya Uluğ", "Oğuzhan Koç", "Berkay", "Ziynet Sali", "Mustafa Ceceli", "Bengü", "Demet Akalın"),

        // Türkçe Arabesk & Fantezi
        listOf("Müslüm Gürses", "Azer Bülbül", "Ferdi Tayfur", "İbrahim Tatlıses", "Bergen", "Cengiz Kurtoğlu", "Ebru Gündeş", "Sibel Can", "Hakan Altun", "Yıldız Tilbe", "Serkan Kaya", "Mahsun Kırmızıgül", "Alişan", "Emrah", "Orhan Gencebay"),

        // Türkçe Slow / Duygusal Pop
        listOf("Sezen Aksu", "Sıla", "Yalın", "Ferhat Göçer", "Sertab Erener", "Levent Yüksel", "Ayten Alpman", "Cem Adrian", "Manuş Baba", "Candan Erçetin"),

        // Anadolu Rock / Özgün
        listOf("Barış Manço", "Cem Karaca", "Erkin Koray", "Fikret Kızılok", "Selda Bağcan", "Haluk Levent", "Kıraç", "Ahmet Kaya", "Kazım Koyuncu", "Volkan Konak"),

        // Global Hip-Hop / Trap
        listOf("Travis Scott", "Drake", "21 Savage", "Future", "Metro Boomin", "Kendrick Lamar", "Kanye West", "Eminem", "Lil Baby", "Gunna", "Playboi Carti", "Central Cee", "Post Malone", "Jack Harlow", "Roddy Ricch", "A\$AP Rocky", "J. Cole"),

        // Global Pop
        listOf("The Weeknd", "Dua Lipa", "Taylor Swift", "Billie Eilish", "Bruno Mars", "Ariana Grande", "Justin Bieber", "Ed Sheeran", "Olivia Rodrigo", "Harry Styles", "Rihanna", "Katy Perry", "Sabrina Carpenter", "Chappell Roan"),

        // Global Rock / Metal
        listOf("Arctic Monkeys", "The Neighbourhood", "Linkin Park", "Metallica", "Nirvana", "Queen", "Guns N' Roses", "Red Hot Chili Peppers", "Coldplay", "Radiohead", "Imagine Dragons", "Green Day", "The Killers")
    )

    private fun normalize(s: String): String =
        s.lowercase(Locale.ROOT)
            .replace('ı', 'i').replace('İ', 'i')
            .replace('ç', 'c').replace('ş', 's')
            .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o')
            .replace(" ", "").replace("-", "").replace(".", "")

    /** Sanatçının adını şarkıdan temiz olarak ayıklar */
    fun extractArtist(s: Song): String {
        val cleanA = s.artist.replace(" - Topic", "").replace(" Official", "").replace(" VEVO", "").trim()
        if (cleanA.isNotBlank() && !cleanA.contains("YouTube", ignoreCase = true) && !cleanA.contains("Records", ignoreCase = true) && !cleanA.contains("Müzik", ignoreCase = true)) {
            return cleanA
        }
        if (s.title.contains(" - ")) {
            val cand = s.title.split(" - ")[0].trim()
            if (cand.length in 2..30) return cand
        }
        return cleanA.ifBlank { s.title.split(" - ").firstOrNull() ?: s.title }
    }

    /** Sanatçıya müzikal tarz ve tür olarak en yakın diğer sanatçıları döner */
    fun getSimilarArtists(artistName: String): List<String> {
        val norm = normalize(artistName)
        if (norm.length < 2) return emptyList()

        for (cluster in clusters) {
            val match = cluster.any { member ->
                val mNorm = normalize(member)
                mNorm == norm || mNorm.contains(norm) || norm.contains(mNorm)
            }
            if (match) {
                return cluster.filterNot { normalize(it) == norm }.shuffled()
            }
        }
        return emptyList()
    }

    /**
     * Çalan şarkıya göre bağlantılı (aynı sanatçı + aynı türdeki kardeş sanatçılar + YouTube related)
     * kaliteli ve türü asla bozmayan bir devam kuyruğu üretir.
     */
    suspend fun getConnectedQueue(currentSong: Song, existingUrls: Set<String> = emptySet(), limit: Int = 20): List<Song> = coroutineScope {
        val artist = extractArtist(currentSong)
        val similarArtists = getSimilarArtists(artist).take(4)

        // 1. YouTube Related parçaları (bu şarkıyla doğrudan ilişkili dinlenenler)
        val relatedDeferred = async(Dispatchers.IO) {
            try {
                if (Uploads.isLocal(currentSong) || currentSong.url.startsWith("local://")) emptyList()
                else MusicRepository.related(currentSong.url).noAi().noLong().noNonMusic()
            } catch (_: Exception) { emptyList() }
        }

        // 2. Çalan sanatçının diğer hit parçaları
        val artistSongsDeferred = async(Dispatchers.IO) {
            try {
                if (artist.isNotBlank()) {
                    MusicRepository.search(artist, persist = false).noAi().noLong().noNonMusic().take(6)
                } else emptyList()
            } catch (_: Exception) { emptyList() }
        }

        // 3. Aynı müzik türündeki benzer sanatçıların parçaları (ör. Ati242, Blok3, Wegh...)
        val similarSongsDeferred = async(Dispatchers.IO) {
            val results = mutableListOf<Song>()
            for (sim in similarArtists) {
                try {
                    val simHits = MusicRepository.search(sim, persist = false).noAi().noLong().noNonMusic().take(3)
                    results.addAll(simHits)
                } catch (_: Exception) {}
            }
            results
        }

        val related = relatedDeferred.await()
        val artistSongs = artistSongsDeferred.await()
        val similarSongs = similarSongsDeferred.await()

        // Birleştir: Önce sanatçının diğer şarkıları ve kardeş sanatçılar, sonra related
        val combined = ArrayList<Song>()
        val seenUrls = existingUrls.toMutableSet()
        seenUrls.add(currentSong.url)

        fun addIfValid(s: Song) {
            if (seenUrls.contains(s.url)) return
            if (AiFilter.isAi(s)) return
            if (LongMusicFilter.isLong(s)) return
            if (combined.any { TitleDeduplicator.isSimilar(it.title, s.title) }) return
            seenUrls.add(s.url)
            combined.add(s)
        }

        // Şarkı akış sıralaması (Dengeli miksaj: Sanatçı -> Benzer Sanatçı 1 -> Related -> Benzer Sanatçı 2 ...)
        val maxLen = maxOf(artistSongs.size, similarSongs.size, related.size)
        for (i in 0 until maxLen) {
            if (i in artistSongs.indices) addIfValid(artistSongs[i])
            if (i in similarSongs.indices) addIfValid(similarSongs[i])
            if (i in related.indices) addIfValid(related[i])
            if (combined.size >= limit) break
        }

        // Eğer hala yetersizse sanatçının adına göre arama yaparak tamamla (asla genel rastgele şarkı ekleme)
        if (combined.size < 5 && artist.isNotBlank()) {
            try {
                val moreArtist = MusicRepository.search("$artist mix", persist = false).noAi()
                for (s in moreArtist) {
                    addIfValid(s)
                    if (combined.size >= limit) break
                }
            } catch (_: Exception) {}
        }

        combined
    }
}
