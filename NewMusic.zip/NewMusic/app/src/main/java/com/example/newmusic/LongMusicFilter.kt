package com.example.newmusic

import java.util.Locale

/**
 * Uzun dakikalı müzikleri (10 dakikadan uzun parçalar, 1 saatlik/10 saatlik looplar,
 * full albümler, diskografiler, canlı konser kayıtları, DJ setleri) tespit eder ve filtreler.
 */
object LongMusicFilter {
    private val hourRegex = Regex("""(?i)\b\d+\s*(?:saat|saatlik|hour|hours|hr|hrs)\b""")
    private val timeStampRegex = Regex("""\b\d+:\d{2}:\d{2}\b""")
    private val longKeywords = listOf(
        "full albüm", "full album", "tüm albüm", "tum album",
        "tüm şarkıları", "tum sarkilari", "bütün şarkıları", "butun sarkilari",
        "diskografi", "discography", "1 hour loop", "10 hour loop",
        "full konser", "canlı konser", "canli konser", "live concert",
        "megamix", "mega mix", "non stop mix", "nonstop mix",
        "10 hours", "10 hour", "1 hour", "1 saatlik", "2 saatlik",
        "1 saat", "2 saat", "3 saat", "kesintisiz müzik ziyafeti",
        "best of album", "en iyileri albüm"
    )

    private fun normalize(s: String): String =
        s.lowercase(Locale.ROOT)
            .replace('ı', 'i').replace('İ', 'i')
            .replace('ç', 'c').replace('ş', 's')
            .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o')

    fun isLong(title: String): Boolean {
        val t = normalize(title)
        if (hourRegex.containsMatchIn(t)) return true
        if (timeStampRegex.containsMatchIn(t)) return true
        for (kw in longKeywords) {
            if (t.contains(kw)) return true
        }
        return false
    }

    fun isLong(s: Song): Boolean = isLong(s.title)
}

/** Uzun dakikalı müzikleri listeden ayıklar */
fun List<Song>.noLong(): List<Song> = filterNot { LongMusicFilter.isLong(it) }
