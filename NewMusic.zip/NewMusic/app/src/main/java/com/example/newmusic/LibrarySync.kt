package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/**
 * Beğendiklerim ve çalma listelerini HESABA kaydeder.
 * Uygulama silinip yeniden kurulsa bile giriş yapınca hepsi geri gelir.
 *
 * - Her değişiklik 2 sn sonra sunucuya yedeklenir (internet yoksa sonra tekrar denenir).
 * - Uygulama açılınca / hesaba girilince sunucudaki kitaplıkla eşitlenir.
 * - İlk eşitlemede ve iki cihazda aynı anda değişiklik olduğunda iki taraf BİRLEŞTİRİLİR; hiçbir şarkı silinmez.
 * - Farklı bir hesapla giriş yapılırsa önceki hesabın şarkıları karışmaz; yeni hesabın kitaplığı gelir.
 * - Cihazdan yüklenen şarkılar (local://) sunucuya gitmez, bu telefonda kalır.
 */
object LibrarySync {
    private var prefs: SharedPreferences? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var pushJob: Job? = null
    @Volatile private var rev = 0
    @Volatile private var lastSyncAt = 0L

    private const val SYNC_EVERY_MS = 60_000L

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
    }

    private val isDirty: Boolean get() = prefs?.getBoolean("lib_dirty", false) == true
    private fun isLocal(s: Song) = s.url.startsWith("local://")

    /** Beğeni veya liste değişince çağrılır. */
    fun markDirty() {
        val p = prefs ?: return
        rev++
        p.edit().putBoolean("lib_dirty", true).apply()
        if (!Social.joined) return
        pushJob?.cancel()
        pushJob = scope.launch { delay(2_000); pushIfDirty() }
    }

    /** Uygulama öne gelince / hesaba girilince. */
    fun syncSoon(force: Boolean = false) {
        if (!Social.joined) return
        val now = System.currentTimeMillis()
        if (!force && now - lastSyncAt < SYNC_EVERY_MS) return
        lastSyncAt = now
        scope.launch { sync() }
    }

    /** Uygulama arka plana giderken bekleyen değişiklikleri hemen gönderir. */
    fun flush() {
        if (!Social.joined || !isDirty) return
        pushJob?.cancel()
        scope.launch { pushIfDirty() }
    }

    private suspend fun pushIfDirty() {
        mutex.withLock {
            if (!Social.joined || !isDirty) return
            push(PlayerManager.favorites.value, Playlists.lists.value)
        }
    }

    /** Sunucudaki kitaplıkla bu cihazdakini eşitler. */
    private suspend fun sync() {
        try {
            mutex.withLock { syncLocked() }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { }
    }

    private suspend fun syncLocked() {
        val p = prefs ?: return
        val owner = Social.username.value ?: return
        if (!Social.joined) return
        val r = Social.call("/social/library-get", JSONObject()) ?: return
        if (r.code !in 200..299) return

        val exists = r.body.optBoolean("exists")
        val at = r.body.optLong("updatedAt")
        val sFavs = parseSongs(r.body.optJSONArray("favs"))
        val sLists = parseLists(r.body.optJSONArray("playlists"))
        val lFavs = PlayerManager.favorites.value
        val lLists = Playlists.lists.value

        val savedOwner = p.getString("lib_owner", null)
        val syncedAt = p.getLong("lib_synced_at", 0L)
        val dirty = isDirty
        val otherAccount = savedOwner != null && savedOwner != owner
        val localEmpty = lFavs.none { !isLocal(it) } && lLists.all { l -> l.songs.none { !isLocal(it) } }

        when {
            // Başka bir hesaba girildi: önceki hesabın şarkıları karışmasın, yeni hesabın kitaplığı gelsin
            otherAccount -> {
                applyLocal(if (exists) sFavs else emptyList(), if (exists) sLists else emptyList())
                markSynced(owner, if (exists) at else 0L)
            }
            // Sunucuda henüz kitaplık yok: bu cihazdakini yükle
            !exists -> {
                if (localEmpty) markSynced(owner, 0L) else push(lFavs, lLists)
            }
            // Yeniden kurulum / bu cihazdan ilk eşitleme
            savedOwner == null || syncedAt == 0L -> {
                if (localEmpty) { applyLocal(sFavs, sLists); markSynced(owner, at) }
                else { val (f, l) = merge(lFavs, lLists, sFavs, sLists); applyLocal(f, l); push(f, l) }
            }
            // İki taraf da değişmiş: birleştir
            dirty && at != syncedAt -> {
                val (f, l) = merge(PlayerManager.favorites.value, Playlists.lists.value, sFavs, sLists)
                applyLocal(f, l); push(f, l)
            }
            // Yalnızca bu cihaz değişmiş
            dirty -> push(PlayerManager.favorites.value, Playlists.lists.value)
            // Başka cihazda değişmiş
            at != syncedAt -> { applyLocal(sFavs, sLists); markSynced(owner, at) }
        }
    }

    private fun markSynced(owner: String, at: Long) {
        prefs?.edit()?.putString("lib_owner", owner)?.putLong("lib_synced_at", at)?.putBoolean("lib_dirty", false)?.apply()
    }

    private suspend fun push(favs: List<Song>, lists: List<UserPlaylist>): Boolean {
        val owner = Social.username.value ?: return false
        val myRev = rev
        val pl = JSONArray()
        lists.forEach { l ->
            pl.put(JSONObject().put("id", l.id).put("name", l.name).put("pub", l.public).put("songs", l.songs.filterNot { isLocal(it) }.toJsonArray()))
        }
        val body = JSONObject().put("favs", favs.filterNot { isLocal(it) }.toJsonArray()).put("playlists", pl)
        val r = Social.call("/social/library-set", body) ?: return false
        if (r.code !in 200..299) return false
        val p = prefs ?: return true
        p.edit().putString("lib_owner", owner).putLong("lib_synced_at", r.body.optLong("updatedAt")).apply()
        if (rev == myRev) p.edit().putBoolean("lib_dirty", false).apply()   // gönderirken yeni değişiklik olduysa tekrar gönderilecek
        else markDirty()
        return true
    }

    // ---- birleştirme ve uygulama ----

    private fun union(a: List<Song>, b: List<Song>) = (a + b).distinctBy { it.url }

    private fun merge(lf: List<Song>, ll: List<UserPlaylist>, sf: List<Song>, sl: List<UserPlaylist>): Pair<List<Song>, List<UserPlaylist>> {
        val out = LinkedHashMap<String, UserPlaylist>()
        ll.forEach { out[it.id] = it }
        sl.forEach { s -> out[s.id] = out[s.id]?.let { l -> l.copy(songs = union(l.songs, s.songs), public = l.public) } ?: s }
        return union(lf, sf) to out.values.toList()
    }

    /** Sunucudan gelen veriyi cihaza yazar; cihazdaki yüklenmiş (local://) şarkılar korunur. */
    private fun applyLocal(favs: List<Song>, lists: List<UserPlaylist>) {
        val keepFavs = PlayerManager.favorites.value.filter { isLocal(it) }
        PlayerManager.replaceFavorites(union(favs, keepFavs))
        val old = Playlists.lists.value
        Playlists.replaceAll(lists.map { pl ->
            val extra = old.firstOrNull { it.id == pl.id }?.songs.orEmpty().filter { isLocal(it) }
            pl.copy(songs = union(pl.songs, extra))
        })
    }

    private fun parseSongs(a: JSONArray?): List<Song> =
        if (a == null) emptyList() else (0 until a.length()).mapNotNull { i -> try { a.getJSONObject(i).toSong() } catch (e: Exception) { null } }

    private fun parseLists(a: JSONArray?): List<UserPlaylist> =
        if (a == null) emptyList() else (0 until a.length()).mapNotNull { i ->
            try {
                val o = a.getJSONObject(i)
                UserPlaylist(o.getString("id"), o.optString("name").ifBlank { "Liste" }, parseSongs(o.optJSONArray("songs")), o.optBoolean("pub", false))
            } catch (e: Exception) { null }
        }
}
