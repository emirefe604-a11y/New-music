package com.example.newmusic

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Bildirim çubuğundaki "hızlı erişim" kartı: müzik çalmıyorken de uygulamayı (veya doğrudan aramayı) açar.
 * Müzik çalınca sistemin medya bildirimi devreder, bu kart kendini gizler.
 */
object QuickLaunch {
    const val EXTRA_OPEN_SEARCH = "open_search"
    private const val CHANNEL = "quick_launch"
    private const val ID = 4242

    /** Bildirimdeki "Ara" tuşuna basılınca artar; uygulama Ara sekmesini açar. */
    val searchTick = MutableStateFlow(0)
    private var app: Context? = null

    fun init(ctx: Context) { app = ctx.applicationContext }

    fun openIntent(ctx: Context, search: Boolean, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code,
            Intent(ctx, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                if (search) putExtra(EXTRA_OPEN_SEARCH, true)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun show(ctx: Context? = app) {
        val c = ctx?.applicationContext ?: return
        if (!AppSettings.quickLaunch.value || PlayerManager.playing.value) return
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java) ?: return
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Hızlı erişim", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Müzik çalmıyorken uygulamayı bildirim çubuğundan açar"
                    setShowBadge(false); setSound(null, null); enableVibration(false)
                }
            )
            val searchAction = Notification.Action.Builder(
                Icon.createWithResource(c, R.drawable.ic_stat_music), "Ara", openIntent(c, true, 2)
            ).build()
            val n = Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle("Sounddeep")
                .setContentText("Müziğe dönmek için dokun")
                .setContentIntent(openIntent(c, false, 1))
                .addAction(searchAction)
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build()
            nm.notify(ID, n)
        } catch (_: Exception) { }
    }

    fun hide(ctx: Context? = app) {
        try { ctx?.getSystemService(NotificationManager::class.java)?.cancel(ID) } catch (_: Exception) { }
    }

    /** Ayar açılıp kapanınca kartı hemen günceller. */
    fun refresh() { if (AppSettings.quickLaunch.value) show() else hide() }
}
