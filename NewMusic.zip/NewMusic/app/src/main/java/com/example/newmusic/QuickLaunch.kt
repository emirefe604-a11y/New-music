package com.example.newmusic

import android.content.Context
import android.app.PendingIntent
import android.content.Intent
import android.app.NotificationManager
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Bildirim çubuğunda yalnızca müzik çalar (medya kontrolleri) kalacak şekilde ayarlandı.
 * "Müziğe dönmek için dokun" bildirimi kaldırıldı.
 */
object QuickLaunch {
    const val EXTRA_OPEN_SEARCH = "open_search"
    private const val ID = 4242

    val searchTick = MutableStateFlow(0)
    private var app: Context? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        hide()
    }

    fun openIntent(ctx: Context, search: Boolean, code: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, code,
            Intent(ctx, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                if (search) putExtra(EXTRA_OPEN_SEARCH, true)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun show(ctx: Context? = app) {
        // "Müziğe dönmek için dokun" bildirim kartı kaldırıldı; sadece medya oynatıcı bildirimi aktiftir.
        hide(ctx)
    }

    fun hide(ctx: Context? = app) {
        try { ctx?.getSystemService(NotificationManager::class.java)?.cancel(ID) } catch (_: Exception) { }
    }

    fun refresh() { hide() }
}
