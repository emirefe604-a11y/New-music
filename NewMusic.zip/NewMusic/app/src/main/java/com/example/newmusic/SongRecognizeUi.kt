package com.example.newmusic

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private enum class RecState { NEEDS_PERMISSION, LISTENING, FOUND, NOT_FOUND, ERROR }

/**
 * Shazam benzeri şarkı tanıma penceresi. Mikrofonu dinler, şarkıyı bulursa [onFound] ile "şarkı sanatçı" metnini verir
 * (arama çubuğu bununla doldurulup arama yapılır). Dinlerken çalan müzik duraklatılır; şarkı bulunamazsa devam eder.
 */
@Composable
fun SongRecognizeDialog(onFound: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(RecState.NEEDS_PERMISSION) }
    var progress by remember { mutableFloatStateOf(0f) }
    var message by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<Recognized?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    var lyricsMode by remember { mutableStateOf(false) }
    val wasPlaying = remember { PlayerManager.playing.value }
    var paused by remember { mutableStateOf(false) }

    fun resumeIfNeeded() {
        if (paused && wasPlaying && !PlayerManager.playing.value) PlayerManager.togglePlay()
        paused = false
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { state = RecState.LISTENING; attempt++ }
        else { state = RecState.ERROR; message = "Şarkıyı tanıyabilmek için mikrofon izni gerekir." }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            state = RecState.LISTENING; attempt++
        } else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(attempt) {
        if (attempt == 0) return@LaunchedEffect
        progress = 0f; message = null; found = null
        if (wasPlaying && PlayerManager.playing.value) { PlayerManager.togglePlay(); paused = true; kotlinx.coroutines.delay(350) }
        lyricsMode = !SongRecognizer.serverConfigured()
        val res = if (lyricsMode) SongRecognizer.listenLyrics(ctx) { progress = it } else SongRecognizer.listen(ctx) { progress = it }
        val song = res.song
        when {
            song != null -> { found = song; state = RecState.FOUND; paused = false }
            res.error != null -> { state = RecState.ERROR; message = res.error; resumeIfNeeded() }
            else -> { state = RecState.NOT_FOUND; resumeIfNeeded() }
        }
    }

    // Pencere kapanınca (iptal dahil) yarım kalan kayıt iptal olur, müzik kaldığı yerden devam eder
    DisposableEffect(Unit) { onDispose { resumeIfNeeded() } }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        1f, 1.18f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulseScale"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = {
            Text(
                when (state) {
                    RecState.FOUND -> if (found?.fromLyrics == true) "Sözler algılandı" else "Şarkı bulundu"
                    RecState.NOT_FOUND -> "Tanıyamadım"
                    RecState.ERROR -> "Bir sorun oluştu"
                    else -> "Dinleniyor…"
                },
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(120.dp)) {
                    if (state == RecState.LISTENING) {
                        Box(Modifier.size(84.dp).scale(scale).clip(CircleShape).background(Accent.copy(alpha = 0.18f)))
                        CircularProgressIndicator(
                            progress = { progress }, modifier = Modifier.size(104.dp),
                            color = Accent, trackColor = Accent.copy(alpha = 0.15f), strokeWidth = 3.dp
                        )
                    }
                    Box(Modifier.size(68.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                        // Uygulamanın kendi Sounddeep logosu
                        SounddeepWaveIcon(modifier = Modifier.size(38.dp), tint = Color.White)
                    }
                }
                Spacer(Modifier.height(14.dp))
                when (state) {
                    RecState.FOUND -> {
                        val s = found
                        Text(s?.title.orEmpty(), fontWeight = if (s?.fromLyrics == true) FontWeight.Normal else FontWeight.Bold, textAlign = TextAlign.Center)
                        if (s?.fromLyrics == true) Text("Bu sözlerle arama yapılacak", color = Color.Gray, textAlign = TextAlign.Center)
                        if (!s?.artist.isNullOrBlank()) Text(s?.artist.orEmpty(), color = Color.Gray, textAlign = TextAlign.Center)
                    }
                    RecState.NOT_FOUND -> Text(if (lyricsMode) "Söz duyamadım. Sözlü ve net bir yerde tekrar dene (enstrümantal parçalar tanınamaz)." else "Bu şarkıyı bulamadım. Müziğe biraz daha yaklaşıp tekrar dene.", color = Color.Gray, textAlign = TextAlign.Center)
                    RecState.ERROR -> Text(message ?: "Şarkı tanınamadı.", color = Color.Gray, textAlign = TextAlign.Center)
                    else -> Text(if (lyricsMode) "Şarkının sözlerini dinliyorum; telefonu hoparlöre yaklaştır" else "Telefonu çalan müziğe yaklaştır", color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
        },
        confirmButton = {
            when (state) {
                RecState.FOUND -> TextButton({ found?.let { onFound(it.query) } }) { Text("Ara ve Çal", color = Accent, fontWeight = FontWeight.SemiBold) }
                RecState.NOT_FOUND, RecState.ERROR ->
                    TextButton({
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            state = RecState.LISTENING; attempt++
                        } else permission.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Text("Tekrar Dene", color = Accent, fontWeight = FontWeight.SemiBold) }
                else -> {}
            }
        },
        dismissButton = { TextButton(onDismiss) { Text(if (state == RecState.FOUND) "Kapat" else "Vazgeç") } }
    )
}
