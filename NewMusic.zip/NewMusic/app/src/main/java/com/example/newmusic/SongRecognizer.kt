package com.example.newmusic

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

/** Tanınan şarkı. */
data class Recognized(val title: String, val artist: String) {
    val query: String get() = listOf(title, artist).filter { it.isNotBlank() }.joinToString(" ")
}

/** Sonuç: ya bir şarkı, ya "bulunamadı" (song = null, error = null), ya da hata mesajı. */
data class RecognizeResult(val song: Recognized? = null, val error: String? = null)

/**
 * Shazam benzeri şarkı tanıma: mikrofondan kısa bir kayıt alır, sunucudaki /recognize adresine gönderir
 * (sunucu AudD parmak izi servisiyle eşleştirir).
 */
object SongRecognizer {
    private const val RECORD_MS = 10_000L

    /** Ortamdaki sesi [RECORD_MS] kadar kaydedip tanır. İzin önceden alınmış olmalıdır. [onLevel] kayıt ilerlemesini 0..1 bildirir. */
    suspend fun listen(ctx: Context, onProgress: (Float) -> Unit = {}): RecognizeResult {
        if (!Social.enabled) return RecognizeResult(error = "Sunucu ayarlanmadı.")
        val file = File(ctx.cacheDir, "tanima_${System.currentTimeMillis()}.m4a")
        @Suppress("DEPRECATION")
        val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        try {
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96_000)
            rec.setAudioChannels(1)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
        } catch (e: Exception) {
            try { rec.release() } catch (_: Exception) { }
            file.delete()
            return RecognizeResult(error = "Mikrofon açılamadı. Başka bir uygulama kullanıyor olabilir.")
        }
        try {
            val step = 100L
            var t = 0L
            while (t < RECORD_MS) { delay(step); t += step; onProgress(t.toFloat() / RECORD_MS) }
        } catch (e: CancellationException) {
            try { rec.stop() } catch (_: Exception) { }
            rec.release(); file.delete()
            throw e
        }
        try { rec.stop() } catch (_: Exception) { file.delete(); rec.release(); return RecognizeResult(error = "Kayıt alınamadı.") }
        rec.release()
        return try { send(file) } finally { file.delete() }
    }

    private suspend fun send(file: File): RecognizeResult = withContext(Dispatchers.IO) {
        try {
            val body = file.readBytes().toRequestBody("audio/mp4".toMediaType())
            val req = Request.Builder().url("$SOCIAL_API_URL/recognize").post(body).build()
            Http.server.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                val json = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                when {
                    !r.isSuccessful -> RecognizeResult(error = json.optString("error").ifBlank { "Şarkı tanınamadı. Biraz sonra tekrar dene." })
                    json.optBoolean("found") -> RecognizeResult(song = Recognized(json.optString("title"), json.optString("artist")))
                    else -> RecognizeResult()
                }
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { RecognizeResult(error = "İnternet bağlantısı yok veya sunucuya ulaşılamadı.") }
    }
}
