package com.example.newmusic

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Tanınan şarkı. */
data class Recognized(val title: String, val artist: String, val fromLyrics: Boolean = false) {
    val query: String get() = listOf(title, artist).filter { it.isNotBlank() }.joinToString(" ")
}

/** Sonuç: ya bir şarkı, ya "bulunamadı" (song = null, error = null), ya da hata mesajı. */
data class RecognizeResult(val song: Recognized? = null, val error: String? = null)

/**
 * Shazam benzeri şarkı tanıma: mikrofondan kısa bir kayıt alır, sunucudaki /recognize adresine gönderir
 * (sunucu AudD parmak izi servisiyle eşleştirir).
 */
object SongRecognizer {
    private const val RECORD_MS = 10_000L

    /** Ortamdaki sesi [RECORD_MS] kadar kaydedip tanır. İzin önceden alınmış olmalıdır. [onLevel] kayıt ilerlemesini 0..1 bildirir. */
    suspend fun listen(ctx: Context, onProgress: (Float) -> Unit = {}): RecognizeResult {
        if (!Social.enabled) return RecognizeResult(error = "Sunucu ayarlanmadı.")
        val file = File(ctx.cacheDir, "tanima_${System.currentTimeMillis()}.m4a")
        @Suppress("DEPRECATION")
        val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
        try {
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96_000)
            rec.setAudioChannels(1)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
        } catch (e: Exception) {
            try { rec.release() } catch (_: Exception) { }
            file.delete()
            return RecognizeResult(error = "Mikrofon açılamadı. Başka bir uygulama kullanıyor olabilir.")
        }
        try {
            val step = 100L
            var t = 0L
            while (t < RECORD_MS) { delay(step); t += step; onProgress(t.toFloat() / RECORD_MS) }
        } catch (e: CancellationException) {
            try { rec.stop() } catch (_: Exception) { }
            rec.release(); file.delete()
            throw e
        }
        try { rec.stop() } catch (_: Exception) { file.delete(); rec.release(); return RecognizeResult(error = "Kayıt alınamadı.") }
        rec.release()
        return try { send(file) } finally { file.delete() }
    }

    private suspend fun send(file: File): RecognizeResult = withContext(Dispatchers.IO) {
        try {
            val body = file.readBytes().toRequestBody("audio/mp4".toMediaType())
            val req = Request.Builder().url("$SOCIAL_API_URL/recognize").post(body).build()
            Http.server.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                val json = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                when {
                    r.code == 404 -> RecognizeResult(error = "Sunucu güncel değil: backend'i yeniden yayınlaman gerekiyor (/recognize bulunamadı).")
                    !r.isSuccessful -> RecognizeResult(error = json.optString("error").ifBlank { "Şarkı tanınamadı. Biraz sonra tekrar dene." })
                    json.optBoolean("found") -> RecognizeResult(song = Recognized(json.optString("title"), json.optString("artist")))
                    else -> RecognizeResult()
                }
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { RecognizeResult(error = "İnternet bağlantısı yok veya sunucuya ulaşılamadı.") }
    }

    private var serverReady: Boolean? = null

    /** Sunucuda AudD anahtarı var mı? Cevap alınamazsa (uyuyor/ağ yok) false döner ve sonra tekrar sorulur. */
    suspend fun serverConfigured(): Boolean {
        serverReady?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val c = Http.client.newBuilder().callTimeout(8, java.util.concurrent.TimeUnit.SECONDS).build()
                c.newCall(Request.Builder().url("$SOCIAL_API_URL/recognize-status").get().build()).execute().use { r ->
                    val ok = r.isSuccessful && JSONObject(r.body?.string().orEmpty()).optBoolean("audd")
                    if (r.isSuccessful) serverReady = ok
                    ok
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { false }
        }
    }

    /**
     * Ücretsiz, anahtarsız yedek yol: telefonun konuşma tanıma servisi çalan şarkının sözlerini yazıya çevirir,
     * bu sözlerle arama yapılır. Sözlü, net duyulan şarkılarda işe yarar; enstrümantal parçaları tanıyamaz.
     */
    suspend fun listenLyrics(ctx: Context, onProgress: (Float) -> Unit = {}): RecognizeResult = withContext(Dispatchers.Main) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx))
            return@withContext RecognizeResult(error = "Telefonunda konuşma tanıma servisi (Google) bulunamadı.")
        suspendCancellableCoroutine { cont ->
            val handler = Handler(Looper.getMainLooper())
            val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
            var best = ""
            var done = false
            val start = System.currentTimeMillis()
            fun finish(r: RecognizeResult) {
                if (done) return
                done = true
                handler.removeCallbacksAndMessages(null)
                try { sr.destroy() } catch (_: Exception) { }
                if (cont.isActive) cont.resume(r)
            }
            fun result() = if (best.trim().split(Regex("\\s+")).size >= 3)
                RecognizeResult(song = Recognized(best.trim(), "", fromLyrics = true)) else RecognizeResult()
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                override fun onPartialResults(p: android.os.Bundle?) {
                    p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { if (it.length >= best.length) best = it }
                }
                override fun onResults(r: android.os.Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { if (it.length >= best.length) best = it }
                    finish(result())
                }
                override fun onError(error: Int) {
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> finish(result())
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> finish(RecognizeResult(error = "Mikrofon izni gerekli."))
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            finish(if (best.isNotBlank()) result() else RecognizeResult(error = "Konuşma tanıma için internet gerekli."))
                        else -> finish(if (best.isNotBlank()) result() else RecognizeResult(error = "Konuşma tanıma servisi hata verdi ($error)."))
                    }
                }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 6000L)
            }
            val total = 14_000L
            val tick = object : Runnable {
                override fun run() {
                    if (done) return
                    val t = System.currentTimeMillis() - start
                    onProgress((t.toFloat() / total).coerceIn(0f, 1f))
                    if (t >= total) { try { sr.stopListening() } catch (_: Exception) { }; handler.postDelayed({ finish(result()) }, 2500) }
                    else handler.postDelayed(this, 100)
                }
            }
            cont.invokeOnCancellation { handler.post { done = true; handler.removeCallbacksAndMessages(null); try { sr.cancel(); sr.destroy() } catch (_: Exception) { } } }
            try { sr.startListening(intent) } catch (e: Exception) { finish(RecognizeResult(error = "Konuşma tanıma başlatılamadı.")); return@suspendCancellableCoroutine }
            handler.post(tick)
        }
    }
}
