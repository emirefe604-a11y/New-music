package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Hesap yedeği: beğenilen şarkılar, çalma listeleri, zevk profili ve ayarlar sunucuda saklanır.
 * Uygulama silinse bile aynı kullanıcı adı + şifreyle girince geri gelir.
 *
 * - Yerel veri değişince 4 sn sonra sunucuya yazılır (yazılamazsa "bekliyor" işaretlenir, sonra tekrar denenir).
 * - Uygulama açılınca: bekleyen değişiklik varsa gönderilir, yoksa sunucudaki daha yeni yedek alınır.
 * - Giriş yapınca: sunucudaki veri ile cihazdaki veri birleştirilir (hiçbir şey kaybolmaz), sonra yedeklenir.
 * - Cihazdan indirilen / yüklenen müzik dosyaları yedeklenmez (yalnızca şarkı bilgileri yedeklenir).
 */
object CloudSync {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private var prefs: SharedPreferences? = null
    private var pushJob: Job? = null
    @Volatile private var applying = false
    @Volatile private var seq = 0L        // her yerel değişiklikte artar

    private var dirty: Boolean
        get() = prefs?.getBoolean("sync_dirty", false) == true
        set(v) { prefs?.edit()?.putBoolean("sync_dirty", v)?.apply() }
    private var localRev: Long
        get() = prefs?.getLong("sync_rev", 0L) ?: 0L
        set(v) { prefs?.edit()?.putLong("sync_rev", v)?.apply() }

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
    }

    /** Yerel veri değişti: kısa bir bekleyişten sonra yedeğe yaz. */
    fun changed() {
        if (applying || !Social.joined) return
        seq++
        dirty = true
        pushJob?.cancel()
        pushJob = scope.launch { delay(4_000); push() }
    }

    // ---- paketleme ----
    private fun snapshot(): JSONObject = JSONObject()
        .put("v", 1)
        .put("favs", PlayerManager.exportFavorites())
        .put("lists", Playlists.export())
        .put("taste", TasteProfile.export())
        .put("settings", JSONObject()
            .put("theme", ThemeStore.index.value).put("ambient", ThemeStore.ambientMode.value).put("gradient", ThemeStore.gradient.value)
            .put("quality", AppSettings.quality.value).put("content", AppSettings.content.value).put("autoplay", AppSettings.autoplay.value))

    private fun encode(o: JSONObject): String {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(o.toString().toByteArray(Charsets.UTF_8)) }
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun decode(s: String): JSONObject =
        JSONObject(String(GZIPInputStream(ByteArrayInputStream(Base64.decode(s, Base64.NO_WRAP))).readBytes(), Charsets.UTF_8))

    private class Remote(val data: JSONObject?, val rev: Long)

    private suspend fun fetch(): Remote? {
        val r = Social.call("/social/data-get", JSONObject()) ?: return null
        if (r.code !in 200..299) return null
        val d = r.body.optString("data", "")
        val obj = if (d.isBlank() || r.body.isNull("data")) null else try { decode(d) } catch (e: Exception) { null }
        return Remote(obj, r.body.optLong("rev"))
    }

    /** Yerel veriyi sunucuya yazar. Başarılıysa true. */
    suspend fun push(): Boolean = lock.withLock {
        if (!Social.joined) return@withLock false
        val mark = seq
        val r = try { Social.call("/social/data-put", JSONObject().put("data", encode(snapshot()))) } catch (e: Exception) { null }
        if (r != null && r.code in 200..299) {
            localRev = r.body.optLong("rev")
            if (mark == seq) dirty = false
            true
        } else false
    }

    /** Uygulama açılınca / öne gelince. */
    fun syncOnStart() {
        if (!Social.joined) return
        scope.launch {
            var needPush = dirty
            if (!needPush) {
                lock.withLock {
                    val remote = fetch() ?: return@launch          // ağ yok: sonra tekrar denenir
                    val data = remote.data
                    when {
                        data == null -> needPush = true               // sunucuda yedek yok: ilk yedeği al
                        remote.rev > localRev -> { apply(data, merge = false); localRev = remote.rev }
                    }
                }
            }
            if (needPush) push()
        }
    }

    /** Hesaba giriş / hesap oluşturma sonrası: sunucudaki veriyle birleştir, sonra yedekle. */
    suspend fun onLogin() {
        lock.withLock {
            val remote = fetch()
            if (remote?.data != null) apply(remote.data, merge = true)
        }
        seq++
        dirty = true
        push()
    }

    /** Bekleyen değişiklik varsa hemen gönderir (uygulama arka plana giderken). */
    fun flush() {
        if (!Social.joined || !dirty) return
        pushJob?.cancel()
        scope.launch { push() }
    }

    /**
     * Çıkış: önce son değişiklikleri yedekler, sonra oturumu kapatıp cihazdaki hesap verisini siler.
     * Yedeklenemezse ve [force] false ise false döner (veri kaybolmasın diye çıkış yapılmaz).
     */
    suspend fun signOut(force: Boolean): Boolean {
        pushJob?.cancel()
        if (dirty && !push() && !force) return false
        Social.logout()
        applying = true
        try {
            PlayerManager.importFavorites(emptyList())
            Playlists.replaceAll(emptyList())
            TasteProfile.replaceAll(JSONArray())
        } finally { applying = false }
        dirty = false; localRev = 0L
        return true
    }

    // ---- uygulama ----
    private fun apply(o: JSONObject, merge: Boolean) {
        applying = true
        try {
            // beğenilenler
            val remoteFavs = o.optJSONArray("favs")?.toSongs() ?: emptyList()
            PlayerManager.importFavorites(
                if (merge) (PlayerManager.favorites.value + remoteFavs).distinctBy { it.url } else remoteFavs
            )
            // listeler
            val remoteLists = Playlists.fromJson(o.optJSONArray("lists") ?: JSONArray())
            if (!merge) Playlists.replaceAll(remoteLists)
            else {
                val local = Playlists.lists.value
                val byId = local.associateBy { it.id }
                val merged = local.map { l ->
                    val r = remoteLists.firstOrNull { it.id == l.id }
                    if (r == null) l else l.copy(songs = (l.songs + r.songs).distinctBy { it.url })
                } + remoteLists.filter { it.id !in byId }
                Playlists.replaceAll(merged)
            }
            // zevk profili
            TasteProfile.replaceAll(o.optJSONArray("taste") ?: JSONArray(), merge)
            // ayarlar
            o.optJSONObject("settings")?.let { s ->
                ThemeStore.applyRemote(s.optInt("theme", 0), s.optInt("ambient", 0), s.optInt("gradient", 0))
                AppSettings.applyRemote(s.optInt("quality", 0), s.optInt("content", 0), s.optBoolean("autoplay", true))
            }
        } finally { applying = false }
    }
}
