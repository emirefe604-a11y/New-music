package com.example.newmusic

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

data class LyricLine(val timeMs: Long, val text: String)

data class LyricsData(
    val isSynced: Boolean,
    val lines: List<LyricLine>,
    val plain: String = ""
)

/**
 * Şarkı sözleri yöneticisi:
 * LRCLIB üzerinden zamana göre senkronize (akan) veya düz metin şarkı sözlerini çeker ve önbelleğe alır.
 */
object LyricsManager {
    private val cache = ConcurrentHashMap<String, LyricsData>()
    private val lrcRegex = Regex("""\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]\s*(.*)""")

    private fun cleanTitle(title: String): String {
        var t = title
        if (" - " in t) {
            val parts = t.split(" - ", limit = 2)
            t = parts[1]
        }
        t = t.replace(Regex("""(?i)\(?(?:official|audio|video|clip|lyrics|visualizer|remix|hd|4k|feat\.?|ft\.?).*?\)?$"""), "")
        t = t.replace(Regex("""\[.*?\]"""), "")
        t = t.replace(Regex("""\(.*?\)"""), "")
        return t.trim()
    }

    private fun cleanArtist(artist: String, title: String): String {
        if (artist.isNotBlank() && !artist.contains("vevo", ignoreCase = true) && !artist.contains("topic", ignoreCase = true)) {
            return artist.replace(Regex("""(?i)\s*-\s*topic"""), "").trim()
        }
        if (" - " in title) {
            return title.split(" - ", limit = 2)[0].trim()
        }
        return artist.trim()
    }

    fun parseLrc(lrc: String): List<LyricLine> {
        val list = mutableListOf<LyricLine>()
        for (line in lrc.lines()) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue
            val m = lrcRegex.matchEntire(trimmed) ?: continue
            val mins = m.groupValues[1].toLongOrNull() ?: 0L
            val secs = m.groupValues[2].toLongOrNull() ?: 0L
            val msStr = m.groupValues[3]
            val ms = when (msStr.length) {
                1 -> (msStr.toLongOrNull() ?: 0L) * 100
                2 -> (msStr.toLongOrNull() ?: 0L) * 10
                else -> (msStr.take(3).toLongOrNull() ?: 0L)
            }
            val time = mins * 60_000L + secs * 1_000L + ms
            val text = m.groupValues[4].trim()
            if (text.isNotEmpty()) {
                list.add(LyricLine(time, text))
            }
        }
        return list.sortedBy { it.timeMs }
    }

    suspend fun fetchLyrics(song: Song): LyricsData? = withContext(Dispatchers.IO) {
        val cacheKey = song.url
        cache[cacheKey]?.let { return@withContext it }

        val track = cleanTitle(song.title)
        val artist = cleanArtist(song.artist, song.title)
        if (track.isBlank()) return@withContext null

        try {
            // 1. Doğrudan GET isteği dene
            val encTrack = URLEncoder.encode(track, "UTF-8")
            val encArtist = URLEncoder.encode(artist, "UTF-8")
            val getUrl = "https://lrclib.net/api/get?track_name=$encTrack&artist_name=$encArtist"

            val req1 = Request.Builder()
                .url(getUrl)
                .header("User-Agent", "NewMusicApp/1.1 (https://github.com/emirefe604-a11y/New-music)")
                .build()

            val res1 = Http.client.newCall(req1).execute()
            if (res1.isSuccessful) {
                val bodyStr = res1.body?.string().orEmpty()
                res1.close()
                val json = JSONObject(bodyStr)
                val synced = json.optString("syncedLyrics").ifBlank { null }
                val plain = json.optString("plainLyrics").ifBlank { null }
                if (synced != null) {
                    val parsed = parseLrc(synced)
                    if (parsed.isNotEmpty()) {
                        val d = LyricsData(isSynced = true, lines = parsed, plain = plain ?: "")
                        cache[cacheKey] = d
                        return@withContext d
                    }
                }
                if (plain != null) {
                    val lines = plain.lines().map { LyricLine(0L, it.trim()) }.filter { it.text.isNotEmpty() }
                    val d = LyricsData(isSynced = false, lines = lines, plain = plain)
                    cache[cacheKey] = d
                    return@withContext d
                }
            } else {
                res1.close()
            }

            // 2. Arama ile yedek istek dene
            val query = URLEncoder.encode("$track $artist", "UTF-8")
            val searchUrl = "https://lrclib.net/api/search?q=$query"
            val req2 = Request.Builder()
                .url(searchUrl)
                .header("User-Agent", "NewMusicApp/1.1")
                .build()

            val res2 = Http.client.newCall(req2).execute()
            if (res2.isSuccessful) {
                val bodyStr = res2.body?.string().orEmpty()
                res2.close()
                val arr = JSONArray(bodyStr)
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val synced = item.optString("syncedLyrics").ifBlank { null }
                    val plain = item.optString("plainLyrics").ifBlank { null }
                    if (synced != null) {
                        val parsed = parseLrc(synced)
                        if (parsed.isNotEmpty()) {
                            val d = LyricsData(isSynced = true, lines = parsed, plain = plain ?: "")
                            cache[cacheKey] = d
                            return@withContext d
                        }
                    }
                    if (plain != null) {
                        val lines = plain.lines().map { LyricLine(0L, it.trim()) }.filter { it.text.isNotEmpty() }
                        val d = LyricsData(isSynced = false, lines = lines, plain = plain)
                        cache[cacheKey] = d
                        return@withContext d
                    }
                }
            } else {
                res2.close()
            }
        } catch (_: Exception) { }

        null
    }
}

/**
 * Müziğin akışına göre satır satır parlayan ve otomatik kayan senkronize şarkı sözü ekranı.
 */
@Composable
fun FlowingLyricsView(
    song: Song,
    posMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var data by remember(song.url) { mutableStateOf<LyricsData?>(null) }
    var loading by remember(song.url) { mutableStateOf(true) }

    LaunchedEffect(song.url) {
        loading = true
        data = LyricsManager.fetchLyrics(song)
        loading = false
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF1E1E2C),
                        Color(0xFF12121A)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        when {
            loading -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Accent, modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("Şarkı sözleri aranıyor...", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                }
            }
            data == null || data.lines.isEmpty() -> {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Icon(Icons.Filled.Mic, null, tint = Color.White.copy(alpha = 0.35f), modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Bu şarkı için söz bulunamadı", color = Color.White.copy(alpha = 0.7f), fontWeight = FontWeight.SemiBold)
                    Text("Enstrümantal veya henüz sisteme eklenmemiş olabilir.", color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
                }
            }
            else -> {
                val currentData = data
                val lines = currentData.lines
                val isSynced = currentData.isSynced
                val activeIdx = remember(posMs, lines) {
                    if (!isSynced) -1
                    else {
                        val found = lines.indexOfLast { it.timeMs <= posMs }
                        if (found >= 0) found else 0
                    }
                }
                val listState = rememberLazyListState()

                // Çalan satıra otomatik yumuşak kaydırma
                LaunchedEffect(activeIdx) {
                    if (activeIdx >= 0) {
                        listState.animateScrollToItem(
                            index = (activeIdx - 2).coerceAtLeast(0),
                            scrollOffset = 0
                        )
                    }
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 120.dp, horizontal = 20.dp)
                ) {
                    itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
                        val isCurrent = isSynced && (i == activeIdx)
                        val textColor by animateColorAsState(
                            targetValue = if (isCurrent) Color.White else Color.White.copy(alpha = 0.38f),
                            animationSpec = tween(250), label = "lyricColor"
                        )
                        val textSize by animateFloatAsState(
                            targetValue = if (isCurrent) 21f else 17f,
                            animationSpec = tween(250, easing = FastOutSlowInEasing), label = "lyricSize"
                        )

                        Text(
                            text = line.text,
                            color = textColor,
                            fontSize = textSize.sp,
                            fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.Medium,
                            lineHeight = (textSize * 1.35f).sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                                .clickable {
                                    if (isSynced) {
                                        onSeek(line.timeMs)
                                    }
                                }
                        )
                    }
                }
            }
        }
    }
}
