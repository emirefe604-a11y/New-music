@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InputStream

/**
 * YouTube tek istekte uzun süre akıtmayı kesiyor (~30 sn). NewPipe gibi dosyayı
 * `range` + `rn` parametreleriyle parça parça indirerek şarkının tamamı kesintisiz çalınır.
 */
class ChunkedDataSource(private val http: OkHttpClient) : BaseDataSource(true) {
    private companion object {
        const val CHUNK = 4_000_000L
        const val FIRST_CHUNK = 128_000L // 128 KB ilk parça (~8 saniye): ağ beklemeden anında başlar // 256 KB ilk parça (~16 saniye kesintisiz müzik): hızlı başlar ve kesintiyi önler
        const val UA_WEB = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"
        const val UA_ANDROID = "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
        const val UA_IOS = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        const val UA_VR = "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"
    }

    private var uri: Uri? = null
    private var response: Response? = null
    private var input: InputStream? = null
    private var pos = 0L
    private var chunkEnd = 0L
    private var end = Long.MAX_VALUE
    private var totalFromRange = -1L
    private var requestNumber = 0
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val clen = dataSpec.uri.getQueryParameter("clen")?.toLongOrNull() ?: -1L
        pos = dataSpec.position
        val lengthSet = dataSpec.length != C.LENGTH_UNSET.toLong()
        end = when {
            lengthSet -> pos + dataSpec.length
            clen > 0 -> clen
            else -> Long.MAX_VALUE
        }
        chunkEnd = pos
        requestNumber = 0
        totalFromRange = -1L
        // İlk parçayı hemen iste: toplam boyutu Content-Range'den öğreniriz.
        if (pos < end) openChunk()
        if (!lengthSet && end == Long.MAX_VALUE && totalFromRange > 0) end = totalFromRange
        opened = true
        transferStarted(dataSpec)
        return if (end == Long.MAX_VALUE) C.LENGTH_UNSET.toLong() else maxOf(0L, end - pos)
    }

    private fun openChunk(): Boolean {
        closeChunk()
        if (pos >= end) return false
        val to = minOf(pos + (if (requestNumber == 0) FIRST_CHUNK else CHUNK), end) - 1
        val src = uri ?: return false
        val builder = src.buildUpon().clearQuery()
        src.queryParameterNames.filter { it != "range" && it != "rn" }.forEach { n ->
            src.getQueryParameters(n).forEach { v -> builder.appendQueryParameter(n, v) }
        }
        builder.appendQueryParameter("range", "$pos-$to")
        val c = src.getQueryParameter("c").orEmpty()
        val rb = Request.Builder()
        when {
            c.startsWith("ANDROID_VR") -> rb.header("User-Agent", UA_VR)
            c.startsWith("ANDROID") -> rb.header("User-Agent", UA_ANDROID)
            c.startsWith("IOS") -> rb.header("User-Agent", UA_IOS)
            else -> {
                builder.appendQueryParameter("rn", (requestNumber).toString())
                rb.header("User-Agent", UA_WEB)
                    .header("Origin", "https://www.youtube.com")
                    .header("Referer", "https://www.youtube.com/")
            }
        }
        requestNumber++
        val request = rb.url(builder.build().toString()).build()
        var got: Response? = null
        var attempt = 0
        while (got == null) {
            try {
                val resp = http.newCall(request).execute()
                // Geçici sunucu hatalarında (5xx / 429) aynı parçayı kısa beklemeyle tekrar dene
                if ((resp.code >= 500 || resp.code == 429) && attempt < 2) {
                    resp.close(); attempt++; backoff(attempt); continue
                }
                got = resp
            } catch (e: java.io.InterruptedIOException) {
                throw e
            } catch (e: IOException) {
                // Anlık ağ kopmasında şarkıyı bırakma: 2 kez daha dene
                if (attempt >= 2) throw e
                attempt++; backoff(attempt)
            }
        }
        val r: Response = got ?: throw IOException("Akış yanıtı alınamadı")
        if (!r.isSuccessful) {
            val code = r.code
            r.close()
            // Konumun bilinen sonundan önce 416 gelmesi akışın bozuk olduğunu gösterir; sessizce bitirme
            if (code == 416) return if (end != Long.MAX_VALUE && pos < end) throw IOException("HTTP 416 (akış erken bitti: $pos/$end)") else false
            throw IOException("HTTP $code (akış reddedildi)")
        }
        r.header("Content-Range")?.substringAfter('/', "")?.toLongOrNull()?.let { totalFromRange = it }
        response = r
        input = r.body?.byteStream() ?: throw IOException("Boş akış yanıtı")
        chunkEnd = to + 1
        return true
    }

    private fun backoff(attempt: Int) {
        try { Thread.sleep(300L * attempt) }
        catch (e: InterruptedException) { Thread.currentThread().interrupt(); throw java.io.InterruptedIOException() }
    }

    /**
     * Uzunluğu belli bir akış beklenenden ÖNCE biterse bunu "şarkı bitti" saymak şarkının ~30. saniyede
     * sessizce durmasına/atlanmasına yol açıyordu. Bunun yerine hata fırlatılır: oynatıcı taze adresle
     * kaldığı saniyeden devam eder.
     */
    private fun endOrFail(): Int {
        if (end != Long.MAX_VALUE && pos < end) throw IOException("Akış erken bitti ($pos/$end)")
        return C.RESULT_END_OF_INPUT
    }

    private fun closeChunk() {
        try { response?.close() } catch (_: Exception) {}
        response = null; input = null
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        var empties = 0
        while (true) {
            if (pos >= end) return C.RESULT_END_OF_INPUT
            if (input == null || pos >= chunkEnd) {
                if (!openChunk()) return endOrFail()
            }
            val inStream = input ?: return endOrFail()
            val n = inStream.read(buffer, offset, minOf(length.toLong(), chunkEnd - pos).toInt())
            if (n == -1) {
                if (++empties > 2) return endOrFail()
                input = null
                continue
            }
            pos += n
            bytesTransferred(n)
            return n
        }
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        closeChunk()
        uri = null
        if (opened) { opened = false; transferEnded() }
    }
}
