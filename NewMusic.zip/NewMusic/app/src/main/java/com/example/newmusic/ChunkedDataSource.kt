@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InputStream

/**
 * YouTube bağlantıları tek istekte uzun süre akıtılınca ~30 sn sonra kesiliyor.
 * Çözüm (NewPipe'ın yaptığı gibi): dosyayı `range` parametresiyle parça parça indirmek.
 */
class ChunkedDataSource(private val client: OkHttpClient) : BaseDataSource(true) {
    private companion object {
        const val CHUNK = 1_000_000L
        const val UA = "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0"
    }

    private var uri: Uri? = null
    private var response: Response? = null
    private var input: InputStream? = null
    private var pos = 0L
    private var chunkEnd = 0L
    private var end = Long.MAX_VALUE
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val total = dataSpec.uri.getQueryParameter("clen")?.toLongOrNull() ?: -1L
        pos = dataSpec.position
        end = when {
            dataSpec.length != C.LENGTH_UNSET.toLong() -> pos + dataSpec.length
            total > 0 -> total
            else -> Long.MAX_VALUE
        }
        chunkEnd = pos
        opened = true
        transferStarted(dataSpec)
        return if (end == Long.MAX_VALUE) C.LENGTH_UNSET.toLong() else maxOf(0L, end - pos)
    }

    private fun openChunk(): Boolean {
        closeChunk()
        if (pos >= end) return false
        val to = minOf(pos + CHUNK, end) - 1
        val src = uri!!
        val builder = src.buildUpon().clearQuery()
        src.queryParameterNames.filter { it != "range" }.forEach { n ->
            src.getQueryParameters(n).forEach { v -> builder.appendQueryParameter(n, v) }
        }
        builder.appendQueryParameter("range", "$pos-$to")
        val req = Request.Builder().url(builder.build().toString())
            .header("User-Agent", UA)
            .header("Origin", "https://www.youtube.com")
            .header("Referer", "https://www.youtube.com/")
            .build()
        val r = client.newCall(req).execute()
        if (!r.isSuccessful) {
            r.close()
            if (r.code == 416) return false
            throw IOException("HTTP ${r.code}")
        }
        response = r
        input = r.body!!.byteStream()
        chunkEnd = to + 1
        return true
    }

    private fun closeChunk() {
        try { response?.close() } catch (_: Exception) {}
        response = null; input = null
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        var empties = 0
        while (true) {
            if (pos >= end) return C.RESULT_END_OF_INPUT
            if (input == null || pos >= chunkEnd) {
                if (!openChunk()) return C.RESULT_END_OF_INPUT
            }
            val n = input!!.read(buffer, offset, minOf(length.toLong(), chunkEnd - pos).toInt())
            if (n == -1) {
                if (++empties > 2) return C.RESULT_END_OF_INPUT
                input = null
                continue
            }
            pos += n
            bytesTransferred(n)
            return n
        }
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        closeChunk()
        uri = null
        if (opened) { opened = false; transferEnded() }
    }
}
