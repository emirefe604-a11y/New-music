package com.example.newmusic

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

enum class BtKind { HEADPHONES, SPEAKER, CAR, OTHER }
enum class BtState { UNSUPPORTED, NO_PERMISSION, OFF, ON }
data class BtDevice(val name: String, val address: String, val kind: BtKind)

/** Şu anda bağlı olan Bluetooth ses cihazlarını (kulaklık, hoparlör, araç) canlı olarak izler. */
@SuppressLint("MissingPermission")
object BluetoothMonitor {
    val devices = MutableStateFlow<List<BtDevice>>(emptyList())
    val state = MutableStateFlow(BtState.ON)

    private var appCtx: Context? = null
    private var started = false
    private val main = Handler(Looper.getMainLooper())

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        appCtx = app
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
            addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                main.postDelayed({ refresh() }, 600)
            }
        }
        ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        refresh()
    }

    private fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun refresh() {
        val ctx = appCtx ?: return
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (adapter == null) { state.value = BtState.UNSUPPORTED; devices.value = emptyList(); return }
        if (!hasPermission(ctx)) { state.value = BtState.NO_PERMISSION; devices.value = emptyList(); return }
        val enabled = try { adapter.isEnabled } catch (e: SecurityException) { false }
        if (!enabled) { state.value = BtState.OFF; devices.value = emptyList(); return }
        state.value = BtState.ON

        val profiles = intArrayOf(BluetoothProfile.A2DP, BluetoothProfile.HEADSET)
        val collected = HashMap<String, BtDevice>()
        var pending = profiles.size
        fun done() {
            pending -= 1
            if (pending == 0) devices.value = collected.values.sortedBy { it.name }
        }
        for (p in profiles) {
            val ok = try {
                adapter.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
                    override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                        try {
                            proxy.connectedDevices.forEach { collected[it.address] = it.toBt() }
                        } catch (e: SecurityException) { }
                        try { adapter.closeProfileProxy(profile, proxy) } catch (e: Exception) { }
                        done()
                    }
                    override fun onServiceDisconnected(profile: Int) {}
                }, p)
            } catch (e: SecurityException) { false }
            if (!ok) done()
        }
    }

    private fun BluetoothDevice.toBt(): BtDevice {
        val label = (try { name } catch (e: SecurityException) { null }) ?: address
        val cls = try { bluetoothClass?.deviceClass } catch (e: SecurityException) { null }
        val kind = when (cls) {
            BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES,
            BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET,
            BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE -> BtKind.HEADPHONES
            BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER,
            BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO,
            BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO -> BtKind.SPEAKER
            BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO -> BtKind.CAR
            else -> BtKind.OTHER
        }
        return BtDevice(label, address, kind)
    }
}
