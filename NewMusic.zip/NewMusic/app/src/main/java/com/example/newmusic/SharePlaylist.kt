package com.example.newmusic

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.text.TextUtils
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PlaylistShareInfo(
    val title: String,
    val subtitle: String,
    val cover: String? = null,
    val id: String? = null,
    val url: String? = null,
    val user: String? = null
)

/**
 * Çalma listesi paylaşma: albüm kapaklı zengin kart görseli + doğrudan listeyi açan deep link oluşturur,
 * WhatsApp, Instagram ve diğer uygulamalara yönlendirir.
 */
object SharePlaylist {
    private const val W = 1080
    private const val H = 1920

    /** Web ve uygulama içi yönlendirme bağlantıları */
    fun links(info: PlaylistShareInfo): Pair<String, String> {
        val encName = Uri.encode(info.title)
        val encId = Uri.encode(info.id ?: "")
        val encUrl = Uri.encode(info.url ?: "")
        val encUser = Uri.encode(info.user ?: "")
        val query = "name=$encName" +
            (if (!info.id.isNullOrBlank()) "&id=$encId" else "") +
            (if (!info.url.isNullOrBlank()) "&url=$encUrl" else "") +
            (if (!info.user.isNullOrBlank()) "&user=$encUser" else "")

        val webLink = "https://new-music-cpzw.onrender.com/playlist?$query"
        val appLink = "sounddeep://playlist?$query"
        return webLink to appLink
    }

    /** WhatsApp ve mesajlarda paylaşılan zengin metin */
    fun text(info: PlaylistShareInfo): String {
        val (webLink, appLink) = links(info)
        return "🎶 ${info.title}\n${info.subtitle}\n\nDinlemek için dokun: $webLink\n(Uygulama içi doğrudan bağlantı: $appLink)\n\nSounddeep ile dinle"
    }

    /** 1080x1920 boyutunda Instagram Story / WhatsApp uyumlu zengin paylaşım kartı */
    suspend fun card(ctx: Context, info: PlaylistShareInfo): File? = withContext(Dispatchers.IO) {
        try {
            val coverSource = info.cover
            val cover: Bitmap? = if (!coverSource.isNullOrBlank()) {
                var loaded: Bitmap? = null
                if (coverSource.startsWith("content://") || coverSource.startsWith("file://")) {
                    try {
                        ctx.contentResolver.openInputStream(Uri.parse(coverSource))?.use {
                            loaded = BitmapFactory.decodeStream(it)
                        }
                    } catch (_: Exception) {}
                }
                if (loaded == null) {
                    for (u in listOf(hiRes(coverSource, 800), hiRes(coverSource, 480), coverSource)) {
                        if (u == null || loaded != null) continue
                        val res = ctx.imageLoader.execute(ImageRequest.Builder(ctx).data(u).allowHardware(false).build())
                        loaded = (res as? SuccessResult)?.drawable?.toBitmap()
                    }
                }
                loaded
            } else null

            val bg = cover?.let { b ->
                val pal = Palette.from(b).generate()
                pal.getDarkMutedColor(pal.getDominantColor(0xFF0D1424.toInt()))
            } ?: 0xFF0D1424.toInt()

            val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), bg, AColor.BLACK, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
            p.shader = null

            // Üstte "ÇALMA LİSTESİ" rozeti
            val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.argb(45, 255, 255, 255)
            }
            val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.WHITE
                textSize = 32f
                typeface = Typeface.DEFAULT_BOLD
                letterSpacing = 0.08f
            }
            val badgeText = "ÇALMA LİSTESİ"
            val badgeTextWidth = badgeTextPaint.measureText(badgeText)
            val badgeBox = RectF((W - badgeTextWidth) / 2f - 28f, 260f, (W + badgeTextWidth) / 2f + 28f, 328f)
            c.drawRoundRect(badgeBox, 34f, 34f, badgePaint)
            c.drawText(badgeText, (W - badgeTextWidth) / 2f, 307f, badgeTextPaint)

            // 900x900 Kare Kapak
            val maxW = 860f
            val maxH = 860f
            val left = (W - maxW) / 2f
            val top = 380f
            val box = RectF(left, top, left + maxW, top + maxH)
            val path = Path().apply { addRoundRect(box, 40f, 40f, Path.Direction.CW) }
            c.save()
            c.clipPath(path)
            val bmp = cover
            if (bmp != null) {
                val imgW = bmp.width.toFloat()
                val imgH = bmp.height.toFloat()
                val scale = maxOf(maxW / imgW, maxH / imgH)
                val drawW = imgW * scale
                val drawH = imgH * scale
                val drawLeft = left + (maxW - drawW) / 2f
                val drawTop = top + (maxH - drawH) / 2f
                c.drawBitmap(bmp, null, RectF(drawLeft, drawTop, drawLeft + drawW, drawTop + drawH), p)
            } else {
                p.color = AColor.argb(80, 41, 121, 255)
                c.drawRect(box, p)
                val iconPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = AColor.WHITE
                    textSize = 180f
                    textAlign = Paint.Align.CENTER
                }
                c.drawText("🎶", left + maxW / 2f, top + maxH / 2f + 60f, iconPaint)
            }
            c.restore()

            // Liste başlığı ve alt açıklama
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.WHITE
                textSize = 62f
                typeface = Typeface.DEFAULT_BOLD
            }
            val subtitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.argb(210, 255, 255, 255)
                textSize = 42f
            }
            val brandPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.argb(200, 255, 255, 255)
                textSize = 38f
                typeface = Typeface.DEFAULT_BOLD
            }

            val textLeft = left
            c.drawText(TextUtils.ellipsize(info.title, titlePaint, maxW, TextUtils.TruncateAt.END).toString(), textLeft, top + maxH + 110f, titlePaint)
            c.drawText(TextUtils.ellipsize(info.subtitle, subtitlePaint, maxW, TextUtils.TruncateAt.END).toString(), textLeft, top + maxH + 180f, subtitlePaint)

            // Sounddeep logosu ve marka metni
            val logoRadius = 28f
            val logoCenterY = H - 130f
            val logoCenterX = textLeft + logoRadius

            val logoBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    logoCenterX - logoRadius, logoCenterY - logoRadius,
                    logoCenterX + logoRadius, logoCenterY + logoRadius,
                    0xFF2979FF.toInt(), 0xFF1565C0.toInt(), Shader.TileMode.CLAMP
                )
            }
            c.drawCircle(logoCenterX, logoCenterY, logoRadius, logoBgPaint)

            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.argb(70, 255, 255, 255)
                style = Paint.Style.STROKE
                strokeWidth = 2f
            }
            c.drawCircle(logoCenterX, logoCenterY, logoRadius * 0.92f, borderPaint)

            val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AColor.WHITE
                strokeWidth = 3.5f
                strokeCap = Paint.Cap.ROUND
            }
            val barHeights = floatArrayOf(6f, 12f, 18f, 12f, 6f)
            for (idx in barHeights.indices) {
                val bx = logoCenterX + (idx - 2) * 6.5f
                val hHalf = barHeights[idx]
                c.drawLine(bx, logoCenterY - hHalf, bx, logoCenterY + hHalf, barPaint)
            }

            c.drawText("Sounddeep", logoCenterX + logoRadius + 20f, logoCenterY + 13f, brandPaint)

            val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 60 * 60_000L }?.forEach { it.delete() }
            val file = File(dir, "playlist_${System.currentTimeMillis()}.png")
            file.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            file
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    /** WhatsApp, Instagram veya Sistem Paylaşımına gönderir */
    fun send(ctx: Context, target: ShareTarget, info: PlaylistShareInfo, card: File?) {
        val (webLink, _) = links(info)
        val shareText = text(info)
        val intent = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, shareText)
            putExtra(Intent.EXTRA_SUBJECT, info.title)
            if (card != null) {
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.shareprovider", card)
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("Sounddeep", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else type = "text/plain"
        }

        try {
            when (target) {
                ShareTarget.WHATSAPP -> {
                    val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(ctx, it) }
                    if (pkg == null) {
                        Toast.makeText(ctx, "WhatsApp yüklü değil", Toast.LENGTH_SHORT).show()
                        return
                    }
                    ctx.startActivity(intent.setPackage(pkg))
                }
                ShareTarget.INSTAGRAM -> {
                    if (!installed(ctx, "com.instagram.android")) {
                        Toast.makeText(ctx, "Instagram yüklü değil", Toast.LENGTH_SHORT).show()
                        return
                    }
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
                        ?.setPrimaryClip(ClipData.newPlainText("Çalma listesi bağlantısı", webLink))
                    Toast.makeText(ctx, "Kapak hazır! Liste bağlantısı panoya kopyalandı, Instagram hikayene ekleyebilirsin", Toast.LENGTH_LONG).show()
                    ctx.startActivity(intent.setPackage("com.instagram.android"))
                }
                ShareTarget.OTHER -> {
                    ctx.startActivity(Intent.createChooser(intent, "Çalma listesini paylaş"))
                }
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun installed(ctx: Context, pkg: String) = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }
}

/** Paylaşım Penceresi: WhatsApp, Instagram ve Bağlantı Kopyalama seçenekleri */
@Composable
fun SharePlaylistDialog(info: PlaylistShareInfo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    fun shareTo(target: ShareTarget) {
        if (busy) return
        busy = true
        scope.launch {
            val card = SharePlaylist.card(ctx, info)
            SharePlaylist.send(ctx, target, info, card)
            busy = false
            onDismiss()
        }
    }

    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(Card)
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Önizleme kapak
            Box(
                Modifier
                    .size(110.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                if (!info.cover.isNullOrBlank()) {
                    AsyncImage(
                        model = if (info.cover.startsWith("content://") || info.cover.startsWith("file://")) info.cover else (hiRes(info.cover, 300) ?: info.cover),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Filled.Share, null, tint = Accent, modifier = Modifier.size(44.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(info.subtitle, color = Color.Gray, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)

            Spacer(Modifier.height(20.dp))
            if (busy) {
                CircularProgressIndicator(color = Accent, modifier = Modifier.size(36.dp), strokeWidth = 3.dp)
                Spacer(Modifier.height(12.dp))
                Text("Paylaşım görseli ve bağlantı hazırlanıyor...", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            } else {
                // WhatsApp Butonu
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF25D366).copy(alpha = 0.15f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { shareTo(ShareTarget.WHATSAPP) }
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF25D366)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Chat, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("WhatsApp'ta Paylaş", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Kapak kartı ve dinleme bağlantısı ile", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Instagram Butonu
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFE1306C).copy(alpha = 0.15f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { shareTo(ShareTarget.INSTAGRAM) }
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(
                                Brush.linearGradient(listOf(Color(0xFF833AB4), Color(0xFFFD1D1D), Color(0xFFFCAF45)))
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.CameraAlt, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Instagram Hikayede Paylaş", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("9:16 özel story kapağı ve bağlantı etiketi", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Bağlantıyı Kopyala Butonu
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.06f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable {
                            val (webLink, _) = SharePlaylist.links(info)
                            val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            cb?.setPrimaryClip(ClipData.newPlainText(info.title, webLink))
                            Toast.makeText(ctx, "Liste bağlantısı kopyalandı", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.ContentCopy, null, tint = Accent, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(14.dp))
                        Text("Bağlantıyı Kopyala", fontWeight = FontWeight.Medium, color = Color.White, modifier = Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Diğer Uygulamalar
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.06f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { shareTo(ShareTarget.OTHER) }
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.MoreHoriz, null, tint = Color.LightGray, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(14.dp))
                        Text("Diğer Uygulamalar", fontWeight = FontWeight.Medium, color = Color.White, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
