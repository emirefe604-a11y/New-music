package com.example.newmusic

import java.util.Locale

/**
 * Aynı veya aşırı benzer şarkı isimlerini (remix, cover, akustik, speed up vb.)
 * tespit eder; böylece bir şarkı açıldığında peş peşe aynı şarkının farklı
 * versiyonlarının çalması kesin olarak engellenir.
 */
object TitleDeduplicator {
    private val tagRegex = Regex(
        """[\(\[\{【「].*?[\)\]\}】」]|(?:ft\.?|feat\.?|remix|cover|akustik|acoustic|slowed|reverb|speed\s*up|sped\s*up|versiyon|version|karaoke|canlı|live|official|lyric|lyrics|sözleri|video|klip|audio|hd|hq)""",
        RegexOption.IGNORE_CASE
    )
    private val punctRegex = Regex("""[^\p{L}\p{N}\s]""")

    fun clean(title: String): String {
        return title
            .replace(tagRegex, " ")
            .replace(punctRegex, " ")
            .lowercase(Locale("tr"))
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    /** İki şarkının aynı temel parçaya ait olup olmadığını tespit eder */
    fun isSimilar(title1: String, title2: String): Boolean {
        val c1 = clean(title1)
        val c2 = clean(title2)
        if (c1.isBlank() || c2.isBlank()) return false
        if (c1 == c2) return true
        if (c1.length >= 4 && c2.length >= 4) {
            if (c1.startsWith(c2) || c2.startsWith(c1)) return true
        }
        val w1 = c1.split(" ").filter { it.length > 1 }.toSet()
        val w2 = c2.split(" ").filter { it.length > 1 }.toSet()
        if (w1.isNotEmpty() && w2.isNotEmpty()) {
            val intersection = w1.intersect(w2).size
            val union = w1.union(w2).size
            if (union > 0 && (intersection.toFloat() / union) >= 0.60f) return true
        }
        return false
    }

    /** Bir listeyi isim benzerliğine göre süzer; aynı şarkının tekrarlarını eler */
    fun distinctSimilar(songs: List<Song>): List<Song> {
        val result = ArrayList<Song>()
        for (s in songs) {
            if (result.none { isSimilar(it.title, s.title) }) {
                result.add(s)
            }
        }
        return result
    }
}
