package com.example.newmusic

/**
 * Yapay zeka ile üretilmiş şarkıları (Suno / Udio, "AI cover" vb.) tanır; arama, liste ve önerilerde gösterilmez.
 * Tanıma başlık ve sanatçı adındaki ipuçlarına bakar; kesin değildir ama bilinen kalıpları yakalar.
 */
object AiFilter {
    private val hints = Regex(
        "yapay\\s*zek|artificial\\s*intelligence|" +
            "\\ba\\.i\\.?\\s*(cover|generated|song|music|voice|remix)|" +
            "\\bai[\\s\\-_]?(generated|cover|covers|song|songs|music|voice|vocal|vocals|remix|version|mix|made|lyrics|produced|singer|sings|singing|artist|track|rap)|" +
            "\\b(generated|made|created|produced|sung|covered|written|composed|remade)\\s+(with|by|using|via)\\s+(an?\\s+)?(ai|a\\.i\\.|suno|udio)\\b|" +
            "\\bsuno(\\s?ai)?\\b|\\budio\\b|\\brvc\\b|so-?vits|\\bdeepfake\\b|\\bai\\s*\\)|\\(\\s*ai\\b|\\[\\s*ai\\b",
        RegexOption.IGNORE_CASE
    )

    /** Büyük harfle tek başına yazılmış "AI" ((AI), - AI, AI Cover ...). Küçük "ai" kelimeleri (j'ai, ai confini) etkilenmez. */
    private val upperAi = Regex("(?<![A-Za-z0-9'’])AI(?![A-Za-z0-9'’])")

    fun isAi(title: String, artist: String = ""): Boolean {
        if (hints.containsMatchIn(title) || hints.containsMatchIn(artist)) return true
        if (upperAi.containsMatchIn(title)) return true
        // "AI" adlı gerçek sanatçı olabilir; sanatçı adı yalnızca "AI" ise sayma. "Xyz AI" gibi kanal adları AI sayılır.
        val a = artist.trim()
        return a.length > 2 && upperAi.containsMatchIn(a)
    }

    fun isAi(s: Song): Boolean = isAi(s.title, s.artist)
}

/** Yapay zeka şarkılarını listeden çıkarır. */
fun List<Song>.noAi(): List<Song> = filterNot { AiFilter.isAi(it) }
