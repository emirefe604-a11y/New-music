package com.example.newmusic

import java.util.Locale

/**
 * Yapay zeka ile üretilmiş şarkıları (Suno / Udio, "AI cover", "RVC", "Diff-SVC" vb.)
 * tespit eder ve tamamen filtreler. Arama, Ana Sayfa, Keşfet, Listeler ve Kuyrukta asla gösterilmez.
 */
object AiFilter {
    private val aiKeywords = listOf(
        "suno", "suno.ai", "suno ai", "suno v3", "suno v4",
        "udio", "udio.ai", "udio ai", "udio v1",
        "yapay zeka", "yapay zekâ", "yapayzeka",
        "ai cover", "ai covers", "ai song", "ai songs", "ai music",
        "ai şarkı", "ai şarkıları", "ai versiyon", "ai version",
        "ai remix", "ai vocal", "ai vocals", "ai voice", "ai ses",
        "ai beat", "ai produced", "ai generated", "ai düet", "ai duet",
        "rvc", "rvc v2", "rvc cover", "rvc model",
        "so-vits", "sovits", "so-vits-svc", "diff-svc",
        "deepfake", "deepfake voice", "voice clone", "ses klonlama",
        "elevenlabs", "text to song", "text to music",
        "chatgpt", "gpt-4", "gpt cover"
    )

    private val regexPattern = Regex(
        """(?i)(?:""" +
            """\b(?:suno|udio|rvc|sovits|so-vits|diff-svc|deepfake|elevenlabs)\b|""" +
            """\b(?:yapay\s*zek[aâ]|artificial\s*intelligence)\b|""" +
            """\ba[\s._-]?i\s*(?:cover|generated|music|song|voice|vocal|remix|version|mix|made|rap|beat|model|düet|duet|şarkı)|""" +
            """(?:cover|generated|remix|music|song|voice|vocal|beat|düet|duet)[\s._-]+a[\s._-]?i\b|""" +
            """[\(\[\{【「]\s*a[\s._-]?i\s*[\)\]\}】」]|""" +
            """(?:feat\.?|ft\.?)\s*a[\s._-]?i\b|\ba[\s._-]?i\s*(?:feat\.?|ft\.?)""" +
            """)"""
    )

    /** Tek başına büyük harfle yazılmış "AI" kelimesi ((AI), - AI, AI...) */
    private val isolatedAi = Regex("""(?<![A-Za-z0-9'’])AI(?![A-Za-z0-9'’])""")

    fun isAi(title: String, artist: String = ""): Boolean {
        val tLower = title.lowercase(Locale("tr"))
        val aLower = artist.lowercase(Locale("tr"))

        // 1. Anahtar kelime taraması
        for (kw in aiKeywords) {
            if (tLower.contains(kw) || aLower.contains(kw)) return true
        }

        // 2. Kapsamlı Regex deseni
        if (regexPattern.containsMatchIn(title) || regexPattern.containsMatchIn(artist)) return true

        // 3. İzole büyük harf AI kontrolü
        if (isolatedAi.containsMatchIn(title)) return true
        val trimmedArtist = artist.trim()
        if (trimmedArtist.length > 2 && isolatedAi.containsMatchIn(trimmedArtist)) return true

        return false
    }

    fun isAi(s: Song): Boolean = isAi(s.title, s.artist)
}

/** Yapay zeka şarkılarını listeden tamamen temizler */
fun List<Song>.noAi(): List<Song> = filterNot { AiFilter.isAi(it) }
