package com.example.newmusic

import java.util.Locale

/**
 * Yapay zeka ile üretilmiş şarkıları (Suno / Udio, "AI cover", "RVC", "Diff-SVC", "Yapay Zeka" vb.)
 * tespit eder ve tamamen filtreler. Arama, Ana Sayfa, Keşfet, Listeler ve Kuyrukta asla gösterilmez.
 */
object AiFilter {
    private fun normalize(s: String): String =
        s.lowercase(Locale.ROOT)
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ç', 'c')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')

    private val aiKeywords = listOf(
        "suno", "suno.ai", "suno ai", "suno v3", "suno v4",
        "udio", "udio.ai", "udio ai", "udio v1", "udio v2",
        "yapay zeka", "yapay zekâ", "yapayzeka", "yapay zeka cover", "yapay zeka sarki", "yapay zeka muzik",
        "ai cover", "ai covers", "ai sarki", "ai sarkilari", "ai versiyon", "ai version",
        "ai remix", "ai vocal", "ai vocals", "ai voice", "ai ses", "ai sesli",
        "ai beat", "ai produced", "ai generated", "ai duet", "ai dueti", "ai sanatci",
        "rvc", "rvc v2", "rvc cover", "rvc model",
        "so-vits", "sovits", "so-vits-svc", "diff-svc", "diffsvc",
        "deepfake", "deepfake voice", "voice clone", "ses klon", "ses klonlama",
        "elevenlabs", "text to song", "text to music",
        "chatgpt", "gpt-4", "gpt cover", "voicify", "jammable", "weights.gg", "kits.ai", "musicfy", "covers.ai",
        "artificial intelligence"
    )

    private val regexPattern = Regex(
        """(?i)(?:""" +
            """\b(?:suno|udio|rvc|sovits|so-vits|diff-svc|diffsvc|deepfake|elevenlabs|voicify|jammable|musicfy)\b|""" +
            """\b(?:yapay\s*zek[aâ]|artificial\s*intelligence)\b|""" +
            """\ba[\s._-]?i\s*(?:cover|generated|music|song|voice|vocal|remix|version|mix|made|rap|beat|model|duet|dueti|sarki|sanatci|edit)|""" +
            """(?:cover|generated|remix|music|song|voice|vocal|beat|duet|dueti|sarki)[\s._-]+a[\s._-]?i\b|""" +
            """[\(\[\{【「]\s*(?:a[\s._-]?i|yapay\s*zek[aâ])\s*[\)\]\}】」]|""" +
            """(?:feat\.?|ft\.?)\s*a[\s._-]?i\b|\ba[\s._-]?i\s*(?:feat\.?|ft\.?)|""" +
            """\b(?:ai)\s+(?:model|cover|remix|voice|vocal|song|track)\b""" +
            """)"""
    )

    private val bracketedAi = Regex("""(?i)[\(\[\{【「]\s*a[\s._-]?i\s*[\)\]\}】」]""")
    private val isolatedArtistAi = Regex("""(?i)\ba[\s._-]?i\b""")

    fun isAi(title: String, artist: String = ""): Boolean {
        val tNorm = normalize(title)
        val aNorm = normalize(artist)

        // 1. Anahtar kelime taraması (Suno, Udio, Yapay Zeka, AI Cover vb.)
        for (kw in aiKeywords) {
            if (tNorm.contains(kw) || aNorm.contains(kw)) return true
        }

        // 2. Kapsamlı Regex deseni
        if (regexPattern.containsMatchIn(tNorm) || regexPattern.containsMatchIn(aNorm)) return true

        // 3. Parantez içi AI kontrolü ((AI), [AI] vb.)
        if (bracketedAi.containsMatchIn(tNorm)) return true

        // 4. Sanatçı adında tek başına AI kontrolü
        val aTrimmed = aNorm.trim()
        if (aTrimmed.length in 2..15 && isolatedArtistAi.containsMatchIn(aTrimmed)) return true

        return false
    }

    fun isAi(s: Song): Boolean = isAi(s.title, s.artist)
}

/** Yapay zeka şarkılarını listeden tamamen temizler */
fun List<Song>.noAi(): List<Song> = filterNot { AiFilter.isAi(it) }
