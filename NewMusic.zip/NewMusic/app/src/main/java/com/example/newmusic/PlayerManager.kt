package com.example.newmusic

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray

/** Kuyruk, çalma durumu ve favoriler. Activity'den bağımsız yaşar; liste bitince benzer şarkılarla devam eder. */
object PlayerManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private lateinit var prefs: SharedPreferences
    private var job: Job? = null

    val queue = MutableStateFlow<List<Song>>(emptyList())
    val index = MutableStateFlow(-1)
    val playing = MutableStateFlow(false)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val favorites = MutableStateFlow<List<Song>>(emptyList())
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(0) // 0 kapalı, 1 liste, 2 tek şarkı
    private var attempt = 0

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { playing.value = isPlaying }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) {
                queue.value.getOrNull(index.value)?.let { TasteProfile.recordCompleted(it) }
                if (repeat.value == 2) playIndex(index.value, true) else next()
            }
        }
        override fun onPlayerError(e: PlaybackException) {
            // Engellenirse: bağlantıyı yeniden al, diğer akışı dene, kaldığı yerden devam et
            if (attempt < 3 && index.value >= 0) {
                if (attempt == 0) queue.value.getOrNull(index.value)?.let { MusicRepository.invalidate(it.url) }
                attempt++
                playIndex(index.value, true, retry = true, resume = controller?.currentPosition ?: 0L)
            } else {
                loading.value = false
                error.value = "Oynatma hatası: ${e.errorCodeName} ${e.cause?.message ?: ""}".trim()
                attempt = 0
                next()
            }
        }
    }

    fun connect(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        favorites.value = loadFavs()
        Downloads.init(app)
        TasteProfile.init(app)
        val f = MediaController.Builder(
            app, SessionToken(app, ComponentName(app, PlaybackService::class.java))
        ).buildAsync()
        future = f
        f.addListener({
            try { controller = f.get().also { it.addListener(listener) } }
            catch (e: Exception) { error.value = "Oynatıcı başlatılamadı" }
        }, ContextCompat.getMainExecutor(app))
    }

    fun position(): Long = controller?.currentPosition ?: 0L
    fun duration(): Long = (controller?.duration ?: 0L).coerceAtLeast(0L)
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }

    fun playQueue(list: List<Song>, start: Int) {
        queue.value = list
        playIndex(start, false)
    }

    fun playIndex(i: Int, auto: Boolean = false, retry: Boolean = false, resume: Long = 0L) {
        val q = queue.value
        if (i !in q.indices) return
        if (!retry) attempt = 0
        index.value = i; error.value = null; loading.value = true
        job?.cancel()
        job = scope.launch {
            try {
                val s = q[i]
                // İndirilmişse internetsiz, yerel dosyadan çal
                val local = Downloads.localFile(s)
                val url = if (local != null) Uri.fromFile(local).toString() else {
                    val urls = MusicRepository.audioUrls(s.url)
                    if (urls.isEmpty()) throw Exception("Ses akışı bulunamadı")
                    urls[attempt % urls.size]
                }
                if (!retry) TasteProfile.recordPlay(s)
                controller?.run {
                    setMediaItem(
                        MediaItem.Builder().setUri(url).setMediaMetadata(
                            MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist)
                                .setArtworkUri(hiRes(s.thumb)?.let { Uri.parse(it) }).build()
                        ).build(),
                        resume
                    )
                    prepare(); play()
                }
                // Sıradaki şarkının adresini şimdiden al: geçiş anında bekleme olmasın
                if (!shuffle.value) q.getOrNull(i + 1)?.let { n ->
                    if (Downloads.localFile(n) == null) MusicRepository.prefetch(n.url)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error.value = e.message ?: "Çalma hatası"
                if (auto) { loading.value = false; next() ; return@launch }
            }
            loading.value = false
        }
    }

    /** Kalite değişince çalan şarkıyı aynı yerden yeni kaliteyle yeniden başlatır. */
    fun reloadCurrent() {
        if (queue.value.isEmpty()) return
        attempt = 0
        playIndex(index.value, true, retry = true, resume = position())
    }

    fun next(auto: Boolean = true) {
        scope.launch {
            val i = index.value
            val size = queue.value.size
            if (shuffle.value && size > 1) {
                var r = i
                while (r == i) r = (0 until size).random()
                playIndex(r, auto); return@launch
            }
            if (i + 1 < size) { playIndex(i + 1, auto); return@launch }
            if (repeat.value == 1) { playIndex(0, auto); return@launch }
            if (!AppSettings.autoplay.value) { controller?.pause(); return@launch } // otomatik devam kapalı
            val cur = queue.value.getOrNull(i) ?: return@launch
            try {
                val more = MusicRepository.related(cur.url)
                    .filter { r -> queue.value.none { it.url == r.url } }
                if (more.isNotEmpty()) { queue.value = queue.value + more; playIndex(i + 1, auto) }
                else playIndex(0, auto)
            } catch (e: Exception) { playIndex(0, auto) }
        }
    }

    fun toggleShuffle() { shuffle.value = !shuffle.value }
    fun cycleRepeat() { repeat.value = (repeat.value + 1) % 3 }

    fun prev() {
        if (position() > 3000) { seekTo(0); return }
        playIndex(maxOf(0, index.value - 1), false)
    }

    fun isFav(s: Song) = favorites.value.any { it.url == s.url }

    fun toggleFav(s: Song) {
        if (!isFav(s)) TasteProfile.recordFav(s)
        favorites.value = if (isFav(s)) favorites.value.filter { it.url != s.url } else listOf(s) + favorites.value
        prefs.edit().putString("favs", favorites.value.toJsonArray().toString()).apply()
    }

    private fun loadFavs(): List<Song> = try {
        JSONArray(prefs.getString("favs", "[]")).toSongs()
    } catch (e: Exception) { emptyList() }
}
