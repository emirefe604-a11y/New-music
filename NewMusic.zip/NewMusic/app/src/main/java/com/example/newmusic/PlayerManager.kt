package com.example.newmusic

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

/** Kuyruk, çalma durumu ve favoriler. Activity'den bağımsız yaşar; liste bitince benzer şarkılarla devam eder. */
object PlayerManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private lateinit var prefs: SharedPreferences
    private var appCtx: Context? = null
    private var job: Job? = null
    private var nextJob: Job? = null
    private var autoQueueJob: Job? = null

    val queue = MutableStateFlow<List<Song>>(emptyList())
    val index = MutableStateFlow(-1)
    val playing = MutableStateFlow(false)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val favorites = MutableStateFlow<List<Song>>(emptyList())
    val dislikes = MutableStateFlow<Set<String>>(emptySet())
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(0) // 0 kapalı, 1 liste, 2 tek şarkı
    private var attempt = 0

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playing.value = isPlaying
            if (isPlaying) QuickLaunch.hide()
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            // Ekran kapalıyken veya açıkken otomatik kesintisiz (soluksuz) geçiş
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                val q = queue.value
                val cur = index.value
                val nextIdx = if (repeat.value == 1 && cur + 1 >= q.size) 0 else cur + 1
                if (nextIdx in q.indices) {
                    index.value = nextIdx
                    q.getOrNull(nextIdx)?.let {
                        TasteProfile.recordPlay(it)
                        ensureAutoQueue(it)
                    }
                    queueNextTrack(nextIdx)
                }
            }
        }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) {
                queue.value.getOrNull(index.value)?.let { TasteProfile.recordCompleted(it) }
                if (repeat.value == 2) playIndex(index.value, true)
                else if ((controller?.mediaItemCount ?: 0) <= 1) next()
            }
        }
        override fun onPlayerError(e: PlaybackException) {
            if (attempt < 3 && index.value >= 0) {
                if (attempt == 0) queue.value.getOrNull(index.value)?.let { MusicRepository.invalidate(it.url) }
                attempt++
                playIndex(index.value, true, retry = true, resume = controller?.currentPosition ?: 0L)
            } else {
                loading.value = false
                error.value = "Oynatma hatası: ${e.errorCodeName} ${e.cause?.message ?: ""}".trim()
                attempt = 0
                next()
            }
        }
    }

    fun connect(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        appCtx = app
        prefs = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        favorites.value = loadFavs()
        dislikes.value = prefs.getStringSet("dislikes", emptySet())?.toSet() ?: emptySet()
        Downloads.init(app)
        TasteProfile.init(app)
        val f = MediaController.Builder(
            app, SessionToken(app, ComponentName(app, PlaybackService::class.java))
        ).buildAsync()
        future = f
        f.addListener({
            try { controller = f.get().also { it.addListener(listener) } }
            catch (e: Exception) { error.value = "Oynatıcı başlatılamadı" }
        }, ContextCompat.getMainExecutor(app))
    }

    fun position(): Long = controller?.currentPosition ?: 0L
    fun duration(): Long = (controller?.duration ?: 0L).coerceAtLeast(0L)
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    private var fadeJob: Job? = null

    /** Spotify benzeri pürüzsüz durdurma (sessizleşerek durma) ve yumuşak başlatma */
    fun togglePlay() {
        val c = controller ?: return
        fadeJob?.cancel()
        if (c.isPlaying) {
            // Sessizleşerek durma (smooth fade-out ~240 ms)
            fadeJob = scope.launch {
                try {
                    val steps = 8
                    val delayMs = 30L
                    for (step in 1..steps) {
                        val v = 1f - (step.toFloat() / steps)
                        try { c.volume = v.coerceIn(0f, 1f) } catch (_: Exception) {}
                        delay(delayMs)
                    }
                    c.pause()
                } catch (_: Exception) {
                    c.pause()
                } finally {
                    try { c.volume = 1f } catch (_: Exception) {}
                }
            }
        } else {
            // Yumuşak açılma (smooth fade-in ~125 ms)
            fadeJob = scope.launch {
                try {
                    try { c.volume = 0.15f } catch (_: Exception) {}
                    c.play()
                    val steps = 5
                    val delayMs = 25L
                    for (step in 1..steps) {
                        val v = 0.15f + 0.85f * (step.toFloat() / steps)
                        try { c.volume = v.coerceIn(0f, 1f) } catch (_: Exception) {}
                        delay(delayMs)
                    }
                } catch (_: Exception) {
                    try { c.volume = 1f } catch (_: Exception) {}
                    c.play()
                }
            }
        }
    }

    /** Sessizleşerek durdurur */
    fun smoothPause(onDone: (() -> Unit)? = null) {
        val c = controller ?: return
        if (!c.isPlaying) { onDone?.invoke(); return }
        fadeJob?.cancel()
        fadeJob = scope.launch {
            try {
                val steps = 8
                val delayMs = 30L
                for (step in 1..steps) {
                    val v = 1f - (step.toFloat() / steps)
                    try { c.volume = v.coerceIn(0f, 1f) } catch (_: Exception) {}
                    delay(delayMs)
                }
                c.pause()
            } catch (_: Exception) {
                c.pause()
            } finally {
                try { c.volume = 1f } catch (_: Exception) {}
                onDone?.invoke()
            }
        }
    }

    /** Arama kısmından şarkı açıldığında: sonraki şarkıları kullanıcının zevkine göre karışık kurar ve benzer isimli/yapay zeka şarkılarını eler */
    fun playFromSearch(clickedSong: Song, allResults: List<Song> = emptyList()) {
        scope.launch(Dispatchers.IO) {
            val candidatePool = ArrayList<Song>()

            // 1. Kullanıcı zevkine göre sanatçılardan rastgele şarkılar (TasteProfile)
            val tasteArtists = TasteProfile.topArtists(8).filter { it.isNotBlank() }
            if (tasteArtists.isNotEmpty()) {
                val picks = tasteArtists.shuffled().take(3)
                for (a in picks) {
                    try {
                        val s = MusicRepository.search(a, persist = false).noAi()
                        candidatePool.addAll(s.shuffled().take(4))
                    } catch (_: Exception) {}
                }
            }

            // 2. Çalan şarkıya benzer parçalar (YouTube Related)
            if (!Uploads.isLocal(clickedSong) && !clickedSong.url.startsWith("local://")) {
                try {
                    val rel = MusicRepository.related(clickedSong.url).noAi()
                    candidatePool.addAll(rel)
                } catch (_: Exception) {}
            }

            // 3. Genel trend Türkçe parçalar
            try {
                val trend = MusicRepository.search("Türkiye en çok dinlenen Türkçe şarkılar", persist = false).noAi()
                candidatePool.addAll(trend.shuffled().take(8))
            } catch (_: Exception) {}

            // 4. Arama sonuçlarındaki diğer şarkılar (karıştırılmış)
            val otherSearch = allResults
                .filter { it.url != clickedSong.url && !AiFilter.isAi(it) && !TasteProfile.isDisliked(it) }
                .shuffled().take(6)
            candidatePool.addAll(otherSearch)

            // Tüm havuzu karıştır (shuffle)
            val shuffledPool = candidatePool.shuffled()

            // 5. Benzer isimli şarkıları ve yapay zeka içeriklerini kesinlikle ele
            val finalQueue = ArrayList<Song>()
            finalQueue.add(clickedSong)

            for (cand in shuffledPool) {
                if (cand.url == clickedSong.url) continue
                if (AiFilter.isAi(cand)) continue
                if (TasteProfile.isDisliked(cand)) continue
                if (isDisliked(cand)) continue
                // Başlık benzerliği kontrolü (aynı isimli remix, cover vb. elenir)
                if (finalQueue.any { TitleDeduplicator.isSimilar(it.title, cand.title) }) continue

                finalQueue.add(cand)
                if (finalQueue.size >= 30) break
            }

            withContext(Dispatchers.Main) {
                playQueue(finalQueue, 0)
                MusicRepository.prefetchAll(finalQueue.drop(1), 8)
            }
        }
    }

    fun playQueue(list: List<Song>, start: Int) {
        queue.value = list
        // Spotify mimarisi: Sıradaki şarkıları arka planda hemen önceden çöz ve hazırla
        MusicRepository.prefetchAll(list.drop(start), 10)
        playIndex(start, false)
    }

    fun playIndex(i: Int, auto: Boolean = false, retry: Boolean = false, resume: Long = 0L) {
        val q = queue.value
        if (i !in q.indices) return
        if (!retry) attempt = 0
        index.value = i; error.value = null; loading.value = true
        job?.cancel()
        nextJob?.cancel()

        job = scope.launch {
            try {
                val s = q[i]
                val local = if (Uploads.isLocal(s)) (Uploads.file(s) ?: throw Exception("Yüklenen dosya bulunamadı"))
                else Downloads.localFile(s)
                val url = if (local != null) Uri.fromFile(local).toString() else {
                    val urls = MusicRepository.audioUrls(s.url, highPriority = true)
                    if (urls.isEmpty()) throw Exception("Ses akışı bulunamadı")
                    urls[attempt % urls.size]
                }
                if (!retry) TasteProfile.recordPlay(s)

                val artworkUri = hiRes(s.thumb)?.let { Uri.parse(it) }
                    ?: appCtx?.let { Uri.parse("android.resource://${it.packageName}/drawable/ic_sounddeep_logo") }
                val meta = MediaMetadata.Builder()
                    .setTitle(s.title)
                    .setDisplayTitle(s.title)
                    .setArtist(s.artist)
                    .setAlbumArtist(s.artist)
                    .setArtworkUri(artworkUri)
                    .build()
                val item = MediaItem.Builder()
                    .setUri(url)
                    .setMediaId(s.url)
                    .setCustomCacheKey(s.url) // Spotify yerel disk önbellek anahtarı: tekrar açıldığında 0 ms'de çalar
                    .setMediaMetadata(meta)
                    .build()

                controller?.run {
                    setMediaItem(item, resume)
                    prepare()
                    play()
                }

                // Çalan şarkıya benzer veya dinleme zevkine göre şarkıları arka planda kuyruğa ekle
                ensureAutoQueue(s)

                // Ekran kapalıyken soluksuz geçiş için sıradaki parçayı ExoPlayer kuyruğuna önden ekle
                queueNextTrack(i)

                // Sıradaki şarkıların adresini arka planda önceden al: geçiş anında bekleme olmasın
                if (!shuffle.value) for (k in 1..4) q.getOrNull(i + k)?.let { n ->
                    if (!Uploads.isLocal(n) && Downloads.localFile(n) == null) MusicRepository.prefetch(n.url)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error.value = e.message ?: "Çalma hatası"
                if (auto) { loading.value = false; next() ; return@launch }
            }
            loading.value = false
        }
    }

    /** Sıradaki parçayı ExoPlayer'a önceden ekleyerek ekran kapalıyken de sıfır gecikmeli (soluksuz) geçiş sağlar */
    private fun queueNextTrack(currentIndex: Int) {
        nextJob?.cancel()
        val q = queue.value
        val nextIdx = if (repeat.value == 1 && currentIndex + 1 >= q.size) 0 else currentIndex + 1
        if (nextIdx !in q.indices || repeat.value == 2) {
            if (repeat.value != 2) q.getOrNull(currentIndex)?.let { ensureAutoQueue(it) }
            return
        }
        val nextSong = q[nextIdx]
        nextJob = scope.launch {
            try {
                val local = if (Uploads.isLocal(nextSong)) Uploads.file(nextSong) else Downloads.localFile(nextSong)
                val url = if (local != null) Uri.fromFile(local).toString() else {
                    val urls = MusicRepository.audioUrls(nextSong.url)
                    if (urls.isNotEmpty()) urls[0] else null
                }
                if (url != null) {
                    val artworkUri = hiRes(nextSong.thumb)?.let { Uri.parse(it) }
                        ?: appCtx?.let { Uri.parse("android.resource://${it.packageName}/drawable/ic_sounddeep_logo") }
                    val meta = MediaMetadata.Builder()
                        .setTitle(nextSong.title)
                        .setDisplayTitle(nextSong.title)
                        .setArtist(nextSong.artist)
                        .setAlbumArtist(nextSong.artist)
                        .setArtworkUri(artworkUri)
                        .build()
                    val item = MediaItem.Builder()
                        .setUri(url)
                        .setMediaId(nextSong.url)
                        .setCustomCacheKey(nextSong.url)
                        .setMediaMetadata(meta)
                        .build()
                    controller?.let { c ->
                        if (c.mediaItemCount <= 1) {
                            c.addMediaItem(item)
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    /** Kalite değişince çalan şarkıyı aynı yerden yeni kaliteyle yeniden başlatır. */
    fun reloadCurrent() {
        if (queue.value.isEmpty()) return
        attempt = 0
        playIndex(index.value, true, retry = true, resume = position())
    }

    /** Şarkıdan sonra o şarkıya benzer veya kullanıcının dinleme zevkine göre rastgele şarkılar ekleyerek kesintisiz akışı sağlar */
    fun ensureAutoQueue(currentSong: Song) {
        if (!AppSettings.autoplay.value) return
        val q = queue.value
        val curIdx = index.value
        val remaining = if (curIdx in q.indices) (q.size - 1 - curIdx) else 0
        if (remaining >= 3) return // kuyrukta henüz yeterince şarkı var

        autoQueueJob?.cancel()
        autoQueueJob = scope.launch(Dispatchers.IO) {
            try {
                val existingUrls = queue.value.map { it.url }.toSet()
                val candidateSongs = ArrayList<Song>()

                // 1. Çalan şarkıya benzer parçalar (YouTube Related)
                if (!Uploads.isLocal(currentSong) && !currentSong.url.startsWith("local://")) {
                    try {
                        val rel = MusicRepository.related(currentSong.url)
                            .filter { it.url !in existingUrls && !TasteProfile.isDisliked(it) && !isDisliked(it) }
                        candidateSongs.addAll(rel)
                    } catch (_: Exception) {}
                }

                // 2. Kullanıcının dinleme zevkine göre (TasteProfile / En çok dinlenen sanatçılar)
                if (candidateSongs.size < 6) {
                    try {
                        val artists = TasteProfile.topArtists(8).filter { it.isNotBlank() }
                        if (artists.isNotEmpty()) {
                            val pick = artists.shuffled().take(2)
                            for (art in pick) {
                                val found = MusicRepository.search(art, persist = false)
                                    .filter { it.url !in existingUrls && it.url !in candidateSongs.map { s -> s.url } && !TasteProfile.isDisliked(it) && !isDisliked(it) }
                                candidateSongs.addAll(found.take(5))
                            }
                        }
                    } catch (_: Exception) {}
                }

                // 3. Genel Türkçe hit ve trend listesinden tamamla
                if (candidateSongs.size < 3) {
                    try {
                        val fallback = MusicRepository.search("Türkiye en çok dinlenen Türkçe şarkılar", persist = false)
                            .filter { it.url !in existingUrls && it.url !in candidateSongs.map { s -> s.url } }
                        candidateSongs.addAll(fallback.take(8))
                    } catch (_: Exception) {}
                }

                val existingTitles = queue.value.map { it.title }
                val distinctNew = candidateSongs
                    .filterNot { AiFilter.isAi(it) }
                    .filterNot { cand -> existingTitles.any { ex -> TitleDeduplicator.isSimilar(ex, cand.title) } }
                    .let { TitleDeduplicator.distinctSimilar(it) }
                if (distinctNew.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        val currentQ = queue.value
                        val updated = currentQ + distinctNew
                        queue.value = updated
                        val nowIdx = index.value
                        if (nowIdx in updated.indices) {
                            queueNextTrack(nowIdx)
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    fun next(auto: Boolean = true) {
        scope.launch {
            val i = index.value
            val size = queue.value.size
            if (shuffle.value && size > 1) {
                var r = i
                while (r == i) r = (0 until size).random()
                playIndex(r, auto); return@launch
            }
            if (i + 1 < size) { playIndex(i + 1, auto); return@launch }
            if (repeat.value == 1) { playIndex(0, auto); return@launch }
            if (!AppSettings.autoplay.value) { controller?.pause(); return@launch } // otomatik devam kapalı
            val cur = queue.value.getOrNull(i) ?: return@launch
            if (Uploads.isLocal(cur)) { playIndex(0, auto); return@launch }
            try {
                val more = try {
                    MusicRepository.related(cur.url).filter { r -> queue.value.none { it.url == r.url } && !TasteProfile.isDisliked(r) && !isDisliked(r) }
                } catch (_: Exception) { emptyList() }
                val tasteMore = if (more.size < 4) {
                    val artists = TasteProfile.topArtists(6).filter { it.isNotBlank() }
                    if (artists.isNotEmpty()) {
                        try {
                            MusicRepository.search(artists.shuffled().first(), persist = false)
                                .filter { r -> queue.value.none { it.url == r.url } && !TasteProfile.isDisliked(r) && !isDisliked(r) }
                        } catch (_: Exception) { emptyList() }
                    } else emptyList()
                } else emptyList()
                val finalMore = (more + tasteMore).distinctBy { it.url }.ifEmpty {
                    try {
                        MusicRepository.search("Türkiye en çok dinlenen Türkçe şarkılar", persist = false)
                            .filter { r -> queue.value.none { it.url == r.url } }
                    } catch (_: Exception) { emptyList() }
                }
                if (finalMore.isNotEmpty()) {
                    queue.value = queue.value + finalMore
                    playIndex(i + 1, auto)
                } else {
                    playIndex(0, auto)
                }
            } catch (e: Exception) { playIndex(0, auto) }
        }
    }

    fun toggleShuffle() { shuffle.value = !shuffle.value }
    fun cycleRepeat() { repeat.value = (repeat.value + 1) % 3 }

    fun prev() {
        if (position() > 3000) { seekTo(0); return }
        playIndex(maxOf(0, index.value - 1), false)
    }

    fun isLiked(s: Song) = favorites.value.any { it.url == s.url }
    fun isDisliked(s: Song) = dislikes.value.contains(s.url)

    /** Beğen: Şarkıyı favorilere alır ve o tarzdan/sanatçıdan benzer parçaları hemen sıraya ekler */
    fun likeSong(s: Song, onDone: ((String) -> Unit)? = null) {
        if (isFav(s)) {
            toggleFav(s)
            onDone?.invoke("Beğeni kaldırıldı")
            return
        }
        if (isDisliked(s)) {
            val updated = dislikes.value - s.url
            dislikes.value = updated
            prefs.edit().putStringSet("dislikes", updated).apply()
        }
        TasteProfile.recordLike(s)
        if (!isFav(s)) toggleFav(s)

        // Benzer şarkıları kuyrukta hemen arkaya ekle
        scope.launch(Dispatchers.IO) {
            try {
                val curIdx = index.value
                val q = queue.value
                val existing = q.map { it.url }.toSet()
                val related = try {
                    MusicRepository.related(s.url).filter { it.url !in existing && !TasteProfile.isDisliked(it) && !isDisliked(it) }
                } catch (_: Exception) { emptyList() }

                val artistSongs = if (s.artist.isNotBlank()) {
                    try {
                        MusicRepository.search(s.artist, persist = false)
                            .filter { it.url !in existing && it.url !in related.map { r -> r.url } && !TasteProfile.isDisliked(it) && !isDisliked(it) }
                            .take(5)
                    } catch (_: Exception) { emptyList() }
                } else emptyList()

                val similar = (related + artistSongs)
                    .filterNot { AiFilter.isAi(it) }
                    .filterNot { TitleDeduplicator.isSimilar(s.title, it.title) }
                    .let { TitleDeduplicator.distinctSimilar(it) }
                    .take(8)
                if (similar.isNotEmpty() && curIdx in q.indices) {
                    withContext(Dispatchers.Main) {
                        val currentQ = queue.value
                        val head = currentQ.take(curIdx + 1)
                        val tail = currentQ.drop(curIdx + 1)
                        val merged = head + similar + tail
                        queue.value = merged
                        queueNextTrack(curIdx)
                        MusicRepository.prefetchAll(similar, 6)
                    }
                }
            } catch (_: Exception) {}
        }
        onDone?.invoke("Beğenildi! Benzer şarkılar sıraya eklendi 🎵")
    }

    /** Beğenme: O şarkıyı ve sanatçıyı zevk profilinden düşürür, kuyruktan çıkarır ve sonrakine geçer */
    fun dislikeSong(s: Song, onDone: ((String) -> Unit)? = null) {
        if (isFav(s)) toggleFav(s)
        val updated = dislikes.value + s.url
        dislikes.value = updated
        prefs.edit().putStringSet("dislikes", updated).apply()
        TasteProfile.recordDislike(s)

        // O şarkıyı ve bu sanatçının sıradaki şarkılarını kuyruktan temizle
        val curIdx = index.value
        val q = queue.value
        if (curIdx in q.indices) {
            val head = q.take(curIdx + 1)
            val tail = q.drop(curIdx + 1).filterNot { it.url == s.url || TasteProfile.isDisliked(it) }
            queue.value = head + tail
        }
        onDone?.invoke("Beğenilmedi. Bu tarz şarkılar daha az önerilecek")
        // Çalan şarkıysa sonraki parçaya geç
        next(false)
    }

    fun isFav(s: Song) = favorites.value.any { it.url == s.url }

    fun toggleFav(s: Song) {
        if (!isFav(s)) TasteProfile.recordFav(s)
        favorites.value = if (isFav(s)) favorites.value.filter { it.url != s.url } else listOf(s) + favorites.value
        prefs.edit().putString("favs", favorites.value.toJsonArray().toString()).apply()
        LibrarySync.markDirty()
    }

    /** Hesaptan gelen beğenileri yazar (tekrar sunucuya göndermez). */
    fun replaceFavorites(list: List<Song>) {
        favorites.value = list
        if (::prefs.isInitialized) prefs.edit().putString("favs", list.toJsonArray().toString()).apply()
    }

    private fun loadFavs(): List<Song> = try {
        JSONArray(prefs.getString("favs", "[]")).toSongs()
    } catch (e: Exception) { emptyList() }
}
