package com.example.newmusic

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Kuyruk, çalma durumu ve favoriler. Activity'den bağımsız yaşar; liste bitince benzer şarkılarla devam eder. */
object PlayerManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private lateinit var prefs: SharedPreferences
    private var job: Job? = null

    val queue = MutableStateFlow<List<Song>>(emptyList())
    val index = MutableStateFlow(-1)
    val playing = MutableStateFlow(false)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val favorites = MutableStateFlow<List<Song>>(emptyList())

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { playing.value = isPlaying }
        override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) next() }
        override fun onPlayerError(e: PlaybackException) {
            loading.value = false
            error.value = "Oynatma hatası: ${e.errorCodeName}"
        }
    }

    fun connect(ctx: Context) {
        if (future != null) return
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        favorites.value = loadFavs()
        val f = MediaController.Builder(
            app, SessionToken(app, ComponentName(app, PlaybackService::class.java))
        ).buildAsync()
        future = f
        f.addListener({
            try { controller = f.get().also { it.addListener(listener) } }
            catch (e: Exception) { error.value = "Oynatıcı başlatılamadı" }
        }, ContextCompat.getMainExecutor(app))
    }

    fun position(): Long = controller?.currentPosition ?: 0L
    fun duration(): Long = (controller?.duration ?: 0L).coerceAtLeast(0L)
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun togglePlay() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }

    fun playQueue(list: List<Song>, start: Int) {
        queue.value = list
        playIndex(start, false)
    }

    fun playIndex(i: Int, auto: Boolean = false) {
        val q = queue.value
        if (i !in q.indices) return
        index.value = i; error.value = null; loading.value = true
        job?.cancel()
        job = scope.launch {
            try {
                val s = q[i]
                val url = MusicRepository.audioUrl(s.url) ?: throw Exception("Ses akışı bulunamadı")
                controller?.run {
                    setMediaItem(
                        MediaItem.Builder().setUri(url).setMediaMetadata(
                            MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist)
                                .setArtworkUri(s.thumb?.let { Uri.parse(it) }).build()
                        ).build()
                    )
                    prepare(); play()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error.value = e.message ?: "Çalma hatası"
                if (auto) { loading.value = false; next() ; return@launch }
            }
            loading.value = false
        }
    }

    fun next() {
        scope.launch {
            val i = index.value
            if (i + 1 < queue.value.size) { playIndex(i + 1, true); return@launch }
            val cur = queue.value.getOrNull(i) ?: return@launch
            try {
                val more = MusicRepository.related(cur.url)
                    .filter { r -> queue.value.none { it.url == r.url } }
                if (more.isNotEmpty()) { queue.value = queue.value + more; playIndex(i + 1, true) }
                else playIndex(0, true)
            } catch (e: Exception) { playIndex(0, true) }
        }
    }

    fun prev() {
        if (position() > 3000) { seekTo(0); return }
        playIndex(maxOf(0, index.value - 1), false)
    }

    fun isFav(s: Song) = favorites.value.any { it.url == s.url }

    fun toggleFav(s: Song) {
        favorites.value = if (isFav(s)) favorites.value.filter { it.url != s.url } else listOf(s) + favorites.value
        val a = JSONArray()
        favorites.value.forEach {
            a.put(JSONObject().put("t", it.title).put("a", it.artist).put("u", it.url).put("i", it.thumb ?: ""))
        }
        prefs.edit().putString("favs", a.toString()).apply()
    }

    private fun loadFavs(): List<Song> = try {
        val a = JSONArray(prefs.getString("favs", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Song(o.getString("t"), o.getString("a"), o.getString("u"), o.optString("i").ifEmpty { null })
        }
    } catch (e: Exception) { emptyList() }
}
