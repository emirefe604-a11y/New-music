package com.example.newmusic

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlin.random.Random

/**
 * Spotify tarzı "sıradaki şarkı" motoru.
 *
 * - Oturum, kullanıcının KENDİSİNİN başlattığı ilk şarkıya (tohum) sabitlenir. Otomatik eklenen
 *   şarkılar tohumu değiştirmez; böylece zincirleme "related" kayması (rap -> pop -> arabesk) olmaz.
 * - Her aday şarkı puanlanır: tohumla aynı tür/sanatçı, YouTube related kaynağı ve kullanıcının
 *   kaydedilen zevki (TasteProfile: sanatçı + tür eğilimi, atlamalar, beğeniler) birlikte hesaplanır.
 * - Tohumdan farklı bilinen bir türe ait sanatçılar elenir.
 * - Bilinmeyen sanatçıların türü, related sonuçlarındaki oylamayla ve sonuna kadar dinlenmeleriyle
 *   öğrenilir ve kalıcı kaydedilir.
 */
object NextSongEngine {
    private var seed: Song? = null
    private var seedIsRadio = false
    private val recent = ArrayList<Song>()
    private var activeCluster = -1

    /** Kullanıcı bir liste/şarkı başlattığında çağrılır. Kısa listeler (arama, tek şarkı) "radyo" sayılır. */
    fun startSession(list: List<Song>, start: Int) {
        val s = list.getOrNull(start) ?: return
        seed = s
        seedIsRadio = list.size <= 10
        activeCluster = -1
        recent.clear()
    }

    fun onPlayed(s: Song) {
        recent.removeAll { it.url == s.url }
        recent.add(s)
        if (recent.size > 6) recent.removeAt(0)
    }

    /** Şarkı sonuna kadar dinlendi: sanatçısının türü bilinmiyorsa, oturumun türüne ait olarak öğren. */
    fun onCompleted(s: Song) {
        val a = GenreRecommender.extractArtist(s)
        if (activeCluster >= 0 && clusterOf(a) < 0) TasteProfile.learnCluster(a, activeCluster)
    }

    fun clusterOf(artist: String): Int {
        val c = GenreRecommender.clusterOf(artist)
        return if (c >= 0) c else TasteProfile.learnedClusterOf(artist)
    }

    private fun norm(a: String) = GenreRecommender.normalize(a)

    private fun recentMajorityCluster(): Int {
        val counts = HashMap<Int, Int>()
        recent.forEach {
            val c = clusterOf(GenreRecommender.extractArtist(it))
            if (c >= 0) counts[c] = (counts[c] ?: 0) + 1
        }
        return counts.maxByOrNull { it.value }?.key ?: -1
    }

    private suspend fun safe(block: suspend () -> List<Song>): List<Song> =
        try { block() } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() }

    private fun remote(s: Song) = !(Uploads.isLocal(s) || s.url.startsWith("local://"))

    private class Cand(val song: Song, val artist: String, val key: String, val cluster: Int, var src: Float)

    suspend fun build(current: Song, existing: Set<String>, limit: Int): List<Song> = coroutineScope {
        val anchor = if (seedIsRadio) (seed ?: current) else current
        val anchorArtist = GenreRecommender.extractArtist(anchor)
        val anchorKey = norm(anchorArtist)

        var cluster = clusterOf(anchorArtist)
        if (cluster < 0 && !seedIsRadio) cluster = recentMajorityCluster()

        val relAnchorD = async(Dispatchers.IO) {
            if (remote(anchor)) safe { MusicRepository.related(anchor.url) } else emptyList()
        }
        val relCurD = async(Dispatchers.IO) {
            if (current.url != anchor.url && remote(current)) safe { MusicRepository.related(current.url) } else emptyList()
        }
        val artistD = async(Dispatchers.IO) {
            if (anchorArtist.isNotBlank()) safe { MusicRepository.search(anchorArtist, persist = false) } else emptyList()
        }
        val relAnchor = relAnchorD.await()

        // Türü bilinmeyen tohum: related sonuçlarındaki sanatçıların türlerine oy verdirerek türü çıkar
        if (cluster < 0) {
            val votes = HashMap<Int, Int>()
            var known = 0
            relAnchor.forEach {
                val c = clusterOf(GenreRecommender.extractArtist(it))
                if (c >= 0) { votes[c] = (votes[c] ?: 0) + 1; known++ }
            }
            val top = votes.maxByOrNull { it.value }
            if (top != null && top.value >= 3 && top.value * 2 >= known) {
                cluster = top.key
                if (anchorArtist.isNotBlank()) TasteProfile.learnCluster(anchorArtist, cluster)
            }
        }
        activeCluster = cluster

        // Aynı türdeki kardeş sanatçılar (kullanıcının sevdikleri öne alınır)
        val simArtists = if (cluster >= 0) {
            val pool = (GenreRecommender.clusterMembers(cluster) + TasteProfile.learnedArtistsIn(cluster))
                .filter { norm(it) != anchorKey }.distinctBy { norm(it) }
            pool.sortedByDescending { TasteProfile.artistAffinity(it) + Random.nextFloat() * 3f }.take(4)
        } else emptyList()
        val simD = simArtists.map { a ->
            async(Dispatchers.IO) { safe { MusicRepository.search(a, persist = false) }.take(4) }
        }

        val relCur = relCurD.await()
        val artistHits = artistD.await()
        val simHits = simD.map { it.await() }

        val playedTitles = PlayerManager.queue.value.map { it.title } + current.title + anchor.title
        val cands = LinkedHashMap<String, Cand>()

        fun addAll(list: List<Song>, weight: (Boolean) -> Float) {
            for (s in list.noAi().noLong().noNonMusic()) {
                if (s.url == current.url || s.url == anchor.url || s.url in existing) continue
                if (!remote(s) || TasteProfile.isDisliked(s) || PlayerManager.isDisliked(s)) continue
                val artist = GenreRecommender.extractArtist(s)
                val key = norm(artist)
                val w = weight(key == anchorKey)
                val old = cands[s.url]
                if (old != null) { if (w > old.src) old.src = w; continue }
                cands[s.url] = Cand(s, artist, key, clusterOf(artist), w)
            }
        }
        addAll(relAnchor) { 2.0f }
        addAll(relCur) { 1.0f }
        addAll(artistHits) { same -> if (same) 2.5f else 0.5f }
        simHits.forEach { addAll(it) { 1.5f } }

        if (cands.size < 8 && anchorArtist.isNotBlank()) {
            addAll(safe { MusicRepository.search("$anchorArtist mix", persist = false) }) { same -> if (same) 1.5f else 0.3f }
        }

        // Puanlama
        val scored = ArrayList<Pair<Cand, Float>>()
        for (c in cands.values) {
            if (playedTitles.any { TitleDeduplicator.isSimilar(it, c.song.title) }) continue
            var sc = c.src
            if (c.key == anchorKey) sc += 3f
            if (cluster >= 0) {
                if (c.cluster == cluster) sc += 4f
                else if (c.cluster >= 0) continue // tohumdan farklı bir türün sanatçısı: ele
            }
            val aff = TasteProfile.artistAffinity(c.artist)
            if (aff <= -5f) continue // sürekli atlanan / sevilmeyen sanatçı
            sc += (aff * 0.25f).coerceIn(-2f, 3f)
            if (c.cluster >= 0) sc += (TasteProfile.genreAffinity(c.cluster) * 0.05f).coerceIn(-1f, 1.5f)
            sc += Random.nextFloat() * 0.8f // hafif çeşitlilik
            scored.add(c to sc)
        }

        // Seçim: puana göre, ama peş peşe aynı sanatçı olmasın ve sanatçı başına sınır olsun
        val pool = scored.sortedByDescending { it.second }.map { it.first }.toMutableList()
        val out = ArrayList<Song>()
        val perArtist = HashMap<String, Int>()
        var lastKey = norm(GenreRecommender.extractArtist(current))
        while (out.size < limit && pool.isNotEmpty()) {
            val pick = pool.firstOrNull { it.key != lastKey && (perArtist[it.key] ?: 0) < 2 }
                ?: pool.firstOrNull { (perArtist[it.key] ?: 0) < 3 }
                ?: break
            pool.remove(pick)
            out.add(pick.song)
            perArtist[pick.key] = (perArtist[pick.key] ?: 0) + 1
            lastKey = pick.key
        }
        out
    }
}
