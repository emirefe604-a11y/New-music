@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File
import java.util.Locale

/**
 * Spotify mimarisi yerel ses disk önbelleği.
 * Çalınan ve önden yüklenen tüm ses parçaları telefonun hafızasına (SSD) kaydedilir.
 * Şarkı tekrar açıldığında veya geri gelindiğinde ağa hiç gitmeden anında (0 ms) yerelden çalar.
 */
object AudioCache {
    @Volatile
    private var instance: SimpleCache? = null

    const val MAX_CACHE_SIZE = 2048L * 1024L * 1024L // 2 GB Spotify tarzı yerel SSD disk önbelleği

    @Synchronized
    fun get(context: Context): SimpleCache {
        return instance ?: synchronized(this) {
            instance ?: run {
                val app = context.applicationContext
                val cacheDir = File(app.cacheDir, "audio_cache").apply { mkdirs() }
                val evictor = LeastRecentlyUsedCacheEvictor(MAX_CACHE_SIZE)
                val db = StandaloneDatabaseProvider(app)
                SimpleCache(cacheDir, evictor, db).also { instance = it }
            }
        }
    }

    /** Oynatıcı ve önden indirme (CacheWriter) aynı önbellek + aynı veri kaynağını kullansın. */
    fun factory(context: Context): CacheDataSource.Factory {
        val app = context.applicationContext
        val base = DefaultDataSource.Factory(app, DataSource.Factory { ChunkedDataSource(Http.client) })
        return CacheDataSource.Factory()
            .setCache(get(app))
            .setUpstreamDataSourceFactory(base)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    /** Diskte kullanılan toplam ses önbelleği boyutu (bayt) */
    fun currentSize(context: Context): Long = try {
        get(context).cacheSpace
    } catch (_: Exception) { 0L }

    /** Okunabilir önbellek boyutu metni (örn. "145.2 MB / 2.0 GB") */
    fun formattedSize(context: Context): String {
        val bytes = currentSize(context)
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        return if (mb >= 1024.0) {
            String.format(Locale.US, "%.1f GB / 2.0 GB", mb / 1024.0)
        } else {
            String.format(Locale.US, "%.1f MB / 2.0 GB", mb)
        }
    }

    /** Tüm ses önbelleğini temizler */
    fun clear(context: Context) {
        try {
            val cache = get(context)
            val keys = cache.keys.toList()
            keys.forEach { k ->
                cache.removeResource(k)
            }
        } catch (_: Exception) {}
    }
}
