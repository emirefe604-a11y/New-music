@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/**
 * Gelişmiş yerel ses disk önbelleği.
 * Çalınan ve önden yüklenen tüm ses parçaları buraya kaydedilir.
 * Şarkı tekrar açıldığında veya geri gelindiğinde ağa hiç gitmeden anında (0 ms) yerelden çalar.
 */
object AudioCache {
    @Volatile
    private var instance: SimpleCache? = null

    @Synchronized
    fun get(context: Context): SimpleCache {
        return instance ?: synchronized(this) {
            instance ?: run {
                val app = context.applicationContext
                val cacheDir = File(app.cacheDir, "audio_cache").apply { mkdirs() }
                val evictor = LeastRecentlyUsedCacheEvictor(350 * 1024 * 1024L) // 350 MB LRU disk alanı
                val db = StandaloneDatabaseProvider(app)
                SimpleCache(cacheDir, evictor, db).also { instance = it }
            }
        }
    }

    /** Oynatıcı ve önden indirme (CacheWriter) aynı önbellek + aynı veri kaynağını kullansın. */
    fun factory(context: Context): CacheDataSource.Factory {
        val app = context.applicationContext
        val base = DefaultDataSource.Factory(app, DataSource.Factory { ChunkedDataSource(Http.client) })
        return CacheDataSource.Factory()
            .setCache(get(app))
            .setUpstreamDataSourceFactory(base)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }
}
