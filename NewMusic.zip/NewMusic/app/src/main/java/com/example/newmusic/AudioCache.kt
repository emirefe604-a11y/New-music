@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/**
 * Spotify benzeri yerel ses disk önbelleği.
 * Çalınan ve önden yüklenen tüm ses parçaları buraya kaydedilir.
 * Şarkı tekrar açıldığında veya geri gelindiğinde ağa hiç gitmeden anında (0 ms) yerelden çalar.
 */
object AudioCache {
    @Volatile
    private var instance: SimpleCache? = null

    @Synchronized
    fun get(context: Context): SimpleCache {
        return instance ?: synchronized(this) {
            instance ?: run {
                val app = context.applicationContext
                val cacheDir = File(app.cacheDir, "spotify_audio_cache").apply { mkdirs() }
                val evictor = LeastRecentlyUsedCacheEvictor(350 * 1024 * 1024L) // 350 MB LRU disk alanı
                val db = StandaloneDatabaseProvider(app)
                SimpleCache(cacheDir, evictor, db).also { instance = it }
            }
        }
    }
}
