package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class UserPlaylist(val id: String, val name: String, val songs: List<Song>)

/** Kullanıcının kendi oluşturduğu çalma listeleri (cihazda saklanır). */
object Playlists {
    val lists = MutableStateFlow<List<UserPlaylist>>(emptyList())
    private lateinit var prefs: SharedPreferences
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        lists.value = load()
        ready = true
    }

    fun create(name: String, songs: List<Song> = emptyList()): UserPlaylist {
        val pl = UserPlaylist(UUID.randomUUID().toString().take(10), name.trim().ifBlank { "Yeni liste" }, songs.distinctBy { it.url })
        lists.update { listOf(pl) + it }
        save()
        return pl
    }

    fun rename(id: String, name: String) {
        lists.update { l -> l.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it } }
        save()
    }

    fun delete(id: String) {
        lists.update { l -> l.filter { it.id != id } }
        save()
    }

    fun add(id: String, song: Song) {
        lists.update { l ->
            l.map { if (it.id == id && it.songs.none { s -> s.url == song.url }) it.copy(songs = it.songs + song) else it }
        }
        save()
    }

    fun removeSong(id: String, url: String) {
        lists.update { l -> l.map { if (it.id == id) it.copy(songs = it.songs.filter { s -> s.url != url }) else it } }
        save()
    }

    private fun save() {
        prefs.edit().putString("playlists", export().toString()).apply()
        CloudSync.changed()
    }

    fun export(): JSONArray = JSONArray().also { arr ->
        lists.value.forEach { pl ->
            val songs = JSONArray()
            pl.songs.forEach { songs.put(JSONObject().put("t", it.title).put("a", it.artist).put("u", it.url).put("h", it.thumb ?: "")) }
            arr.put(JSONObject().put("id", pl.id).put("name", pl.name).put("songs", songs))
        }
    }

    /** Hesap yedeğinden gelen listeleri uygular (yedeği tekrar tetiklemez). */
    fun replaceAll(l: List<UserPlaylist>) {
        lists.value = l
        if (ready) prefs.edit().putString("playlists", export().toString()).apply()
    }

    private fun load(): List<UserPlaylist> = try {
        fromJson(JSONArray(prefs.getString("playlists", "[]")))
    } catch (e: Exception) { emptyList() }

    fun fromJson(arr: JSONArray): List<UserPlaylist> = try {
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val sa = o.getJSONArray("songs")
            UserPlaylist(
                o.getString("id"), o.optString("name"),
                (0 until sa.length()).map { j ->
                    val s = sa.getJSONObject(j)
                    Song(s.optString("t"), s.optString("a"), s.optString("u"), s.optString("h").ifBlank { null })
                }
            )
        }
    } catch (e: Exception) { emptyList() }
}
