package com.example.newmusic

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Bg = Color(0xFF030303)
private val Card = Color(0xFF1F1F1F)
private val Accent = Color(0xFF1ED760)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicRepository.init()
        PlayerManager.connect(this)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = Bg,
                    onSurface = Color.White, onBackground = Color.White
                )
            ) { Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() } }
        }
    }
}

private val chips = listOf("Türkçe Pop", "Rock", "Hip Hop", "Arabesk", "Lo-Fi", "Slow", "Rap", "Klasik")

@Composable
fun App() {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }

    var homeSel by remember { mutableIntStateOf(0) }
    var homeSongs by remember { mutableStateOf(listOf<Song>()) }
    var homeLoading by remember { mutableStateOf(false) }
    var homeError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(homeSel) {
        homeLoading = true; homeError = null
        try { homeSongs = MusicRepository.search("${chips[homeSel]} şarkılar") }
        catch (e: Exception) { homeError = e.message ?: "Yüklenemedi" }
        homeLoading = false
    }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Song>()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    fun doSearch() {
        if (query.isBlank()) return
        searching = true; searchError = null
        scope.launch {
            try { results = MusicRepository.search(query) }
            catch (e: Exception) { searchError = e.message ?: "Arama hatası" }
            searching = false
        }
    }

    val mixes by TasteProfile.mixes.collectAsState()
    val mixLoading by TasteProfile.loading.collectAsState()
    LaunchedEffect(Unit) { try { TasteProfile.buildMixes() } catch (_: Exception) {} }
    val refreshMixes: () -> Unit = { scope.launch { try { TasteProfile.buildMixes() } catch (_: Exception) {} } }

    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val err by PlayerManager.error.collectAsState()
    val song = queue.getOrNull(idx)
    BackHandler(enabled = showPlayer) { showPlayer = false }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeTab(homeSel, { homeSel = it }, homeSongs, homeLoading, homeError, mixes, mixLoading, refreshMixes)
                    1 -> SearchTab(query, { query = it }, { doSearch() }, results, searching, searchError)
                    else -> LibraryTab()
                }
            }
            err?.let { Text(it, color = Accent, modifier = Modifier.fillMaxWidth().background(Card).padding(8.dp), style = MaterialTheme.typography.bodySmall) }
            if (song != null) MiniPlayer(song) { showPlayer = true }
            NavigationBar(containerColor = Color(0xFF0F0F0F)) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Ana sayfa") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Search, null) }, label = { Text("Ara") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.VideoLibrary, null) }, label = { Text("Kitaplık") })
            }
        }
        AnimatedVisibility(showPlayer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            FullPlayer { showPlayer = false }
        }
    }
}

@Composable
fun HomeTab(
    sel: Int, onSel: (Int) -> Unit, songs: List<Song>, loading: Boolean, error: String?,
    mixes: List<Mix>, mixLoading: Boolean, onRefreshMixes: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Text("Müzik", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp))
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Senin için", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (mixLoading) CircularProgressIndicator(Modifier.size(18.dp).padding(end = 2.dp), strokeWidth = 2.dp, color = Accent)
            else IconButton(onRefreshMixes) { Icon(Icons.Filled.Refresh, "Yenile", tint = Color.Gray) }
        }
        if (mixes.isEmpty()) {
            Text(
                if (mixLoading) "Listelerin hazırlanıyor…" else "Birkaç şarkı dinle veya beğen; zevkine göre karışık listeler burada çıkacak.",
                color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        } else {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(mixes) { _, m -> MixCard(m) { PlayerManager.playQueue(m.songs, 0) } }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(chips) { i, c ->
                FilterChip(selected = sel == i, onClick = { onSel(i) }, label = { Text(c) })
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent)
        error?.let { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) }
        if (songs.isNotEmpty()) {
            Button(
                onClick = { PlayerManager.playQueue(songs, 0) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                modifier = Modifier.padding(12.dp)
            ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Tümünü çal") }
        }
        SongList(songs)
    }
}

@Composable
fun SearchTab(query: String, onQuery: (String) -> Unit, onSearch: () -> Unit, songs: List<Song>, loading: Boolean, error: String?) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            placeholder = { Text("Şarkı, sanatçı ara") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            shape = RoundedCornerShape(28.dp), singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() })
        )
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
        error?.let { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) }
        SongList(songs)
    }
}

@Composable
fun LibraryTab() {
    val favs by PlayerManager.favorites.collectAsState()
    val downloaded by Downloads.songs.collectAsState()
    var section by remember { mutableIntStateOf(0) }
    val list = if (section == 0) favs else downloaded
    Column(Modifier.fillMaxSize()) {
        Text("Kitaplık", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(section == 0, { section = 0 }, label = { Text("Beğendiklerim") })
            FilterChip(section == 1, { section = 1 }, label = { Text("İndirilenler") })
        }
        if (list.isEmpty()) Text(
            if (section == 0) "Henüz beğendiğin şarkı yok. Kalp simgesine dokun."
            else "Henüz indirilen şarkı yok. Şarkının yanındaki indirme simgesine dokun.",
            modifier = Modifier.padding(16.dp), color = Color.Gray
        ) else {
            Button(
                onClick = { PlayerManager.playQueue(list, 0) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                modifier = Modifier.padding(12.dp)
            ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Hepsini çal") }
            SongList(list)
        }
    }
}

@Composable
fun SongList(songs: List<Song>) {
    val idx by PlayerManager.index.collectAsState()
    val queue by PlayerManager.queue.collectAsState()
    val activeUrl = queue.getOrNull(idx)?.url
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(songs) { i, s ->
            SongRow(s, s.url == activeUrl) { PlayerManager.playQueue(songs, i) }
        }
    }
}

@Composable
fun SongRow(s: Song, active: Boolean, onClick: () -> Unit) {
    val favs by PlayerManager.favorites.collectAsState()
    val fav = favs.any { it.url == s.url }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(s.thumb, null, Modifier.size(56.dp).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (active) Accent else Color.White, fontWeight = FontWeight.Medium)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        DownloadButton(s)
        IconButton({ PlayerManager.toggleFav(s) }) {
            Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.Gray)
        }
    }
}

/** İndir / indiriliyor (iptal) / indirildi (sil) / hata (tekrar dene). */
@Composable
fun DownloadButton(s: Song) {
    val done by Downloads.songs.collectAsState()
    val prog by Downloads.progress.collectAsState()
    val isDone = done.any { it.url == s.url }
    val p = prog[s.url]
    var confirm by remember { mutableStateOf(false) }
    IconButton({
        when {
            isDone -> confirm = true
            p != null && p >= 0 -> Downloads.cancel(s)
            else -> Downloads.download(s)
        }
    }) {
        when {
            isDone -> Icon(Icons.Filled.DownloadDone, "İndirildi", tint = Accent)
            p == null -> Icon(Icons.Filled.Download, "İndir", tint = Color.Gray)
            p < 0 -> Icon(Icons.Filled.ErrorOutline, "İndirilemedi, tekrar dene", tint = Color(0xFFFF6B6B))
            p == 0 -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
            else -> CircularProgressIndicator(progress = { p / 100f }, modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("İndirme silinsin mi?") },
        text = { Text("\"${s.title}\" cihazdan silinecek.") },
        confirmButton = { TextButton({ Downloads.remove(s); confirm = false }) { Text("Sil") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Vazgeç") } }
    )
}

@Composable
fun MixCard(m: Mix, onClick: () -> Unit) {
    val tints = listOf(0xFF1ED760, 0xFFE91E63, 0xFF7C4DFF, 0xFFFF9800, 0xFF00BCD4, 0xFFFF5252)
    val tint = Color(tints[(m.title.hashCode() and 0x7fffffff) % tints.size])
    Box(Modifier.size(150.dp).clip(RoundedCornerShape(12.dp)).background(Card).clickable(onClick = onClick)) {
        AsyncImage(m.songs.firstOrNull()?.thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.25f), Color(0xE6000000)))))
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(m.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(m.subtitle, color = Color(0xFFCCCCCC), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun rememberPosition(): Pair<Long, Long> {
    var p by remember { mutableLongStateOf(0L) }
    var d by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) { p = PlayerManager.position(); d = PlayerManager.duration(); delay(100) }
    }
    return p to d
}

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun MiniPlayer(song: Song, onOpen: () -> Unit) {
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val (pos, dur) = rememberPosition()
    val smooth by animateFloatAsState(
        if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f, tween(150, easing = LinearEasing), label = "mini"
    )
    Surface(color = Card) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(song.thumb, null, Modifier.size(44.dp).clip(RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                if (loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
                else IconButton({ PlayerManager.togglePlay() }) {
                    Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat")
                }
                IconButton({ PlayerManager.next(false) }) { Icon(Icons.Filled.SkipNext, "Sonraki") }
            }
            LinearProgressIndicator(
                progress = { smooth },
                modifier = Modifier.fillMaxWidth().height(2.dp), color = Color.White, trackColor = Color(0x33FFFFFF)
            )
        }
    }
}

/** Albüm kapağındaki baskın rengi çıkarır; şarkı değişince renk yumuşakça geçiş yapar. */
@Composable
fun rememberAmbientColor(url: String?): Color {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf(Accent) }
    LaunchedEffect(url) {
        if (url == null) return@LaunchedEffect
        try {
            val res = ctx.imageLoader.execute(
                ImageRequest.Builder(ctx).data(url).allowHardware(false).size(128).build()
            )
            val bmp = (res as? SuccessResult)?.drawable?.toBitmap() ?: return@LaunchedEffect
            val pal = withContext(Dispatchers.Default) { Palette.from(bmp).maximumColorCount(16).generate() }
            val fallback = pal.getDominantColor(0xFF1ED760.toInt())
            target = Color(pal.getVibrantColor(pal.getMutedColor(fallback)))
        } catch (_: Exception) { }
    }
    return animateColorAsState(target, tween(1000), label = "ambient").value
}

/** Dokunarak ve sürükleyerek ilerletilebilen, sürüklerken büyüyen ilerleme çubuğu. */
@Composable
fun SeekBar(progress: Float, onPreview: (Float) -> Unit, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var width by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    var cur by remember { mutableFloatStateOf(0f) }
    val seek by rememberUpdatedState(onSeek)       // pointerInput eski lambda'yı tutmasın
    val preview by rememberUpdatedState(onPreview)
    val thumbR by animateDpAsState(if (dragging) 9.dp else 5.dp, label = "thumb")
    val trackH by animateDpAsState(if (dragging) 6.dp else 4.dp, label = "track")
    Canvas(
        modifier.fillMaxWidth().height(36.dp)
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o -> seek((o.x / width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragging = true; cur = (o.x / width).coerceIn(0f, 1f); preview(cur) },
                    onDragEnd = { dragging = false; seek(cur) },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        cur = (change.position.x / width).coerceIn(0f, 1f)
                        preview(cur)
                    }
                )
            }
    ) {
        val cy = size.height / 2
        val th = trackH.toPx()
        val w = size.width * progress.coerceIn(0f, 1f)
        drawRoundRect(Color(0x44FFFFFF), Offset(0f, cy - th / 2), Size(size.width, th), CornerRadius(th / 2))
        drawRoundRect(Color.White, Offset(0f, cy - th / 2), Size(w, th), CornerRadius(th / 2))
        drawCircle(Color.White, thumbR.toPx(), Offset(w, cy))
    }
}

@Composable
fun FullPlayer(onClose: () -> Unit) {
    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val favs by PlayerManager.favorites.collectAsState()
    val shuffle by PlayerManager.shuffle.collectAsState()
    val repeat by PlayerManager.repeat.collectAsState()
    val song = queue.getOrNull(idx) ?: return
    val (pos, dur) = rememberPosition()
    val scope = rememberCoroutineScope()
    var drag by remember { mutableStateOf<Float?>(null) }
    val target = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val smooth by animateFloatAsState(target, tween(150, easing = LinearEasing), label = "progress")
    val dragValue = drag
    val shown = dragValue ?: smooth
    val fav = favs.any { it.url == song.url }

    // Ambient ışık: kapak renginde, nefes alır gibi hafifçe parlayıp sönen arka plan
    val ambient = rememberAmbientColor(song.thumb)
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.8f, 1f, infiniteRepeatable(tween<Float>(3500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulseValue"
    )

    Box(Modifier.fillMaxSize().background(Bg)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to ambient.copy(alpha = 0.55f * pulse),
                    0.55f to ambient.copy(alpha = 0.12f),
                    1f to Bg
                )
            )
        )
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Kapat", Modifier.size(32.dp)) }
                Spacer(Modifier.weight(1f))
                Text("Şimdi çalıyor", color = Color(0xFFDDDDDD))
                Spacer(Modifier.weight(1f)); Spacer(Modifier.width(48.dp))
            }
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f).drawBehind {
                    drawCircle(
                        Brush.radialGradient(
                            listOf(ambient.copy(alpha = 0.65f * pulse), Color.Transparent),
                            center = center, radius = size.maxDimension * 0.8f
                        ),
                        radius = size.maxDimension * 0.8f, center = center
                    )
                }
            ) {
                AsyncImage(song.thumb, null, Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
            }
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Color(0xFFDDDDDD), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                DownloadButton(song)
                IconButton({ PlayerManager.toggleFav(song) }) {
                    Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.White)
                }
            }
            SeekBar(
                progress = shown,
                onPreview = { drag = it },
                onSeek = {
                    PlayerManager.seekTo((it * dur).toLong())
                    drag = it
                    // Konum güncellenene kadar çubuk bıraktığın yerde kalsın
                    scope.launch { delay(300); drag = null }
                },
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(if (dragValue != null) (dragValue * dur).toLong() else pos), color = Color(0xFFDDDDDD), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text(fmt(dur), color = Color(0xFFDDDDDD), style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ PlayerManager.toggleShuffle() }, Modifier.size(44.dp)) {
                    Icon(Icons.Filled.Shuffle, "Karıştır", tint = if (shuffle) Accent else Color.White)
                }
                IconButton({ PlayerManager.prev() }, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipPrevious, "Önceki", Modifier.size(34.dp)) }
                Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { PlayerManager.togglePlay() }, contentAlignment = Alignment.Center) {
                    if (loading) CircularProgressIndicator(Modifier.size(32.dp), color = Color.Black, strokeWidth = 3.dp)
                    else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat", Modifier.size(40.dp), tint = Color.Black)
                }
                IconButton({ PlayerManager.next(false) }, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipNext, "Sonraki", Modifier.size(34.dp)) }
                IconButton({ PlayerManager.cycleRepeat() }, Modifier.size(44.dp)) {
                    Icon(if (repeat == 2) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Tekrar",
                        tint = if (repeat > 0) Accent else Color.White)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Sıradaki", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            queue.drop(idx + 1).take(20).forEachIndexed { k, s ->
                SongRow(s, false) { PlayerManager.playIndex(idx + 1 + k) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
