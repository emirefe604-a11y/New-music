package com.example.newmusic

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Bg = Color(0xFF030303)
private val Card = Color(0xFF1F1F1F)
private val Accent = Color(0xFFFF1744)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicRepository.init()
        PlayerManager.connect(this)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, background = Bg, surface = Bg,
                    onSurface = Color.White, onBackground = Color.White
                )
            ) { Surface(color = Bg, modifier = Modifier.fillMaxSize()) { App() } }
        }
    }
}

private val chips = listOf("Türkçe Pop", "Rock", "Hip Hop", "Arabesk", "Lo-Fi", "Slow", "Rap", "Klasik")

@Composable
fun App() {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }

    var homeSel by remember { mutableIntStateOf(0) }
    var homeSongs by remember { mutableStateOf(listOf<Song>()) }
    var homeLoading by remember { mutableStateOf(false) }
    var homeError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(homeSel) {
        homeLoading = true; homeError = null
        try { homeSongs = MusicRepository.search("${chips[homeSel]} şarkılar") }
        catch (e: Exception) { homeError = e.message ?: "Yüklenemedi" }
        homeLoading = false
    }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Song>()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    fun doSearch() {
        if (query.isBlank()) return
        searching = true; searchError = null
        scope.launch {
            try { results = MusicRepository.search(query) }
            catch (e: Exception) { searchError = e.message ?: "Arama hatası" }
            searching = false
        }
    }

    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val err by PlayerManager.error.collectAsState()
    val song = queue.getOrNull(idx)
    BackHandler(enabled = showPlayer) { showPlayer = false }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeTab(homeSel, { homeSel = it }, homeSongs, homeLoading, homeError)
                    1 -> SearchTab(query, { query = it }, { doSearch() }, results, searching, searchError)
                    else -> LibraryTab()
                }
            }
            err?.let { Text(it, color = Accent, modifier = Modifier.fillMaxWidth().background(Card).padding(8.dp), style = MaterialTheme.typography.bodySmall) }
            if (song != null) MiniPlayer(song) { showPlayer = true }
            NavigationBar(containerColor = Color(0xFF0F0F0F)) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Ana sayfa") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Search, null) }, label = { Text("Ara") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.VideoLibrary, null) }, label = { Text("Kitaplık") })
            }
        }
        AnimatedVisibility(showPlayer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            FullPlayer { showPlayer = false }
        }
    }
}

@Composable
fun HomeTab(sel: Int, onSel: (Int) -> Unit, songs: List<Song>, loading: Boolean, error: String?) {
    Column(Modifier.fillMaxSize()) {
        Text("Müzik", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(chips) { i, c ->
                FilterChip(selected = sel == i, onClick = { onSel(i) }, label = { Text(c) })
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent)
        error?.let { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) }
        if (songs.isNotEmpty()) {
            Button(
                onClick = { PlayerManager.playQueue(songs, 0) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                modifier = Modifier.padding(12.dp)
            ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Tümünü çal") }
        }
        SongList(songs)
    }
}

@Composable
fun SearchTab(query: String, onQuery: (String) -> Unit, onSearch: () -> Unit, songs: List<Song>, loading: Boolean, error: String?) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            placeholder = { Text("Şarkı, sanatçı ara") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            shape = RoundedCornerShape(28.dp), singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() })
        )
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
        error?.let { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) }
        SongList(songs)
    }
}

@Composable
fun LibraryTab() {
    val favs by PlayerManager.favorites.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Text("Kitaplık", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp))
        Text("Beğendiğin şarkılar", modifier = Modifier.padding(horizontal = 16.dp), color = Color.Gray)
        if (favs.isEmpty()) Text("Henüz beğendiğin şarkı yok. Kalp simgesine dokun.", modifier = Modifier.padding(16.dp), color = Color.Gray)
        else {
            Button(
                onClick = { PlayerManager.playQueue(favs, 0) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                modifier = Modifier.padding(12.dp)
            ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Hepsini çal") }
            SongList(favs)
        }
    }
}

@Composable
fun SongList(songs: List<Song>) {
    val idx by PlayerManager.index.collectAsState()
    val queue by PlayerManager.queue.collectAsState()
    val activeUrl = queue.getOrNull(idx)?.url
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(songs) { i, s ->
            SongRow(s, s.url == activeUrl) { PlayerManager.playQueue(songs, i) }
        }
    }
}

@Composable
fun SongRow(s: Song, active: Boolean, onClick: () -> Unit) {
    val favs by PlayerManager.favorites.collectAsState()
    val fav = favs.any { it.url == s.url }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(s.thumb, null, Modifier.size(56.dp).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (active) Accent else Color.White, fontWeight = FontWeight.Medium)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        IconButton({ PlayerManager.toggleFav(s) }) {
            Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.Gray)
        }
    }
}

@Composable
fun rememberPosition(): Pair<Long, Long> {
    var p by remember { mutableLongStateOf(0L) }
    var d by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) { p = PlayerManager.position(); d = PlayerManager.duration(); delay(500) }
    }
    return p to d
}

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun MiniPlayer(song: Song, onOpen: () -> Unit) {
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val (pos, dur) = rememberPosition()
    Surface(color = Card) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(song.thumb, null, Modifier.size(44.dp).clip(RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                if (loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
                else IconButton({ PlayerManager.togglePlay() }) {
                    Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat")
                }
                IconButton({ PlayerManager.next(false) }) { Icon(Icons.Filled.SkipNext, "Sonraki") }
            }
            LinearProgressIndicator(
                progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth().height(2.dp), color = Color.White, trackColor = Color(0x33FFFFFF)
            )
        }
    }
}

@Composable
fun FullPlayer(onClose: () -> Unit) {
    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val favs by PlayerManager.favorites.collectAsState()
    val song = queue.getOrNull(idx) ?: return
    val (pos, dur) = rememberPosition()
    var drag by remember { mutableStateOf<Float?>(null) }
    val value = drag ?: if (dur > 0) pos.toFloat() / dur else 0f
    val fav = favs.any { it.url == song.url }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Kapat", Modifier.size(32.dp)) }
            Spacer(Modifier.weight(1f))
            Text("Şimdi çalıyor", color = Color.Gray)
            Spacer(Modifier.weight(1f)); Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.height(16.dp))
        AsyncImage(song.thumb, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(song.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton({ PlayerManager.toggleFav(song) }) {
                Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.White)
            }
        }
        Slider(
            value = value.coerceIn(0f, 1f),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { PlayerManager.seekTo((it * dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0x55FFFFFF))
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(pos), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            Text(fmt(dur), color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ PlayerManager.prev() }, Modifier.size(56.dp)) { Icon(Icons.Filled.SkipPrevious, "Önceki", Modifier.size(36.dp)) }
            Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { PlayerManager.togglePlay() }, contentAlignment = Alignment.Center) {
                if (loading) CircularProgressIndicator(Modifier.size(32.dp), color = Color.Black, strokeWidth = 3.dp)
                else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat", Modifier.size(40.dp), tint = Color.Black)
            }
            IconButton({ PlayerManager.next(false) }, Modifier.size(56.dp)) { Icon(Icons.Filled.SkipNext, "Sonraki", Modifier.size(36.dp)) }
        }
        Spacer(Modifier.height(16.dp))
        Text("Sıradaki", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        queue.drop(idx + 1).take(20).forEachIndexed { k, s ->
            SongRow(s, false) { PlayerManager.playIndex(idx + 1 + k) }
        }
        Spacer(Modifier.height(24.dp))
    }
}
