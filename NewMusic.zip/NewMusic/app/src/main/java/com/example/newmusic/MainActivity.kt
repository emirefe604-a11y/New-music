package com.example.newmusic

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.lerp
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeOut
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicRepository.init(applicationContext)
        ThemeStore.init(applicationContext)
        PlayerManager.connect(this)
        BluetoothMonitor.start(applicationContext)
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31) perms += Manifest.permission.BLUETOOTH_CONNECT
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)
        setContent {
            val themeIdx by ThemeStore.index.collectAsState()
            val pal = Palettes[themeIdx.coerceIn(Palettes.indices)]
            CompositionLocalProvider(LocalPalette provides pal) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = pal.accent, background = pal.bg, surface = pal.bg,
                        surfaceVariant = pal.card, onSurface = Color.White, onBackground = Color.White,
                        secondaryContainer = pal.accent.copy(alpha = 0.30f), onSecondaryContainer = Color.White
                    )
                ) {
                    var splash by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) { delay(2400); splash = false }
                    Surface(color = pal.bg, modifier = Modifier.fillMaxSize()) {
                        Box(Modifier.fillMaxSize()) {
                            App(onRequestBluetooth = { requestBluetooth() }) // açılış ekranının arkasında şimdiden yüklenir
                            AnimatedVisibility(splash, exit = fadeOut(tween(700))) { SplashScreen() }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        BluetoothMonitor.refresh()
    }

    private fun requestBluetooth() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
        else BluetoothMonitor.refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        BluetoothMonitor.refresh()
    }
}

private val chips = listOf("Türkçe Pop", "Rock", "Hip Hop", "Arabesk", "Lo-Fi", "Slow", "Rap", "Klasik")

private data class Genre(val name: String, val query: String, val color: Color, val icon: ImageVector)

private val genres = listOf(
    Genre("Türkçe Pop", "Türkçe pop", Color(0xFFE91E63), Icons.Filled.MusicNote),
    Genre("Hip Hop & Rap", "Türkçe rap hip hop", Color(0xFFFF9800), Icons.Filled.Mic),
    Genre("Rock", "Rock", Color(0xFFE53935), Icons.Filled.FlashOn),
    Genre("Arabesk", "Arabesk", Color(0xFF8E24AA), Icons.Filled.Favorite),
    Genre("Lo-Fi", "Lo-fi chill", Color(0xFF26A69A), Icons.Filled.Nightlight),
    Genre("Slow", "Slow şarkılar", Color(0xFF5C6BC0), Icons.Filled.Headphones),
    Genre("Klasik", "Klasik müzik", Color(0xFF8D6E63), Icons.Filled.Piano),
    Genre("Dans", "Dance party", Color(0xFF00BCD4), Icons.Filled.Celebration),
    Genre("Antrenman", "Workout", Color(0xFFFF5722), Icons.Filled.FitnessCenter),
    Genre("Rahatla", "Relax", Color(0xFF4CAF50), Icons.Filled.Spa)
)

private val discoverSections = listOf(
    "Senin için seçtiklerimiz" to "Türkçe pop hits",
    "Popüler Türkçe" to "Türkçe hit",
    "Hip Hop & Rap" to "Türkçe rap",
    "Rock klasikleri" to "Rock classics",
    "Rahatlatıcı" to "Lo-fi chill",
    "Antrenman" to "Workout",
    "Arabesk & Slow" to "Arabesk slow",
    "Yeni çıkanlar" to "Yeni çıkan şarkılar 2026"
)

@Composable
fun App(onRequestBluetooth: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var openPlaylist by remember { mutableStateOf<PlaylistRef?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    var homeSel by remember { mutableIntStateOf(0) }
    var homeSongs by remember { mutableStateOf(listOf<Song>()) }
    var homeLoading by remember { mutableStateOf(false) }
    var homeError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(homeSel) {
        val q = "${chips[homeSel]} şarkılar"
        homeSongs = MusicRepository.cachedSearch(q) ?: emptyList() // önbellek varsa liste anında gelir
        homeLoading = homeSongs.isEmpty(); homeError = null
        try {
            homeSongs = MusicRepository.search(q, persist = true)
            homeSongs.firstOrNull()?.let { MusicRepository.prefetch(it.url) } // "Tümünü çal" gecikmesiz başlasın
        } catch (e: Exception) { if (homeSongs.isEmpty()) homeError = e.message ?: "Yüklenemedi" }
        homeLoading = false
    }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Song>()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    fun doSearch(q: String) {
        if (q.isBlank()) return
        query = q
        searching = true; searchError = null
        scope.launch {
            try { results = MusicRepository.search(q) }
            catch (e: Exception) { searchError = e.message ?: "Arama hatası" }
            searching = false
        }
    }

    val mixes by TasteProfile.mixes.collectAsState()
    val mixLoading by TasteProfile.loading.collectAsState()
    LaunchedEffect(Unit) { try { TasteProfile.buildMixes() } catch (_: Exception) {} }
    val refreshMixes: () -> Unit = { scope.launch { try { TasteProfile.buildMixes() } catch (_: Exception) {} } }

    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val err by PlayerManager.error.collectAsState()
    val song = queue.getOrNull(idx)
    // Sonra tanımlanan BackHandler önceliklidir: önce oynatıcı, sonra çalma listesi kapanır
    BackHandler(enabled = showSettings) { showSettings = false }
    BackHandler(enabled = openPlaylist != null) { openPlaylist = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }

    Box(Modifier.fillMaxSize().background(Bg)) {
        AmbientGlow(song, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                val pl = openPlaylist
                if (showSettings) {
                    SettingsScreen { showSettings = false }
                } else if (pl != null) {
                    PlaylistScreen(pl) { openPlaylist = null }
                } else when (tab) {
                    0 -> HomeTab(
                        homeSel, { homeSel = it }, homeSongs, homeLoading, homeError, mixes, mixLoading, refreshMixes,
                        onOpenSearch = { tab = 2 }, onOpenSettings = { showSettings = true }
                    )
                    1 -> DiscoverTab(onOpenSearch = { tab = 2 }, onOpen = { openPlaylist = it })
                    2 -> SearchTab(query, { query = it }, { doSearch(it) }, results, searching, searchError)
                    else -> LibraryTab()
                }
            }
            err?.let { Text(it, color = Accent, modifier = Modifier.fillMaxWidth().background(Card).padding(8.dp), style = MaterialTheme.typography.bodySmall) }
            if (song != null) MiniPlayer(song) { showPlayer = true }
            SoftNavBar(
                tab, { tab = it; openPlaylist = null; showSettings = false },
                listOf(
                    Triple("Ana sayfa", Icons.Filled.Home, Icons.Outlined.Home),
                    Triple("Keşfet", Icons.Filled.Explore, Icons.Outlined.Explore),
                    Triple("Ara", Icons.Filled.Search, Icons.Outlined.Search),
                    Triple("Kitaplık", Icons.Filled.LibraryMusic, Icons.Outlined.LibraryMusic)
                )
            )
        }
        AnimatedVisibility(showPlayer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            FullPlayer(onRequestBluetooth) { showPlayer = false }
        }
    }
}

/** Yüzen, yuvarlak alt çubuk. Seçili sekme tema renginde bir hap olarak açılır. */
@Composable
fun SoftNavBar(
    selected: Int, onSelect: (Int) -> Unit,
    items: List<Triple<String, ImageVector, ImageVector>>
) {
    val accent = Accent
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(Card)
                .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { i, (label, filled, outlined) ->
                val sel = i == selected
                val bg by animateColorAsState(if (sel) accent.copy(alpha = 0.28f) else Color.Transparent, tween(300), label = "navBg")
                Row(
                    Modifier.clip(RoundedCornerShape(26.dp)).background(bg)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSelect(i) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (sel) filled else outlined, label, tint = if (sel) Color.White else Color(0xFF9A9A9A), modifier = Modifier.size(24.dp))
                    AnimatedVisibility(sel, enter = expandHorizontally(), exit = shrinkHorizontally()) {
                        Text(label, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Arama çubuğu

/** Yuvarlak, dolgulu, çizgisiz arama alanı. */
@Composable
fun SearchPill(
    value: String, onValue: (String) -> Unit, onSearch: () -> Unit,
    placeholder: String = "Şarkı, sanatçı ara", autoFocus: Boolean = false
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (autoFocus) try { focus.requestFocus() } catch (_: Exception) { } }
    val muted = Color(0xFF9A9A9A)
    TextField(
        value = value, onValueChange = onValue,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).focusRequester(focus),
        placeholder = { Text(placeholder, color = muted) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = muted) },
        trailingIcon = {
            if (value.isNotEmpty()) IconButton({ onValue("") }) { Icon(Icons.Filled.Close, "Temizle", tint = muted) }
        },
        singleLine = true, shape = RoundedCornerShape(28.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Card, unfocusedContainerColor = Card, disabledContainerColor = Card,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = Accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() })
    )
}

/** Dokununca Ara sekmesini açan, yazılamayan arama çubuğu (Ana sayfa ve Keşfet için). */
@Composable
fun SearchPillButton(placeholder: String = "Şarkı, sanatçı ara", onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp)).background(Card).clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = Color(0xFF9A9A9A))
        Spacer(Modifier.width(12.dp))
        Text(placeholder, color = Color(0xFF9A9A9A))
    }
}

// ---------------------------------------------------------------- Ana sayfa

@Composable
fun HomeTab(
    sel: Int, onSel: (Int) -> Unit, songs: List<Song>, loading: Boolean, error: String?,
    mixes: List<Mix>, mixLoading: Boolean, onRefreshMixes: () -> Unit,
    onOpenSearch: () -> Unit, onOpenSettings: () -> Unit
) {
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val greet = when {
        hour in 5..11 -> "Günaydın"
        hour in 12..17 -> "İyi günler"
        hour in 18..22 -> "İyi akşamlar"
        else -> "İyi geceler"
    }
    SongList(songs, header = {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greet, color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium)
                    Text("Müzik", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
                IconButton(onOpenSettings) { Icon(Icons.Filled.Settings, "Ayarlar", tint = Color.White) }
            }
        }
        item { SearchPillButton(onClick = onOpenSearch) }
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Senin için", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (mixLoading) CircularProgressIndicator(Modifier.size(18.dp).padding(end = 2.dp), strokeWidth = 2.dp, color = Accent)
                else IconButton(onRefreshMixes) { Icon(Icons.Filled.Refresh, "Yenile", tint = Color.Gray) }
            }
        }
        item {
            if (mixes.isEmpty()) {
                Text(
                    if (mixLoading) "Listelerin hazırlanıyor…" else "Birkaç şarkı dinle veya beğen; zevkine göre karışık listeler burada çıkacak.",
                    color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            } else {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(mixes) { _, m -> MixCard(m) { PlayerManager.playQueue(m.songs, 0) } }
                }
            }
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 10.dp)
            ) {
                itemsIndexed(chips) { i, c ->
                    FilterChip(selected = sel == i, onClick = { onSel(i) }, label = { Text(c) })
                }
            }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent) }
        error?.let { item { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) } }
        if (songs.isNotEmpty()) item { PlayAllButton("Tümünü çal") { PlayerManager.playQueue(songs, 0) } }
    })
}

// ---------------------------------------------------------------- Ayarlar

@Composable
private fun SettingsTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Accent,
        modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 6.dp))
}

@Composable
private fun SettingsRow(selected: Boolean, onClick: () -> Unit, leading: @Composable () -> Unit, label: String) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(14.dp))
        Text(label, modifier = Modifier.weight(1f))
        if (selected) Icon(Icons.Filled.Check, null, tint = Accent)
    }
}

/** Ayarlar: tema, ambient ışık seçenekleri ve uygulama bilgisi. */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val theme by ThemeStore.index.collectAsState()
    val mode by ThemeStore.ambientMode.collectAsState()
    val grad by ThemeStore.gradient.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
                Text("Ayarlar", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }
        item { SettingsTitle("Tema") }
        itemsIndexed(Palettes) { i, p ->
            SettingsRow(i == theme, { ThemeStore.set(i) }, { Box(Modifier.size(28.dp).clip(CircleShape).background(p.accent)) }, p.name)
        }
        item { SettingsTitle("Ambient ışık") }
        itemsIndexed(AmbientModes) { i, name ->
            SettingsRow(i == mode, { ThemeStore.setAmbientMode(i) }, {
                Icon(
                    when (i) { 0 -> Icons.Filled.LightMode; 1 -> Icons.Filled.Palette; 2 -> Icons.Filled.Album; else -> Icons.Filled.Gradient },
                    null, tint = Color(0xFFCCCCCC), modifier = Modifier.size(28.dp)
                )
            }, name)
        }
        if (mode == 3) {
            item { SettingsTitle("Renk geçişi") }
            itemsIndexed(Gradients) { i, g ->
                SettingsRow(i == grad, { ThemeStore.setGradient(i) }, {
                    Box(Modifier.size(width = 56.dp, height = 28.dp).clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(g.colors)))
                }, g.name)
            }
        }
        item { SettingsTitle("Hakkında") }
        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text("NewMusic", fontWeight = FontWeight.Medium)
                Text("Sürüm 1.0", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(10.dp))
                Text("Geliştirici", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodySmall)
                Text("Efe Emir", fontWeight = FontWeight.Medium)
            }
        }
    }
}

// ---------------------------------------------------------------- Ambient ışık

/** Albüm kapağındaki baskın rengi çıkarır; şarkı değişince renk yumuşakça geçiş yapar. */
@Composable
fun rememberAmbientColor(url: String?): Color {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf(Color(0xFF1ED760)) }
    LaunchedEffect(url) {
        if (url == null) return@LaunchedEffect
        try {
            val res = ctx.imageLoader.execute(
                ImageRequest.Builder(ctx).data(url).allowHardware(false).size(128).build()
            )
            val bmp = (res as? SuccessResult)?.drawable?.toBitmap() ?: return@LaunchedEffect
            val pal = withContext(Dispatchers.Default) { Palette.from(bmp).maximumColorCount(16).generate() }
            val fallback = pal.getDominantColor(0xFF1ED760.toInt())
            target = Color(pal.getVibrantColor(pal.getMutedColor(fallback)))
        } catch (_: Exception) { }
    }
    return animateColorAsState(target, tween(1000), label = "ambient").value
}

/** Ayarlardaki seçime göre arka plan ışığı çizer; kapalıysa hiçbir şey çizmez. */
@Composable
fun AmbientGlow(song: Song?, modifier: Modifier = Modifier) {
    val mode by ThemeStore.ambientMode.collectAsState()
    val presetIdx by ThemeStore.gradient.collectAsState()
    when (mode) {
        1 -> GlowBox(Accent, Accent, modifier)
        2 -> { val c = rememberAmbientColor(hiRes(song?.thumb, 300)); GlowBox(c, c, modifier) }
        3 -> FlowingGlow(Gradients[presetIdx.coerceIn(Gradients.indices)].colors, modifier)
    }
}

@Composable
private fun GlowBox(a: Color, b: Color, modifier: Modifier) {
    Box(modifier.background(Brush.verticalGradient(0f to a.copy(alpha = 0.45f), 0.5f to b.copy(alpha = 0.15f), 1f to Color.Transparent)))
}

/** Renkleri yavaşça birbirine akıtan hareketli ışık. */
@Composable
private fun FlowingGlow(colors: List<Color>, modifier: Modifier) {
    val n = colors.size
    val t by rememberInfiniteTransition(label = "flow").animateFloat(
        0f, n.toFloat(), infiniteRepeatable(tween<Float>(n * 6000, easing = LinearEasing)), label = "flowValue"
    )
    val i = t.toInt() % n
    val f = t - t.toInt()
    val j = (i + 1) % n
    val top = lerp(colors[i], colors[j], f)
    val mid = lerp(colors[j], colors[(j + 1) % n], f)
    GlowBox(top, mid, modifier)
}

// ---------------------------------------------------------------- Bluetooth

private fun openBluetoothSettings(ctx: android.content.Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { }
}

private fun openAppSettings(ctx: android.content.Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}

/** "Bluetooth cihazları" alanı (medya oynatıcıda): şu an bağlı kulaklık, hoparlör ve araç sistemlerini gösterir. */
@Composable
fun BluetoothSection(onRequestPermission: () -> Unit, inset: Dp = 16.dp) {
    val ctx = LocalContext.current
    val devices by BluetoothMonitor.devices.collectAsState()
    val state by BluetoothMonitor.state.collectAsState()
    Column(Modifier.padding(top = 6.dp, bottom = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = inset, end = 0.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Bağlı cihazlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ BluetoothMonitor.refresh() }) { Icon(Icons.Filled.Refresh, "Yenile", tint = Color.Gray) }
        }
        when {
            state == BtState.UNSUPPORTED ->
                BtInfoCard(Icons.Filled.BluetoothDisabled, "Bu cihazda Bluetooth bulunmuyor.", inset)
            state == BtState.NO_PERMISSION ->
                BtInfoCard(Icons.Filled.Bluetooth, "Bağlı cihazları görmek için Bluetooth izni gerekiyor.", inset) {
                    Button(onRequestPermission, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)) { Text("İzin ver") }
                    TextButton({ openAppSettings(ctx) }) { Text("Ayarlar", color = Color.White) }
                }
            state == BtState.OFF ->
                BtInfoCard(Icons.Filled.BluetoothDisabled, "Bluetooth kapalı.", inset) {
                    Button({ openBluetoothSettings(ctx) }, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)) { Text("Aç") }
                }
            devices.isEmpty() ->
                BtInfoCard(Icons.Filled.Bluetooth, "Şu an bağlı cihaz yok.", inset) {
                    TextButton({ openBluetoothSettings(ctx) }) { Text("Cihaz bağla", color = Accent) }
                }
            else -> LazyRow(contentPadding = PaddingValues(horizontal = inset), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(devices, key = { it.address }) { d -> DeviceCard(d) { openBluetoothSettings(ctx) } }
            }
        }
    }
}

@Composable
private fun BtInfoCard(icon: ImageVector, text: String, inset: Dp, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = inset).clip(RoundedCornerShape(16.dp)).background(Card).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color(0xFF9A9A9A))
        Spacer(Modifier.width(12.dp))
        Text(text, color = Color(0xFFCCCCCC), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
private fun DeviceCard(d: BtDevice, onClick: () -> Unit) {
    val icon = when (d.kind) {
        BtKind.HEADPHONES -> Icons.Filled.Headphones
        BtKind.SPEAKER -> Icons.Filled.Speaker
        BtKind.CAR -> Icons.Filled.DirectionsCar
        BtKind.OTHER -> Icons.Filled.BluetoothConnected
    }
    Row(
        Modifier.clip(RoundedCornerShape(16.dp)).background(Card).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(Accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Accent)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(d.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, modifier = Modifier.widthIn(max = 140.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF4CAF50)))
                Spacer(Modifier.width(6.dp))
                Text("Bağlı", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ---------------------------------------------------------------- Keşfet

@Composable
fun DiscoverTab(onOpenSearch: () -> Unit, onOpen: (PlaylistRef) -> Unit) {
    var selected by remember { mutableStateOf<Genre?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Column(Modifier.padding(start = 16.dp, top = 8.dp)) {
                Text("Keşfet", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("YouTube Music çalma listeleri", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium)
            }
        }
        item { SearchPillButton(onClick = onOpenSearch) }
        item {
            Text("Ruh hali ve türler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 8.dp))
        }
        item {
            GenreGrid(genres, selected?.name) { g -> selected = if (selected?.name == g.name) null else g }
        }
        selected?.let { g ->
            item(key = "genre_${g.query}") {
                PlaylistRow("${g.name} çalma listeleri", g.query, onOpen)
            }
        }
        items(discoverSections, key = { it.second }) { (title, q) ->
            PlaylistRow(title, q, onOpen)
        }
    }
}

@Composable
private fun GenreGrid(list: List<Genre>, selected: String?, onClick: (Genre) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { g -> GenreTile(g, g.name == selected, Modifier.weight(1f)) { onClick(g) } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun GenreTile(g: Genre, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(54.dp).clip(RoundedCornerShape(12.dp))
            .background(if (sel) g.color.copy(alpha = 0.40f) else Card).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(g.color))
        Icon(g.icon, null, tint = g.color, modifier = Modifier.padding(start = 12.dp).size(22.dp))
        Text(g.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp, end = 6.dp))
    }
}

/** Başlık + YouTube Music çalma listesi kartlarından oluşan yatay satır. Satır ekrana gelince yüklenir. */
@Composable
fun PlaylistRow(title: String, query: String, onOpen: (PlaylistRef) -> Unit) {
    var lists by remember(query) { mutableStateOf<List<PlaylistRef>?>(null) }
    var failed by remember(query) { mutableStateOf(false) }
    LaunchedEffect(query) {
        failed = false
        lists = MusicRepository.cachedPlaylists(query)
        try { lists = MusicRepository.searchPlaylists(query) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { if (lists == null) failed = true }
    }
    Column(Modifier.padding(top = 14.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        val current = lists
        when {
            current == null && !failed -> LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(3) { Box(Modifier.size(150.dp).clip(RoundedCornerShape(14.dp)).background(Card)) }
            }
            current.isNullOrEmpty() -> Text("Liste yüklenemedi. İnternet bağlantını kontrol et.", color = Color.Gray,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
            else -> LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(current.orEmpty(), key = { it.url }) { p -> PlaylistCard(p) { onOpen(p) } }
            }
        }
    }
}

@Composable
fun PlaylistCard(p: PlaylistRef, onClick: () -> Unit) {
    val tint = tintFor(p.title)
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(Modifier.size(150.dp).clip(RoundedCornerShape(14.dp)).background(Card)) {
            AsyncImage(hiRes(p.thumb, 400), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = 0.55f)))))
            if (p.count > 0) Row(
                Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.LibraryMusic, null, Modifier.size(12.dp), tint = Color.White)
                Spacer(Modifier.width(4.dp))
                Text("${p.count}", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
        Text(p.title, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(p.owner, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Bir çalma listesinin içeriği: kapak, çal / karıştır düğmeleri ve şarkılar. */
@Composable
fun PlaylistScreen(p: PlaylistRef, onBack: () -> Unit) {
    var songs by remember(p.url) { mutableStateOf<List<Song>>(emptyList()) }
    var loading by remember(p.url) { mutableStateOf(true) }
    var error by remember(p.url) { mutableStateOf<String?>(null) }
    LaunchedEffect(p.url) {
        loading = true; error = null
        try {
            songs = MusicRepository.playlistSongs(p.url)
            if (songs.isEmpty()) error = "Bu listede çalınabilir şarkı bulunamadı."
            songs.firstOrNull()?.let { MusicRepository.prefetch(it.url) }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { error = e.message ?: "Liste yüklenemedi" }
        loading = false
    }
    SongList(songs, header = {
        item {
            IconButton(onBack, Modifier.padding(start = 4.dp, top = 4.dp)) { Icon(Icons.Filled.ArrowBack, "Geri") }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(
                    hiRes(p.thumb, 600), null,
                    Modifier.size(200.dp).shadow(16.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Card),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.height(16.dp))
                Text(p.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Text(
                    if (songs.isNotEmpty()) "${p.owner} • ${songs.size} şarkı" else p.owner,
                    color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center
                )
            }
        }
        if (songs.isNotEmpty()) item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    { PlayerManager.playQueue(songs, 0) },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal") }
                OutlinedButton({ PlayerManager.playQueue(songs.shuffled(), 0) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
                }
            }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent) }
        error?.let { item { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) } }
    })
}

@Composable
fun PlayAllButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
    ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(label) }
}

@Composable
fun SearchTab(
    query: String, onQuery: (String) -> Unit, onSearch: (String) -> Unit,
    songs: List<Song>, loading: Boolean, error: String?
) {
    Column(Modifier.fillMaxSize()) {
        Text("Ara", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp))
        SearchPill(query, onQuery, { onSearch(query) }, autoFocus = query.isBlank())
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
        error?.let { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) }
        if (songs.isEmpty() && !loading && query.isBlank()) {
            Text("Popüler aramalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 8.dp))
            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                GenreGrid(genres, null) { g -> onSearch("${g.name} şarkılar") }
            }
        } else SongList(songs)
    }
}

@Composable
fun LibraryTab() {
    val favs by PlayerManager.favorites.collectAsState()
    val downloaded by Downloads.songs.collectAsState()
    var section by remember { mutableIntStateOf(0) }
    val list = if (section == 0) favs else downloaded
    SongList(list, header = {
        item {
            Text("Kitaplık", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp))
        }
        item {
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(section == 0, { section = 0 }, label = { Text("Beğendiklerim") })
                FilterChip(section == 1, { section = 1 }, label = { Text("İndirilenler") })
            }
        }
        if (list.isEmpty()) item {
            Text(
                if (section == 0) "Henüz beğendiğin şarkı yok. Kalp simgesine dokun."
                else "Henüz indirilen şarkı yok. Şarkının yanındaki indirme simgesine dokun.",
                modifier = Modifier.padding(16.dp), color = Color.Gray
            )
        } else item { PlayAllButton("Hepsini çal") { PlayerManager.playQueue(list, 0) } }
    })
}

/** Şarkı listesi. [header] içindeki öğeler listeyle birlikte kayar; böylece liste tüm ekranı kullanır. */
@Composable
fun SongList(songs: List<Song>, header: LazyListScope.() -> Unit = {}) {
    val idx by PlayerManager.index.collectAsState()
    val queue by PlayerManager.queue.collectAsState()
    val activeUrl = queue.getOrNull(idx)?.url
    LazyColumn(Modifier.fillMaxSize()) {
        header()
        itemsIndexed(songs, key = { i, s -> "$i${s.url}" }) { i, s ->
            SongRow(s, s.url == activeUrl) { PlayerManager.playQueue(songs, i) }
        }
    }
}

@Composable
fun SongRow(s: Song, active: Boolean, onClick: () -> Unit) {
    val favs by PlayerManager.favorites.collectAsState()
    val fav = favs.any { it.url == s.url }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(hiRes(s.thumb, 300), null, Modifier.size(56.dp).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (active) Accent else Color.White, fontWeight = FontWeight.Medium)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        DownloadButton(s)
        IconButton({ PlayerManager.toggleFav(s) }) {
            Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.Gray)
        }
    }
}

/** İndir / indiriliyor (iptal) / indirildi (sil) / hata (tekrar dene). */
@Composable
fun DownloadButton(s: Song) {
    val done by Downloads.songs.collectAsState()
    val prog by Downloads.progress.collectAsState()
    val isDone = done.any { it.url == s.url }
    val p = prog[s.url]
    var confirm by remember { mutableStateOf(false) }
    IconButton({
        when {
            isDone -> confirm = true
            p != null && p >= 0 -> Downloads.cancel(s)
            else -> Downloads.download(s)
        }
    }) {
        when {
            isDone -> Icon(Icons.Filled.DownloadDone, "İndirildi", tint = Accent)
            p == null -> Icon(Icons.Filled.Download, "İndir", tint = Color.Gray)
            p < 0 -> Icon(Icons.Filled.ErrorOutline, "İndirilemedi, tekrar dene", tint = Color(0xFFFF6B6B))
            p == 0 -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
            else -> CircularProgressIndicator(progress = { p / 100f }, modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("İndirme silinsin mi?") },
        text = { Text("\"${s.title}\" cihazdan silinecek.") },
        confirmButton = { TextButton({ Downloads.remove(s); confirm = false }) { Text("Sil") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Vazgeç") } }
    )
}

@Composable
fun MixCard(m: Mix, onClick: () -> Unit) {
    val tints = listOf(0xFF1ED760, 0xFFE91E63, 0xFF7C4DFF, 0xFFFF9800, 0xFF00BCD4, 0xFFFF5252)
    val tint = Color(tints[(m.title.hashCode() and 0x7fffffff) % tints.size])
    Box(Modifier.size(150.dp).clip(RoundedCornerShape(12.dp)).background(Card).clickable(onClick = onClick)) {
        AsyncImage(hiRes(m.songs.firstOrNull()?.thumb, 400), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.25f), Color(0xE6000000)))))
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(m.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(m.subtitle, color = Color(0xFFCCCCCC), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun rememberPosition(): Pair<Long, Long> {
    var p by remember { mutableLongStateOf(0L) }
    var d by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) { p = PlayerManager.position(); d = PlayerManager.duration(); delay(100) }
    }
    return p to d
}

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
fun MiniPlayer(song: Song, onOpen: () -> Unit) {
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val (pos, dur) = rememberPosition()
    val smooth by animateFloatAsState(
        if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f, tween(150, easing = LinearEasing), label = "mini"
    )
    Surface(
        color = Card,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(hiRes(song.thumb, 300), null, Modifier.size(44.dp).clip(RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                if (loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
                else IconButton({ PlayerManager.togglePlay() }) {
                    Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat")
                }
                IconButton({ PlayerManager.next(false) }) { Icon(Icons.Filled.SkipNext, "Sonraki") }
            }
            LinearProgressIndicator(
                progress = { smooth },
                modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent, trackColor = Color(0x33FFFFFF)
            )
        }
    }
}

/** Dokunarak ve sürükleyerek ilerletilebilen, sürüklerken büyüyen ilerleme çubuğu. */
@Composable
fun SeekBar(progress: Float, onPreview: (Float) -> Unit, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var width by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    var cur by remember { mutableFloatStateOf(0f) }
    val seek by rememberUpdatedState(onSeek)       // pointerInput eski lambda'yı tutmasın
    val preview by rememberUpdatedState(onPreview)
    val thumbR by animateDpAsState(if (dragging) 9.dp else 5.dp, label = "thumb")
    val trackH by animateDpAsState(if (dragging) 6.dp else 4.dp, label = "track")
    Canvas(
        modifier.fillMaxWidth().height(36.dp)
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o -> seek((o.x / width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragging = true; cur = (o.x / width).coerceIn(0f, 1f); preview(cur) },
                    onDragEnd = { dragging = false; seek(cur) },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        cur = (change.position.x / width).coerceIn(0f, 1f)
                        preview(cur)
                    }
                )
            }
    ) {
        val cy = size.height / 2
        val th = trackH.toPx()
        val w = size.width * progress.coerceIn(0f, 1f)
        drawRoundRect(Color(0x44FFFFFF), Offset(0f, cy - th / 2), Size(size.width, th), CornerRadius(th / 2))
        drawRoundRect(Color.White, Offset(0f, cy - th / 2), Size(w, th), CornerRadius(th / 2))
        drawCircle(Color.White, thumbR.toPx(), Offset(w, cy))
    }
}

@Composable
fun FullPlayer(onRequestBluetooth: () -> Unit, onClose: () -> Unit) {
    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val favs by PlayerManager.favorites.collectAsState()
    val shuffle by PlayerManager.shuffle.collectAsState()
    val repeat by PlayerManager.repeat.collectAsState()
    val song = queue.getOrNull(idx) ?: return
    val (pos, dur) = rememberPosition()
    val scope = rememberCoroutineScope()
    var drag by remember { mutableStateOf<Float?>(null) }
    val target = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val smooth by animateFloatAsState(target, tween(150, easing = LinearEasing), label = "progress")
    val dragValue = drag
    val shown = dragValue ?: smooth
    val fav = favs.any { it.url == song.url }

    Box(Modifier.fillMaxSize().background(Bg)) {
        AmbientGlow(song, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Kapat", Modifier.size(32.dp)) }
                Spacer(Modifier.weight(1f))
                Text("Şimdi çalıyor", color = Color(0xFFDDDDDD))
                Spacer(Modifier.weight(1f)); Spacer(Modifier.width(48.dp))
            }
            Spacer(Modifier.height(16.dp))
            AsyncImage(
                hiRes(song.thumb, 900), null,
                Modifier.fillMaxWidth().aspectRatio(1f).shadow(20.dp, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp)).background(Card),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Color(0xFFDDDDDD), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                DownloadButton(song)
                IconButton({ PlayerManager.toggleFav(song) }) {
                    Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.White)
                }
            }
            SeekBar(
                progress = shown,
                onPreview = { drag = it },
                onSeek = {
                    PlayerManager.seekTo((it * dur).toLong())
                    drag = it
                    // Konum güncellenene kadar çubuk bıraktığın yerde kalsın
                    scope.launch { delay(300); drag = null }
                },
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(if (dragValue != null) (dragValue * dur).toLong() else pos), color = Color(0xFFDDDDDD), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text(fmt(dur), color = Color(0xFFDDDDDD), style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ PlayerManager.toggleShuffle() }, Modifier.size(44.dp)) {
                    Icon(Icons.Filled.Shuffle, "Karıştır", tint = if (shuffle) Accent else Color.White)
                }
                IconButton({ PlayerManager.prev() }, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipPrevious, "Önceki", Modifier.size(34.dp)) }
                Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { PlayerManager.togglePlay() }, contentAlignment = Alignment.Center) {
                    if (loading) CircularProgressIndicator(Modifier.size(32.dp), color = Color.Black, strokeWidth = 3.dp)
                    else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat", Modifier.size(40.dp), tint = Color.Black)
                }
                IconButton({ PlayerManager.next(false) }, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipNext, "Sonraki", Modifier.size(34.dp)) }
                IconButton({ PlayerManager.cycleRepeat() }, Modifier.size(44.dp)) {
                    Icon(if (repeat == 2) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Tekrar",
                        tint = if (repeat > 0) Accent else Color.White)
                }
            }
            Spacer(Modifier.height(8.dp))
            BluetoothSection(onRequestBluetooth, inset = 0.dp)
            Spacer(Modifier.height(8.dp))
            Text("Sıradaki", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            queue.drop(idx + 1).take(20).forEachIndexed { k, s ->
                SongRow(s, false) { PlayerManager.playIndex(idx + 1 + k) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Uygulama açılırken görünen logo benzeri karşılama yazısı. */
@Composable
fun SplashScreen() {
    var start by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { start = true }
    val appear by animateFloatAsState(if (start) 1f else 0f, tween(900), label = "splashAlpha")
    val grow by animateFloatAsState(if (start) 1f else 0.85f, tween(900, easing = FastOutSlowInEasing), label = "splashScale")
    val beat by rememberInfiniteTransition(label = "beat").animateFloat(
        1f, 1.18f, infiniteRepeatable(tween<Float>(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "beatValue"
    )
    val pink = Color(0xFFFF4D8D)
    val textBrush = Brush.linearGradient(listOf(Color(0xFFFF8FB8), Color(0xFFFF4D8D), Color(0xFFB388FF)))
    Box(
        Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }, // açılışta dokunuşları yut
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(320.dp).alpha(appear * 0.6f)
                .background(Brush.radialGradient(listOf(pink.copy(alpha = 0.45f), Color.Transparent)), CircleShape)
        )
        Column(
            Modifier.graphicsLayer { alpha = appear; scaleX = grow; scaleY = grow },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.Favorite, null, tint = pink,
                modifier = Modifier.size(56.dp).graphicsLayer { scaleX = beat; scaleY = beat }
            )
            Spacer(Modifier.height(20.dp))
            Text("İrem", style = TextStyle(brush = textBrush, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp))
            Text(
                "Seni Çok Seviyorum",
                style = TextStyle(brush = textBrush, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp),
                textAlign = TextAlign.Center
            )
        }
        Text(
            "Geliştirici: Efe Emir", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp).alpha(appear)
        )
    }
}
