package com.example.newmusic

import android.Manifest
import android.content.ComponentName
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MusicRepository.init()
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var songs by remember { mutableStateOf(listOf<Song>()) }
    var current by remember { mutableIntStateOf(-1) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(false) }
    var controller by remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(Unit) {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({ controller = future.get() }, ContextCompat.getMainExecutor(ctx))
        onDispose { MediaController.releaseFuture(future) }
    }

    fun playAt(i: Int) {
        if (i !in songs.indices) return
        current = i; error = null
        scope.launch {
            try {
                val s = songs[i]
                val url = MusicRepository.audioUrl(s.url) ?: throw Exception("Ses akışı bulunamadı")
                controller?.run {
                    setMediaItem(
                        MediaItem.Builder().setUri(url).setMediaMetadata(
                            MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist)
                                .setArtworkUri(s.thumb?.let { Uri.parse(it) }).build()
                        ).build()
                    )
                    prepare(); play()
                }
            } catch (e: Exception) { error = e.message ?: "Çalma hatası" }
        }
    }

    DisposableEffect(controller, songs, current) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) playAt(current + 1) // otomatik sonraki
            }
        }
        controller?.addListener(l)
        onDispose { controller?.removeListener(l) }
    }

    fun doSearch() {
        if (query.isBlank()) return
        loading = true; error = null
        scope.launch {
            try { songs = MusicRepository.search(query); current = -1 }
            catch (e: Exception) { error = e.message ?: "Arama hatası" }
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            placeholder = { Text("Şarkı veya sanatçı ara") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { doSearch() })
        )
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }

        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(songs) { i, s ->
                Row(
                    Modifier.fillMaxWidth().clickable { playAt(i) }.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(s.thumb, null, Modifier.size(56.dp).clip(MaterialTheme.shapes.small), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (i == current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        Text(s.artist, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        if (current in songs.indices) {
            Surface(tonalElevation = 6.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(songs[current].thumb, null, Modifier.size(48.dp).clip(MaterialTheme.shapes.small), contentScale = ContentScale.Crop)
                    Text(songs[current].title, Modifier.weight(1f).padding(horizontal = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    IconButton({ playAt(current - 1) }) { Icon(Icons.Default.SkipPrevious, "Önceki") }
                    IconButton({ controller?.let { if (it.isPlaying) it.pause() else it.play() } }) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Oynat/Duraklat")
                    }
                    IconButton({ playAt(current + 1) }) { Icon(Icons.Default.SkipNext, "Sonraki") }
                }
            }
        }
    }
}
