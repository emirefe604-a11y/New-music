package com.example.newmusic

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.lerp
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        QuickLaunch.init(applicationContext)
        MusicRepository.init(applicationContext)
        Charts.init(applicationContext)
        ThemeStore.init(applicationContext)
        AppSettings.init(applicationContext)
        LibrarySync.init(applicationContext)
        AuthStore.init(applicationContext)
        Uploads.init(applicationContext)
        Playlists.init(applicationContext)
        Social.init(applicationContext)
        PlayerManager.connect(this)
        BluetoothMonitor.start(applicationContext)
        handleLaunchIntent(intent)
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31) perms += Manifest.permission.BLUETOOTH_CONNECT
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), 1)
        setContent {
            val themeIdx by ThemeStore.index.collectAsState()
            val pal = Palettes[themeIdx.coerceIn(Palettes.indices)]
            CompositionLocalProvider(LocalPalette provides pal) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = pal.accent, background = pal.bg, surface = pal.bg,
                        surfaceVariant = pal.card, onSurface = Color.White, onBackground = Color.White,
                        secondaryContainer = pal.accent.copy(alpha = 0.30f), onSecondaryContainer = Color.White
                    )
                ) {
                    var splash by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) { delay(900); splash = false }
                    Surface(color = pal.bg, modifier = Modifier.fillMaxSize()) {
                        Box(Modifier.fillMaxSize()) {
                            App(onRequestBluetooth = { requestBluetooth() }) // açılış ekranının arkasında şimdiden yüklenir
                            AnimatedVisibility(splash, exit = fadeOut(tween(300))) { SplashScreen() }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        BluetoothMonitor.refresh()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleLaunchIntent(intent)
    }

    /** Bildirimdeki "Ara" tuşundan gelindiyse Ara sekmesi ve arama çubuğu açılır. */
    private fun handleLaunchIntent(i: Intent?) {
        if (i?.getBooleanExtra(QuickLaunch.EXTRA_OPEN_SEARCH, false) == true) {
            i.removeExtra(QuickLaunch.EXTRA_OPEN_SEARCH)
            QuickLaunch.searchTick.value = QuickLaunch.searchTick.value + 1
        }
    }

    // Uygulama görünürken arkadaşlara "çevrim içi" görünürüz, kapanınca "çevrim dışı"
    override fun onStart() {
        super.onStart()
        Social.start()
        QuickLaunch.hide()
    }

    override fun onStop() {
        super.onStop()
        Social.stop()
        QuickLaunch.show() // uygulama kapanınca bildirim çubuğundan tekrar açılabilsin
    }

    private fun requestBluetooth() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
        else BluetoothMonitor.refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        BluetoothMonitor.refresh()
    }
}

private val chips = listOf(
    "Türkçe Pop" to "Türkçe pop şarkılar",
    "English Pop" to "English pop songs",
    "Türkçe Rap" to "Türkçe rap şarkılar",
    "Hip Hop" to "hip hop songs",
    "Rock" to "rock songs",
    "Arabesk" to "arabesk şarkılar",
    "Lo-Fi" to "lo-fi chill",
    "Slow" to "slow türkçe şarkılar"
)

private data class Genre(val name: String, val query: String, val color: Color, val icon: ImageVector)

private val genres = listOf(
    Genre("Türkçe Pop", "Türkçe pop", Color(0xFFE91E63), Icons.Filled.MusicNote),
    Genre("English Pop", "English pop hits", Color(0xFF2196F3), Icons.Filled.Public),
    Genre("Hip Hop & Rap", "Türkçe rap hip hop", Color(0xFFFF9800), Icons.Filled.Mic),
    Genre("Rock", "Rock", Color(0xFFE53935), Icons.Filled.FlashOn),
    Genre("Arabesk", "Arabesk", Color(0xFF8E24AA), Icons.Filled.Favorite),
    Genre("R&B", "English r&b hits", Color(0xFF7C4DFF), Icons.Filled.Album),
    Genre("Lo-Fi", "Lo-fi chill", Color(0xFF26A69A), Icons.Filled.Nightlight),
    Genre("Slow", "Slow şarkılar", Color(0xFF5C6BC0), Icons.Filled.Headphones),
    Genre("Klasik", "Klasik müzik", Color(0xFF8D6E63), Icons.Filled.Piano),
    Genre("Antrenman", "Workout", Color(0xFFFF5722), Icons.Filled.FitnessCenter)
)

/** lang: 0 her ikisi, 1 Türkçe, 2 İngilizce. İçerik dili ayarına göre süzülür. */
private data class Section(val title: String, val query: String, val lang: Int)

private val discoverSections = listOf(
    Section("Türkçe Pop Hits", "Türkçe pop hits", 1),
    Section("English Pop Hits", "English pop hits", 2),
    Section("Türkçe Rap & Hip Hop", "Türkçe rap", 1),
    Section("Global Hip Hop", "hip hop hits", 2),
    Section("Rock klasikleri", "Rock classics", 0),
    Section("Rahatlatıcı", "Lo-fi chill", 0),
    Section("Arabesk & Slow", "Arabesk slow", 1),
    Section("Yeni çıkanlar", "Yeni çıkan şarkılar ${java.time.Year.now().value}", 0),
    Section("Türkçe Gündem", "Türkçe hit gündem şarkılar", 1),
    Section("Türkçe Nostalji", "90lar türkçe pop şarkılar", 1),
    Section("Dans & Parti", "dance party hits", 2),
    Section("Akustik", "acoustic songs", 0),
    Section("Latin Hits", "latin hits", 2),
    Section("Odaklanma", "focus study music", 0),
    Section("Yol Şarkıları", "road trip songs", 0)
)

/** Ana sayfadaki şarkı listeleri. Günün saatine göre değişir; havuzdan her gün farklı listeler seçilir (dailyPick). */
private data class HomeSpec(val title: String, val subtitle: String, val query: String, val lang: Int)

private fun homeSpecs(hour: Int): List<HomeSpec> {
    val moment = when {
        hour in 5..11 -> HomeSpec("Güne enerjiyle başla", "Sabah için hareketli şarkılar", "feel good morning songs", 0)
        hour in 12..17 -> HomeSpec("Gün boyu keyif", "Gündüz için hafif şarkılar", "feel good pop hits", 0)
        hour in 18..22 -> HomeSpec("Akşam sakinliği", "Akşam için yumuşak şarkılar", "akşam slow chill şarkılar", 0)
        else -> HomeSpec("Gece lo-fi", "Gece için dinlendirici şarkılar", "lo-fi night chill", 0)
    }
    return listOf(
        moment,
        HomeSpec("Türkçe Hit Mix", "Gündemdeki Türkçe şarkılar", "Türkçe pop hit şarkılar", 1),
        HomeSpec("English Hits", "Dünya listelerinden", "top english pop hits", 2),
        HomeSpec("Türkçe Rap Mix", "En iyi Türkçe rap", "Türkçe rap hit", 1),
        HomeSpec("Chill English", "Rahat İngilizce şarkılar", "english chill songs", 2),
        HomeSpec("Slow Türkçe", "Duygusal Türkçe şarkılar", "slow türkçe şarkılar", 1),
        HomeSpec("R&B Vibes", "Yumuşak ritimler", "english r&b hits", 2),
        HomeSpec("Yeni Türkçe", "Yeni çıkan Türkçe şarkılar", "yeni çıkan türkçe şarkılar ${java.time.Year.now().value}", 1),
        HomeSpec("Pop Gündemi", "Bu haftanın pop şarkıları", "top pop songs this week", 2),
        HomeSpec("Dans Mix", "Hareketli şarkılar", "dance hits", 2),
        HomeSpec("Akustik Türkçe", "Sakin ve akustik", "türkçe akustik şarkılar", 1),
        HomeSpec("Yol Şarkıları", "Yolculuk için", "road trip songs", 0),
        HomeSpec("Türkçe Nostalji", "Eski sevdiklerin", "90lar türkçe pop şarkılar", 1),
        HomeSpec("Rock Enerjisi", "Güçlü gitarlar", "rock hits", 2),
        HomeSpec("Odaklan", "Çalışırken dinle", "focus study music", 0),
        HomeSpec("Yeni Türkçe Rap", "Yeni çıkan Türkçe rap", "yeni türkçe rap şarkılar", 1)
    )
}

private fun langOk(pref: Int, lang: Int) = pref == 0 || lang == 0 || pref == lang

/** İki listeyi sırayla karıştırır (bir Türkçe, bir İngilizce gibi). */
private fun interleave(a: List<Song>, b: List<Song>): List<Song> {
    val out = ArrayList<Song>()
    for (i in 0 until maxOf(a.size, b.size)) {
        a.getOrNull(i)?.let { out += it }
        b.getOrNull(i)?.let { out += it }
    }
    return out.distinctBy { it.url }
}

/** Arka plan yüklemeleri aynı anda en fazla 2 ağ isteği yapar; arayüz ve oynatma akıcı kalır. */
private val bgGate = Semaphore(2)

@Composable
fun App(onRequestBluetooth: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(pageCount = { if (Social.enabled) 5 else 4 })
    var showPlayer by remember { mutableStateOf(false) }
    var openPlaylist by remember { mutableStateOf<PlaylistRef?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var showAuth by remember { mutableStateOf(AuthStore.shouldPrompt()) }
    var openUserList by remember { mutableStateOf<String?>(null) }
    var profileUser by remember { mutableStateOf<String?>(null) }
    val goTab: (Int) -> Unit = { i ->
        openPlaylist = null; showSettings = false; openUserList = null; profileUser = null
        scope.launch { pager.animateScrollToPage(i) }
    }

    val searchTick by QuickLaunch.searchTick.collectAsState()
    LaunchedEffect(searchTick) { if (searchTick > 0) { focusSearch = true; goTab(2) } }

    val content by AppSettings.content.collectAsState()
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val today = remember { dayKey() }

    // YouTube Music'in güncel top listeleri: gün içinde yenilenir, ağ yoksa son kayıt gösterilir
    val chartSections by Charts.sections.collectAsState()
    LaunchedEffect(Unit) {
        delay(800)
        while (true) {
            Charts.refreshIfNeeded()
            delay(30 * 60_000L)
        }
    }
    val chartMixes = remember(chartSections, content) {
        chartSections.filter { langOk(content, it.lang) && it.songs.size >= 5 }.take(4)
            .map { Mix("${it.place} · ${it.title}", "YouTube Charts · güncel", it.songs.take(50)) }
    }

    var homeSel by remember { mutableIntStateOf(0) }
    var homeSongs by remember { mutableStateOf(listOf<Song>()) }
    var homeLoading by remember { mutableStateOf(false) }
    var homeError by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(homeSel) {
        val q = chips[homeSel].second
        homeSongs = MusicRepository.cachedSearch(q) ?: emptyList() // önbellek varsa liste anında gelir
        homeLoading = homeSongs.isEmpty(); homeError = null
        try {
            homeSongs = MusicRepository.search(q, persist = true)
            MusicRepository.prefetchAll(homeSongs, 6) // "Tümünü çal" gecikmesiz başlasın
        } catch (e: Exception) { if (homeSongs.isEmpty()) homeError = e.message ?: "Yüklenemedi" }
        homeLoading = false
    }

    // Ana sayfa: kullanıcıya hitap eden hazır listeler (Türkçe + İngilizce, saate göre)
    var homeLists by remember { mutableStateOf<List<Mix>>(emptyList()) }
    LaunchedEffect(content, today) {
        delay(1200) // ilk şarkı için ağı serbest bırak
        // Günün saatine uyan liste hep ilk sırada; geri kalanlar havuzdan her gün farklı seçilir
        val all = homeSpecs(hour).filter { langOk(content, it.lang) }
        val specs = all.take(1) + dailyPick(all.drop(1), 6)
        // Şarkı sırası da bugüne göre karışır: her gün listenin başında farklı şarkılar olur
        fun mix(sp: HomeSpec, songs: List<Song>) = Mix(sp.title, sp.subtitle, dailyShuffle(songs, sp.query.hashCode()).take(30))
        homeLists = specs.mapNotNull { sp ->
            MusicRepository.cachedSearch(sp.query)?.let { mix(sp, it) }
        }.filter { it.songs.size >= 5 }
        val loaded = coroutineScope {
            specs.map { sp ->
                async {
                    try { mix(sp, bgGate.withPermit { MusicRepository.search(sp.query, persist = true) }) }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) { null }
                }
            }.awaitAll()
        }
        val ok = loaded.filterNotNull().filter { it.songs.size >= 5 }
        if (ok.isNotEmpty()) homeLists = ok
    }

    // Ara sekmesi: altta tavsiye edilen şarkılar
    var recommended by remember { mutableStateOf<List<Song>>(emptyList()) }
    LaunchedEffect(content, chartSections) {
        val tr = "Türkçe pop hit şarkılar"
        val en = "top english pop hits"
        fun build() {
            val a = if (content != 2) MusicRepository.cachedSearch(tr).orEmpty() else emptyList()
            val b = if (content != 1) MusicRepository.cachedSearch(en).orEmpty() else emptyList()
            val charted = chartSections.filter { langOk(content, it.lang) }.flatMap { it.songs.take(15) }
            recommended = interleave(charted, interleave(a, b)).take(40)
        }
        build()
        delay(1500)
        try {
            if (content != 2) bgGate.withPermit { MusicRepository.search(tr, persist = true) }
            if (content != 1) bgGate.withPermit { MusicRepository.search(en, persist = true) }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { }
        build()
    }

    var query by remember { mutableStateOf("") }
    var lastSearched by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(listOf<Song>()) }
    var searching by remember { mutableStateOf(false) }
    var searchError by remember { mutableStateOf<String?>(null) }
    fun doSearch(q: String) {
        if (q.isBlank()) return
        query = q; lastSearched = q
        searching = true; searchError = null
        scope.launch {
            try {
                results = MusicRepository.search(q)
                MusicRepository.prefetchAll(results, 6) // ilk sonuçlar hemen çalmaya hazır
            }
            catch (e: Exception) { searchError = e.message ?: "Arama hatası" }
            searching = false
        }
    }

    val mixes by TasteProfile.mixes.collectAsState()
    val mixLoading by TasteProfile.loading.collectAsState()
    LaunchedEffect(Unit) { delay(3000); try { TasteProfile.buildMixes() } catch (_: Exception) {} }
    val refreshMixes: () -> Unit = { scope.launch { try { TasteProfile.buildMixes() } catch (_: Exception) {} } }

    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val err by PlayerManager.error.collectAsState()
    val song = queue.getOrNull(idx)
    // Sonra tanımlanan BackHandler önceliklidir: önce oynatıcı, sonra ayarlar/çalma listesi kapanır
    BackHandler(enabled = showSettings) { showSettings = false }
    BackHandler(enabled = profileUser != null) { profileUser = null }
    BackHandler(enabled = openUserList != null) { openUserList = null }
    BackHandler(enabled = openPlaylist != null) { openPlaylist = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }

    Box(Modifier.fillMaxSize().background(Bg)) {
        AmbientGlow(song, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                // Sekmeler arasında yana kaydırarak geçilir
                HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !showSettings && openPlaylist == null && profileUser == null) { page ->
                    when (page) {
                        0 -> HomeTab(
                            homeSel, { homeSel = it }, homeSongs, homeLoading, homeError, mixes, mixLoading, refreshMixes,
                            chartMixes + homeLists,
                            onOpenSearch = { focusSearch = true; goTab(2) }, onOpenSettings = { showSettings = true }
                        )
                        1 -> DiscoverTab(onOpenSearch = { focusSearch = true; goTab(2) }, onOpen = { openPlaylist = it })
                        2 -> SearchTab(
                            query, { query = it }, { doSearch(it) }, lastSearched, results, searching, searchError,
                            recommended, focusSearch, { focusSearch = false }
                        )
                        3 -> LibraryTab(onOpenList = { openUserList = it }, onOpenAuth = { showAuth = true })
                        else -> FriendsTab(onOpenProfile = { profileUser = it.username }, onOpenAuth = { showAuth = true })
                    }
                }
                val pl = openPlaylist
                val pu = profileUser
                if (showSettings) {
                    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) { SettingsScreen(onOpenAuth = { showAuth = true }) { showSettings = false } }
                } else if (pu != null) {
                    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) {
                        FriendProfileScreen(pu, { profileUser = null }) { openUserList = it; profileUser = null }
                    }
                } else if (openUserList != null) {
                    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) {
                        UserPlaylistScreen(openUserList ?: "") { openUserList = null }
                    }
                } else if (pl != null) {
                    Box(Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }) { PlaylistScreen(pl) { openPlaylist = null } }
                }
            }
            err?.let { Text(it, color = Accent, modifier = Modifier.fillMaxWidth().background(Card).padding(8.dp), style = MaterialTheme.typography.bodySmall) }
            if (song != null) MiniPlayer(song) { showPlayer = true }
            SoftNavBar(
                pager.currentPage, goTab,
                buildList {
                    add(Triple("Ana sayfa", Icons.Filled.Home, Icons.Outlined.Home))
                    add(Triple("Keşfet", Icons.Filled.Explore, Icons.Outlined.Explore))
                    add(Triple("Ara", Icons.Filled.Search, Icons.Outlined.Search))
                    add(Triple("Kitaplık", Icons.Filled.LibraryMusic, Icons.Outlined.LibraryMusic))
                    if (Social.enabled) add(Triple("Arkadaşlar", Icons.Filled.People, Icons.Outlined.People))
                }
            )
        }
        AnimatedVisibility(showPlayer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            FullPlayer(onRequestBluetooth) { showPlayer = false }
        }
        if (showAuth) AuthScreen { showAuth = false }
    }
}

/** Yüzen, yuvarlak alt çubuk. Seçili sekme tema renginde bir hap olarak açılır. */
@Composable
fun SoftNavBar(
    selected: Int, onSelect: (Int) -> Unit,
    items: List<Triple<String, ImageVector, ImageVector>>
) {
    val accent = Accent
    val current by rememberUpdatedState(selected)
    val select by rememberUpdatedState(onSelect)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(Card)
                // Alt çubukta yana kaydırarak da sekme değiştirilir
                .pointerInput(items.size) {
                    var acc = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { acc = 0f }, onDragEnd = { acc = 0f }, onDragCancel = { acc = 0f }
                    ) { change, d ->
                        change.consume()
                        acc += d
                        if (acc > 60f && current < items.size - 1) { select(current + 1); acc = 0f }
                        else if (acc < -60f && current > 0) { select(current - 1); acc = 0f }
                    }
                }
                .padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { i, (label, filled, outlined) ->
                val sel = i == selected
                val bg by animateColorAsState(if (sel) accent.copy(alpha = 0.28f) else Color.Transparent, tween(300), label = "navBg")
                Row(
                    Modifier.clip(RoundedCornerShape(26.dp)).background(bg)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onSelect(i) }
                        .padding(horizontal = if (items.size > 4) 10.dp else 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (sel) filled else outlined, label, tint = if (sel) Color.White else Color(0xFF9A9A9A), modifier = Modifier.size(24.dp))
                    AnimatedVisibility(sel, enter = expandHorizontally(), exit = shrinkHorizontally()) {
                        Text(label, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Arama çubuğu

/**
 * Yuvarlak, dolgulu, çizgisiz arama alanı. Açılınca [focusKey] arttıkça klavye ile odaklanır.
 * Sağdaki çarpı: yazı varsa temizler, yoksa ([onClose] verilmişse) arama çubuğunu gizler.
 */
@Composable
fun SearchPill(
    value: String, onValue: (String) -> Unit, onSearch: () -> Unit,
    placeholder: String = "Şarkı, sanatçı ara", focusKey: Int = 0, onClose: (() -> Unit)? = null
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(focusKey) {
        if (focusKey > 0) {
            delay(250) // sekme kayması / açılış animasyonu bitsin
            try { focus.requestFocus() } catch (_: Exception) { }
        }
    }
    val muted = Color(0xFF9A9A9A)
    TextField(
        value = value, onValueChange = onValue,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).focusRequester(focus),
        placeholder = { Text(placeholder, color = muted) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Accent) },
        trailingIcon = {
            if (value.isNotEmpty()) IconButton({ onValue("") }) { Icon(Icons.Filled.Close, "Temizle", tint = muted) }
            else if (onClose != null) IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowUp, "Aramayı gizle", tint = muted) }
        },
        singleLine = true, shape = RoundedCornerShape(28.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Card, unfocusedContainerColor = Card, disabledContainerColor = Card,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent,
            cursorColor = Accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() })
    )
}

/** Başlık satırlarındaki küçük, yuvarlak arama tuşu: arama çubuğu gizlidir, bu tuşa basınca açılır. */
@Composable
fun SearchIconButton(onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Card).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Filled.Search, "Ara", tint = Color.White, modifier = Modifier.size(22.dp)) }
}

// ---------------------------------------------------------------- Ana sayfa

@Composable
fun HomeTab(
    sel: Int, onSel: (Int) -> Unit, songs: List<Song>, loading: Boolean, error: String?,
    mixes: List<Mix>, mixLoading: Boolean, onRefreshMixes: () -> Unit,
    lists: List<Mix>,
    onOpenSearch: () -> Unit, onOpenSettings: () -> Unit
) {
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val greet = when {
        hour in 5..11 -> "Günaydın"
        hour in 12..17 -> "İyi günler"
        hour in 18..22 -> "İyi akşamlar"
        else -> "İyi geceler"
    }
    SongList(songs, header = {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(greet, color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium)
                    Text("Sounddeep", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
                SearchIconButton(onOpenSearch)
                Spacer(Modifier.width(8.dp))
                Avatar(36.dp, Modifier.clickable { onOpenSettings() })
                IconButton(onOpenSettings) { Icon(Icons.Filled.Settings, "Ayarlar", tint = Color.White) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Senin için", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (mixLoading) CircularProgressIndicator(Modifier.size(18.dp).padding(end = 2.dp), strokeWidth = 2.dp, color = Accent)
                else IconButton(onRefreshMixes) { Icon(Icons.Filled.Refresh, "Yenile", tint = Color.Gray) }
            }
        }
        item {
            if (mixes.isEmpty()) {
                Text(
                    if (mixLoading) "Listelerin hazırlanıyor…" else "Birkaç şarkı dinle veya beğen; zevkine göre karışık listeler burada çıkacak.",
                    color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            } else {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(mixes) { _, m -> MixCard(m) { PlayerManager.playQueue(m.songs, 0) } }
                }
            }
        }
        if (lists.isNotEmpty()) {
            item {
                Text("Sana özel listeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 8.dp))
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(lists) { _, m -> MixCard(m) { PlayerManager.playQueue(m.songs, 0) } }
                }
            }
        }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 10.dp)
            ) {
                itemsIndexed(chips) { i, c ->
                    FilterChip(selected = sel == i, onClick = { onSel(i) }, label = { Text(c.first) })
                }
            }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent) }
        error?.let { item { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) } }
        if (songs.isNotEmpty()) item { PlayAllButton("Tümünü çal") { PlayerManager.playQueue(songs, 0) } }
    })
}

// ---------------------------------------------------------------- Ayarlar

private val GrayText = Color(0xFF9A9A9A)

/** Yuvarlak köşeli kart içinde gruplanmış ayar satırları. */
@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp).padding(top = 18.dp)) {
        Text(title, color = Accent, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Card), content = content)
    }
}

/** Renkli simge karolu, sağında değer ve ok bulunan ayar satırı. */
@Composable
private fun SettingsItem(
    icon: ImageVector, tile: Color, title: String, value: String? = null, divider: Boolean = true,
    trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit
) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(tile), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(14.dp))
            Text(title, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            if (value != null) {
                Text(value, color = GrayText, style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
                Spacer(Modifier.width(4.dp))
            }
            if (trailing != null) trailing() else Icon(Icons.Filled.ChevronRight, null, tint = GrayText)
        }
        if (divider) HorizontalDivider(Modifier.padding(start = 64.dp), color = Color(0x14FFFFFF))
    }
}

/** Alt sayfalardaki seçilebilir kart. */
@Composable
private fun OptionCard(selected: Boolean, title: String, sub: String? = null, leading: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.16f) else Card)
            .border(if (selected) 1.5.dp else 0.dp, if (selected) Accent else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) { leading(); Spacer(Modifier.width(14.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = GrayText, style = MaterialTheme.typography.bodySmall)
        }
        RadioButton(selected, null, colors = RadioButtonDefaults.colors(selectedColor = Accent))
    }
}

@Composable
private fun ProfileCard(onOpenAuth: () -> Unit, onEdit: () -> Unit) {
    val email by AuthStore.email.collectAsState()
    val name by AuthStore.name.collectAsState()
    val mail = email
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.9f), Accent.copy(alpha = 0.45f))))
            .clickable { if (mail == null) onOpenAuth() else onEdit() }.padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(if (mail == null) "Giriş yap / Hesap oluştur" else name,
                color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(mail ?: "Profil fotoğrafı, çalma listeleri ve daha fazlası", color = Color(0xCCFFFFFF), style = MaterialTheme.typography.bodySmall,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = Color.White)
    }
}

/** Ayarlar: gruplanmış, modern kart tasarımı; her satıra dokununca ilgili sayfa açılır. */
@Composable
fun SettingsScreen(onOpenAuth: () -> Unit, onBack: () -> Unit) {
    var page by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = page != null) { page = null }
    val theme by ThemeStore.index.collectAsState()
    val mode by ThemeStore.ambientMode.collectAsState()
    val grad by ThemeStore.gradient.collectAsState()
    val quality by AppSettings.quality.collectAsState()
    val contentPref by AppSettings.content.collectAsState()
    val autoplay by AppSettings.autoplay.collectAsState()
    val quickLaunch by AppSettings.quickLaunch.collectAsState()
    var confirm by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf<String?>(null) }
    val title = when (page) {
        "theme" -> "Tema"
        "ambient" -> "Ambient ışık"
        "quality" -> "Ses kalitesi"
        "content" -> "İçerik dili"
        "storage" -> "Depolama"
        "about" -> "Hakkında"
        "profile" -> "Profil"
        else -> "Ayarlar"
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ if (page != null) page = null else onBack() }) { Icon(Icons.Filled.ArrowBack, "Geri") }
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            when (page) {
                null -> {
                    ProfileCard(onOpenAuth) { page = "profile" }
                    SettingsGroup("Görünüm") {
                        SettingsItem(Icons.Filled.Palette, Color(0xFFE91E63), "Tema", Palettes[theme].name) { page = "theme" }
                        SettingsItem(Icons.Filled.LightMode, Color(0xFFFF9800), "Ambient ışık",
                            AmbientModes[mode], divider = false) { page = "ambient" }
                    }
                    SettingsGroup("Oynatma") {
                        SettingsItem(Icons.Filled.GraphicEq, Color(0xFF2196F3), "Ses kalitesi", QualityNames[quality]) { page = "quality" }
                        SettingsItem(Icons.Filled.Translate, Color(0xFF009688), "İçerik dili", ContentNames[contentPref]) { page = "content" }
                        SettingsItem(Icons.Filled.PlayCircle, Color(0xFF7C4DFF), "Otomatik devam",
                            onClick = { AppSettings.setAutoplay(!autoplay) },
                            trailing = { Switch(checked = autoplay, onCheckedChange = { AppSettings.setAutoplay(it) }) })
                        SettingsItem(Icons.Filled.Notifications, Color(0xFFFF7043), "Bildirim kısayolu", "Çalmıyorken de aç", divider = false,
                            onClick = { AppSettings.setQuickLaunch(!quickLaunch) },
                            trailing = { Switch(checked = quickLaunch, onCheckedChange = { AppSettings.setQuickLaunch(it) }) })
                    }
                    SettingsGroup("Veri") {
                        SettingsItem(Icons.Filled.Storage, Color(0xFF607D8B), "Depolama", "Önbellek, geçmiş", divider = false) { page = "storage" }
                    }
                    SettingsGroup("Uygulama") {
                        SettingsItem(Icons.Filled.Info, Color(0xFF1565FF), "Hakkında", "Sürüm 1.0", divider = false) { page = "about" }
                    }
                }
                "profile" -> ProfilePage { page = null }
                "theme" -> Palettes.forEachIndexed { i, p ->
                    OptionCard(i == theme, p.name, leading = {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(p.bg).border(3.dp, p.accent, CircleShape))
                    }) { ThemeStore.set(i) }
                }
                "ambient" -> {
                    AmbientModes.forEachIndexed { i, name ->
                        OptionCard(i == mode, name, leading = {
                            Icon(when (i) { 0 -> Icons.Filled.LightMode; 1 -> Icons.Filled.Palette; 2 -> Icons.Filled.Album; else -> Icons.Filled.Gradient },
                                null, tint = GrayText, modifier = Modifier.size(28.dp))
                        }) { ThemeStore.setAmbientMode(i) }
                    }
                    if (mode == 3) {
                        Text("Renk geçişi", color = Accent, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(start = 24.dp, top = 18.dp, bottom = 4.dp))
                        Gradients.forEachIndexed { i, g ->
                            OptionCard(i == grad, g.name, leading = {
                                Box(Modifier.size(width = 56.dp, height = 28.dp).clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(g.colors)))
                            }) { ThemeStore.setGradient(i) }
                        }
                    }
                }
                "quality" -> {
                    QualityNames.forEachIndexed { i, name ->
                        OptionCard(i == quality, name, QualityDescs[i], leading = {
                            Icon(Icons.Filled.GraphicEq, null, tint = GrayText, modifier = Modifier.size(28.dp))
                        }) { AppSettings.setQuality(i); PlayerManager.reloadCurrent() }
                    }
                    Text("Ses kalitesini oynatıcıdan da değiştirebilirsin. İndirilmiş şarkılar kendi kalitesinde çalar.",
                        color = GrayText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp))
                }
                "content" -> {
                    ContentNames.forEachIndexed { i, name ->
                        OptionCard(i == contentPref, name, leading = {
                            Icon(Icons.Filled.Translate, null, tint = GrayText, modifier = Modifier.size(28.dp))
                        }) { AppSettings.setContent(i) }
                    }
                    Text("Ana sayfa, Keşfet ve Ara sekmesindeki önerileri etkiler.",
                        color = GrayText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp))
                }
                "storage" -> {
                    SettingsGroup("Temizlik") {
                        SettingsItem(Icons.Filled.Delete, Color(0xFFE53935), "Önbelleği temizle", "Arama ve liste verileri") { confirm = "cache" }
                        SettingsItem(Icons.Filled.History, Color(0xFF8E24AA), "Dinleme geçmişini sıfırla", "Kişisel listeler", divider = false) { confirm = "taste" }
                    }
                    done?.let { Text(it, color = Accent, modifier = Modifier.padding(24.dp)) }
                }
                else -> {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        AppLogo(96.dp)
                        Spacer(Modifier.height(16.dp))
                        Text("Sounddeep", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Sürüm 1.0", color = GrayText, style = MaterialTheme.typography.bodySmall)
                    }
                    SettingsGroup("Geliştirici") {
                        SettingsItem(Icons.Filled.Code, Color(0xFF1565FF), "Efe Emir", "Geliştirici", onClick = {}, trailing = {})
                        SettingsItem(Icons.Filled.Brush, Color(0xFFE91E63), "İrem Harmancı", "Arayüz tasarımcısı", divider = false, onClick = {}, trailing = {})
                    }
                }
            }
        }
    }
    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = Card,
            title = { Text(if (c == "cache") "Önbellek temizlensin mi?" else "Geçmiş sıfırlansın mı?") },
            text = {
                Text(
                    if (c == "cache") "Kayıtlı arama ve liste verileri silinir. İndirdiğin şarkılar silinmez."
                    else "Kişiye özel listeler sıfırlanır; beğendiklerin ve indirdiklerin silinmez."
                )
            },
            confirmButton = {
                TextButton({
                    if (c == "cache") MusicRepository.clearCache() else TasteProfile.reset()
                    done = "Tamamlandı"; confirm = null
                }) { Text("Evet") }
            },
            dismissButton = { TextButton({ confirm = null }) { Text("Vazgeç") } }
        )
    }
}

// ---------------------------------------------------------------- Ambient ışık

/** Albüm kapağındaki baskın rengi çıkarır; şarkı değişince renk yumuşakça geçiş yapar. */
@Composable
fun rememberAmbientColor(url: String?): Color {
    val ctx = LocalContext.current
    var target by remember { mutableStateOf(Color(0xFF1ED760)) }
    LaunchedEffect(url) {
        if (url == null) return@LaunchedEffect
        try {
            val res = ctx.imageLoader.execute(
                ImageRequest.Builder(ctx).data(url).allowHardware(false).size(128).build()
            )
            val bmp = (res as? SuccessResult)?.drawable?.toBitmap() ?: return@LaunchedEffect
            val pal = withContext(Dispatchers.Default) { Palette.from(bmp).maximumColorCount(16).generate() }
            val fallback = pal.getDominantColor(0xFF1ED760.toInt())
            target = Color(pal.getVibrantColor(pal.getMutedColor(fallback)))
        } catch (_: Exception) { }
    }
    return animateColorAsState(target, tween(1000), label = "ambient").value
}

/** Ayarlardaki seçime göre arka plan ışığı çizer; kapalıysa hiçbir şey çizmez. */
@Composable
fun AmbientGlow(song: Song?, modifier: Modifier = Modifier) {
    val mode by ThemeStore.ambientMode.collectAsState()
    val presetIdx by ThemeStore.gradient.collectAsState()
    when (mode) {
        1 -> GlowBox(Accent, Accent, modifier)
        2 -> { val c = rememberAmbientColor(hiRes(song?.thumb, 300)); GlowBox(c, c, modifier) }
        3 -> FlowingGlow(Gradients[presetIdx.coerceIn(Gradients.indices)].colors, modifier)
    }
}

@Composable
private fun GlowBox(a: Color, b: Color, modifier: Modifier) {
    Box(modifier.background(Brush.verticalGradient(0f to a.copy(alpha = 0.45f), 0.5f to b.copy(alpha = 0.15f), 1f to Color.Transparent)))
}

/** Renkleri yavaşça birbirine akıtan hareketli ışık. Animasyon yalnızca çizim aşamasında okunur (yeniden kompozisyon yok). */
@Composable
private fun FlowingGlow(colors: List<Color>, modifier: Modifier) {
    val n = colors.size
    val t = rememberInfiniteTransition(label = "flow").animateFloat(
        0f, n.toFloat(), infiniteRepeatable(tween<Float>(n * 8000, easing = LinearEasing)), label = "flowValue"
    )
    Box(modifier.drawBehind {
        val v = t.value
        val i = v.toInt() % n
        val f = v - v.toInt()
        val j = (i + 1) % n
        val top = lerp(colors[i], colors[j], f)
        val mid = lerp(colors[j], colors[(j + 1) % n], f)
        drawRect(Brush.verticalGradient(0f to top.copy(alpha = 0.45f), 0.5f to mid.copy(alpha = 0.15f), 1f to Color.Transparent))
    })
}

// ---------------------------------------------------------------- Bluetooth

private fun openBluetoothSettings(ctx: android.content.Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { }
}

private fun openAppSettings(ctx: android.content.Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) { }
}

/** Oynatıcıda solda duran küçük Bluetooth etiketi: bağlı cihazın adını gösterir. */
@Composable
fun BluetoothChip(onRequestPermission: () -> Unit) {
    val ctx = LocalContext.current
    val devices by BluetoothMonitor.devices.collectAsState()
    val state by BluetoothMonitor.state.collectAsState()
    if (state == BtState.UNSUPPORTED) return
    val connected = state == BtState.ON && devices.isNotEmpty()
    val label = when {
        state == BtState.NO_PERMISSION -> "İzin ver"
        state == BtState.OFF -> "Kapalı"
        devices.isEmpty() -> "Bağlı değil"
        devices.size == 1 -> devices.first().name
        else -> "${devices.first().name} +${devices.size - 1}"
    }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Card)
            .clickable { if (state == BtState.NO_PERMISSION) onRequestPermission() else openBluetoothSettings(ctx) }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (connected) Icons.Filled.BluetoothConnected else if (state == BtState.OFF) Icons.Filled.BluetoothDisabled else Icons.Filled.Bluetooth,
            null, Modifier.size(16.dp), tint = if (connected) Accent else Color(0xFF9A9A9A)
        )
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = if (connected) Color.White else Color(0xFF9A9A9A), modifier = Modifier.widthIn(max = 120.dp))
    }
}

// ---------------------------------------------------------------- Keşfet

@Composable
fun DiscoverTab(onOpenSearch: () -> Unit, onOpen: (PlaylistRef) -> Unit) {
    val content by AppSettings.content.collectAsState()
    // "Yeni çıkanlar" hep üstte; diğer bölümler havuzdan her gün farklı seçilir
    val shown = remember(content) {
        val all = discoverSections.filter { langOk(content, it.lang) }
        val fixed = all.filter { it.title == "Yeni çıkanlar" }
        fixed + dailyPick(all.filterNot { it in fixed }, 7)
    }
    val charts by Charts.sections.collectAsState()
    var selected by remember { mutableStateOf<Genre?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Keşfet", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("YouTube Music çalma listeleri · her gün yenilenir", color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium)
                }
                SearchIconButton(onOpenSearch)
            }
        }
        item {
            Text("Ruh hali ve türler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 8.dp))
        }
        item {
            GenreGrid(genres, selected?.name) { g -> selected = if (selected?.name == g.name) null else g }
        }
        selected?.let { g ->
            item(key = "genre_${g.query}") {
                PlaylistRow("${g.name} çalma listeleri", g.query, onOpen)
            }
        }
        // YouTube Music'in güncel top listeleri (Türkiye + dünya)
        charts.filter { langOk(content, it.lang) && it.playlists.isNotEmpty() }.forEach { sec ->
            item(key = "chart_${sec.key}") {
                ChartPlaylistsRow("${sec.place} · ${sec.title}", sec.playlists, onOpen)
            }
        }
        items(shown, key = { it.query }) { sec ->
            PlaylistRow(sec.title, sec.query, onOpen)
        }
    }
}

@Composable
private fun GenreGrid(list: List<Genre>, selected: String?, onClick: (Genre) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { g -> GenreTile(g, g.name == selected, Modifier.weight(1f)) { onClick(g) } }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun GenreTile(g: Genre, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(54.dp).clip(RoundedCornerShape(12.dp))
            .background(if (sel) g.color.copy(alpha = 0.40f) else Card).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(g.color))
        Icon(g.icon, null, tint = g.color, modifier = Modifier.padding(start = 12.dp).size(22.dp))
        Text(g.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 10.dp, end = 6.dp))
    }
}

/** Hazır çalma listesi kartlarından oluşan yatay satır (YouTube Music güncel top listeleri). */
@Composable
private fun ChartPlaylistsRow(title: String, lists: List<PlaylistRef>, onOpen: (PlaylistRef) -> Unit) {
    Column(Modifier.padding(top = 14.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(lists, key = { it.url }) { p -> PlaylistCard(p) { onOpen(p) } }
        }
    }
}

/** Başlık + YouTube Music çalma listesi kartlarından oluşan yatay satır. Satır ekrana gelince yüklenir. */
@Composable
fun PlaylistRow(title: String, query: String, onOpen: (PlaylistRef) -> Unit) {
    var lists by remember(query) { mutableStateOf<List<PlaylistRef>?>(null) }
    var failed by remember(query) { mutableStateOf(false) }
    LaunchedEffect(query) {
        failed = false
        lists = MusicRepository.cachedPlaylists(query)
        try { lists = bgGate.withPermit { MusicRepository.searchPlaylists(query) } }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { if (lists == null) failed = true }
    }
    Column(Modifier.padding(top = 14.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        val current = lists
        when {
            current == null && !failed -> LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(3) { Box(Modifier.size(150.dp).clip(RoundedCornerShape(14.dp)).background(Card)) }
            }
            current.isNullOrEmpty() -> Text("Liste yüklenemedi. İnternet bağlantını kontrol et.", color = Color.Gray,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
            else -> LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(current.orEmpty(), key = { it.url }) { p -> PlaylistCard(p) { onOpen(p) } }
            }
        }
    }
}

@Composable
fun PlaylistCard(p: PlaylistRef, onClick: () -> Unit) {
    val tint = tintFor(p.title)
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(Modifier.size(150.dp).clip(RoundedCornerShape(14.dp)).background(Card)) {
            AsyncImage(hiRes(p.thumb, 400), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = 0.55f)))))
            if (p.count > 0) Row(
                Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.LibraryMusic, null, Modifier.size(12.dp), tint = Color.White)
                Spacer(Modifier.width(4.dp))
                Text("${p.count}", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
        Text(p.title, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(p.owner, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Bir çalma listesinin içeriği: kapak, çal / karıştır düğmeleri ve şarkılar. */
@Composable
fun PlaylistScreen(p: PlaylistRef, onBack: () -> Unit) {
    var songs by remember(p.url) { mutableStateOf<List<Song>>(emptyList()) }
    var loading by remember(p.url) { mutableStateOf(true) }
    var error by remember(p.url) { mutableStateOf<String?>(null) }
    LaunchedEffect(p.url) {
        loading = true; error = null
        try {
            songs = MusicRepository.playlistSongs(p.url)
            if (songs.isEmpty()) error = "Bu listede çalınabilir şarkı bulunamadı."
            MusicRepository.prefetchAll(songs, 6)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { error = e.message ?: "Liste yüklenemedi" }
        loading = false
    }
    SongList(songs, header = {
        item {
            IconButton(onBack, Modifier.padding(start = 4.dp, top = 4.dp)) { Icon(Icons.Filled.ArrowBack, "Geri") }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(
                    hiRes(p.thumb, 600), null,
                    Modifier.size(200.dp).shadow(16.dp, RoundedCornerShape(16.dp)).clip(RoundedCornerShape(16.dp)).background(Card),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.height(16.dp))
                Text(p.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Text(
                    if (songs.isNotEmpty()) "${p.owner} • ${songs.size} şarkı" else p.owner,
                    color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center
                )
            }
        }
        if (songs.isNotEmpty()) item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    { PlayerManager.playQueue(songs, 0) },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal") }
                OutlinedButton({ PlayerManager.playQueue(songs.shuffled(), 0) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
                }
            }
        }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent) }
        error?.let { item { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) } }
    })
}

@Composable
fun PlayAllButton(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
    ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(label) }
}

@Composable
private fun SuggestionRow(text: String, onClick: () -> Unit, onFill: (() -> Unit)?) {
    val gray = Color(0xFF9A9A9A)
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = gray)
        Spacer(Modifier.width(16.dp))
        Text(text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (onFill != null) IconButton(onFill) { Icon(Icons.Filled.NorthWest, "Aramaya yaz", tint = gray) }
    }
}

@Composable
fun SearchTab(
    query: String, onQuery: (String) -> Unit, onSearch: (String) -> Unit, lastSearched: String,
    songs: List<Song>, loading: Boolean, error: String?,
    recommended: List<Song>, autoFocus: Boolean, onFocusHandled: () -> Unit
) {
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    val typing = query.isNotBlank() && query != lastSearched
    // Yazarken muhtemel aramalar (kısa bir bekleme ile)
    LaunchedEffect(query, lastSearched) {
        if (!typing) { suggestions = emptyList(); return@LaunchedEffect }
        delay(250)
        suggestions = MusicRepository.suggestions(query.trim())
    }
    // Arama çubuğu varsayılan olarak gizli; tuşa basınca yumuşakça açılır
    var open by remember { mutableStateOf(false) }
    var focusKey by remember { mutableIntStateOf(0) }
    LaunchedEffect(autoFocus) { if (autoFocus) { open = true; focusKey++; onFocusHandled() } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Ara", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            AnimatedVisibility(!(open || query.isNotBlank()), enter = fadeIn(tween(200)), exit = fadeOut(tween(120))) {
                SearchIconButton { open = true; focusKey++ }
            }
        }
        AnimatedVisibility(
            open || query.isNotBlank(),
            enter = expandVertically(tween(250)) + fadeIn(tween(250)),
            exit = shrinkVertically(tween(200)) + fadeOut(tween(150))
        ) {
            SearchPill(query, onQuery, { onSearch(query) }, focusKey = focusKey, onClose = { onQuery(""); open = false })
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent)
        error?.let { Text(it, color = Accent, modifier = Modifier.padding(16.dp)) }
        when {
            typing -> LazyColumn(Modifier.fillMaxSize()) {
                item { SuggestionRow("\"${query.trim()}\" ara", { onSearch(query) }, null) }
                items(suggestions.filter { !it.equals(query.trim(), ignoreCase = true) }, key = { it }) { sug ->
                    SuggestionRow(sug, { onSearch(sug) }) { onQuery(sug) }
                }
            }
            query.isBlank() -> SongList(recommended, header = {
                item {
                    Text("Popüler aramalar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 8.dp))
                }
                item { GenreGrid(genres, null) { g -> onSearch(g.query) } }
                item {
                    Text("Tavsiye edilen şarkılar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 4.dp))
                }
                if (recommended.isEmpty()) item {
                    Text("Öneriler hazırlanıyor…", color = Color.Gray, style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            })
            else -> SongList(songs)
        }
    }
}


/** Şarkı listesi. [header] içindeki öğeler listeyle birlikte kayar; böylece liste tüm ekranı kullanır. */
@Composable
fun SongList(songs: List<Song>, onRemove: ((Song) -> Unit)? = null, header: LazyListScope.() -> Unit = {}) {
    val idx by PlayerManager.index.collectAsState()
    val queue by PlayerManager.queue.collectAsState()
    val activeUrl = queue.getOrNull(idx)?.url
    LazyColumn(Modifier.fillMaxSize()) {
        header()
        itemsIndexed(songs, key = { i, s -> "$i${s.url}" }) { i, s ->
            // Ekranda görünen şarkı arka planda hazırlanır: dokununca anında çalar
            LaunchedEffect(s.url) { MusicRepository.prefetchWhenIdle(s) }
            SongRow(s, s.url == activeUrl, onRemove = onRemove?.let { f -> { f(s) } }) { PlayerManager.playQueue(songs, i) }
        }
    }
}

@Composable
fun SongRow(s: Song, active: Boolean, onRemove: (() -> Unit)? = null, onClick: () -> Unit) {
    val favs by PlayerManager.favorites.collectAsState()
    val fav = favs.any { it.url == s.url }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(hiRes(s.thumb, 300), null, Modifier.size(56.dp).clip(RoundedCornerShape(6.dp)), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (active) Accent else Color.White, fontWeight = FontWeight.Medium)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        if (!Uploads.isLocal(s)) DownloadButton(s)
        IconButton({ PlayerManager.toggleFav(s) }) {
            Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.Gray)
        }
        SongMenu(s, onRemove)
    }
}

/** İndir / indiriliyor (iptal) / indirildi (sil) / hata (tekrar dene). */
@Composable
fun DownloadButton(s: Song) {
    val done by Downloads.songs.collectAsState()
    val prog by Downloads.progress.collectAsState()
    val isDone = done.any { it.url == s.url }
    val p = prog[s.url]
    var confirm by remember { mutableStateOf(false) }
    IconButton({
        when {
            isDone -> confirm = true
            p != null && p >= 0 -> Downloads.cancel(s)
            else -> Downloads.download(s)
        }
    }) {
        when {
            isDone -> Icon(Icons.Filled.DownloadDone, "İndirildi", tint = Accent)
            p == null -> Icon(Icons.Filled.Download, "İndir", tint = Color.Gray)
            p < 0 -> Icon(Icons.Filled.ErrorOutline, "İndirilemedi, tekrar dene", tint = Color(0xFFFF6B6B))
            p == 0 -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
            else -> CircularProgressIndicator(progress = { p / 100f }, modifier = Modifier.size(22.dp), strokeWidth = 2.dp, color = Accent)
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("İndirme silinsin mi?") },
        text = { Text("\"${s.title}\" cihazdan silinecek.") },
        confirmButton = { TextButton({ Downloads.remove(s); confirm = false }) { Text("Sil") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Vazgeç") } }
    )
}

@Composable
fun MixCard(m: Mix, onClick: () -> Unit) {
    val tints = listOf(0xFF1ED760, 0xFFE91E63, 0xFF7C4DFF, 0xFFFF9800, 0xFF00BCD4, 0xFFFF5252)
    val tint = Color(tints[(m.title.hashCode() and 0x7fffffff) % tints.size])
    LaunchedEffect(m.title) { m.songs.firstOrNull()?.let { MusicRepository.prefetchWhenIdle(it) } }
    Box(Modifier.size(150.dp).clip(RoundedCornerShape(12.dp)).background(Card).clickable(onClick = onClick)) {
        AsyncImage(hiRes(m.songs.firstOrNull()?.thumb, 400), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.25f), Color(0xE6000000)))))
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(m.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(m.subtitle, color = Color(0xFFCCCCCC), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun rememberPosition(): State<Pair<Long, Long>> {
    val s = remember { mutableStateOf(0L to 0L) }
    LaunchedEffect(Unit) {
        while (true) { s.value = PlayerManager.position() to PlayerManager.duration(); delay(250) }
    }
    return s
}

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

/** Mini oynatıcının ince ilerleme çubuğu; konum yalnızca çizim aşamasında okunur, yeniden kompozisyon olmaz. */
@Composable
private fun MiniProgress() {
    val pos = rememberPosition()
    LinearProgressIndicator(
        progress = { val (p, d) = pos.value; if (d > 0) (p.toFloat() / d).coerceIn(0f, 1f) else 0f },
        modifier = Modifier.fillMaxWidth().height(2.dp), color = Accent, trackColor = Color(0x33FFFFFF)
    )
}

@Composable
fun MiniPlayer(song: Song, onOpen: () -> Unit) {
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    Surface(
        color = Card,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(hiRes(song.thumb, 300), null, Modifier.size(44.dp).clip(RoundedCornerShape(4.dp)), contentScale = ContentScale.Crop)
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(song.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                if (loading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Color.White)
                else IconButton({ PlayerManager.togglePlay() }) {
                    Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat")
                }
                IconButton({ PlayerManager.next(false) }) { Icon(Icons.Filled.SkipNext, "Sonraki") }
            }
            MiniProgress()
        }
    }
}

/** Dokunarak ve sürükleyerek ilerletilebilen, sürüklerken büyüyen ilerleme çubuğu. */
@Composable
fun SeekBar(progress: Float, onPreview: (Float) -> Unit, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    var width by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    var cur by remember { mutableFloatStateOf(0f) }
    val seek by rememberUpdatedState(onSeek)       // pointerInput eski lambda'yı tutmasın
    val preview by rememberUpdatedState(onPreview)
    val thumbR by animateDpAsState(if (dragging) 9.dp else 5.dp, label = "thumb")
    val trackH by animateDpAsState(if (dragging) 6.dp else 4.dp, label = "track")
    Canvas(
        modifier.fillMaxWidth().height(36.dp)
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o -> seek((o.x / width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragging = true; cur = (o.x / width).coerceIn(0f, 1f); preview(cur) },
                    onDragEnd = { dragging = false; seek(cur) },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        cur = (change.position.x / width).coerceIn(0f, 1f)
                        preview(cur)
                    }
                )
            }
    ) {
        val cy = size.height / 2
        val th = trackH.toPx()
        val w = size.width * progress.coerceIn(0f, 1f)
        drawRoundRect(Color(0x44FFFFFF), Offset(0f, cy - th / 2), Size(size.width, th), CornerRadius(th / 2))
        drawRoundRect(Color.White, Offset(0f, cy - th / 2), Size(w, th), CornerRadius(th / 2))
        drawCircle(Color.White, thumbR.toPx(), Offset(w, cy))
    }
}

/** İlerleme çubuğu ve süreler: sık güncellenen kısım ayrı tutulur, böylece oynatıcının geri kalanı yeniden çizilmez. */
@Composable
private fun PlayerSeek() {
    val posState = rememberPosition()
    val (pos, dur) = posState.value
    val scope = rememberCoroutineScope()
    var drag by remember { mutableStateOf<Float?>(null) }
    val target = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val dragValue = drag
    val shown = dragValue ?: target
    Column {
        SeekBar(
            progress = shown,
            onPreview = { drag = it },
            onSeek = {
                PlayerManager.seekTo((it * dur).toLong())
                drag = it
                // Konum güncellenene kadar çubuk bıraktığın yerde kalsın
                scope.launch { delay(400); drag = null }
            },
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(if (dragValue != null) (dragValue * dur).toLong() else pos), color = Color(0xFFDDDDDD), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.weight(1f))
            Text(fmt(dur), color = Color(0xFFDDDDDD), style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Oynatıcıdan ses kalitesi seçimi; çalan şarkı seçilen kaliteyle aynı yerden yeniden başlar. */
@Composable
private fun QualityChip() {
    val q by AppSettings.quality.collectAsState()
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Card).clickable { open = true }
                .padding(start = 10.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.GraphicEq, null, Modifier.size(16.dp), tint = Accent)
            Spacer(Modifier.width(6.dp))
            Text(QualityNames[q], style = MaterialTheme.typography.labelMedium)
            Icon(Icons.Filled.ArrowDropDown, null, Modifier.size(18.dp), tint = Color(0xFF9A9A9A))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            QualityNames.forEachIndexed { i, n ->
                DropdownMenuItem(
                    text = {
                        Column(Modifier.widthIn(max = 220.dp)) {
                            Text(n, fontWeight = FontWeight.Medium)
                            Text(QualityDescs[i], color = Color(0xFF9A9A9A), style = MaterialTheme.typography.bodySmall)
                        }
                    },
                    trailingIcon = { if (i == q) Icon(Icons.Filled.Check, null, tint = Accent) },
                    onClick = {
                        open = false
                        if (i != q) { AppSettings.setQuality(i); PlayerManager.reloadCurrent() }
                    }
                )
            }
        }
    }
}

@Composable
fun FullPlayer(onRequestBluetooth: () -> Unit, onClose: () -> Unit) {
    val queue by PlayerManager.queue.collectAsState()
    val idx by PlayerManager.index.collectAsState()
    val playing by PlayerManager.playing.collectAsState()
    val loading by PlayerManager.loading.collectAsState()
    val favs by PlayerManager.favorites.collectAsState()
    val shuffle by PlayerManager.shuffle.collectAsState()
    val repeat by PlayerManager.repeat.collectAsState()
    val song = queue.getOrNull(idx) ?: return
    val fav = favs.any { it.url == song.url }
    var addOpen by remember { mutableStateOf(false) }
    var shareOpen by remember { mutableStateOf(false) }
    if (addOpen) AddToPlaylistDialog(song) { addOpen = false }
    if (shareOpen) ShareSongDialog(song) { shareOpen = false }

    Box(Modifier.fillMaxSize().background(Bg)) {
        AmbientGlow(song, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Kapat", Modifier.size(32.dp)) }
                BluetoothChip(onRequestBluetooth)
                Spacer(Modifier.weight(1f))
                QualityChip()
                if (ShareSong.canShare(song)) IconButton({ shareOpen = true }) { Icon(Icons.Filled.Share, "Paylaş") }
            }
            Spacer(Modifier.height(16.dp))
            AsyncImage(
                hiRes(song.thumb, 900), null,
                Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Card),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Color(0xFFDDDDDD), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (!Uploads.isLocal(song)) DownloadButton(song)
                IconButton({ addOpen = true }) { Icon(Icons.Filled.PlaylistAdd, "Listeye ekle") }
                IconButton({ PlayerManager.toggleFav(song) }) {
                    Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", tint = if (fav) Accent else Color.White)
                }
            }
            PlayerSeek()
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton({ PlayerManager.toggleShuffle() }, Modifier.size(44.dp)) {
                    Icon(Icons.Filled.Shuffle, "Karıştır", tint = if (shuffle) Accent else Color.White)
                }
                IconButton({ PlayerManager.prev() }, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipPrevious, "Önceki", Modifier.size(34.dp)) }
                Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { PlayerManager.togglePlay() }, contentAlignment = Alignment.Center) {
                    if (loading) CircularProgressIndicator(Modifier.size(32.dp), color = Color.Black, strokeWidth = 3.dp)
                    else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Oynat/Duraklat", Modifier.size(40.dp), tint = Color.Black)
                }
                IconButton({ PlayerManager.next(false) }, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipNext, "Sonraki", Modifier.size(34.dp)) }
                IconButton({ PlayerManager.cycleRepeat() }, Modifier.size(44.dp)) {
                    Icon(if (repeat == 2) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Tekrar",
                        tint = if (repeat > 0) Accent else Color.White)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Sıradaki", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            queue.drop(idx + 1).take(20).forEachIndexed { k, s ->
                SongRow(s, false) { PlayerManager.playIndex(idx + 1 + k) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Uygulama açılırken yalnızca yuvarlak NM logosu görünür. */
@Composable
fun SplashScreen() {
    var start by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { start = true }
    val appear by animateFloatAsState(if (start) 1f else 0f, tween(450), label = "splashAlpha")
    val grow by animateFloatAsState(if (start) 1f else 0.8f, tween(450, easing = FastOutSlowInEasing), label = "splashScale")
    val blue = Color(0xFF1565FF)
    Box(
        Modifier.fillMaxSize().background(Bg).pointerInput(Unit) { }, // açılışta dokunuşları yut
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.size(300.dp).alpha(appear * 0.7f)
                .background(Brush.radialGradient(listOf(blue.copy(alpha = 0.40f), Color.Transparent)), CircleShape)
        )
        Box(Modifier.graphicsLayer { alpha = appear; scaleX = grow; scaleY = grow }) { AppLogo(132.dp) }
    }
}
