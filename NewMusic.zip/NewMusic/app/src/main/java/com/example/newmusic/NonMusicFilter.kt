package com.example.newmusic

import java.util.Locale

/**
 * Muzik ve sarki olmayan icerikleri (Podcastler, oyun/gameplay videolari,
 * mac ozetleri/haberler, roportajlar, belgeseller, vloglar, tepki/reaction videolari,
 * soru-cevap, unboxing, sesli kitaplar, ders anlatimlari, film/dizi sahneleri ve fragmanlari)
 * tespit eder ve tamamen filtreler.
 *
 * Arama, Ana Sayfa, Kesfet, Listeler, Benzer Parcalar ve Calma Kuyrugunda asla gosterilmez.
 */
object NonMusicFilter {

    private fun normalize(s: String): String =
        s.lowercase(Locale.ROOT)
            .replace('ı', 'i').replace('İ', 'i')
            .replace('ç', 'c').replace('ş', 's')
            .replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o')

    private val nonMusicRegex = Regex(
        """(?i)(?:""" +
            // 1. Podcastler, Sohbet, Stand-up
            """\b(?:podcast|podcasts|podcasti|podcaste)\b|""" +
            """\b(?:talk\s*show|stand-?up|komedi\s*kulubu)\b|""" +
            """\b(?:sohbet|muhabbet|panel|konferans|seminer)\s*(?:bolum\w*|program\w*|kayd\w*)\b|""" +
            """\bprogrami\s*(?:bolum|izle|full)\b|""" +

            // 2. Bolumler, Sezonlar, Kisimlar (Dizi/Program/Yayin/Oyun)
            """\b(?:ep|episode|bolum|kisim|part)\s*[\.#-]?\s*\d+\b|""" +
            """\b\d+\s*[\.#-]?\s*(?:bolum|kisim|sezon|episode)\b|""" +
            """\b(?:sezon|season)\s*\d+\b|""" +
            """\b(?:sezon\s*finali|final\s*bolumu|yeni\s*bolum)\b|""" +

            // 3. Roportajlar, Belgeseller, Kamera Arkasi, Biyografi
            """\b(?:roportaj\w*|interview\w*)\b|""" +
            """\b(?:belgesel\w*|documentary|biyografi|kimdir|hayati|hayat\s*hikayesi)\b|""" +
            """\b(?:kamera\s*arkasi|behind\s*the\s*scenes|making\s*of|bloopers|cekim\s*hatalar\w*)\b|""" +

            // 4. Oyunlar, Yayincilar, Canli Yayin Kesitleri, Oynanis
            """\b(?:gameplay|walkthrough|oynanis|let\'?s\s*play|tam\s*cozum|speedrun|oyun\s*inceleme)\b|""" +
            """\b(?:twitch|kick|yayinci|streamer)\b.*?\b(?:kesit\w*|anlar\w*|en\s*iyi)\b|""" +
            """\b(?:yayin\s*kesit\w*|yayin\s*anlar\w*|canli\s*yayin\s*kayd\w*)\b|""" +

            // 5. Vloglar, Mukbang, Kutu Acilisi, Tepki / Reaction
            """\b(?:vlog\w*|gunluk\s*vlog|tatil\s*vlog\w*|gezi\s*vlog\w*)\b|""" +
            """\b(?:mukbang|unboxing|kutu\s*acil\w*)\b|""" +
            """\b(?:reaction\w*|reacting|reacts?\s*to|tepki\w*|tepki\s*videosu)\b|""" +
            """\b(?:first\s*time\s*(?:hearing|listening)|ilk\s*defa\s*dinle\w*|ilk\s*kez\s*dinli\w*)\b|""" +
            """\b(?:soru\s*[-–]?\s*cevap|q&a|challenge|meydan\s*okuma|prank|sosyal\s*deney)\b|""" +

            // 6. Dersler, Egitsel, Nasil Calinir / Yapilir (Muzik disi ogretici icerikler)
            """\b(?:nasil\s*yapilir|how\s*to|tutorial|rehber|kilavuz)\b|""" +
            """\b(?:gitar\s*ders\w*|piyano\s*ders\w*|san\s*ders\w*|guitar\s*lesson\w*|piano\s*lesson\w*|davul\s*ders\w*|baglama\s*ders\w*)\b|""" +
            """\b(?:nasil\s*calinir|akorlar\w*\s*ve\s*sozler\w*|akor\s*ve\s*tab)\b|""" +
            """\b(?:konu\s*anlatim\w*|soru\s*cozum\w*|oabt|kpss|yks|ayt|tyt|lgs)\b|""" +
            """\b(?:vocal\s*coach\s*react\w*|ses\s*egitim\w*|san\s*egitim\w*)\b|""" +

            // 7. Sesli Kitaplar, Masallar, Vaazlar
            """\b(?:sesli\s*kitap\w*|audiobook\w*|audio\s*book\w*|sesli\s*masal\w*|sesli\s*roman\w*|masal\s*dinle|hikaye\s*dinle|kitap\s*ozet\w*)\b|""" +
            """\b(?:vaaz|hutbe|dini\s*sohbet|tefsir\s*dersler\w*|mukabele)\b|""" +

            // 8. Haberler, Basin Toplantilari, Spor / Mac Ozetleri
            """\b(?:haber\s*bulten\w*|ana\s*haber|son\s*dakika|breaking\s*news|haberleri|gunun\s*haberleri)\b|""" +
            """\b(?:mac\s*ozet\w*|genis\s*ozet|ozet\s*izle|tum\s*goller|highlights)\b|""" +
            """\b(?:basin\s*toplantisi|basin\s*aciklamasi)\b|""" +

            // 9. Filmler, Diziler, Fragmanlar, Skecler, Sahneler
            """\b(?:fragman\w*|trailer|official\s*trailer|teaser\s*trailer)\b|""" +
            """\b(?:full\s*izle|tek\s*parca|film\s*izle|dizi\s*izle|turkce\s*dublaj\s*izle|full\s*hd\s*izle)\b|""" +
            """\b(?:dizi\s*sahnesi|film\s*sahnesi|en\s*komik\s*sahne)\b|""" +
            """\b(?:skec\w*|guldur\s*guldur|cok\s*guzel\s*hareketler)\b|""" +

            // 11. Konserler, Canli Performanslar ve Sahne Kayitlari
            """(?:konser|konseri|konserleri|konserinde|konserinden|konser\s*kayd\w*)|""" +
            """(?:acikhava|harbiye|bostanci|kucukciftlik|volkswagen\s*arena)\s*(?:konser\w*|sahne\w*)|""" +
            """(?:canli\s*konser|live\s*concert|concert\s*live|full\s*concert)|""" +
            """(?:canli\s*performans|canli\s*sahne|canli\s*soyledi|canli\s*okudu|canli\s*kayit|canli\s*akustik)|""" +
            """(?:live\s*performance|live\s*session|live\s*sessions|live\s*acoustic|live\s*recording)|""" +
            """(?:live\s*at|live\s*in|live\s*from|live\s*on\s*tour)|""" +
            """(?:akustikhane|kral\s*pop\s*akustik|joyturk\s*akustik)|""" +
            """[\(\[\{【「]\s*(?:canli|live|canli\s*yayin|canli\s*konser|live\s*version)\s*[\)\]\}】」]|""" +
            """[\(\[\{【「]\s*live\s+(?:at|in|from)\s+[^\\]\)]+[\)\]\}】」]|""" +

            // 10. Ses efektleri, saf meme sesleri
            """\b(?:sound\s*effects?|ses\s*efekt\w*|meme\s*sound\w*|earrape|green\s*screen|intro\s*template)\b""" +
        """)"""
    )

    fun isNonMusic(title: String, artist: String = ""): Boolean {
        val t = normalize(title)
        val a = normalize(artist)
        return nonMusicRegex.containsMatchIn(t) || nonMusicRegex.containsMatchIn(a)
    }

    fun isNonMusic(s: Song): Boolean = isNonMusic(s.title, s.artist)
}

/** Muzik ve sarki olmayan icerikleri listeden temizler */
fun List<Song>.noNonMusic(): List<Song> = filterNot { NonMusicFilter.isNonMusic(it) }
