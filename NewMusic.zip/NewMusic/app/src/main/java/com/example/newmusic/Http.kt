package com.example.newmusic

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Ortak HTTP istemcisi: bağlantılar yeniden kullanılır, böylece şarkılar daha hızlı başlar. */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .fastFallback(true) // Mobil veride IPv6/IPv4 takılmalarını önleyen Happy Eyeballs (RFC 8305)
            .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
            .dispatcher(Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 24 })
            .connectTimeout(10, TimeUnit.SECONDS) // Mobil veride baz istasyonu geçişlerinde zaman aşımını önler
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .protocols(listOf(okhttp3.Protocol.HTTP_2, okhttp3.Protocol.HTTP_1_1))
            .retryOnConnectionFailure(true)
            .build()
    }

    /** Kendi sunucumuz için: Render ücretsiz paketi uykudan 30-60 sn'de uyandığından zaman aşımı uzundur. */
    val server: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(70, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()
    }
}
