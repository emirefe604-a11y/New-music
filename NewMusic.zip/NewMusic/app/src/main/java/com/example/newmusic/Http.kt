package com.example.newmusic

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Ortak HTTP istemcisi: bağlantılar yeniden kullanılır, böylece şarkılar daha hızlı başlar. */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectionPool(ConnectionPool(32, 10, TimeUnit.MINUTES))
            .dispatcher(Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 24 })
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(12, TimeUnit.SECONDS)
            .protocols(listOf(okhttp3.Protocol.HTTP_2, okhttp3.Protocol.HTTP_1_1))
            .retryOnConnectionFailure(true)
            .build()
    }

    /** Kendi sunucumuz için: Render ücretsiz paketi uykudan 30-60 sn'de uyandığından zaman aşımı uzundur. */
    val server: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(70, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()
    }
}
