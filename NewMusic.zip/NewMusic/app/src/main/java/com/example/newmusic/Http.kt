package com.example.newmusic

import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Ortak HTTP istemcisi: bağlantılar yeniden kullanılır, böylece şarkılar daha hızlı başlar. */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectionPool(ConnectionPool(24, 10, TimeUnit.MINUTES))
            .dispatcher(Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 20 })
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    /** Kendi sunucumuz için: Render ücretsiz paketi uykudan 30-60 sn'de uyandığından zaman aşımı uzundur. */
    val server: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(70, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(90, TimeUnit.SECONDS)
            .build()
    }
}
