package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Doğrulama kodunu e-postaya gönderen sunucunun adresi.
 * Örnek: "https://newmusic-auth.onrender.com"
 * Sunucu kodu projedeki `backend/` klasöründe hazır; kurulumu `backend/README.md` içinde anlatılıyor.
 * Boş bırakılırsa uygulama çalışır ama kod gönderilemez.
 */
const val AUTH_API_URL = ""

/** Giriş yapan hesap bu cihazda saklanır. */
object AuthStore {
    val email = MutableStateFlow<String?>(null)
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        email.value = p.getString("auth_email", null)
    }

    /** İlk açılışta giriş ekranı bir kez önerilir. */
    fun shouldPrompt(): Boolean = email.value == null && prefs?.getBoolean("auth_prompted", false) != true

    fun markPrompted() { prefs?.edit()?.putBoolean("auth_prompted", true)?.apply() }

    fun signIn(mail: String) {
        email.value = mail
        prefs?.edit()?.putString("auth_email", mail)?.putBoolean("auth_prompted", true)?.apply()
    }

    fun signOut() {
        email.value = null
        prefs?.edit()?.remove("auth_email")?.apply()
    }

    fun displayName(mail: String): String =
        mail.substringBefore('@').replace('.', ' ').replace('_', ' ').trim()
            .replaceFirstChar { it.uppercase() }.ifBlank { "Hesabım" }
}

/** E-posta kodu sunucusuyla konuşur. Hata varsa mesajı, başarılıysa null döner. */
object AuthApi {
    private val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()

    private suspend fun post(path: String, json: JSONObject): Pair<Int, String> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(AUTH_API_URL.trimEnd('/') + path)
            .post(json.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(req).execute().use { r -> r.code to (r.body?.string() ?: "") }
    }

    private fun errorOf(body: String, fallback: String): String =
        try { JSONObject(body).optString("error").ifBlank { fallback } } catch (e: Exception) { fallback }

    private suspend fun call(path: String, json: JSONObject, fallback: String): String? {
        if (AUTH_API_URL.isBlank()) return "Kod gönderme sunucusu henüz ayarlanmadı. Kurulum için backend/README.md dosyasına bak."
        return try {
            val (code, body) = post(path, json)
            if (code in 200..299) null else errorOf(body, fallback)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Bağlantı kurulamadı. İnternetini kontrol et." }
    }

    suspend fun sendCode(email: String): String? =
        call("/send-code", JSONObject().put("email", email), "Kod gönderilemedi.")

    suspend fun verify(email: String, code: String): String? =
        call("/verify", JSONObject().put("email", email).put("code", code), "Kod doğrulanamadı.")
}
