package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

/*
 * HESAPLAR sunucuda saklanır (backend/ klasörü, Render + Upstash Redis): uygulama silinip yeniden kurulsa bile
 * aynı e-posta ve şifreyle giriş yapılır. Sunucu adresi Social.kt içindeki SOCIAL_API_URL'dir (hesap ve arkadaşlar aynı sunucuda).
 *
 * E-posta kodu: sunucuda e-posta ayarlıysa (Brevo / SMTP, bkz. backend/README.md) kod sunucudan gelir.
 * Ayarlı değilse aşağıdaki EmailJS değerleri yedek olarak kullanılır (EPOSTA_KURULUM.md).
 */
const val EMAILJS_SERVICE_ID = "service_psblk8l"
const val EMAILJS_TEMPLATE_ID = "template_xbfokyn"
const val EMAILJS_PUBLIC_KEY = "E6Xp9kgx0CI-4nqzt"

/** Sunucunun giriş / kayıt / şifre sıfırlama yanıtı. [error] null ise başarılıdır. */
class AuthResult(
    val error: String?,
    val name: String = "",
    val session: String = "",
    val socialName: String? = null,
    val socialToken: String? = null
)

/**
 * Giriş yapılmış hesap: e-posta, ad, oturum anahtarı. Parola cihazda tutulmaz; doğrulama sunucudadır.
 * Profil fotoğrafı yalnızca bu cihazda saklanır (arkadaşlar sekmesindeki fotoğraf ayrıdır ve sunucudadır).
 */
object AuthStore {
    val email = MutableStateFlow<String?>(null)
    val name = MutableStateFlow("")
    val photo = MutableStateFlow<String?>(null)
    private var prefs: SharedPreferences? = null
    private var avatarDir: File? = null

    /** Sunucu oturum anahtarı; yoksa (eski sürümden kalan yerel hesap) sunucuya bağlı işlemler yapılamaz. */
    val session: String? get() = prefs?.getString("auth_session", null)

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        val p = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        avatarDir = File(app.filesDir, "avatars").apply { mkdirs() }
        email.value = p.getString("auth_email", null)
        refreshProfile()
    }

    private fun accounts(): JSONObject =
        try { JSONObject(prefs?.getString("accounts", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun saveAccounts(o: JSONObject) { prefs?.edit()?.putString("accounts", o.toString())?.apply() }

    private fun refreshProfile() {
        val m = email.value
        if (m == null) { name.value = ""; photo.value = null; return }
        val a = accounts().optJSONObject(m)
        val n = a?.optString("name").orEmpty()
        name.value = if (n.isNotBlank()) n else "Hesabım"   // e-posta adresinden ad türetilmez
        val ph = a?.optString("photo").orEmpty()
        photo.value = if (ph.isNotBlank() && File(ph).exists()) ph else null
    }

    /** Sunucu girişi başarılıysa oturumu açar; arkadaş hesabı (kullanıcı adı) da bu cihaza otomatik gelir. */
    fun signIn(mail: String, r: AuthResult) {
        updateAccount(mail) { if (r.name.isNotBlank()) it.put("name", r.name) }
        email.value = mail
        prefs?.edit()?.putString("auth_email", mail)?.putString("auth_session", r.session)?.putBoolean("auth_prompted", true)?.apply()
        refreshProfile()
        val sn = r.socialName
        val st = r.socialToken
        if (sn != null && st != null) Social.restore(sn, st)
    }

    fun signOut() {
        val s = session
        email.value = null
        prefs?.edit()?.remove("auth_email")?.remove("auth_session")?.apply()
        refreshProfile()
        Social.signOutLocal()   // arkadaş hesabı hesaba bağlı; tekrar girince sunucudan geri gelir
        if (s != null) AuthApi.logoutAsync(s)
    }

    private fun updateAccount(mail: String, block: (JSONObject) -> Unit) {
        val all = accounts()
        val o = all.optJSONObject(mail) ?: JSONObject()
        block(o)
        all.put(mail, o)
        saveAccounts(all)
    }

    fun setName(n: String) {
        val mail = email.value ?: return
        updateAccount(mail) { it.put("name", n.trim()) }
        refreshProfile()
        AuthApi.updateNameAsync(session, n.trim())
    }

    /** Seçilen resmi kare kırpıp küçülterek profil fotoğrafı yapar. */
    suspend fun setPhoto(ctx: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        val mail = email.value ?: return@withContext false
        val dir = avatarDir ?: return@withContext false
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
            val file = File(dir, "${Integer.toHexString(mail.hashCode())}_${System.currentTimeMillis()}.jpg")
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val old = accounts().optJSONObject(mail)?.optString("photo").orEmpty()
            if (old.isNotBlank()) File(old).delete()
            updateAccount(mail) { it.put("photo", file.absolutePath) }
            refreshProfile()
            true
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { false }
    }

    /** Cihazdaki profil fotoğrafını siler. */
    fun clearPhoto() {
        val mail = email.value ?: return
        val old = accounts().optJSONObject(mail)?.optString("photo").orEmpty()
        if (old.isNotBlank()) File(old).delete()
        updateAccount(mail) { it.remove("photo") }
        refreshProfile()
    }

    /** İlk açılışta giriş ekranı bir kez önerilir. */
    fun shouldPrompt(): Boolean = email.value == null && prefs?.getBoolean("auth_prompted", false) != true

    fun markPrompted() { prefs?.edit()?.putBoolean("auth_prompted", true)?.apply() }
}

/** Sunucu ile hesap işlemleri. Kod gönderme sunucuda ayarlı değilse EmailJS ile yedek yol kullanılır. */
object AuthApi {
    private val random = SecureRandom()
    private const val JSON = "application/json; charset=utf-8"
    private const val NO_NET = "Sunucuya bağlanılamadı. İnternetini kontrol et; sunucu uykudaysa 1 dakika sonra tekrar dene."
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private class Pending(val hash: String, val expires: Long, var attempts: Int, val sentAt: Long)
    private val pending = HashMap<String, Pending>()
    /** Kodu hangi yolla gönderdik? true: EmailJS (kod uygulamada doğrulanır), false: sunucu. */
    private val localMode = HashMap<String, Boolean>()

    private val emailJsMode: Boolean
        get() = EMAILJS_SERVICE_ID.isNotBlank() && EMAILJS_TEMPLATE_ID.isNotBlank() && EMAILJS_PUBLIC_KEY.isNotBlank()

    private fun sha(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())

    private class Reply(val code: Int, val json: JSONObject)

    private suspend fun post(url: String, json: JSONObject, client: OkHttpClient = Http.server): Reply = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).post(json.toString().toRequestBody(JSON.toMediaType())).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            Reply(r.code, try { JSONObject(text) } catch (e: Exception) { JSONObject() })
        }
    }

    private suspend fun server(path: String, json: JSONObject): Reply? =
        try { post(SOCIAL_API_URL.trimEnd('/') + path, json) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { null }

    private fun errorOf(r: Reply, fallback: String): String =
        r.json.optString("error").ifBlank { if (r.code >= 500) "Sunucu hatası. Biraz sonra tekrar dene." else fallback }

    private fun resultOf(r: Reply?, fallback: String): AuthResult {
        if (r == null) return AuthResult(NO_NET)
        if (r.code !in 200..299) return AuthResult(errorOf(r, fallback))
        val soc = r.json.optJSONObject("social")
        return AuthResult(
            null, r.json.optString("name"), r.json.optString("session"),
            soc?.optString("username")?.ifBlank { null }, soc?.optString("token")?.ifBlank { null }
        )
    }

    // ---- EmailJS yedek yolu: kod uygulamada üretilir, e-posta EmailJS ile gider ----
    private suspend fun sendViaEmailJs(email: String): String? {
        val now = System.currentTimeMillis()
        pending[email]?.let { if (now - it.sentAt < 30_000) return "Lütfen yeni kod istemeden önce biraz bekle." }
        val code = String.format(Locale.US, "%06d", random.nextInt(1_000_000))
        val json = JSONObject()
            .put("service_id", EMAILJS_SERVICE_ID)
            .put("template_id", EMAILJS_TEMPLATE_ID)
            .put("user_id", EMAILJS_PUBLIC_KEY)
            .put("template_params", JSONObject()
                .put("to_email", email).put("email", email)
                .put("code", code).put("app_name", "Sounddeep"))
        return try {
            val r = post("https://api.emailjs.com/api/v1.0/email/send", json, Http.client)
            when {
                r.code in 200..299 -> { pending[email] = Pending(Base64.encodeToString(sha(code), Base64.NO_WRAP), now + 10 * 60_000, 0, now); null }
                r.code == 403 -> "EmailJS isteği reddetti. EmailJS hesabında API çağrılarına izin verildiğinden emin ol."
                else -> "E-posta gönderilemedi (${r.code})."
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Bağlantı kurulamadı. İnternetini kontrol et." }
    }

    private fun verifyLocal(email: String, code: String): String? {
        val p = pending[email]
        if (p == null || p.expires < System.currentTimeMillis()) return "Kodun süresi dolmuş. Yeni kod iste."
        if (p.attempts >= 5) { pending.remove(email); return "Çok fazla yanlış deneme. Yeni kod iste." }
        p.attempts += 1
        val ok = MessageDigest.isEqual(Base64.decode(p.hash, Base64.NO_WRAP), sha(code))
        if (!ok) return "Kod yanlış. Tekrar dene."
        pending.remove(email)
        return null
    }

    // ---- Açık işlemler ----

    /**
     * Doğrulama kodu gönderir. [reset] true ise şifre sıfırlama. Hata varsa mesajı, başarılıysa null döner.
     * Hesap var/yok kontrolü sunucudadır: "kayıtlı hesap yok" ve "zaten hesap var" cevapları ondan gelir.
     */
    suspend fun sendCode(email: String, reset: Boolean): String? {
        val r = server("/auth/send-code", JSONObject().put("email", email).put("purpose", if (reset) "reset" else "signup"))
            ?: return NO_NET
        return when {
            r.code in 200..299 -> { localMode[email] = false; null }
            r.code == 503 && r.json.optBoolean("mailDisabled") ->
                if (emailJsMode) sendViaEmailJs(email).also { if (it == null) localMode[email] = true }
                else "E-posta gönderimi henüz ayarlanmadı. Kurulum için backend/README.md dosyasına bak."
            else -> errorOf(r, "Kod gönderilemedi.")
        }
    }

    suspend fun verify(email: String, code: String): String? {
        if (localMode[email] == true) return verifyLocal(email, code)
        val r = server("/auth/verify", JSONObject().put("email", email).put("code", code)) ?: return NO_NET
        return if (r.code in 200..299) null else errorOf(r, "Kod doğrulanamadı.")
    }

    suspend fun register(email: String, password: String, name: String): AuthResult =
        resultOf(server("/auth/register", JSONObject().put("email", email).put("password", password).put("name", name)
            .put("clientVerified", localMode[email] == true)), "Hesap oluşturulamadı.")

    suspend fun login(email: String, password: String): AuthResult =
        resultOf(server("/auth/login", JSONObject().put("email", email).put("password", password)), "Giriş yapılamadı.")

    suspend fun reset(email: String, password: String): AuthResult =
        resultOf(server("/auth/reset", JSONObject().put("email", email).put("password", password)
            .put("clientVerified", localMode[email] == true)), "Şifre değiştirilemedi.")

    /** Sunucudan sosyal kullanıcı adı alır ve hesaba bağlar. Hata varsa mesajı döner. */
    suspend fun socialJoin(session: String, username: String): Triple<String?, String?, String?> {
        val r = server("/auth/social-join", JSONObject().put("session", session).put("username", username))
            ?: return Triple(NO_NET, null, null)
        if (r.code !in 200..299) return Triple(errorOf(r, "Hesap oluşturulamadı."), null, null)
        return Triple(null, r.json.optString("username"), r.json.optString("token"))
    }

    fun updateNameAsync(session: String?, name: String) {
        if (session == null) return
        scope.launch { server("/auth/profile", JSONObject().put("session", session).put("name", name)) }
    }

    fun logoutAsync(session: String) {
        scope.launch { server("/auth/logout", JSONObject().put("session", session)) }
    }
}
