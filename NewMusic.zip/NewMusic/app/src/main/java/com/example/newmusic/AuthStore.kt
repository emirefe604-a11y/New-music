package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.util.concurrent.TimeUnit

/*
 * E-POSTA KODU AYARI (iki yoldan birini seç, ayrıntılar proje kökündeki EPOSTA_KURULUM.md dosyasında):
 *
 * 1) EmailJS (sunucu gerekmez, en kolayı): aşağıdaki üç değeri EmailJS panelinden al.
 * 2) Kendi sunucun: backend/ klasöründeki sunucuyu yayınla ve AUTH_API_URL'ye adresini yaz.
 *
 * AUTH_API_URL doluysa sunucu, değilse EmailJS kullanılır. Hepsi boşsa kod gönderilemez.
 */
const val AUTH_API_URL = ""
const val EMAILJS_SERVICE_ID = "service_psblk8l"
const val EMAILJS_TEMPLATE_ID = "template_xbfokyn"
const val EMAILJS_PUBLIC_KEY = "E6Xp9kgx0CI-4nqzt"

/**
 * Hesaplar bu cihazda saklanır: e-posta, şifre (tuzlu hash), ad ve profil fotoğrafı.
 * E-posta kodu yalnızca hesap oluştururken ve şifre sıfırlarken istenir; sonraki girişler şifreyle yapılır.
 */
object AuthStore {
    val email = MutableStateFlow<String?>(null)
    val name = MutableStateFlow("")
    val photo = MutableStateFlow<String?>(null)
    private var prefs: SharedPreferences? = null
    private var avatarDir: File? = null

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        val p = app.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        avatarDir = File(app.filesDir, "avatars").apply { mkdirs() }
        email.value = p.getString("auth_email", null)
        refreshProfile()
    }

    private fun accounts(): JSONObject =
        try { JSONObject(prefs?.getString("accounts", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun saveAccounts(o: JSONObject) { prefs?.edit()?.putString("accounts", o.toString())?.apply() }

    fun hasAccount(mail: String): Boolean = accounts().optJSONObject(mail)?.has("hash") == true

    private fun refreshProfile() {
        val m = email.value
        if (m == null) { name.value = ""; photo.value = null; return }
        val a = accounts().optJSONObject(m)
        val n = a?.optString("name").orEmpty()
        name.value = if (n.isNotBlank()) n else displayName(m)
        val ph = a?.optString("photo").orEmpty()
        photo.value = if (ph.isNotBlank() && File(ph).exists()) ph else null
    }

    private fun hash(pw: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 60_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /** Şifreyi kaydeder (yeni hesap veya şifre sıfırlama). Ad ve fotoğraf korunur. */
    suspend fun saveCredentials(mail: String, password: String, displayName: String?) = withContext(Dispatchers.Default) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val h = hash(password, salt)
        val all = accounts()
        val old = all.optJSONObject(mail)
        val nm = if (!displayName.isNullOrBlank()) displayName else old?.optString("name").orEmpty()
        val o = JSONObject()
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .put("hash", h)
            .put("name", nm)
            .put("photo", old?.optString("photo").orEmpty())
        all.put(mail, o)
        saveAccounts(all)
    }

    suspend fun checkPassword(mail: String, password: String): Boolean = withContext(Dispatchers.Default) {
        val o = accounts().optJSONObject(mail) ?: return@withContext false
        if (!o.has("hash")) return@withContext false
        val salt = Base64.decode(o.optString("salt"), Base64.NO_WRAP)
        MessageDigest.isEqual(hash(password, salt).toByteArray(), o.optString("hash").toByteArray())
    }

    /** Oturumu açar; çıkış yapılana kadar açık kalır. */
    fun signIn(mail: String) {
        email.value = mail
        prefs?.edit()?.putString("auth_email", mail)?.putBoolean("auth_prompted", true)?.apply()
        refreshProfile()
    }

    fun signOut() {
        email.value = null
        prefs?.edit()?.remove("auth_email")?.apply()
        refreshProfile()
    }

    private fun updateAccount(mail: String, block: (JSONObject) -> Unit) {
        val all = accounts()
        val o = all.optJSONObject(mail) ?: JSONObject()
        block(o)
        all.put(mail, o)
        saveAccounts(all)
    }

    fun setName(n: String) {
        val mail = email.value ?: return
        updateAccount(mail) { it.put("name", n.trim()) }
        refreshProfile()
    }

    /** Seçilen resmi kare kırpıp küçülterek profil fotoğrafı yapar. */
    suspend fun setPhoto(ctx: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        val mail = email.value ?: return@withContext false
        val dir = avatarDir ?: return@withContext false
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
            val file = File(dir, "${Integer.toHexString(mail.hashCode())}_${System.currentTimeMillis()}.jpg")
            file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val old = accounts().optJSONObject(mail)?.optString("photo").orEmpty()
            if (old.isNotBlank()) File(old).delete()
            updateAccount(mail) { it.put("photo", file.absolutePath) }
            refreshProfile()
            true
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { false }
    }

    /** İlk açılışta giriş ekranı bir kez önerilir. */
    fun shouldPrompt(): Boolean = email.value == null && prefs?.getBoolean("auth_prompted", false) != true

    fun markPrompted() { prefs?.edit()?.putBoolean("auth_prompted", true)?.apply() }

    fun displayName(mail: String): String =
        mail.substringBefore('@').replace('.', ' ').replace('_', ' ').trim()
            .replaceFirstChar { it.uppercase() }.ifBlank { "Hesabım" }
}

/** E-posta kodunu gönderir ve doğrular. Hata varsa mesajı, başarılıysa null döner. */
object AuthApi {
    private val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    private val random = SecureRandom()

    private const val NOT_CONFIGURED =
        "E-posta gönderimi henüz ayarlanmadı. Kurulum için EPOSTA_KURULUM.md dosyasına bak."
    private const val JSON = "application/json; charset=utf-8"

    private class Pending(val hash: String, val expires: Long, var attempts: Int, val sentAt: Long)
    private val pending = HashMap<String, Pending>()

    private val serverMode: Boolean get() = AUTH_API_URL.isNotBlank()
    private val emailJsMode: Boolean
        get() = EMAILJS_SERVICE_ID.isNotBlank() && EMAILJS_TEMPLATE_ID.isNotBlank() && EMAILJS_PUBLIC_KEY.isNotBlank()

    private fun sha(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())

    private suspend fun post(url: String, json: JSONObject): Pair<Int, String> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).post(json.toString().toRequestBody(JSON.toMediaType())).build()
        client.newCall(req).execute().use { r -> r.code to (r.body?.string() ?: "") }
    }

    private fun errorOf(body: String, fallback: String): String =
        try { JSONObject(body).optString("error").ifBlank { fallback } } catch (e: Exception) { fallback }

    // ---- Sunucu modu ----
    private suspend fun callServer(path: String, json: JSONObject, fallback: String): String? =
        try {
            val (code, body) = post(AUTH_API_URL.trimEnd('/') + path, json)
            if (code in 200..299) null else errorOf(body, fallback)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Bağlantı kurulamadı. İnternetini kontrol et." }

    // ---- EmailJS modu: kod uygulamada üretilir, e-posta EmailJS ile gider ----
    private suspend fun sendViaEmailJs(email: String): String? {
        val now = System.currentTimeMillis()
        pending[email]?.let { if (now - it.sentAt < 30_000) return "Lütfen yeni kod istemeden önce biraz bekle." }
        val code = String.format(Locale.US, "%06d", random.nextInt(1_000_000))
        val json = JSONObject()
            .put("service_id", EMAILJS_SERVICE_ID)
            .put("template_id", EMAILJS_TEMPLATE_ID)
            .put("user_id", EMAILJS_PUBLIC_KEY)
            .put("template_params", JSONObject()
                .put("to_email", email).put("email", email)
                .put("code", code).put("app_name", "Sounddeep"))
        return try {
            val (status, body) = post("https://api.emailjs.com/api/v1.0/email/send", json)
            when {
                status in 200..299 -> { pending[email] = Pending(Base64.encodeToString(sha(code), Base64.NO_WRAP), now + 10 * 60_000, 0, now); null }
                status == 403 -> "EmailJS isteği reddetti. EmailJS hesabında API çağrılarına izin verildiğinden emin ol."
                else -> "E-posta gönderilemedi ($status). ${body.take(80)}"
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Bağlantı kurulamadı. İnternetini kontrol et." }
    }

    private fun verifyLocal(email: String, code: String): String? {
        val p = pending[email]
        if (p == null || p.expires < System.currentTimeMillis()) return "Kodun süresi dolmuş. Yeni kod iste."
        if (p.attempts >= 5) { pending.remove(email); return "Çok fazla yanlış deneme. Yeni kod iste." }
        p.attempts += 1
        val ok = MessageDigest.isEqual(
            Base64.decode(p.hash, Base64.NO_WRAP), sha(code)
        )
        if (!ok) return "Kod yanlış. Tekrar dene."
        pending.remove(email)
        return null
    }

    suspend fun sendCode(email: String): String? = when {
        serverMode -> callServer("/send-code", JSONObject().put("email", email), "Kod gönderilemedi.")
        emailJsMode -> sendViaEmailJs(email)
        else -> NOT_CONFIGURED
    }

    suspend fun verify(email: String, code: String): String? = when {
        serverMode -> callServer("/verify", JSONObject().put("email", email).put("code", code), "Kod doğrulanamadı.")
        emailJsMode -> verifyLocal(email, code)
        else -> NOT_CONFIGURED
    }
}
