package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.TimeUnit

/*
 * E-POSTA KODU AYARI (iki yoldan birini seç, ayrıntılar proje kökündeki EPOSTA_KURULUM.md dosyasında):
 *
 * 1) EmailJS (sunucu gerekmez, en kolayı): aşağıdaki üç değeri EmailJS panelinden al.
 * 2) Kendi sunucun: backend/ klasöründeki sunucuyu yayınla ve AUTH_API_URL'ye adresini yaz.
 *
 * AUTH_API_URL doluysa sunucu, değilse EmailJS kullanılır. Hepsi boşsa kod gönderilemez.
 */
const val AUTH_API_URL = ""
const val EMAILJS_SERVICE_ID = "service_psblk8l"
const val EMAILJS_TEMPLATE_ID = "template_xbfokyn"
const val EMAILJS_PUBLIC_KEY = "E6Xp9kgx0CI-4nqzt"

/** Giriş yapan hesap bu cihazda saklanır. */
object AuthStore {
    val email = MutableStateFlow<String?>(null)
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        email.value = p.getString("auth_email", null)
    }

    /** İlk açılışta giriş ekranı bir kez önerilir. */
    fun shouldPrompt(): Boolean = email.value == null && prefs?.getBoolean("auth_prompted", false) != true

    fun markPrompted() { prefs?.edit()?.putBoolean("auth_prompted", true)?.apply() }

    fun signIn(mail: String) {
        email.value = mail
        prefs?.edit()?.putString("auth_email", mail)?.putBoolean("auth_prompted", true)?.apply()
    }

    fun signOut() {
        email.value = null
        prefs?.edit()?.remove("auth_email")?.apply()
    }

    fun displayName(mail: String): String =
        mail.substringBefore('@').replace('.', ' ').replace('_', ' ').trim()
            .replaceFirstChar { it.uppercase() }.ifBlank { "Hesabım" }
}

/** E-posta kodunu gönderir ve doğrular. Hata varsa mesajı, başarılıysa null döner. */
object AuthApi {
    private val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    private val random = SecureRandom()

    private const val NOT_CONFIGURED =
        "E-posta gönderimi henüz ayarlanmadı. Kurulum için EPOSTA_KURULUM.md dosyasına bak."
    private const val JSON = "application/json; charset=utf-8"

    private class Pending(val hash: String, val expires: Long, var attempts: Int, val sentAt: Long)
    private val pending = HashMap<String, Pending>()

    private val serverMode: Boolean get() = AUTH_API_URL.isNotBlank()
    private val emailJsMode: Boolean
        get() = EMAILJS_SERVICE_ID.isNotBlank() && EMAILJS_TEMPLATE_ID.isNotBlank() && EMAILJS_PUBLIC_KEY.isNotBlank()

    private fun sha(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())

    private suspend fun post(url: String, json: JSONObject): Pair<Int, String> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).post(json.toString().toRequestBody(JSON.toMediaType())).build()
        client.newCall(req).execute().use { r -> r.code to (r.body?.string() ?: "") }
    }

    private fun errorOf(body: String, fallback: String): String =
        try { JSONObject(body).optString("error").ifBlank { fallback } } catch (e: Exception) { fallback }

    // ---- Sunucu modu ----
    private suspend fun callServer(path: String, json: JSONObject, fallback: String): String? =
        try {
            val (code, body) = post(AUTH_API_URL.trimEnd('/') + path, json)
            if (code in 200..299) null else errorOf(body, fallback)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Bağlantı kurulamadı. İnternetini kontrol et." }

    // ---- EmailJS modu: kod uygulamada üretilir, e-posta EmailJS ile gider ----
    private suspend fun sendViaEmailJs(email: String): String? {
        val now = System.currentTimeMillis()
        pending[email]?.let { if (now - it.sentAt < 30_000) return "Lütfen yeni kod istemeden önce biraz bekle." }
        val code = String.format(Locale.US, "%06d", random.nextInt(1_000_000))
        val json = JSONObject()
            .put("service_id", EMAILJS_SERVICE_ID)
            .put("template_id", EMAILJS_TEMPLATE_ID)
            .put("user_id", EMAILJS_PUBLIC_KEY)
            .put("template_params", JSONObject()
                .put("to_email", email).put("email", email)
                .put("code", code).put("app_name", "Sounddeep"))
        return try {
            val (status, body) = post("https://api.emailjs.com/api/v1.0/email/send", json)
            when {
                status in 200..299 -> { pending[email] = Pending(Base64.encodeToString(sha(code), Base64.NO_WRAP), now + 10 * 60_000, 0, now); null }
                status == 403 -> "EmailJS isteği reddetti. EmailJS hesabında API çağrılarına izin verildiğinden emin ol."
                else -> "E-posta gönderilemedi ($status). ${body.take(80)}"
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { "Bağlantı kurulamadı. İnternetini kontrol et." }
    }

    private fun verifyLocal(email: String, code: String): String? {
        val p = pending[email]
        if (p == null || p.expires < System.currentTimeMillis()) return "Kodun süresi dolmuş. Yeni kod iste."
        if (p.attempts >= 5) { pending.remove(email); return "Çok fazla yanlış deneme. Yeni kod iste." }
        p.attempts += 1
        val ok = MessageDigest.isEqual(
            Base64.decode(p.hash, Base64.NO_WRAP), sha(code)
        )
        if (!ok) return "Kod yanlış. Tekrar dene."
        pending.remove(email)
        return null
    }

    suspend fun sendCode(email: String): String? = when {
        serverMode -> callServer("/send-code", JSONObject().put("email", email), "Kod gönderilemedi.")
        emailJsMode -> sendViaEmailJs(email)
        else -> NOT_CONFIGURED
    }

    suspend fun verify(email: String, code: String): String? = when {
        serverMode -> callServer("/verify", JSONObject().put("email", email).put("code", code), "Kod doğrulanamadı.")
        emailJsMode -> verifyLocal(email, code)
        else -> NOT_CONFIGURED
    }
}
