package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale

// ---------------------------------------------------------------- günlük değişim yardımcıları

/** Bugünün numarası: gün değişince değişir, gün içinde sabit kalır. */
fun dayKey(): Long = LocalDate.now().toEpochDay()

/** Listeden bugüne özel [n] öğe seçer. Aynı gün hep aynı sonucu verir, ertesi gün değişir. */
fun <T> dailyPick(list: List<T>, n: Int, salt: Int = 0): List<T> = dailyShuffle(list, salt).take(n)

/** Listeyi bugüne özel karıştırır (gün içinde sabit, ertesi gün farklı). */
fun <T> dailyShuffle(list: List<T>, salt: Int = 0): List<T> =
    list.shuffled(kotlin.random.Random(dayKey() * 31 + salt))

// ---------------------------------------------------------------- YouTube Music güncel listeleri

/**
 * YouTube Music "Listeler" (Charts) sayfasından bir bölüm: örn. "Türkiye · Günlük en çok izlenen müzik videoları".
 * lang: 0 her ikisi, 1 Türkçe, 2 İngilizce (içerik dili ayarıyla aynı anlamda).
 */
data class ChartSection(
    val key: String, val title: String, val place: String, val lang: Int,
    val songs: List<Song>, val playlists: List<PlaylistRef>
)

/**
 * YouTube Music'in güncel top listelerini (Türkiye ve dünya) çeker.
 * Günde en az bir kez, uygulama açıkken 6 saatte bir yenilenir; ağ yoksa son kaydedilen liste gösterilir.
 */
object Charts {
    val sections = MutableStateFlow<List<ChartSection>>(emptyList())

    private var prefs: SharedPreferences? = null
    private val mutex = Mutex()
    private const val MAX_AGE_MS = 6L * 60 * 60 * 1000
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        sections.value = try { load(p.getString("charts_json", null)) } catch (e: Exception) { emptyList() }
    }

    /** Liste bugün çekilmediyse veya 6 saatten eskiyse yeniler. */
    suspend fun refreshIfNeeded(force: Boolean = false) {
        val p = prefs ?: return
        val today = LocalDate.now().toString()
        val fresh = p.getString("charts_day", "") == today &&
            System.currentTimeMillis() - p.getLong("charts_at", 0L) < MAX_AGE_MS
        if (!force && fresh && sections.value.isNotEmpty()) return
        mutex.withLock {
            try {
                val got = withContext(Dispatchers.IO) { fetchAll() }
                if (got.isNotEmpty()) {
                    sections.value = got
                    p.edit().putString("charts_json", save(got)).putString("charts_day", today)
                        .putLong("charts_at", System.currentTimeMillis()).apply()
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { /* son kaydedilen liste kalır */ }
        }
    }

    // ---- ağ ----

    private fun fetchAll(): List<ChartSection> {
        val device = Locale.getDefault().country.uppercase().takeIf { it.length == 2 } ?: "TR"
        var local = fetchCountry(device)
        if (local.isEmpty() && device != "TR") local = fetchCountry("TR")
        val world = fetchCountry("ZZ")
        return local + world
    }

    private fun clientVersion(): String = "1." + LocalDate.now().minusDays(1).toString().replace("-", "") + ".01.00"

    private fun fetchCountry(cc: String): List<ChartSection> {
        return try {
            val client = JSONObject().put("clientName", "WEB_REMIX").put("clientVersion", clientVersion())
                .put("hl", "tr").put("gl", if (cc == "ZZ") "TR" else cc)
            val body = JSONObject()
                .put("context", JSONObject().put("client", client))
                .put("browseId", "FEmusic_charts")
                .put("formData", JSONObject().put("selectedValues", JSONArray().put(cc)))
            val req = Request.Builder()
                .url("https://music.youtube.com/youtubei/v1/browse?prettyPrint=false")
                .header("User-Agent", UA).header("Origin", "https://music.youtube.com").header("Referer", "https://music.youtube.com/")
                .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
            val text = Http.client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return emptyList()
                r.body?.string().orEmpty()
            }
            val place = if (cc == "ZZ") "Dünya" else Locale("", cc).getDisplayCountry(Locale("tr")).ifBlank { cc }
            val lang = when (cc) { "TR" -> 1; "ZZ" -> 2; else -> 0 }
            parse(JSONObject(text), cc, place, lang)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { emptyList() }
    }

    // ---- ayrıştırma (YouTube yanıtı sık değişir; alanlar tek tek, korumalı okunur) ----

    private fun parse(root: JSONObject, cc: String, place: String, lang: Int): List<ChartSection> {
        val out = ArrayList<ChartSection>()
        val shelfKeys = listOf("musicCarouselShelfRenderer", "musicShelfRenderer", "musicImmersiveCarouselShelfRenderer")
        fun visit(node: Any?) {
            when (node) {
                is JSONObject -> {
                    for (k in shelfKeys) node.optJSONObject(k)?.let { s -> readShelf(s, cc, place, lang)?.let { out += it } }
                    val keys = node.keys()
                    while (keys.hasNext()) visit(node.opt(keys.next()))
                }
                is JSONArray -> for (i in 0 until node.length()) visit(node.opt(i))
            }
        }
        visit(root)
        return out.distinctBy { it.key }
    }

    private fun readShelf(shelf: JSONObject, cc: String, place: String, lang: Int): ChartSection? {
        val header = shelf.optJSONObject("header")
        val title = runsText(header?.optJSONObject("musicCarouselShelfBasicHeaderRenderer")?.optJSONObject("title"))
            .ifBlank { runsText(header?.optJSONObject("musicImmersiveCarouselShelfBasicHeaderRenderer")?.optJSONObject("title")) }
            .ifBlank { runsText(shelf.optJSONObject("title")) }
            .ifBlank { "Güncel liste" }
        val contents = shelf.optJSONArray("contents") ?: return null
        val songs = ArrayList<Song>()
        val lists = ArrayList<PlaylistRef>()
        for (i in 0 until contents.length()) {
            val o = contents.optJSONObject(i) ?: continue
            o.optJSONObject("musicResponsiveListItemRenderer")?.let { rowSong(it)?.let(songs::add) }
            o.optJSONObject("musicTwoRowItemRenderer")?.let { twoRow(it, songs, lists) }
        }
        val uniqueSongs = songs.distinctBy { it.url }
        if (uniqueSongs.size < 5 && lists.isEmpty()) return null
        return ChartSection("$cc|$title", title, place, lang, uniqueSongs, lists.distinctBy { it.url })
    }

    private fun rowSong(r: JSONObject): Song? {
        val id = r.optJSONObject("playlistItemData")?.optString("videoId").orEmpty().ifBlank {
            r.optJSONObject("overlay")?.optJSONObject("musicItemThumbnailOverlayRenderer")?.optJSONObject("content")
                ?.optJSONObject("musicPlayButtonRenderer")?.optJSONObject("playNavigationEndpoint")
                ?.optJSONObject("watchEndpoint")?.optString("videoId").orEmpty()
        }
        if (id.isBlank()) return null
        val cols = r.optJSONArray("flexColumns") ?: return null
        fun col(i: Int) = runsText(cols.optJSONObject(i)?.optJSONObject("musicResponsiveListItemFlexColumnRenderer")?.optJSONObject("text"))
        val title = col(0)
        if (title.isBlank()) return null
        val thumb = lastThumb(r.optJSONObject("thumbnail")?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail"))
        return Song(title, artistOf(col(1)), watchUrl(id), thumb)
    }

    private fun twoRow(r: JSONObject, songs: MutableList<Song>, lists: MutableList<PlaylistRef>) {
        val title = runsText(r.optJSONObject("title"))
        if (title.isBlank()) return
        val sub = runsText(r.optJSONObject("subtitle"))
        val nav = r.optJSONObject("navigationEndpoint")
        val vid = nav?.optJSONObject("watchEndpoint")?.optString("videoId").orEmpty()
        val bid = nav?.optJSONObject("browseEndpoint")?.optString("browseId").orEmpty()
        val thumb = lastThumb(r.optJSONObject("thumbnailRenderer")?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail"))
        when {
            vid.isNotBlank() -> songs += Song(title, artistOf(sub), watchUrl(vid), thumb)
            bid.startsWith("VL") -> lists += PlaylistRef(
                title, sub.ifBlank { "YouTube Music" }, "https://www.youtube.com/playlist?list=" + bid.removePrefix("VL"), thumb, 0
            )
        }
    }

    private fun runsText(o: JSONObject?): String {
        val a = o?.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until a.length()) sb.append(a.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString().trim()
    }

    private fun artistOf(s: String) = s.substringBefore(" • ").trim().take(100)

    private fun watchUrl(id: String) = "https://www.youtube.com/watch?v=$id"

    private fun lastThumb(o: JSONObject?): String? {
        val a = o?.optJSONArray("thumbnails") ?: return null
        if (a.length() == 0) return null
        return a.optJSONObject(a.length() - 1)?.optString("url")?.ifBlank { null }
    }

    // ---- diske kaydet / oku ----

    private fun save(list: List<ChartSection>): String {
        val arr = JSONArray()
        list.forEach { s ->
            val pl = JSONArray()
            s.playlists.forEach { pl.put(JSONObject().put("t", it.title).put("o", it.owner).put("u", it.url).put("i", it.thumb ?: "")) }
            arr.put(JSONObject().put("k", s.key).put("t", s.title).put("p", s.place).put("l", s.lang)
                .put("songs", s.songs.toJsonArray()).put("lists", pl))
        }
        return arr.toString()
    }

    private fun load(json: String?): List<ChartSection> {
        if (json.isNullOrBlank()) return emptyList()
        val arr = JSONArray(json)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val la = o.optJSONArray("lists") ?: JSONArray()
            ChartSection(
                o.getString("k"), o.getString("t"), o.optString("p"), o.optInt("l"),
                o.optJSONArray("songs")?.toSongs().orEmpty(),
                (0 until la.length()).map { j ->
                    val p = la.getJSONObject(j)
                    PlaylistRef(p.optString("t"), p.optString("o"), p.optString("u"), p.optString("i").ifBlank { null }, 0)
                }
            )
        }
    }
}
