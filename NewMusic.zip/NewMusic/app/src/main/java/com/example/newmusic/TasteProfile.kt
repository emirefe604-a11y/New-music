package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray

/** Otomatik hazırlanan "Senin için" karışık listesi. */
data class Mix(val title: String, val subtitle: String, val songs: List<Song>)

/**
 * Kullanıcının dinleme zevkini öğrenir: dinlenen, sonuna kadar dinlenen ve beğenilen
 * şarkılar puan alır. Bu puanlardan kişiye özel karışık listeler üretilir.
 */
object TasteProfile {
    private class Entry(val song: Song, var score: Int, var last: Long)

    private val entries = LinkedHashMap<String, Entry>()
    private lateinit var prefs: SharedPreferences
    private var ready = false

    val mixes = MutableStateFlow<List<Mix>>(emptyList())
    val loading = MutableStateFlow(false)

    fun init(ctx: Context) {
        if (ready) return
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        load()
        ready = true
    }

    val hasData: Boolean get() = entries.size >= 3

    fun recordPlay(s: Song) = add(s, 1)
    fun recordCompleted(s: Song) = add(s, 2)
    fun recordFav(s: Song) = add(s, 3)

    private fun add(s: Song, points: Int) {
        if (!ready) return
        val e = entries.getOrPut(s.url) { Entry(s, 0, 0L) }
        e.score += points
        e.last = System.currentTimeMillis()
        if (entries.size > 300) {
            // En düşük puanlı / en eski kayıtları at
            entries.values.sortedWith(compareBy<Entry> { it.score }.thenBy { it.last })
                .take(entries.size - 250).forEach { entries.remove(it.song.url) }
        }
        save()
    }

    /** Dinleme geçmişini ve kişiye özel listeleri sıfırlar. */
    fun reset() {
        entries.clear()
        if (ready) save()
        mixes.value = emptyList()
    }

    private fun cleanArtist(a: String) = a.removeSuffix(" - Topic").trim()

    /** Zevk profilinden karışık listeleri üretir. Ağ hatalarında o liste atlanır. */
    suspend fun buildMixes() {
        if (!ready || !hasData) { mixes.value = emptyList(); return }
        loading.value = true
        try {
            val ranked = entries.values
                .sortedWith(compareByDescending<Entry> { it.score }.thenByDescending { it.last })
            val known = entries.keys.toSet()

            val topArtists = ranked.groupBy { cleanArtist(it.song.artist) }
                .filterKeys { it.isNotBlank() }
                .mapValues { (_, v) -> v.sumOf { it.score } }
                .entries.sortedByDescending { it.value }
                .take(3).map { it.key }

            val result = coroutineScope {
                val artistMixes = topArtists.map { artist ->
                    async {
                        val seed = ranked.first { cleanArtist(it.song.artist) == artist }.song
                        val songs = (safe { MusicRepository.search(artist) } +
                                safe { MusicRepository.related(seed.url) })
                            .distinctBy { it.url }.shuffled().take(30)
                        Mix("$artist Karışık", "$artist ve benzerleri", songs)
                    }
                }
                val discover = async {
                    val seeds = ranked.take(10).shuffled().take(3)
                    val songs = seeds.flatMap { safe { MusicRepository.related(it.song.url) } }
                        .filter { it.url !in known }
                        .distinctBy { it.url }.shuffled().take(30)
                    Mix("Keşfet", "Zevkine yakın yeni şarkılar", songs)
                }
                val favorites = Mix(
                    "Sık dinlediklerin", "En çok dinlediğin şarkılar",
                    ranked.take(25).map { it.song }.shuffled()
                )
                listOf(favorites) + artistMixes.awaitAll() + discover.await()
            }
            mixes.value = result.filter { it.songs.size >= 5 }
        } finally {
            loading.value = false
        }
    }

    private suspend fun safe(block: suspend () -> List<Song>): List<Song> =
        try { block() } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { emptyList() }

    private fun save() {
        val a = JSONArray()
        entries.values.forEach {
            a.put(it.song.toJson().put("s", it.score).put("l", it.last))
        }
        prefs.edit().putString("taste", a.toString()).apply()
    }

    private fun load() {
        try {
            val a = JSONArray(prefs.getString("taste", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val s = o.toSong()
                entries[s.url] = Entry(s, o.optInt("s", 1), o.optLong("l", 0L))
            }
        } catch (e: Exception) { entries.clear() }
    }
}
