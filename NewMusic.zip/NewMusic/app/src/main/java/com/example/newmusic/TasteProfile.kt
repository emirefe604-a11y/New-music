package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray

/** Otomatik hazırlanan "Senin için" karışık listesi. */
data class Mix(val title: String, val subtitle: String, val songs: List<Song>)

/**
 * Kullanıcının dinleme zevkini öğrenir: dinlenen, sonuna kadar dinlenen ve beğenilen
 * şarkılar puan alır. Bu puanlardan kişiye özel karışık listeler üretilir.
 */
object TasteProfile {
    private class Entry(val song: Song, var score: Int, var last: Long)

    private val entries = LinkedHashMap<String, Entry>()
    private val dislikedUrls = HashSet<String>()
    private val dislikedArtists = HashSet<String>()
    private lateinit var prefs: SharedPreferences
    private var ready = false

    // Sıradaki şarkı algoritması için kalıcı zevk verisi: sanatçı / tür eğilimi ve öğrenilen türler
    private val artistAff = HashMap<String, Float>()
    private val genreAff = HashMap<Int, Float>()
    private val learnedCluster = HashMap<String, Int>()
    private val learnedNames = HashMap<String, String>()
    private var signalCount = 0

    val mixes = MutableStateFlow<List<Mix>>(emptyList())
    val loading = MutableStateFlow(false)

    fun init(ctx: Context) {
        if (ready) return
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        load()
        loadAff()
        ready = true
    }

    val hasData: Boolean get() = entries.size >= 3

    fun recordPlay(s: Song) = add(s, 1)

    /** Şarkı ilk 20 saniyede atlandı: o sanatçıya/türe doğru eğilim düşer. */
    fun recordSkip(s: Song) = signal(s, -2.5f)

    /** Pozitif tür ağırlıkları, 0..1 (en çok sevilen tür = 1). Zevk verisi yoksa boş. */
    fun genreWeights(): Map<Int, Float> {
        val mx = genreAff.values.maxOrNull() ?: return emptyMap()
        if (mx <= 0f) return emptyMap()
        return genreAff.filterValues { it > 0f }.mapValues { it.value / mx }
    }

    /** Şarkının kullanıcı zevkine uygunluğu (-6..8). Beğenilmeyenler -100. */
    fun tasteScore(s: Song): Float {
        if (isDisliked(s)) return -100f
        val name = GenreRecommender.extractArtist(s)
        var sc = artistAffinity(name) * 0.5f
        val c = NextSongEngine.clusterOf(name)
        if (c >= 0) sc += genreAffinity(c) * 0.15f
        return sc.coerceIn(-6f, 8f)
    }

    // Tür gruplarının (GenreRecommender.clusters sırasıyla) liste/bölüm başlıklarında geçen anahtar kelimeleri
    private val clusterWords = listOf(
        listOf("rap", "drill", "trap"), listOf("rap"), listOf("rock", "alternatif"),
        listOf("pop", "dans", "hit"), listOf("arabesk", "damar"),
        listOf("slow", "akustik", "duygusal", "acoustic"), listOf("rock", "nostalji", "90"),
        listOf("hip hop", "trap", "rap", "r&b"), listOf("pop", "hits", "english", "dance"), listOf("rock")
    )

    /** Bir bölüm/liste başlığının kullanıcının sevdiği türlere yakınlığı (0..1.5). */
    fun textAffinity(text: String): Float {
        val w = genreWeights()
        if (w.isEmpty()) return 0f
        val t = text.lowercase(java.util.Locale("tr"))
        var sum = 0f
        w.forEach { (c, v) -> if (clusterWords.getOrNull(c)?.any { t.contains(it) } == true) sum += v }
        return sum.coerceAtMost(1.5f)
    }

    /** +: Türkçe müziğe, -: yabancı müziğe eğilim (-1..1). */
    fun langBias(): Float {
        val tr = (0..6).sumOf { genreAffinity(it).coerceAtLeast(0f).toDouble() }
        val en = (7..9).sumOf { genreAffinity(it).coerceAtLeast(0f).toDouble() }
        val tot = tr + en
        return if (tot <= 0.0) 0f else ((tr - en) / tot).toFloat()
    }

    fun artistAffinity(artist: String): Float =
        artistAff[GenreRecommender.normalize(cleanArtist(artist))] ?: 0f

    fun genreAffinity(cluster: Int): Float = genreAff[cluster] ?: 0f

    fun learnedClusterOf(artist: String): Int =
        learnedCluster[GenreRecommender.normalize(cleanArtist(artist))] ?: -1

    fun learnedArtistsIn(cluster: Int): List<String> =
        learnedCluster.filterValues { it == cluster }.keys.mapNotNull { learnedNames[it] }

    fun learnCluster(artist: String, cluster: Int) {
        if (!ready || cluster < 0) return
        val k = GenreRecommender.normalize(cleanArtist(artist))
        if (k.length < 2 || learnedCluster[k] == cluster) return
        learnedCluster[k] = cluster
        learnedNames[k] = cleanArtist(artist)
        saveAff()
    }

    private fun signal(s: Song, delta: Float) {
        if (!ready || s.url.startsWith("local://")) return
        val name = GenreRecommender.extractArtist(s)
        val k = GenreRecommender.normalize(name)
        if (k.length < 2) return
        artistAff[k] = ((artistAff[k] ?: 0f) + delta).coerceIn(-20f, 40f)
        val c = NextSongEngine.clusterOf(name)
        if (c >= 0) genreAff[c] = ((genreAff[c] ?: 0f) + delta).coerceIn(-20f, 60f)
        // Zevk zamanla değişir: her 40 sinyalde eski eğilimler biraz sönümlenir
        if (++signalCount % 40 == 0) {
            artistAff.keys.toList().forEach { artistAff[it] = artistAff[it]!! * 0.92f }
            genreAff.keys.toList().forEach { genreAff[it] = genreAff[it]!! * 0.92f }
            artistAff.entries.removeAll { kotlin.math.abs(it.value) < 0.3f }
        }
        saveAff()
    }

    private fun saveAff() {
        val a = org.json.JSONObject(); artistAff.forEach { (k, v) -> a.put(k, v.toDouble()) }
        val g = org.json.JSONObject(); genreAff.forEach { (k, v) -> g.put(k.toString(), v.toDouble()) }
        val l = org.json.JSONObject()
        learnedCluster.forEach { (k, v) -> l.put(k, org.json.JSONObject().put("c", v).put("n", learnedNames[k] ?: k)) }
        prefs.edit().putString("aff_art", a.toString()).putString("aff_gen", g.toString())
            .putString("aff_learn", l.toString()).apply()
    }

    private fun loadAff() {
        artistAff.clear(); genreAff.clear(); learnedCluster.clear(); learnedNames.clear()
        try {
            val a = org.json.JSONObject(prefs.getString("aff_art", "{}"))
            a.keys().forEach { artistAff[it] = a.getDouble(it).toFloat() }
            val g = org.json.JSONObject(prefs.getString("aff_gen", "{}"))
            g.keys().forEach { genreAff[it.toInt()] = g.getDouble(it).toFloat() }
            val l = org.json.JSONObject(prefs.getString("aff_learn", "{}"))
            l.keys().forEach {
                val o = l.getJSONObject(it)
                learnedCluster[it] = o.getInt("c"); learnedNames[it] = o.optString("n", it)
            }
        } catch (_: Exception) { }
    }
    fun recordCompleted(s: Song) = add(s, 2)
    fun recordFav(s: Song) = add(s, 3)

    fun recordLike(s: Song) {
        add(s, 5)
        dislikedUrls.remove(s.url)
        val a = cleanArtist(s.artist)
        if (a.isNotBlank()) dislikedArtists.remove(a)
        save()
    }

    fun recordDislike(s: Song) {
        if (!ready || s.url.startsWith("local://")) return
        dislikedUrls.add(s.url)
        val a = cleanArtist(s.artist)
        if (a.isNotBlank()) dislikedArtists.add(a)
        entries.remove(s.url)
        signal(s, -6f)
        save()
    }

    fun isDisliked(s: Song): Boolean {
        if (dislikedUrls.contains(s.url)) return true
        val a = cleanArtist(s.artist)
        return a.isNotBlank() && dislikedArtists.contains(a)
    }

    private fun add(s: Song, points: Int) {
        if (!ready || s.url.startsWith("local://")) return
        val e = entries.getOrPut(s.url) { Entry(s, 0, 0L) }
        e.score += points
        e.last = System.currentTimeMillis()
        signal(s, points.toFloat())
        if (entries.size > 300) {
            // En düşük puanlı / en eski kayıtları at
            entries.values.sortedWith(compareBy<Entry> { it.score }.thenBy { it.last })
                .take(entries.size - 250).forEach { entries.remove(it.song.url) }
        }
        save()
    }

    /** Dinleme geçmişini ve kişiye özel listeleri sıfırlar. */
    fun reset() {
        entries.clear()
        dislikedUrls.clear()
        dislikedArtists.clear()
        artistAff.clear(); genreAff.clear(); learnedCluster.clear(); learnedNames.clear()
        if (ready) { save(); saveAff() }
        mixes.value = emptyList()
    }

    /** En çok dinlenen sanatçılar ve puanları (Blend için). */
    fun topArtistsWeighted(n: Int = 10): List<Pair<String, Int>> {
        val sums = LinkedHashMap<String, Int>()
        entries.values.forEach { e ->
            val a = cleanArtist(e.song.artist)
            if (a.isNotBlank() && a !in dislikedArtists) sums[a] = (sums[a] ?: 0) + e.score
        }
        return sums.entries.sortedByDescending { it.value }.take(n).map { it.key to it.value }
    }

    /** En çok dinlenen sanatçılar (Blend için). */
    fun topArtists(n: Int = 10): List<String> = topArtistsWeighted(n).map { it.first }

    private fun cleanArtist(a: String) = a.removeSuffix(" - Topic").trim()

    /** Zevk profilinden karışık listeleri üretir. Ağ hatalarında o liste atlanır. */
    suspend fun buildMixes() {
        if (!ready || !hasData) { mixes.value = emptyList(); return }
        loading.value = true
        try {
            val ranked = entries.values
                .sortedWith(compareByDescending<Entry> { it.score }.thenByDescending { it.last })
            val known = entries.keys.toSet()

            val topArtists = ranked.groupBy { cleanArtist(it.song.artist) }
                .filterKeys { it.isNotBlank() }
                .mapValues { (_, v) -> v.sumOf { it.score } }
                .entries.sortedByDescending { it.value }
                .take(3).map { it.key }

            val result = coroutineScope {
                val artistMixes = topArtists.map { artist ->
                    async {
                        val seed = ranked.first { cleanArtist(it.song.artist) == artist }.song
                        val songs = (safe { MusicRepository.search(artist) } +
                                safe { MusicRepository.related(seed.url) })
                            .distinctBy { it.url }.shuffled().take(30)
                        Mix("$artist Karışık", "$artist ve benzerleri", songs)
                    }
                }
                val discover = async {
                    val seeds = ranked.take(10).shuffled().take(3)
                    val songs = seeds.flatMap { safe { MusicRepository.related(it.song.url) } }
                        .filter { it.url !in known }
                        .distinctBy { it.url }.shuffled().take(30)
                    Mix("Keşfet", "Zevkine yakın yeni şarkılar", songs)
                }
                val favorites = Mix(
                    "Sık dinlediklerin", "En çok dinlediğin şarkılar",
                    ranked.take(25).map { it.song }.shuffled()
                )
                listOf(favorites) + artistMixes.awaitAll() + discover.await()
            }
            mixes.value = result.filter { it.songs.size >= 5 }
        } finally {
            loading.value = false
        }
    }

    private suspend fun safe(block: suspend () -> List<Song>): List<Song> =
        try { block() } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { emptyList() }

    private fun save() {
        val a = JSONArray()
        entries.values.forEach {
            a.put(it.song.toJson().put("s", it.score).put("l", it.last))
        }
        val uArr = JSONArray(dislikedUrls.toList())
        val aArr = JSONArray(dislikedArtists.toList())
        prefs.edit()
            .putString("taste", a.toString())
            .putString("dis_urls", uArr.toString())
            .putString("dis_arts", aArr.toString())
            .apply()
    }

    private fun load() {
        try {
            val a = JSONArray(prefs.getString("taste", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val s = o.toSong()
                entries[s.url] = Entry(s, o.optInt("s", 1), o.optLong("l", 0L))
            }
            dislikedUrls.clear()
            dislikedArtists.clear()
            val uArr = JSONArray(prefs.getString("dis_urls", "[]"))
            for (i in 0 until uArr.length()) dislikedUrls.add(uArr.getString(i))
            val aArr = JSONArray(prefs.getString("dis_arts", "[]"))
            for (i in 0 until aArr.length()) dislikedArtists.add(aArr.getString(i))
        } catch (e: Exception) { entries.clear() }
    }
}
