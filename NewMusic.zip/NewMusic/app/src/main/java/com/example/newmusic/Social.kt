package com.example.newmusic

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/*
 * SOSYAL ÖZELLİKLER (arkadaşlar, çevrim içi/dışı, ne dinlediği, profil fotoğrafı, liste paylaşımı)
 * Sunucu: backend/ klasörü (Render). Adres boşsa sosyal özellikler gizlenir.
 */
const val SOCIAL_API_URL = "https://new-music-cpzw.onrender.com"

data class SocialPerson(val username: String, val avatar: String?, val name: String = username)
data class SocialFriend(val username: String, val online: Boolean, val lastSeen: Long, val avatar: String? = null, val listening: Song? = null, val name: String = username)
data class SharedList(val id: String, val from: String, val name: String, val songs: List<Song>)

object Social {
    /** Benzersiz arkadaş kimliği (e-postadan otomatik üretilir, değişmez). */
    val username = MutableStateFlow<String?>(null)
    /** Görünen ad: istenildiği gibi yazılır, benzersiz olmak zorunda değil. */
    val displayName = MutableStateFlow<String?>(null)
    val myAvatar = MutableStateFlow<String?>(null)
    val friends = MutableStateFlow<List<SocialFriend>>(emptyList())
    val incoming = MutableStateFlow<List<SocialPerson>>(emptyList())
    val outgoing = MutableStateFlow<List<SocialPerson>>(emptyList())
    val inbox = MutableStateFlow<List<SharedList>>(emptyList())
    /** Açıkken çevrim içi arkadaşların şu an çalan şarkını görür. */
    val showListening = MutableStateFlow(true)

    val enabled: Boolean get() = SOCIAL_API_URL.isNotBlank()
    val joined: Boolean get() = token != null

    private var prefs: SharedPreferences? = null
    private var token: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var watcher: Job? = null
    private const val JSON = "application/json; charset=utf-8"

    // Uygulama görünürken 5 sn, arka planda müzik çalarken 15 sn'de bir sinyal gönderilir.
    private const val FG_TICK = 5_000L
    private const val BG_TICK = 15_000L
    // Arka plana geçip müzik de çalmıyorsa bu süre sonra çevrim dışı olunur (haritaya kısa bakmak vb. için tolerans).
    private const val GRACE_MS = 60_000L
    @Volatile private var foreground = false
    @Volatile private var lastActiveAt = 0L

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        token = p.getString("social_token", null)
        username.value = p.getString("social_name", null)
        showListening.value = p.getBoolean("social_show_listening", true)
        // Render ücretsiz sunucusu uykudaysa 30-60 sn'de uyanır; uygulama açılır açılmaz uyandır
        if (enabled) scope.launch {
            try { Http.server.newCall(Request.Builder().url(SOCIAL_API_URL).get().build()).execute().close() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { }
        }
    }

    /** Hesaba giriş yapılınca sunucudaki kullanıcı adı ve anahtar bu cihaza gelir (yeniden kurulumdan sonra arkadaşlar kaybolmaz). */
    fun restore(name: String, tok: String) {
        token = tok
        username.value = name
        prefs?.edit()?.putString("social_token", tok)?.putString("social_name", name)?.apply()
        start()
        scope.launch { refresh() }
        LibrarySync.syncSoon(force = true)   // beğeniler ve listeler hesaptan geri gelir
    }

    /** Hesaptan çıkınca bu cihazdaki sosyal oturum kapanır; sunucudaki hesap ve arkadaşlar silinmez. */
    fun signOutLocal() {
        loop?.cancel(); loop = null
        watcher?.cancel(); watcher = null
        token = null
        username.value = null; displayName.value = null; myAvatar.value = null
        friends.value = emptyList(); incoming.value = emptyList(); outgoing.value = emptyList(); inbox.value = emptyList()
        prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
    }

    fun setShowListening(on: Boolean) {
        showListening.value = on
        prefs?.edit()?.putBoolean("social_show_listening", on)?.apply()
    }

    fun avatarUrl(id: String?): String? =
        if (id.isNullOrBlank() || !enabled) null else SOCIAL_API_URL.trimEnd('/') + "/social/avatar/" + id

    // ---------------------------------------------------------------- çevrim içi sinyali

    /** Uygulama öne gelince çağrılır. */
    fun start() {
        foreground = true
        lastActiveAt = System.currentTimeMillis()
        if (!enabled || token == null) return
        if (watcher?.isActive != true) {
            // Uygulama arka plandayken müzik başlarsa (örn. arabadan) yeniden çevrim içi ol
            watcher = scope.launch { PlayerManager.playing.collect { if (it) ensureLoop() } }
        }
        ensureLoop()
        LibrarySync.syncSoon()
    }

    /** Uygulama arka plana gidince çağrılır. Müzik çalıyorsa çevrim içi kalınır. */
    fun stop() {
        foreground = false
        lastActiveAt = System.currentTimeMillis()
        LibrarySync.flush()
    }

    @Synchronized
    private fun ensureLoop() {
        if (!enabled || token == null || loop?.isActive == true) return
        loop = scope.launch {
            val outer = this
            launch {
                var ticks = 0
                while (isActive && token != null) {
                    val now = System.currentTimeMillis()
                    if (foreground || PlayerManager.playing.value) lastActiveAt = now
                    if (now - lastActiveAt > GRACE_MS) {
                        call("/social/offline", JSONObject())
                        break
                    }
                    sendHeartbeat()
                    if (ticks++ % 12 == 0) pushTaste()   // Blend için zevk bilgisi (yalnızca arkadaşların görür)
                    delay(if (foreground) FG_TICK else BG_TICK)
                }
                outer.cancel()
            }
            launch {
                // Şarkı değişince / durup başlayınca hemen bildir
                combine(PlayerManager.queue, PlayerManager.index, PlayerManager.playing, showListening) { _, _, _, _ -> Unit }
                    .collectLatest { delay(300); sendHeartbeat() }
            }
        }
    }

    /** Çalan şarkıyı da içeren sinyal. Sunucu yanıt olarak güncel arkadaş listesini döner. */
    private suspend fun sendHeartbeat() {
        val json = JSONObject()
        if (showListening.value && PlayerManager.playing.value) {
            val s = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
            if (s != null) json.put("playing", JSONObject()
                .put("title", s.title).put("artist", s.artist).put("url", s.url).put("thumb", s.thumb ?: JSONObject.NULL))
        }
        val r = call("/social/heartbeat", json)
        if (r != null && r.code in 200..299) applySnapshot(r.body) else errorOf(r, "")
    }

    // ---------------------------------------------------------------- ağ

    internal class Result(val code: Int, val body: JSONObject)

    internal suspend fun call(path: String, json: JSONObject): Result? = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(SOCIAL_API_URL.trimEnd('/') + path)
                .post(json.toString().toRequestBody(JSON.toMediaType()))
            token?.let { b.header("Authorization", "Bearer $it") }
            Http.server.newCall(b.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                Result(r.code, try { JSONObject(text) } catch (e: Exception) { JSONObject() })
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    private fun errorOf(r: Result?, fallback: String): String? = when {
        r == null -> "Sunucuya bağlanılamadı. İnternetini kontrol et; sunucu uykudaysa 1 dakika sonra tekrar dene."
        r.code in 200..299 -> null
        r.code == 401 -> { // anahtar sunucuda yok (sunucu sıfırlanmış olabilir)
            token = null; username.value = null; myAvatar.value = null
            prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
            "Sosyal hesabın sunucuda bulunamadı. Yeniden kullanıcı adı al."
        }
        else -> r.body.optString("error").ifBlank { if (r.code >= 500) "Sunucu hatası. Biraz sonra tekrar dene." else fallback }
    }

    private fun avatarOf(o: JSONObject): String? = if (o.isNull("avatar")) null else o.optString("avatar").ifBlank { null }

    /** Sunucudan gelen özeti (ben, arkadaşlar, istekler) ekrana yansıtır. */
    private suspend fun applySnapshot(b: JSONObject) {
        b.optJSONObject("me")?.let { m ->
            val n = m.optString("username")
            if (n.isNotBlank() && n != username.value) {
                username.value = n
                prefs?.edit()?.putString("social_name", n)?.apply()
            }
            myAvatar.value = avatarOf(m)
            displayName.value = m.optString("name").ifBlank { null } ?: n.ifBlank { null }
        }
        friends.value = b.optJSONArray("friends").toList { o ->
            val l = o.optJSONObject("listening")
            SocialFriend(
                o.getString("username"), o.optBoolean("online"), o.optLong("lastSeen"), avatarOf(o),
                l?.let { Song(it.optString("title"), it.optString("artist"), it.optString("url"),
                    if (it.isNull("thumb")) null else it.optString("thumb").ifBlank { null }) },
                o.optString("name").ifBlank { o.getString("username") }
            )
        }.sortedWith(compareByDescending<SocialFriend> { it.listening != null }
            .thenByDescending { it.online }.thenBy { it.username.lowercase() })
        incoming.value = b.optJSONArray("incoming").toList { SocialPerson(it.getString("username"), avatarOf(it), it.optString("name").ifBlank { it.getString("username") }) }
        outgoing.value = b.optJSONArray("outgoing").toList { SocialPerson(it.getString("username"), avatarOf(it), it.optString("name").ifBlank { it.getString("username") }) }
        val n = b.optInt("inbox", -1)
        if (n >= 0 && n != inbox.value.size) fetchInbox()
    }

    private suspend fun fetchInbox() {
        val ib = call("/social/inbox", JSONObject())
        if (ib != null && ib.code in 200..299) {
            inbox.value = ib.body.optJSONArray("items").toList { o ->
                val sa = o.optJSONArray("songs") ?: JSONArray()
                SharedList(
                    o.getString("id"), o.optString("from"), o.optString("name"),
                    (0 until sa.length()).map { j ->
                        val s = sa.getJSONObject(j)
                        Song(s.optString("title"), s.optString("artist"), s.optString("url"),
                            if (s.isNull("thumb")) null else s.optString("thumb").ifBlank { null })
                    }
                )
            }
        }
    }

    // ---------------------------------------------------------------- işlemler

    /** Kullanıcı adı alır. Hesaba giriş yapılmışsa kullanıcı adı hesaba bağlanır. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun join(name: String): String? {
        val clean = name.trim().removePrefix("@")
        val session = AuthStore.session
        if (session != null) {
            val (err, uname, tok) = AuthApi.socialJoin(session, clean)
            if (err != null) return err
            val un = uname ?: return "Hesap oluşturulamadı."
            val tk = tok ?: return "Hesap oluşturulamadı."
            restore(un, tk)
            return null
        }
        val r = call("/social/join", JSONObject().put("username", clean))
        val err = errorOf(r, "Hesap oluşturulamadı.")
        if (err != null) return err
        token = r!!.body.optString("token")
        username.value = r.body.optString("username")
        prefs?.edit()?.putString("social_token", token)?.putString("social_name", username.value)?.apply()
        start()
        return null
    }

    /** Görünen adı değiştirir (herkes istediği adı yazabilir). Hata varsa mesajı, başarılıysa null döner. */
    suspend fun setDisplayName(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Ad boş olamaz."
        val r = call("/social/display-name", JSONObject().put("name", n.take(30)))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        displayName.value = n.take(30)
        refresh()
        return null
    }

    /** Kullanıcı adını değiştirir. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun rename(name: String): String? {
        val r = call("/social/rename", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        username.value = r!!.body.optString("username")
        prefs?.edit()?.putString("social_name", username.value)?.apply()
        refresh()
        return null
    }

    suspend fun refresh() {
        if (token == null) return
        val r = call("/social/friends", JSONObject())
        if (r != null && r.code in 200..299) applySnapshot(r.body) else errorOf(r, "")
    }

    /** Seçilen resmi kare kırpıp 256x256 JPEG yaparak profil fotoğrafı olarak yükler. */
    suspend fun setAvatar(ctx: Context, uri: Uri): String? {
        if (token == null) return "Önce kullanıcı adı al."
        val bytes: ByteArray = withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@withContext null
                val side = minOf(bmp.width, bmp.height)
                val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)
                var q = 85
                var out = ByteArray(0)
                do {
                    val bos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, q, bos)
                    out = bos.toByteArray()
                    q -= 10
                } while (out.size > 55_000 && q > 30)
                out
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { null }
        } ?: return "Fotoğraf okunamadı."
        val r = call("/social/avatar-set", JSONObject().put("image", Base64.encodeToString(bytes, Base64.NO_WRAP)))
        val err = errorOf(r, "Fotoğraf yüklenemedi.")
        if (err != null) return err
        myAvatar.value = r!!.body.optString("avatar").ifBlank { null }
        refresh()
        return null
    }

    suspend fun clearAvatar(): String? {
        val err = errorOf(call("/social/avatar-clear", JSONObject()), "Fotoğraf kaldırılamadı.")
        if (err == null) { myAvatar.value = null; refresh() }
        return err
    }

    suspend fun sendRequest(name: String): String? {
        val n = name.trim().removePrefix("@")
        if (!Regex("^[A-Za-z0-9_.]{3,20}$").matches(n)) return "Kullanıcı adı 3-20 karakter olmalı (harf, rakam, _ ve .)."
        return errorOf(call("/social/friend-request", JSONObject().put("username", n)), "İstek gönderilemedi.").also { refresh() }
    }

    // ---------------------------------------------------------------- Blend (uyum oranı)

    private var lastTaste = ""

    /** En çok dinlenen sanatçılarımı sunucuya yollar; yalnızca arkadaşlar Blend'de görür. */
    suspend fun pushTaste(force: Boolean = false) {
        if (token == null) return
        try {
            val top = withContext(Dispatchers.Main) { TasteProfile.topArtistsWeighted(25) }
            if (top.isEmpty()) return
            val arr = JSONArray()
            top.forEach { arr.put(JSONObject().put("n", it.first).put("w", it.second)) }
            val sig = arr.toString()
            if (!force && sig == lastTaste) return
            val r = call("/social/taste-set", JSONObject().put("artists", arr))
            if (r != null && r.code in 200..299) lastTaste = sig
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { }
    }

    /** Arkadaşımla iki tarafın zevkini getirir. Hata varsa (mesaj, null), başarılıysa (null, veri) döner. */
    suspend fun blendWith(friend: String): Pair<String?, BlendPair?> {
        pushTaste(force = true)
        val r = call("/social/blend", JSONObject().put("username", friend))
        val err = errorOf(r, "Blend yüklenemedi.")
        if (err != null) return err to null
        val b = r!!.body
        fun parse(o: JSONObject?): List<WArtist> =
            o?.optJSONArray("artists").toList { WArtist(it.optString("n"), it.optInt("w", 1)) }.filter { it.name.isNotBlank() }
        return null to BlendPair(parse(b.optJSONObject("me")), parse(b.optJSONObject("friend")))
    }

    suspend fun respond(name: String, accept: Boolean): String? =
        errorOf(call("/social/friend-respond", JSONObject().put("username", name).put("accept", accept)), "İşlem yapılamadı.").also { refresh() }

    suspend fun remove(name: String): String? =
        errorOf(call("/social/friend-remove", JSONObject().put("username", name)), "Silinemedi.").also { refresh() }

    /** Listeyi seçilen arkadaşlara gönderir. Cihazdan yüklenen şarkılar atlanır. */
    suspend fun share(to: List<String>, name: String, songs: List<Song>): String? {
        val arr = JSONArray()
        songs.filterNot { Uploads.isLocal(it) }.forEach {
            arr.put(JSONObject().put("title", it.title).put("artist", it.artist).put("url", it.url).put("thumb", it.thumb ?: JSONObject.NULL))
        }
        if (arr.length() == 0) return "Paylaşılacak şarkı yok. Cihazdan yüklenen şarkılar paylaşılamaz."
        val r = call("/social/share", JSONObject().put("to", JSONArray(to)).put("name", name).put("songs", arr))
        return errorOf(r, "Paylaşılamadı.")
    }

    suspend fun dismiss(id: String) {
        call("/social/inbox-dismiss", JSONObject().put("id", id))
        refresh()
    }

    private fun <T> JSONArray?.toList(f: (JSONObject) -> T): List<T> =
        if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }
}

// ====================================================================== ARAYÜZ

private val SMuted = Color(0xFF9A9A9A)
private val OnlineGreen = Color(0xFF3DDC84)
private val OfflineGrey = Color(0xFF5A5A5A)
private val avatarColors = listOf(0xFF6C5CE7, 0xFF00B894, 0xFFE17055, 0xFF0984E3, 0xFFD63031, 0xFFE84393, 0xFFB7791F, 0xFF00A8B5).map { Color(it) }

private fun lastSeenText(f: SocialFriend): String {
    if (f.online) return "Çevrim içi"
    if (f.lastSeen <= 0) return "Çevrim dışı"
    val min = ((System.currentTimeMillis() - f.lastSeen) / 60_000).coerceAtLeast(1)
    return when {
        min < 60 -> "Son görülme · $min dk önce"
        min < 60 * 24 -> "Son görülme · ${min / 60} sa önce"
        else -> "Son görülme · ${min / (60 * 24)} gün önce"
    }
}

/** Yuvarlak profil resmi. Fotoğraf yoksa isme göre renkli baş harf gösterir; online verilirse köşede durum noktası olur. */
@Composable
fun UserAvatar(name: String, avatarId: String?, size: Dp, online: Boolean? = null, modifier: Modifier = Modifier) {
    val url = Social.avatarUrl(avatarId)
    Box(modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape)
                .background(avatarColors[(name.lowercase().hashCode() and 0x7fffffff) % avatarColors.size]),
            contentAlignment = Alignment.Center
        ) {
            Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
            if (url != null) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        if (online != null) {
            val dot = (size.value * 0.28f).coerceAtLeast(10f).dp
            Box(
                Modifier.align(Alignment.BottomEnd).size(dot).clip(CircleShape).background(Bg).padding(2.dp)
                    .clip(CircleShape).background(if (online) OnlineGreen else OfflineGrey)
            )
        }
    }
}

/** Küçük "müzik çalıyor" çubukları. */
@Composable
private fun EqualizerBars(color: Color) {
    val t = rememberInfiniteTransition(label = "eq")
    val bars = listOf(420, 560, 700).map { ms ->
        t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Reverse), label = "bar$ms")
    }
    Row(Modifier.height(14.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        bars.forEach { h -> Box(Modifier.width(3.dp).fillMaxHeight(h.value).clip(RoundedCornerShape(1.dp)).background(color)) }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SMuted,
        modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp))
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card), content = content)
}

@Composable
private fun FriendMenu(onRemove: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü", tint = SMuted) }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text("Arkadaşlıktan çıkar") }, leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                onClick = { menu = false; onRemove() })
        }
    }
}

/** Şu an müzik dinleyen arkadaş kartı: kapak, şarkı adı ve "sen de dinle" düğmesi. */
@Composable
private fun ListeningCard(f: SocialFriend, onOpen: () -> Unit, onRemove: () -> Unit) {
    val l = f.listening ?: return
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(22.dp)).background(Card).padding(12.dp)) {
        Row(Modifier.clip(RoundedCornerShape(16.dp)).clickable { onOpen() }, verticalAlignment = Alignment.CenterVertically) {
            UserAvatar(f.username, f.avatar, 46.dp, online = true)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EqualizerBars(OnlineGreen)
                    Spacer(Modifier.width(6.dp))
                    Text("şu an dinliyor", color = OnlineGreen, style = MaterialTheme.typography.bodySmall)
                }
            }
            BlendHint()
            FriendMenu(onRemove)
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Bg.copy(alpha = 0.55f)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.MusicNote, null, tint = Accent)
                if (l.thumb != null) AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(l.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (l.artist.isNotBlank()) Text(l.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (l.url.isNotBlank()) {
                IconButton({ PlayerManager.playQueue(listOf(l), 0) }, Modifier.clip(CircleShape).background(Accent)) {
                    Icon(Icons.Filled.PlayArrow, "Sen de dinle", tint = Color.White)
                }
            }
        }
    }
}

/** Arkadaş satırlarında "dokun, Blend yap" ipucu. */
@Composable
private fun BlendHint() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 2.dp)) {
        Icon(Icons.Filled.Group, null, tint = Accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text("Blend", color = Accent, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FriendRow(f: SocialFriend, onOpen: () -> Unit, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen() }.padding(start = 14.dp, end = 2.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        UserAvatar(f.username, f.avatar, 44.dp, online = f.online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("@${f.username} · " + lastSeenText(f), color = if (f.online) OnlineGreen else SMuted, style = MaterialTheme.typography.bodySmall)
        }
        BlendHint()
        FriendMenu(onRemove)
    }
}

/** Arkadaşlar sekmesi: profil (fotoğraf, ad), ne dinlediklerini gösteren arkadaşlar, istekler ve gelen paylaşımlar. */
@Composable
fun FriendsTab(onBlend: (SocialFriend) -> Unit = {}, onOpenAuth: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    val myDisplayName by Social.displayName.collectAsState()
    val clipboard = LocalClipboardManager.current
    val myAvatar by Social.myAvatar.collectAsState()
    val friends by Social.friends.collectAsState()
    val incoming by Social.incoming.collectAsState()
    val outgoing by Social.outgoing.collectAsState()
    val inbox by Social.inbox.collectAsState()
    val showListening by Social.showListening.collectAsState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var removeTarget by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var avatarMenu by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            uploading = true
            val e = Social.setAvatar(ctx, uri)
            uploading = false
            Toast.makeText(ctx, e ?: "Profil fotoğrafın güncellendi", Toast.LENGTH_SHORT).show()
        }
    }

    // Sekme açılınca hemen güncelle; sonrası sinyal döngüsü her 5 sn'de yeniler
    LaunchedEffect(me) { if (me != null) { Social.start(); Social.refresh() } }

    Column(Modifier.fillMaxSize()) {
        if (!Social.enabled) {
            Text("Sosyal özellikler henüz ayarlanmadı. Sunucuyu yayınlayıp Social.kt dosyasındaki SOCIAL_API_URL değerine adresini yaz (backend/README.md).",
                color = SMuted, modifier = Modifier.padding(20.dp))
            return@Column
        }

        if (me == null) {
            val signedIn = AuthStore.session != null
            // Giriş yapılmışsa arkadaş kimliği e-postadan otomatik oluşur; kullanıcı isim aramak zorunda kalmaz
            LaunchedEffect(signedIn) { if (signedIn) { busy = true; error = Social.join(""); busy = false } }
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.People, null, tint = Accent, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("Arkadaşlarınla dinle", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (signedIn) {
                    Text("Hesabın hazırlanıyor...", color = SMuted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    if (busy) CircularProgressIndicator(color = Accent)
                    else {
                        error?.let { Text(it, color = Accent, textAlign = TextAlign.Center) }
                        Spacer(Modifier.height(8.dp))
                        Button(
                            { scope.launch { busy = true; error = Social.join(""); busy = false } },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                        ) { Text("Tekrar dene") }
                    }
                } else {
                    Text("Giriş yap, arkadaşlarını ekle. Beğendiklerin ve listelerin de hesabına kaydedilir.", color = SMuted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        { onOpenAuth() }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) { Text("Giriş yap / Hesap oluştur") }
                }
            }
            return@Column
        }

        val myName = me ?: ""
        val myShown = myDisplayName ?: myName
        val listening = friends.filter { it.listening != null }
        val onlineRest = friends.filter { it.online && it.listening == null }
        val offline = friends.filter { !it.online }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
            item {
                Column(Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp)) {
                    Text("Arkadaşlar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("${friends.count { it.online }} çevrim içi · ${friends.size} arkadaş", color = SMuted, style = MaterialTheme.typography.bodySmall)
                    if (friends.isNotEmpty()) Text("Müzik uyumunu görmek için bir arkadaşına dokun.", color = SMuted, style = MaterialTheme.typography.bodySmall)
                }
            }

            // ---- Profil kartı ----
            item {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.6f), Card)))
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                Box(Modifier.clip(CircleShape).clickable { avatarMenu = true }) { UserAvatar(myShown, myAvatar, 78.dp) }
                                if (uploading) Box(Modifier.size(78.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(Modifier.size(28.dp), color = Color.White, strokeWidth = 3.dp)
                                }
                                Box(Modifier.align(Alignment.BottomEnd).size(28.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.CameraAlt, "Fotoğraf", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                DropdownMenu(avatarMenu, { avatarMenu = false }) {
                                    DropdownMenuItem(text = { Text("Fotoğraf seç") }, leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null) },
                                        onClick = { avatarMenu = false; picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
                                    if (myAvatar != null) DropdownMenuItem(text = { Text("Fotoğrafı kaldır") }, leadingIcon = { Icon(Icons.Filled.Delete, null) },
                                        onClick = {
                                            avatarMenu = false
                                            scope.launch { Social.clearAvatar()?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }
                                        })
                                }
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(myShown, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Row(Modifier.clickable {
                                    clipboard.setText(AnnotatedString(myName))
                                    Toast.makeText(ctx, "Kullanıcı adın kopyalandı", Toast.LENGTH_SHORT).show()
                                }, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Kullanıcı adın: @$myName", color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                    Spacer(Modifier.width(4.dp))
                                    Icon(Icons.Filled.ContentCopy, "Kopyala", tint = SMuted, modifier = Modifier.size(14.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(OnlineGreen))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Çevrim içi", color = OnlineGreen, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            IconButton({
                                ctx.startActivity(Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "Beni New Music'te arkadaş olarak ekle. Kullanıcı adım: @$myName")
                                    }, null))
                            }) { Icon(Icons.Filled.Share, "Kullanıcı adını gönder") }
                            IconButton({ renaming = true }) { Icon(Icons.Filled.Edit, "Görünen adı değiştir") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.2f)).padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Headphones, null, tint = Accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Ne dinlediğimi göster", fontWeight = FontWeight.Medium)
                                Text("Arkadaşların şu an çalan şarkını görür", color = SMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(showListening, { Social.setShowListening(it) })
                        }
                    }
                }
            }

            // ---- Arkadaş ekle ----
            item {
                val canSend = !busy && input.removePrefix("@").length >= 3
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(22.dp)).background(Card).padding(16.dp)
                ) {
                    Text("Arkadaş ekle", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Arkadaşının kullanıcı adını yaz. Onun kullanıcı adı, kendi profil kartında görünür.",
                        color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        input, { input = it.filterNot { c -> c.isWhitespace() }.take(30); error = null },
                        placeholder = { Text("Örn. ali_4821") }, singleLine = true,
                        shape = RoundedCornerShape(16.dp), isError = error != null,
                        supportingText = error?.let { { Text(it) } },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        {
                            scope.launch {
                                busy = true
                                val e = Social.sendRequest(input)
                                busy = false
                                error = e
                                if (e == null) { Toast.makeText(ctx, "İstek gönderildi", Toast.LENGTH_SHORT).show(); input = "" }
                            }
                        },
                        enabled = canSend, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        else { Icon(Icons.Filled.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("İstek gönder") }
                    }
                }
            }

            // ---- Gelen paylaşımlar ----
            if (inbox.isNotEmpty()) {
                item { SectionTitle("SANA GÖNDERİLEN LİSTELER") }
                item {
                    SectionCard {
                        inbox.forEach { l ->
                            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.LibraryMusic, null, tint = Accent)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(l.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${l.from} · ${l.songs.size} şarkı", color = SMuted, style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton({
                                    Playlists.create("${l.name} (${l.from})", l.songs)
                                    scope.launch { Social.dismiss(l.id) }
                                    Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                                }) { Text("Kaydet", color = Accent) }
                                IconButton({ scope.launch { Social.dismiss(l.id) } }) { Icon(Icons.Filled.Close, "Yoksay", tint = SMuted) }
                            }
                        }
                    }
                }
            }

            // ---- Arkadaşlık istekleri ----
            if (incoming.isNotEmpty()) {
                item { SectionTitle("ARKADAŞLIK İSTEKLERİ") }
                item {
                    SectionCard {
                        incoming.forEach { p ->
                            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                UserAvatar(p.username, p.avatar, 44.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("@${p.username} · Arkadaş olmak istiyor", color = SMuted, style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton({ scope.launch { Social.respond(p.username, true) } }, Modifier.clip(CircleShape).background(Accent)) {
                                    Icon(Icons.Filled.Check, "Kabul et", tint = Color.White)
                                }
                                Spacer(Modifier.width(6.dp))
                                IconButton({ scope.launch { Social.respond(p.username, false) } }) { Icon(Icons.Filled.Close, "Reddet", tint = SMuted) }
                            }
                        }
                    }
                }
            }

            // ---- Şimdi dinleyenler ----
            if (listening.isNotEmpty()) {
                item { SectionTitle("ŞİMDİ DİNLİYOR (${listening.size})") }
                items(listening, key = { "ls" + it.username }) { f -> ListeningCard(f, { onBlend(f) }) { removeTarget = f.username } }
            }

            // ---- Çevrim içi ----
            if (onlineRest.isNotEmpty()) {
                item { SectionTitle("ÇEVRİM İÇİ (${onlineRest.size})") }
                item { SectionCard { onlineRest.forEach { f -> FriendRow(f, { onBlend(f) }) { removeTarget = f.username } } } }
            }

            // ---- Çevrim dışı ----
            if (offline.isNotEmpty()) {
                item { SectionTitle("ÇEVRİM DIŞI (${offline.size})") }
                item { SectionCard { offline.forEach { f -> FriendRow(f, { onBlend(f) }) { removeTarget = f.username } } } }
            }

            if (friends.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(top = 36.dp, start = 32.dp, end = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.People, null, tint = SMuted, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Henüz arkadaşın yok", fontWeight = FontWeight.Bold)
                    Text("Yukarıya arkadaşının kullanıcı adını yazıp istek gönder. Sen de kendi kullanıcı adını paylaş butonuyla ona yollayabilirsin.", color = SMuted, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                }
            }

            // ---- Bekleyen istekler ----
            if (outgoing.isNotEmpty()) {
                item { SectionTitle("BEKLEYEN İSTEKLER") }
                item {
                    SectionCard {
                        outgoing.forEach { p ->
                            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                UserAvatar(p.username, p.avatar, 36.dp)
                                Spacer(Modifier.width(12.dp))
                                Text("${p.name} (@${p.username})", Modifier.weight(1f), color = SMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                TextButton({ scope.launch { Social.remove(p.username) } }) { Text("İptal", color = SMuted) }
                            }
                        }
                    }
                }
            }
        }
    }

    removeTarget?.let { n ->
        AlertDialog(
            onDismissRequest = { removeTarget = null }, containerColor = Card, title = { Text("@$n") },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ scope.launch { Social.remove(n) }; removeTarget = null }) { Text("Çıkar") } },
            dismissButton = { TextButton({ removeTarget = null }) { Text("Vazgeç") } }
        )
    }

    if (renaming) {
        var text by remember { mutableStateOf(myDisplayName ?: me ?: "") }
        var err by remember { mutableStateOf<String?>(null) }
        var saving by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!saving) renaming = false }, containerColor = Card, title = { Text("Görünen adını değiştir") },
            text = {
                OutlinedTextField(text, { text = it.take(30); err = null }, singleLine = true, shape = RoundedCornerShape(14.dp), isError = err != null,
                    supportingText = { Text(err ?: "İstediğin adı yazabilirsin. Kullanıcı adın (@${me ?: ""}) değişmez.") })
            },
            confirmButton = {
                TextButton({
                    scope.launch {
                        saving = true
                        val e = Social.setDisplayName(text)
                        saving = false
                        err = e
                        if (e == null) {
                            if (AuthStore.email.value != null) AuthStore.setName(text)
                            renaming = false
                            Toast.makeText(ctx, "Görünen adın değişti", Toast.LENGTH_SHORT).show()
                        }
                    }
                }, enabled = !saving && text.isNotBlank() && text.trim() != (myDisplayName ?: "")) { Text("Kaydet") }
            },
            dismissButton = { TextButton({ renaming = false }, enabled = !saving) { Text("Vazgeç") } }
        )
    }
}

/** Bir arkadaşınla Blend: uyum oranı, ortak sanatçılar ve karışık liste. */
@Composable
fun FriendBlendScreen(friend: SocialFriend, onBack: () -> Unit, onOpenList: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val myId by Social.username.collectAsState()
    val myDisp by Social.displayName.collectAsState()
    val myName = myDisp ?: myId
    val myAvatar by Social.myAvatar.collectAsState()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var data by remember { mutableStateOf<BlendPair?>(null) }
    var building by remember { mutableStateOf(false) }
    var buildError by remember { mutableStateOf<String?>(null) }
    var resultId by remember { mutableStateOf<String?>(null) }
    var resultSongs by remember { mutableStateOf<List<Song>>(emptyList()) }

    LaunchedEffect(friend.username) {
        loading = true; error = null
        val res = Social.blendWith(friend.username)
        error = res.first; data = res.second; loading = false
    }

    val d = data
    val compat = remember(d) { if (d != null && d.me.isNotEmpty() && d.friend.isNotEmpty()) Blend.compat(d.me, d.friend) else null }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
            Text("Blend", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        // ---- İki profil + uyum oranı ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                UserAvatar(myName ?: "", myAvatar, 72.dp)
                Text(myName ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                when {
                    loading -> CircularProgressIndicator(Modifier.size(32.dp), color = Accent, strokeWidth = 3.dp)
                    compat != null -> {
                        Text("%${compat.percent}", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
                        Text("uyum", color = SMuted, style = MaterialTheme.typography.bodySmall)
                    }
                    else -> Icon(Icons.Filled.Group, null, tint = SMuted, modifier = Modifier.size(36.dp))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                UserAvatar(friend.username, friend.avatar, 72.dp)
                Text(friend.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
            }
        }

        error?.let {
            Text(it, color = Accent, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp))
        }

        if (!loading && error == null && d != null) {
            if (compat != null) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.12f))) {
                        Box(Modifier.fillMaxWidth(compat.percent / 100f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(Accent))
                    }
                    Text(compat.label, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                }
                SectionTitle("ORTAK SANATÇILAR")
                SectionCard {
                    Text(
                        if (compat.shared.isEmpty()) "Henüz ortak sanatçınız yok. Blend listesi ikinizin zevkinden karışık şarkılar getirir."
                        else compat.shared.take(8).joinToString(", "),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                SectionCard {
                    Text(
                        if (d.me.isEmpty()) "Uyum oranı için önce birkaç şarkı dinle veya beğen."
                        else "${friend.name} henüz yeterince müzik dinlememiş ya da uygulamayı güncellememiş. O açıp birkaç şarkı dinleyince uyum oranı görünür.",
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            if (d.friend.isNotEmpty()) {
                SectionTitle("${friend.name.uppercase()} EN ÇOK DİNLEDİKLERİ")
                SectionCard { Text(d.friend.take(8).joinToString(", ") { it.name }, modifier = Modifier.padding(16.dp)) }
            }

            Spacer(Modifier.height(16.dp))
            Column(Modifier.padding(horizontal = 16.dp)) {
                Button(
                    onClick = {
                        buildError = null; resultId = null; building = true
                        scope.launch {
                            val songs = Blend.make(d.me.map { it.name }, d.friend.map { it.name })
                            building = false
                            if (songs.isEmpty()) buildError = "Şarkı bulunamadı. İnternetini kontrol edip tekrar dene."
                            else {
                                val pl = Playlists.create("Blend: ${myName ?: "Sen"} + ${friend.name}", songs)
                                resultId = pl.id; resultSongs = songs
                            }
                        }
                    },
                    enabled = !building && d.me.isNotEmpty() && d.friend.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                ) {
                    if (building) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    else { Icon(Icons.Filled.Group, null); Spacer(Modifier.width(8.dp)); Text("Blend listesi oluştur") }
                }
                buildError?.let { Text(it, color = Accent, modifier = Modifier.padding(top = 8.dp)) }
                resultId?.let { rid ->
                    Column(Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(20.dp)).background(Accent.copy(alpha = 0.16f)).padding(16.dp)) {
                        Text("Blend hazır!", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("${resultSongs.size} şarkı • Kitaplık > Listelerim'e kaydedildi", color = SMuted, style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ PlayerManager.playQueue(resultSongs, 0) }, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)) {
                                Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal")
                            }
                            OutlinedButton({ onOpenList(rid) }) { Text("Listeyi aç") }
                        }
                    }
                }
            }
        }
    }
}

/** Bir listeyi seçilen arkadaşlara gönderir. */
@Composable
fun ShareListDialog(pl: UserPlaylist, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { Social.refresh() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card, title = { Text("\"${pl.name}\" paylaş") },
        text = {
            when {
                !Social.enabled || !Social.joined -> Text("Paylaşmak için önce Arkadaşlar sekmesinden kullanıcı adı al.")
                friends.isEmpty() -> Text("Henüz arkadaşın yok.")
                else -> LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(friends, key = { it.username }) { f ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if (f.username in selected) selected.remove(f.username) else selected.add(f.username)
                        }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.username in selected, { if (it) selected.add(f.username) else selected.remove(f.username) })
                            UserAvatar(f.username, f.avatar, 34.dp, online = f.online)
                            Spacer(Modifier.width(10.dp))
                            Text(f.name)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    busy = true
                    val e = Social.share(selected.toList(), pl.name, pl.songs)
                    busy = false
                    Toast.makeText(ctx, e ?: "Gönderildi", Toast.LENGTH_SHORT).show()
                    if (e == null) onDismiss()
                }
            }, enabled = selected.isNotEmpty() && !busy) { Text("Gönder") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}
