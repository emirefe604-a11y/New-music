package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import coil.compose.AsyncImage
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive

/*
 * SOSYAL ÖZELLİKLER (arkadaşlar, çevrim içi/dışı, liste paylaşımı)
 * backend/ klasöründeki sunucuyu yayınlayıp adresini aşağıya yaz. Boşsa sosyal özellikler gizlenir.
 */
const val SOCIAL_API_URL = "https://new-music-cpzw.onrender.com"

data class SocialFriend(val username: String, val online: Boolean, val lastSeen: Long, val listening: Song? = null)
data class SharedList(val id: String, val from: String, val name: String, val songs: List<Song>)

object Social {
    val username = MutableStateFlow<String?>(null)
    val friends = MutableStateFlow<List<SocialFriend>>(emptyList())
    val incoming = MutableStateFlow<List<String>>(emptyList())
    val outgoing = MutableStateFlow<List<String>>(emptyList())
    val inbox = MutableStateFlow<List<SharedList>>(emptyList())
    /** Açıkken çevrim içi arkadaşların şu an çalan şarkını görür. */
    val showListening = MutableStateFlow(true)

    val enabled: Boolean get() = SOCIAL_API_URL.isNotBlank()

    private var prefs: SharedPreferences? = null
    private var token: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private const val JSON = "application/json; charset=utf-8"

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        token = p.getString("social_token", null)
        username.value = p.getString("social_name", null)
        showListening.value = p.getBoolean("social_show_listening", true)
    }

    fun setShowListening(on: Boolean) {
        showListening.value = on
        prefs?.edit()?.putBoolean("social_show_listening", on)?.apply()
    }

    val joined: Boolean get() = token != null

    /** Çalan şarkıyı da içeren "çevrim içiyim" sinyali. Gizlilik kapalıysa şarkı gönderilmez. */
    private suspend fun sendHeartbeat() {
        val json = JSONObject()
        if (showListening.value && PlayerManager.playing.value) {
            val s = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
            if (s != null) json.put("playing", JSONObject()
                .put("title", s.title).put("artist", s.artist).put("url", s.url).put("thumb", s.thumb ?: JSONObject.NULL))
        }
        call("/social/heartbeat", json)
    }

    /** Uygulama öne gelince: 30 sn'de bir sinyal gönderir; şarkı değişince/durunca hemen günceller. */
    fun start() {
        if (!enabled || token == null || loop?.isActive == true) return
        loop = scope.launch {
            launch {
                while (isActive && token != null) {
                    sendHeartbeat()
                    refresh()
                    delay(30_000)
                }
            }
            launch {
                combine(PlayerManager.queue, PlayerManager.index, PlayerManager.playing, showListening) { _, _, _, _ -> Unit }
                    .collectLatest { delay(800); sendHeartbeat() }
            }
        }
    }

    /** Uygulama arka plana gidince: sinyali durdurur ve çevrim dışı olur. */
    fun stop() {
        loop?.cancel(); loop = null
        if (!enabled || token == null) return
        scope.launch { call("/social/offline", JSONObject()) }
    }

    private class Result(val code: Int, val body: JSONObject)

    private suspend fun call(path: String, json: JSONObject): Result? = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(SOCIAL_API_URL.trimEnd('/') + path)
                .post(json.toString().toRequestBody(JSON.toMediaType()))
            token?.let { b.header("Authorization", "Bearer $it") }
            Http.client.newCall(b.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                Result(r.code, try { JSONObject(text) } catch (e: Exception) { JSONObject() })
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    private fun errorOf(r: Result?, fallback: String): String? = when {
        r == null -> "Bağlantı kurulamadı. İnternetini kontrol et."
        r.code in 200..299 -> null
        r.code == 401 -> { // anahtar sunucuda yok (sunucu sıfırlanmış olabilir)
            token = null; username.value = null
            prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
            "Sosyal hesabın sunucuda bulunamadı. Yeniden kullanıcı adı al."
        }
        else -> r.body.optString("error").ifBlank { fallback }
    }

    /** Kullanıcı adı alır. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun join(name: String): String? {
        val r = call("/social/join", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Hesap oluşturulamadı.")
        if (err != null) return err
        token = r!!.body.optString("token")
        username.value = r.body.optString("username")
        prefs?.edit()?.putString("social_token", token)?.putString("social_name", username.value)?.apply()
        start()
        return null
    }

    /** Kullanıcı adını değiştirir. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun rename(name: String): String? {
        val r = call("/social/rename", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        username.value = r!!.body.optString("username")
        prefs?.edit()?.putString("social_name", username.value)?.apply()
        refresh()
        return null
    }

    suspend fun refresh() {
        if (token == null) return
        val r = call("/social/friends", JSONObject())
        if (r != null && r.code in 200..299) {
            val b = r.body
            friends.value = b.optJSONArray("friends").toList { o ->
                val l = o.optJSONObject("listening")
                SocialFriend(
                    o.getString("username"), o.optBoolean("online"), o.optLong("lastSeen"),
                    l?.let { Song(it.optString("title"), it.optString("artist"), it.optString("url"),
                        if (it.isNull("thumb")) null else it.optString("thumb").ifBlank { null }) }
                )
            }.sortedWith(compareByDescending<SocialFriend> { it.listening != null }
                .thenByDescending { it.online }.thenBy { it.username.lowercase() })
            incoming.value = b.optJSONArray("incoming").toList { it.getString("username") }
            outgoing.value = b.optJSONArray("outgoing").toList { it.getString("username") }
        } else errorOf(r, "")
        val ib = call("/social/inbox", JSONObject())
        if (ib != null && ib.code in 200..299) {
            inbox.value = ib.body.optJSONArray("items").toList { o ->
                val sa = o.optJSONArray("songs") ?: JSONArray()
                SharedList(
                    o.getString("id"), o.optString("from"), o.optString("name"),
                    (0 until sa.length()).map { j ->
                        val s = sa.getJSONObject(j)
                        Song(s.optString("title"), s.optString("artist"), s.optString("url"),
                            if (s.isNull("thumb")) null else s.optString("thumb").ifBlank { null })
                    }
                )
            }
        }
    }

    suspend fun sendRequest(name: String): String? =
        errorOf(call("/social/friend-request", JSONObject().put("username", name.trim())), "İstek gönderilemedi.").also { refresh() }

    suspend fun respond(name: String, accept: Boolean): String? =
        errorOf(call("/social/friend-respond", JSONObject().put("username", name).put("accept", accept)), "İşlem yapılamadı.").also { refresh() }

    suspend fun remove(name: String): String? =
        errorOf(call("/social/friend-remove", JSONObject().put("username", name)), "Silinemedi.").also { refresh() }

    /** Listeyi seçilen arkadaşlara gönderir. Cihazdan yüklenen şarkılar atlanır. */
    suspend fun share(to: List<String>, name: String, songs: List<Song>): String? {
        val arr = JSONArray()
        songs.filterNot { Uploads.isLocal(it) }.forEach {
            arr.put(JSONObject().put("title", it.title).put("artist", it.artist).put("url", it.url).put("thumb", it.thumb ?: JSONObject.NULL))
        }
        if (arr.length() == 0) return "Paylaşılacak şarkı yok. Cihazdan yüklenen şarkılar paylaşılamaz."
        val r = call("/social/share", JSONObject().put("to", JSONArray(to)).put("name", name).put("songs", arr))
        return errorOf(r, "Paylaşılamadı.")
    }

    suspend fun dismiss(id: String) {
        call("/social/inbox-dismiss", JSONObject().put("id", id))
        refresh()
    }

    private fun <T> JSONArray?.toList(f: (JSONObject) -> T): List<T> =
        if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }
}

private val SMuted = Color(0xFF9A9A9A)
private val OnlineGreen = Color(0xFF3DDC84)

private fun lastSeenText(f: SocialFriend): String {
    if (f.online) return "Çevrim içi"
    if (f.lastSeen <= 0) return "Çevrim dışı"
    val min = ((System.currentTimeMillis() - f.lastSeen) / 60_000).coerceAtLeast(1)
    return when {
        min < 60 -> "Çevrim dışı · $min dk önce"
        min < 60 * 24 -> "Çevrim dışı · ${min / 60} sa önce"
        else -> "Çevrim dışı · ${min / (60 * 24)} gün önce"
    }
}

@Composable
private fun StatusDot(online: Boolean) {
    Box(Modifier.size(12.dp).clip(CircleShape).background(if (online) OnlineGreen else Color(0xFF5A5A5A)))
}

/** Arkadaşlar sekmesi: profilin (ad değiştirme), arkadaşların ne dinlediği, istekler ve gelen paylaşımlar. */
@Composable
fun FriendsTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    val friends by Social.friends.collectAsState()
    val incoming by Social.incoming.collectAsState()
    val outgoing by Social.outgoing.collectAsState()
    val inbox by Social.inbox.collectAsState()
    val showListening by Social.showListening.collectAsState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var removeTarget by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf(false) }

    // Sekme görünürken listeyi canlı tut
    LaunchedEffect(me) {
        if (me != null) {
            Social.start()
            while (true) { Social.refresh(); delay(15_000) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Text("Arkadaşlar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp))

        if (!Social.enabled) {
            Text("Sosyal özellikler henüz ayarlanmadı. Sunucuyu yayınlayıp Social.kt dosyasındaki SOCIAL_API_URL değerine adresini yaz (backend/README.md).",
                color = SMuted, modifier = Modifier.padding(20.dp))
            return@Column
        }

        if (me == null) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Arkadaş eklemek için bir kullanıcı adı seç. Arkadaşların seni bu adla bulur.", color = SMuted)
                OutlinedTextField(input, { input = it.take(20); error = null }, label = { Text("Kullanıcı adı") }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(), isError = error != null,
                    supportingText = { Text(error ?: "3-20 karakter: harf, rakam, _ ve .") })
                Button(
                    { scope.launch { busy = true; error = Social.join(input); busy = false } },
                    Modifier.fillMaxWidth(), enabled = !busy && input.length >= 3, shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                ) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp) else Text("Devam") }
            }
            return@Column
        }

        LazyColumn(Modifier.fillMaxSize()) {
            // ---- Profil ----
            item {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(20.dp)).background(Card).padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(Accent.copy(alpha = 0.35f)), contentAlignment = Alignment.Center) {
                            Text((me ?: "?").take(1).uppercase(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("@$me", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Arkadaşların seni bu adla görür", color = SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton({ renaming = true }) { Icon(Icons.Filled.Edit, "Adı değiştir") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Ne dinlediğimi göster", fontWeight = FontWeight.Medium)
                            Text("Açıkken çevrim içi arkadaşların şu an çalan şarkını görür", color = SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(showListening, { Social.setShowListening(it) })
                    }
                }
            }

            // ---- Arkadaş ekle ----
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(input, { input = it.take(20); error = null }, label = { Text("Arkadaş ekle (kullanıcı adı)") }, singleLine = true,
                        shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f), isError = error != null,
                        supportingText = error?.let { { Text(it) } })
                    Button(
                        {
                            scope.launch {
                                busy = true
                                val e = Social.sendRequest(input)
                                busy = false
                                error = e
                                if (e == null) { Toast.makeText(ctx, "İstek gönderildi", Toast.LENGTH_SHORT).show(); input = "" }
                            }
                        },
                        Modifier.padding(top = 6.dp), enabled = !busy && input.length >= 3, shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) { Icon(Icons.Filled.PersonAdd, "Ekle") }
                }
            }

            if (inbox.isNotEmpty()) {
                item { SectionTitle("Sana gönderilen listeler") }
                items(inbox, key = { "in" + it.id }) { l ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(l.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("@${l.from} · ${l.songs.size} şarkı", color = SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton({
                            Playlists.create("${l.name} (@${l.from})", l.songs)
                            scope.launch { Social.dismiss(l.id) }
                            Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                        }) { Text("Kaydet") }
                        IconButton({ scope.launch { Social.dismiss(l.id) } }) { Icon(Icons.Filled.Close, "Yoksay", tint = SMuted) }
                    }
                }
            }

            if (incoming.isNotEmpty()) {
                item { SectionTitle("Arkadaşlık istekleri") }
                items(incoming, key = { "rq" + it }) { n ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("@$n", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        TextButton({ scope.launch { Social.respond(n, true) } }) { Text("Kabul et") }
                        TextButton({ scope.launch { Social.respond(n, false) } }) { Text("Reddet", color = SMuted) }
                    }
                }
            }

            // ---- Arkadaşlar + ne dinledikleri ----
            item { SectionTitle("Arkadaşların (${friends.count { it.online }} çevrim içi)") }
            if (friends.isEmpty()) item {
                Text("Henüz arkadaşın yok. Yukarıdan kullanıcı adıyla arkadaş ekle.", color = SMuted, modifier = Modifier.padding(16.dp))
            }
            items(friends, key = { "fr" + it.username }) { f ->
                var menu by remember { mutableStateOf(false) }
                val l = f.listening
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(f.online)
                    Spacer(Modifier.width(12.dp))
                    if (l?.thumb != null) {
                        AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(10.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("@${f.username}", fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (l != null) {
                            Text("♪ ${l.title}" + if (l.artist.isNotBlank()) " · ${l.artist}" else "", color = Accent,
                                style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        } else {
                            Text(lastSeenText(f), color = if (f.online) OnlineGreen else SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (l != null && l.url.isNotBlank()) {
                        IconButton({ PlayerManager.playQueue(listOf(l), 0) }) { Icon(Icons.Filled.PlayArrow, "Sen de dinle", tint = Accent) }
                    }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü", tint = SMuted) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text("Arkadaşlıktan çıkar") }, leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                                onClick = { menu = false; removeTarget = f.username })
                        }
                    }
                }
            }

            if (outgoing.isNotEmpty()) {
                item { SectionTitle("Bekleyen istekler") }
                items(outgoing, key = { "out" + it }) { n ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("@$n", Modifier.weight(1f), color = SMuted)
                        TextButton({ scope.launch { Social.remove(n) } }) { Text("İptal", color = SMuted) }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    removeTarget?.let { n ->
        AlertDialog(
            onDismissRequest = { removeTarget = null }, containerColor = Card, title = { Text("@$n") },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ scope.launch { Social.remove(n) }; removeTarget = null }) { Text("Çıkar") } },
            dismissButton = { TextButton({ removeTarget = null }) { Text("Vazgeç") } }
        )
    }

    if (renaming) {
        var text by remember { mutableStateOf(me ?: "") }
        var err by remember { mutableStateOf<String?>(null) }
        var saving by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!saving) renaming = false }, containerColor = Card, title = { Text("Kullanıcı adını değiştir") },
            text = {
                OutlinedTextField(text, { text = it.take(20); err = null }, singleLine = true, shape = RoundedCornerShape(14.dp), isError = err != null,
                    supportingText = { Text(err ?: "3-20 karakter: harf, rakam, _ ve .") })
            },
            confirmButton = {
                TextButton({
                    scope.launch {
                        saving = true
                        val e = Social.rename(text)
                        saving = false
                        err = e
                        if (e == null) { renaming = false; Toast.makeText(ctx, "Kullanıcı adın değişti", Toast.LENGTH_SHORT).show() }
                    }
                }, enabled = !saving && text.length >= 3 && text != me) { Text("Kaydet") }
            },
            dismissButton = { TextButton({ renaming = false }, enabled = !saving) { Text("Vazgeç") } }
        )
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SMuted,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp))
}

/** Bir listeyi seçilen arkadaşlara gönderir. */
@Composable
fun ShareListDialog(pl: UserPlaylist, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { Social.refresh() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card, title = { Text("\"${pl.name}\" paylaş") },
        text = {
            when {
                !Social.enabled || !Social.joined -> Text("Paylaşmak için önce Arkadaşlar sekmesinden kullanıcı adı al.")
                friends.isEmpty() -> Text("Henüz arkadaşın yok.")
                else -> LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(friends, key = { it.username }) { f ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if (f.username in selected) selected.remove(f.username) else selected.add(f.username)
                        }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.username in selected, { if (it) selected.add(f.username) else selected.remove(f.username) })
                            StatusDot(f.online)
                            Spacer(Modifier.width(10.dp))
                            Text("@${f.username}")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    busy = true
                    val e = Social.share(selected.toList(), pl.name, pl.songs)
                    busy = false
                    Toast.makeText(ctx, e ?: "Gönderildi", Toast.LENGTH_SHORT).show()
                    if (e == null) onDismiss()
                }
            }, enabled = selected.isNotEmpty() && !busy) { Text("Gönder") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}
