package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/*
 * SOSYAL ÖZELLİKLER (arkadaşlar, çevrim içi/dışı, liste paylaşımı, profil resmi)
 * backend/ klasöründeki sunucuyu yayınlayıp adresini aşağıya yaz. Boşsa sosyal özellikler gizlenir.
 */
const val SOCIAL_API_URL = "https://new-music-cpzw.onrender.com"

data class SocialFriend(
    val username: String, val online: Boolean, val lastSeen: Long,
    val listening: Song? = null, val avatarV: Long = 0L
)
data class SocialPerson(val username: String, val avatarV: Long = 0L)
data class SharedList(val id: String, val from: String, val name: String, val songs: List<Song>)

object Social {
    val username = MutableStateFlow<String?>(null)
    val friends = MutableStateFlow<List<SocialFriend>>(emptyList())
    val incoming = MutableStateFlow<List<SocialPerson>>(emptyList())
    val outgoing = MutableStateFlow<List<SocialPerson>>(emptyList())
    val inbox = MutableStateFlow<List<SharedList>>(emptyList())
    /** Benim profil resmimin sürümü (0 = resim yok). */
    val myAvatarV = MutableStateFlow(0L)
    /** Açıkken çevrim içi arkadaşların şu an çalan şarkını görür. */
    val showListening = MutableStateFlow(true)
    /** Uygulama ekranda mı? (Arka planda müzik çalarken de çevrim içi kalırız.) */
    val foreground = MutableStateFlow(false)

    val enabled: Boolean get() = SOCIAL_API_URL.isNotBlank()

    private var prefs: SharedPreferences? = null
    private var token: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var idleJob: Job? = null
    private val presenceLock = Mutex()   // "çevrim içi" ve "çevrim dışı" sinyalleri birbirini ezmesin
    private const val JSON = "application/json; charset=utf-8"
    private const val HEARTBEAT_MS = 25_000L
    private const val IDLE_GRACE_MS = 45_000L   // arka planda müzik durunca bu süre sonra çevrim dışı

    // Render ücretsiz sunucusu uykudan geç uyanabilir: normal istemciden daha sabırlı bir istemci kullan
    private val client: OkHttpClient by lazy {
        Http.client.newBuilder().readTimeout(40, TimeUnit.SECONDS).callTimeout(50, TimeUnit.SECONDS).build()
    }

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        token = p.getString("social_token", null)
        username.value = p.getString("social_name", null)
        myAvatarV.value = p.getLong("social_avatar_v", 0L)
        showListening.value = p.getBoolean("social_show_listening", true)
    }

    fun setShowListening(on: Boolean) {
        showListening.value = on
        prefs?.edit()?.putBoolean("social_show_listening", on)?.apply()
    }

    val joined: Boolean get() = token != null
    internal val authToken: String? get() = token
    internal fun avatarUrl(name: String, version: Long) = SOCIAL_API_URL.trimEnd('/') + "/social/avatar/" + name + "?v=" + version

    /** Müzik çalıyor veya yükleniyor mu? Şarkı geçişlerinde kısa duraklamalar çevrim dışı yapmaz. */
    private fun isListening() = PlayerManager.playing.value || PlayerManager.loading.value

    /** "Çevrim içiyim" sinyali; müzik çalıyorsa şarkıyı da içerir. Gizlilik kapalıysa şarkı gönderilmez. */
    private suspend fun sendHeartbeat() {
        val json = JSONObject()
        if (showListening.value && isListening()) {
            val s = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
            if (s != null) json.put("playing", JSONObject()
                .put("title", s.title).put("artist", s.artist).put("url", s.url).put("thumb", s.thumb ?: JSONObject.NULL))
        }
        presenceLock.withLock { call("/social/heartbeat", json) }
    }

    /**
     * Uygulama öne gelince çağrılır. Sinyal döngüsü, uygulama arka plandayken de müzik çaldığı sürece sürer;
     * böylece arkadaşların seni çevrim içi görür ve ne dinlediğini bilir.
     */
    fun start() {
        foreground.value = true
        idleJob?.cancel(); idleJob = null
        ensureLoop()
    }

    private fun ensureLoop() {
        if (!enabled || token == null || loop?.isActive == true) return
        loop = scope.launch {
            launch {
                while (isActive && token != null) {
                    sendHeartbeat()
                    if (foreground.value) refresh()
                    delay(HEARTBEAT_MS)
                }
            }
            launch {
                // Şarkı değişince/durunca/başlayınca hemen güncelle
                combine(PlayerManager.queue, PlayerManager.index, PlayerManager.playing, PlayerManager.loading, showListening) { _, _, _, _, _ -> Unit }
                    .collectLatest {
                        delay(800)
                        sendHeartbeat()
                        if (!foreground.value && !isListening()) scheduleOffline()
                    }
            }
        }
    }

    /** Uygulama arka plana gidince: müzik çalıyorsa çevrim içi kalır, çalmıyorsa kısa süre sonra çevrim dışı olur. */
    fun stop() {
        foreground.value = false
        if (!enabled || token == null) return
        if (!isListening()) scheduleOffline()
    }

    private fun scheduleOffline() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(IDLE_GRACE_MS)
            presenceLock.withLock {
                if (foreground.value || isListening() || token == null) return@withLock
                loop?.cancel(); loop = null
                call("/social/offline", JSONObject())
            }
        }
    }

    private class Result(val code: Int, val body: JSONObject)

    private suspend fun call(path: String, json: JSONObject): Result? = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(SOCIAL_API_URL.trimEnd('/') + path)
                .post(json.toString().toRequestBody(JSON.toMediaType()))
            token?.let { b.header("Authorization", "Bearer $it") }
            client.newCall(b.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                Result(r.code, try { JSONObject(text) } catch (e: Exception) { JSONObject() })
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    private fun errorOf(r: Result?, fallback: String): String? = when {
        r == null -> "Bağlantı kurulamadı. İnternetini kontrol et."
        r.code in 200..299 -> null
        r.code == 401 -> { // anahtar sunucuda yok (sunucu sıfırlanmış olabilir)
            token = null; username.value = null; myAvatarV.value = 0L
            prefs?.edit()?.remove("social_token")?.remove("social_name")?.remove("social_avatar_v")?.apply()
            "Sosyal hesabın sunucuda bulunamadı. Yeniden kullanıcı adı al."
        }
        else -> r.body.optString("error").ifBlank { fallback }
    }

    /** Kullanıcı adı alır. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun join(name: String): String? {
        val r = call("/social/join", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Hesap oluşturulamadı.")
        if (err != null) return err
        token = r!!.body.optString("token")
        username.value = r.body.optString("username")
        prefs?.edit()?.putString("social_token", token)?.putString("social_name", username.value)?.apply()
        start()
        return null
    }

    /** Kullanıcı adını değiştirir. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun rename(name: String): String? {
        val r = call("/social/rename", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        username.value = r!!.body.optString("username")
        prefs?.edit()?.putString("social_name", username.value)?.apply()
        refresh()
        return null
    }

    private fun setMyAvatar(v: Long) {
        myAvatarV.value = v
        prefs?.edit()?.putLong("social_avatar_v", v)?.apply()
    }

    /** Seçilen resmi kare kırpıp küçültür (256 px JPEG) ve profil resmi olarak yükler. */
    suspend fun setAvatar(ctx: Context, uri: Uri): String? {
        val bytes = withContext(Dispatchers.Default) { try { encodeAvatar(ctx, uri) } catch (e: Exception) { null } }
            ?: return "Resim okunamadı."
        val r = call("/social/avatar", JSONObject().put("image", Base64.encodeToString(bytes, Base64.NO_WRAP)))
        val err = errorOf(r, "Resim yüklenemedi.")
        if (err == null) setMyAvatar(r!!.body.optLong("avatarV"))
        return err
    }

    suspend fun removeAvatar(): String? {
        val r = call("/social/avatar", JSONObject().put("image", JSONObject.NULL))
        val err = errorOf(r, "Resim kaldırılamadı.")
        if (err == null) setMyAvatar(0L)
        return err
    }

    private fun encodeAvatar(ctx: Context, uri: Uri): ByteArray? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        val raw = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val rotation = try {
            cr.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        val upright = if (rotation == 0f) raw
        else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(rotation) }, true)
        val side = minOf(upright.width, upright.height)
        val square = Bitmap.createBitmap(upright, (upright.width - side) / 2, (upright.height - side) / 2, side, side)
        val small = Bitmap.createScaledBitmap(square, 256, 256, true)
        var q = 88
        while (true) {
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, q, out)
            if (out.size() <= 55 * 1024 || q <= 40) return out.toByteArray()
            q -= 8
        }
    }

    suspend fun refresh() {
        if (token == null) return
        val r = call("/social/friends", JSONObject())
        if (r != null && r.code in 200..299) {
            val b = r.body
            friends.value = b.optJSONArray("friends").toList { o ->
                val l = o.optJSONObject("listening")
                SocialFriend(
                    o.getString("username"), o.optBoolean("online"), o.optLong("lastSeen"),
                    l?.let { Song(it.optString("title"), it.optString("artist"), it.optString("url"),
                        if (it.isNull("thumb")) null else it.optString("thumb").ifBlank { null }) },
                    o.optLong("avatarV")
                )
            }.sortedWith(compareByDescending<SocialFriend> { it.listening != null }
                .thenByDescending { it.online }.thenBy { it.username.lowercase() })
            incoming.value = b.optJSONArray("incoming").toList { SocialPerson(it.getString("username"), it.optLong("avatarV")) }
            outgoing.value = b.optJSONArray("outgoing").toList { SocialPerson(it.getString("username"), it.optLong("avatarV")) }
            b.optJSONObject("me")?.let { if (it.optLong("avatarV") != myAvatarV.value) setMyAvatar(it.optLong("avatarV")) }
        } else errorOf(r, "")
        val ib = call("/social/inbox", JSONObject())
        if (ib != null && ib.code in 200..299) {
            inbox.value = ib.body.optJSONArray("items").toList { o ->
                val sa = o.optJSONArray("songs") ?: JSONArray()
                SharedList(
                    o.getString("id"), o.optString("from"), o.optString("name"),
                    (0 until sa.length()).map { j ->
                        val s = sa.getJSONObject(j)
                        Song(s.optString("title"), s.optString("artist"), s.optString("url"),
                            if (s.isNull("thumb")) null else s.optString("thumb").ifBlank { null })
                    }
                )
            }
        }
    }

    suspend fun sendRequest(name: String): String? =
        errorOf(call("/social/friend-request", JSONObject().put("username", name.trim())), "İstek gönderilemedi.").also { refresh() }

    suspend fun respond(name: String, accept: Boolean): String? =
        errorOf(call("/social/friend-respond", JSONObject().put("username", name).put("accept", accept)), "İşlem yapılamadı.").also { refresh() }

    suspend fun remove(name: String): String? =
        errorOf(call("/social/friend-remove", JSONObject().put("username", name)), "Silinemedi.").also { refresh() }

    /** Listeyi seçilen arkadaşlara gönderir. Cihazdan yüklenen şarkılar atlanır. */
    suspend fun share(to: List<String>, name: String, songs: List<Song>): String? {
        val arr = JSONArray()
        songs.filterNot { Uploads.isLocal(it) }.forEach {
            arr.put(JSONObject().put("title", it.title).put("artist", it.artist).put("url", it.url).put("thumb", it.thumb ?: JSONObject.NULL))
        }
        if (arr.length() == 0) return "Paylaşılacak şarkı yok. Cihazdan yüklenen şarkılar paylaşılamaz."
        val r = call("/social/share", JSONObject().put("to", JSONArray(to)).put("name", name).put("songs", arr))
        return errorOf(r, "Paylaşılamadı.")
    }

    suspend fun dismiss(id: String) {
        call("/social/inbox-dismiss", JSONObject().put("id", id))
        refresh()
    }

    private fun <T> JSONArray?.toList(f: (JSONObject) -> T): List<T> =
        if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }
}

private val SMuted = Color(0xFF9A9A9A)
private val OnlineGreen = Color(0xFF3DDC84)

private fun lastSeenText(f: SocialFriend): String {
    if (f.online) return "Çevrim içi"
    if (f.lastSeen <= 0) return "Çevrim dışı"
    val min = ((System.currentTimeMillis() - f.lastSeen) / 60_000).coerceAtLeast(1)
    return when {
        min < 60 -> "Çevrim dışı · $min dk önce"
        min < 60 * 24 -> "Çevrim dışı · ${min / 60} sa önce"
        else -> "Çevrim dışı · ${min / (60 * 24)} gün önce"
    }
}

/** Yuvarlak profil resmi; resim yoksa (veya yüklenemezse) adın baş harfi görünür. */
@Composable
fun Avatar(name: String, version: Long, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Box(modifier.size(size).clip(CircleShape).background(tintFor(name)), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = Color.White, fontSize = (size.value * 0.42f).sp)
        if (version > 0L && Social.authToken != null) {
            val key = "av:$name:$version"
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(Social.avatarUrl(name, version))
                    .addHeader("Authorization", "Bearer ${Social.authToken}")
                    .memoryCacheKey(key).diskCacheKey(key).crossfade(true).build(),
                contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/** Profil resmi + sağ altta çevrim içi/dışı noktası. */
@Composable
fun AvatarWithDot(name: String, version: Long, size: Dp, online: Boolean?) {
    Box(Modifier.size(size)) {
        Avatar(name, version, size)
        if (online != null) {
            Box(
                Modifier.align(Alignment.BottomEnd).size((size.value * 0.30f).coerceAtLeast(11f).dp)
                    .clip(CircleShape).background(if (online) OnlineGreen else Color(0xFF5A5A5A))
                    .border(2.dp, Card, CircleShape)
            )
        }
    }
}

@Composable
private fun Surface2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
        .clip(RoundedCornerShape(18.dp)).background(Card), content = content)
}

/** Arkadaşlar sekmesi: profilin (resim, ad), arkadaşların ne dinlediği, istekler ve gelen paylaşımlar. */
@Composable
fun FriendsTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    val myAvatarV by Social.myAvatarV.collectAsState()
    val friends by Social.friends.collectAsState()
    val incoming by Social.incoming.collectAsState()
    val outgoing by Social.outgoing.collectAsState()
    val inbox by Social.inbox.collectAsState()
    val showListening by Social.showListening.collectAsState()
    val foreground by Social.foreground.collectAsState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var removeTarget by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            uploading = true
            val e = Social.setAvatar(ctx, uri)
            uploading = false
            Toast.makeText(ctx, e ?: "Profil resmin güncellendi", Toast.LENGTH_SHORT).show()
        }
    }

    // Sekme görünürken ve uygulama ekrandayken listeyi canlı tut (arka planda boşuna istek atma)
    LaunchedEffect(me, foreground) {
        if (me != null && foreground) {
            while (true) { Social.refresh(); delay(15_000) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Arkadaşlar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            val onlineCount = friends.count { it.online }
            if (me != null && friends.isNotEmpty()) {
                Row(Modifier.clip(RoundedCornerShape(50)).background(Card).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (onlineCount > 0) OnlineGreen else Color(0xFF5A5A5A)))
                    Spacer(Modifier.width(6.dp))
                    Text("$onlineCount çevrim içi", style = MaterialTheme.typography.labelMedium, color = SMuted)
                }
            }
        }

        if (!Social.enabled) {
            Text("Sosyal özellikler henüz ayarlanmadı. Sunucuyu yayınlayıp Social.kt dosyasındaki SOCIAL_API_URL değerine adresini yaz (backend/README.md).",
                color = SMuted, modifier = Modifier.padding(20.dp))
            return@Column
        }

        if (me == null) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.People, null, tint = Accent, modifier = Modifier.size(42.dp))
                }
                Text("Arkadaşlarınla müzik dinle", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Bir kullanıcı adı seç. Arkadaşların seni bu adla bulur, ne dinlediğini görür.", color = SMuted)
                OutlinedTextField(input, { input = it.take(20); error = null }, label = { Text("Kullanıcı adı") }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(), isError = error != null,
                    supportingText = { Text(error ?: "3-20 karakter: harf, rakam, _ ve .") })
                Button(
                    { scope.launch { busy = true; error = Social.join(input); busy = false } },
                    Modifier.fillMaxWidth(), enabled = !busy && input.length >= 3, shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                ) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp) else Text("Devam") }
            }
            return@Column
        }

        val listeningNow = friends.filter { it.listening != null }
        val others = friends.filter { it.listening == null }

        LazyColumn(Modifier.fillMaxSize()) {
            // ---- Profil ----
            item {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.38f), Card)))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(84.dp).clickable(enabled = !uploading) { picker.launch("image/*") }) {
                            Avatar(me ?: "?", myAvatarV, 84.dp)
                            if (uploading) {
                                Box(Modifier.matchParentSize().clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(Modifier.size(26.dp), color = Color.White, strokeWidth = 2.5.dp)
                                }
                            }
                            Box(
                                Modifier.align(Alignment.BottomEnd).size(28.dp).clip(CircleShape).background(Accent).border(2.dp, Card, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Filled.CameraAlt, "Profil resmi ekle", tint = Color.White, modifier = Modifier.size(15.dp)) }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("@$me", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(8.dp).clip(CircleShape).background(OnlineGreen))
                                Spacer(Modifier.width(6.dp))
                                Text("Çevrim içi", color = OnlineGreen, style = MaterialTheme.typography.bodySmall)
                            }
                            Text(if (myAvatarV > 0) "Resmi değiştirmek için dokun" else "Profil resmi eklemek için dokun",
                                color = SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            IconButton({ renaming = true }) { Icon(Icons.Filled.Edit, "Adı değiştir") }
                            if (myAvatarV > 0) IconButton({
                                scope.launch {
                                    val e = Social.removeAvatar()
                                    Toast.makeText(ctx, e ?: "Profil resmi kaldırıldı", Toast.LENGTH_SHORT).show()
                                }
                            }) { Icon(Icons.Filled.Delete, "Resmi kaldır", tint = SMuted) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = 0.22f)).padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Ne dinlediğimi göster", fontWeight = FontWeight.Medium)
                            Text("Açıkken çevrim içi arkadaşların şu an çalan şarkını görür", color = SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(showListening, { Social.setShowListening(it) })
                    }
                }
            }

            // ---- Arkadaş ekle ----
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(input, { input = it.take(20); error = null }, placeholder = { Text("Kullanıcı adıyla arkadaş ekle") }, singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Search, null, tint = SMuted) },
                        shape = RoundedCornerShape(28.dp), modifier = Modifier.weight(1f), isError = error != null,
                        supportingText = error?.let { { Text(it) } })
                    Button(
                        {
                            scope.launch {
                                busy = true
                                val e = Social.sendRequest(input)
                                busy = false
                                error = e
                                if (e == null) { Toast.makeText(ctx, "İstek gönderildi", Toast.LENGTH_SHORT).show(); input = "" }
                            }
                        },
                        Modifier.height(56.dp), enabled = !busy && input.length >= 3, shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Filled.PersonAdd, "Ekle")
                    }
                }
            }

            if (incoming.isNotEmpty()) {
                item { SectionTitle("Arkadaşlık istekleri (${incoming.size})") }
                items(incoming, key = { "rq" + it.username }) { p ->
                    Surface2 {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.username, p.avatarV, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("@${p.username}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("Arkadaş olmak istiyor", color = SMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            Button({ scope.launch { Social.respond(p.username, true) } }, shape = RoundedCornerShape(50),
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)) { Text("Kabul") }
                            IconButton({ scope.launch { Social.respond(p.username, false) } }) { Icon(Icons.Filled.Close, "Reddet", tint = SMuted) }
                        }
                    }
                }
            }

            if (inbox.isNotEmpty()) {
                item { SectionTitle("Sana gönderilen listeler") }
                items(inbox, key = { "in" + it.id }) { l ->
                    Surface2 {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.QueueMusic, null, tint = Accent)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(l.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("@${l.from} · ${l.songs.size} şarkı", color = SMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton({
                                Playlists.create("${l.name} (@${l.from})", l.songs)
                                scope.launch { Social.dismiss(l.id) }
                                Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                            }) { Text("Kaydet") }
                            IconButton({ scope.launch { Social.dismiss(l.id) } }) { Icon(Icons.Filled.Close, "Yoksay", tint = SMuted) }
                        }
                    }
                }
            }

            // ---- Şu an dinleyenler ----
            if (listeningNow.isNotEmpty()) {
                item { SectionTitle("Şu an dinliyor (${listeningNow.size})") }
                items(listeningNow, key = { "ls" + it.username }) { f ->
                    val l = f.listening!!
                    Surface2 {
                        Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AvatarWithDot(f.username, f.avatarV, 48.dp, true)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("@${f.username}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (l.thumb != null) {
                                        AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop,
                                            modifier = Modifier.padding(top = 4.dp, end = 8.dp).size(30.dp).clip(RoundedCornerShape(6.dp)))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(l.title, color = Accent, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        if (l.artist.isNotBlank()) Text(l.artist, color = SMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                            if (l.url.isNotBlank()) {
                                IconButton({ PlayerManager.playQueue(listOf(l), 0) }) { Icon(Icons.Filled.PlayCircle, "Sen de dinle", tint = Accent, modifier = Modifier.size(34.dp)) }
                            }
                            FriendMenu(f.username) { removeTarget = it }
                        }
                    }
                }
            }

            // ---- Diğer arkadaşlar ----
            item { SectionTitle(if (listeningNow.isEmpty()) "Arkadaşların (${friends.size})" else "Diğer arkadaşların (${others.size})") }
            if (friends.isEmpty()) item {
                Surface2 {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.People, null, tint = SMuted, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Henüz arkadaşın yok", fontWeight = FontWeight.Bold)
                        Text("Yukarıdan kullanıcı adıyla arkadaş ekle; kabul edince ne dinlediğini görürsün.", color = SMuted,
                            style = MaterialTheme.typography.bodySmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
            items(others, key = { "fr" + it.username }) { f ->
                Surface2 {
                    Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AvatarWithDot(f.username, f.avatarV, 44.dp, f.online)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("@${f.username}", fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(lastSeenText(f), color = if (f.online) OnlineGreen else SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                        FriendMenu(f.username) { removeTarget = it }
                    }
                }
            }

            if (outgoing.isNotEmpty()) {
                item { SectionTitle("Bekleyen istekler") }
                items(outgoing, key = { "out" + it.username }) { p ->
                    Surface2 {
                        Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.username, p.avatarV, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Text("@${p.username}", Modifier.weight(1f), color = SMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            TextButton({ scope.launch { Social.remove(p.username) } }) { Text("İptal", color = SMuted) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    removeTarget?.let { n ->
        AlertDialog(
            onDismissRequest = { removeTarget = null }, containerColor = Card, title = { Text("@$n") },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ scope.launch { Social.remove(n) }; removeTarget = null }) { Text("Çıkar") } },
            dismissButton = { TextButton({ removeTarget = null }) { Text("Vazgeç") } }
        )
    }

    if (renaming) {
        var text by remember { mutableStateOf(me ?: "") }
        var err by remember { mutableStateOf<String?>(null) }
        var saving by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!saving) renaming = false }, containerColor = Card, title = { Text("Kullanıcı adını değiştir") },
            text = {
                OutlinedTextField(text, { text = it.take(20); err = null }, singleLine = true, shape = RoundedCornerShape(14.dp), isError = err != null,
                    supportingText = { Text(err ?: "3-20 karakter: harf, rakam, _ ve .") })
            },
            confirmButton = {
                TextButton({
                    scope.launch {
                        saving = true
                        val e = Social.rename(text)
                        saving = false
                        err = e
                        if (e == null) { renaming = false; Toast.makeText(ctx, "Kullanıcı adın değişti", Toast.LENGTH_SHORT).show() }
                    }
                }, enabled = !saving && text.length >= 3 && text != me) { Text("Kaydet") }
            },
            dismissButton = { TextButton({ renaming = false }, enabled = !saving) { Text("Vazgeç") } }
        )
    }
}

@Composable
private fun FriendMenu(username: String, onRemove: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü", tint = SMuted) }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text("Arkadaşlıktan çıkar") }, leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                onClick = { menu = false; onRemove(username) })
        }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SMuted,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp))
}

/** Bir listeyi seçilen arkadaşlara gönderir. */
@Composable
fun ShareListDialog(pl: UserPlaylist, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { Social.refresh() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card, title = { Text("\"${pl.name}\" paylaş") },
        text = {
            when {
                !Social.enabled || !Social.joined -> Text("Paylaşmak için önce Arkadaşlar sekmesinden kullanıcı adı al.")
                friends.isEmpty() -> Text("Henüz arkadaşın yok.")
                else -> LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(friends, key = { it.username }) { f ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if (f.username in selected) selected.remove(f.username) else selected.add(f.username)
                        }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.username in selected, { if (it) selected.add(f.username) else selected.remove(f.username) })
                            AvatarWithDot(f.username, f.avatarV, 36.dp, f.online)
                            Spacer(Modifier.width(10.dp))
                            Text("@${f.username}")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    busy = true
                    val e = Social.share(selected.toList(), pl.name, pl.songs)
                    busy = false
                    Toast.makeText(ctx, e ?: "Gönderildi", Toast.LENGTH_SHORT).show()
                    if (e == null) onDismiss()
                }
            }, enabled = selected.isNotEmpty() && !busy) { Text("Gönder") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}
