package com.example.newmusic

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/*
 * SOSYAL ÖZELLİKLER (arkadaşlar, çevrim içi/dışı, ne dinlediği, profil fotoğrafı, liste paylaşımı)
 * Sunucu: backend/ klasörü (Render). Adres boşsa sosyal özellikler gizlenir.
 */
const val SOCIAL_API_URL = "https://new-music-cpzw.onrender.com"

data class StatusItem(val text: String, val song: Song? = null, val createdAt: Long = System.currentTimeMillis())
data class SocialPerson(val username: String, val avatar: String?, val name: String = username)
data class SocialFriend(
    val username: String,
    val online: Boolean,
    val lastSeen: Long,
    val avatar: String? = null,
    val listening: Song? = null,
    val name: String = username,
    val profileSong: Song? = null,
    val status: StatusItem? = null,
    /** Arkadaşın çalma konumu (ms, -1 = bilinmiyor) ve bu bilginin kaç ms önce alındığı (birlikte dinleme senkronu için). */
    val listenPos: Long = -1L,
    val listenAgo: Long = 0L
)
data class SharedList(val id: String, val from: String, val name: String, val songs: List<Song>)
/** Herkese açık bir çalma listesi (keşfette özet, açılınca şarkılarla). */
data class PubList(
    val owner: String, val ownerName: String, val avatar: String?, val id: String, val name: String,
    val songs: List<Song>, val count: Int, val cover: String?, val likes: Int, val liked: Boolean
)

object Social {
    /** Benzersiz arkadaş kimliği (e-postadan otomatik üretilir, değişmez). */
    val username = MutableStateFlow<String?>(null)
    /** Görünen ad: istenildiği gibi yazılır, benzersiz olmak zorunda değil. */
    val displayName = MutableStateFlow<String?>(null)
    val myAvatar = MutableStateFlow<String?>(null)
    val friends = MutableStateFlow<List<SocialFriend>>(emptyList())
    val incoming = MutableStateFlow<List<SocialPerson>>(emptyList())
    val outgoing = MutableStateFlow<List<SocialPerson>>(emptyList())
    val inbox = MutableStateFlow<List<SharedList>>(emptyList())
    /** Açıkken çevrim içi arkadaşların şu an çalan şarkını görür. */
    val showListening = MutableStateFlow(true)
    val myProfileSong = MutableStateFlow<Song?>(null)
    val myStatus = MutableStateFlow<StatusItem?>(null)
    val syncFriend = MutableStateFlow<String?>(null)

    fun startSync(name: String) { syncFriend.value = name }
    fun stopSync() { syncFriend.value = null }

    val enabled: Boolean get() = SOCIAL_API_URL.isNotBlank()
    val joined: Boolean get() = token != null

    private var prefs: SharedPreferences? = null
    private var token: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var watcher: Job? = null
    private const val JSON = "application/json; charset=utf-8"

    // Uygulama görünürken 5 sn, arka planda müzik çalarken 15 sn'de bir sinyal gönderilir.
    private const val FG_TICK = 5_000L
    private const val BG_TICK = 15_000L
    // Arka plana geçip müzik de çalmıyorsa bu süre sonra çevrim dışı olunur (haritaya kısa bakmak vb. için tolerans).
    private const val GRACE_MS = 60_000L
    @Volatile private var joining = false
    @Volatile private var foreground = false
    @Volatile private var lastActiveAt = 0L

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        token = p.getString("social_token", null)
        username.value = p.getString("social_name", null)
        showListening.value = p.getBoolean("social_show_listening", true)
        // Render ücretsiz sunucusu uykudaysa 30-60 sn'de uyanır; uygulama açılır açılmaz uyandır
        if (enabled) scope.launch {
            try { Http.server.newCall(Request.Builder().url(SOCIAL_API_URL).get().build()).execute().close() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { }
        }
    }

    /** Hesaba giriş yapılınca sunucudaki kullanıcı adı ve anahtar bu cihaza gelir (yeniden kurulumdan sonra arkadaşlar kaybolmaz). */
    fun restore(name: String, tok: String) {
        token = tok
        username.value = name
        prefs?.edit()?.putString("social_token", tok)?.putString("social_name", name)?.apply()
        start()
        scope.launch { refresh() }
        LibrarySync.syncSoon(force = true)   // beğeniler ve listeler hesaptan geri gelir
    }

    /** Hesaptan çıkınca bu cihazdaki sosyal oturum kapanır; sunucudaki hesap ve arkadaşlar silinmez. */
    fun signOutLocal() {
        loop?.cancel(); loop = null
        watcher?.cancel(); watcher = null
        token = null
        username.value = null; displayName.value = null; myAvatar.value = null
        friends.value = emptyList(); incoming.value = emptyList(); outgoing.value = emptyList(); inbox.value = emptyList()
        myProfileSong.value = null; myStatus.value = null; syncFriend.value = null
        prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
    }

    suspend fun deleteAccount(): String? {
        val r = call("/social/delete-account", JSONObject())
        val err = errorOf(r, "Hesap silinemedi.")
        if (err != null && r?.code != 404) return err
        signOutLocal()
        return null
    }

    fun setShowListening(on: Boolean) {
        showListening.value = on
        prefs?.edit()?.putBoolean("social_show_listening", on)?.apply()
    }

    private fun parseSongsArr(sa: JSONArray?): List<Song> =
        (if (sa == null) emptyList() else (0 until sa.length()).mapNotNull { j -> try { sa.getJSONObject(j).toSong() } catch (e: Exception) { null } }).noAi().noLong().noNonMusic()

    /** Bir kullanıcının HERKESE AÇIK çalma listeleri. Hata varsa (mesaj, null), başarılıysa (null, liste) döner. */
    suspend fun userLists(username: String, ownerName: String = username, avatar: String? = null): Pair<String?, List<PubList>?> {
        val r = call("/social/user-lists", JSONObject().put("username", username))
        val err = errorOf(r, "Listeler yüklenemedi.")
        if (err != null) {
            // Sunucuda /social/user-lists henüz yoksa veya 404 döndüyse genel herkese açık listelerden filtrele
            val (_, allPub) = publicLists()
            if (allPub != null) {
                val userPubs = allPub.filter { it.owner.equals(username, ignoreCase = true) }
                if (userPubs.isNotEmpty()) return null to userPubs
            }
            if (r?.code == 404) return null to emptyList()
            return err to null
        }
        val arr = r?.body?.optJSONArray("lists")
        val lists = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                val songs = parseSongsArr(o.optJSONArray("songs"))
                val cov = o.optString("cover").ifBlank { null } ?: songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb
                PubList(username, ownerName, avatar, o.optString("id"), o.optString("name").ifBlank { "Liste" },
                    songs, songs.size, cov, o.optInt("likes"), o.optBoolean("liked"))
            } catch (e: Exception) { null }
        }
        return null to lists
    }

    /**
     * Herkese açık tek bir listeyi şarkılarıyla getirir (Keşfet'ten açılırken).
     * Hata varsa (mesaj, null), başarılıysa (null, liste) döner.
     */
    suspend fun publicList(summary: PubList): Pair<String?, PubList?> {
        val r = call("/social/public-list", JSONObject().put("username", summary.owner).put("id", summary.id))
        val err = errorOf(r, "Liste açılamadı.")
        if (err != null) return err to null
        val o = r?.body?.optJSONObject("list") ?: return "Liste artık herkese açık değil." to null
        val songs = parseSongsArr(o.optJSONArray("songs"))
        if (songs.isEmpty()) return "Bu listede çalınabilir şarkı yok." to null
        return null to summary.copy(
            name = o.optString("name").ifBlank { summary.name }, songs = songs, count = songs.size,
            cover = songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb ?: summary.cover,
            likes = o.optInt("likes", summary.likes), liked = o.optBoolean("liked", summary.liked)
        )
    }

    /** Keşfet: herkese açık listeler, en çok beğenilenler önde. Şarkılar liste açılınca yüklenir. */
    suspend fun publicLists(): Pair<String?, List<PubList>?> {
        val r = call("/social/public-lists", JSONObject())
        val err = errorOf(r, "Herkese açık listeler yüklenemedi.")
        if (err != null) return err to null
        val arr = r?.body?.optJSONArray("lists")
        val lists = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                PubList(o.optString("owner"), o.optString("ownerName").ifBlank { o.optString("owner") }, avatarOf(o), o.optString("id"),
                    o.optString("name").ifBlank { "Liste" }, emptyList(), o.optInt("count"),
                    if (o.isNull("cover")) null else o.optString("cover").ifBlank { null }, o.optInt("likes"), o.optBoolean("liked"))
            } catch (e: Exception) { null }
        }
        return null to lists
    }

    /** Herkese açık bir listeyi beğen / vazgeç. Başarılıysa (null, yeni beğeni sayısı). */
    suspend fun likeList(owner: String, id: String, like: Boolean): Pair<String?, Int?> {
        val r = call("/social/list-like", JSONObject().put("username", owner).put("id", id).put("like", like))
        val err = errorOf(r, "Beğenilemedi.")
        return if (err != null) err to null else null to (r?.body?.optInt("likes") ?: 0)
    }

    fun avatarUrl(id: String?): String? {
        if (id.isNullOrBlank() || !enabled) return null
        if (id.startsWith("http://") || id.startsWith("https://")) return id
        if (id.startsWith("content://") || id.startsWith("file://")) return id
        val clean = if (id.startsWith("/social/avatar/")) id else "/social/avatar/$id"
        return SOCIAL_API_URL.trimEnd('/') + clean
    }

    /** Çalma listesi kapağını sunucuya yükleyerek herkesin (arkadaşların, WhatsApp ve web kullanıcılarının) görebileceği genel HTTPS linki üretir */
    suspend fun uploadPlaylistCover(ctx: Context, uri: Uri): Pair<String?, String?> {
        val bytes: ByteArray = withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@withContext null
                val side = minOf(bmp.width, bmp.height)
                val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
                var q = 88
                var out = ByteArray(0)
                do {
                    val bos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, q, bos)
                    out = bos.toByteArray()
                    q -= 5
                } while (out.size > 180_000 && q > 50)
                out
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { null }
        } ?: return "Kapak fotoğrafı okunamadı." to null

        val r = call("/social/cover-set", JSONObject().put("image", Base64.encodeToString(bytes, Base64.NO_WRAP)))
        val err = errorOf(r, "Kapak sunucuya yüklenemedi.")
        if (err != null || r == null) {
            return err to uri.toString()
        }
        val id = r.body.optString("id").ifBlank { r.body.optString("url") }
        val fullUrl = avatarUrl(id)
        return null to fullUrl
    }

    // ---------------------------------------------------------------- çevrim içi sinyali

    /** Uygulama öne gelince çağrılır. */
    fun start() {
        foreground = true
        lastActiveAt = System.currentTimeMillis()
        // Giriş yapılmış ama arkadaş kimliği henüz bu cihaza gelmediyse (eski sürüm, ağ hatası) şimdi alınır;
        // böylece beğeniler ve herkese açık listeler hesaba yüklenebilir.
        if (enabled && token == null && AuthStore.session != null && !joining) {
            joining = true
            scope.launch { try { join("") } finally { joining = false } }
        }
        if (!enabled || token == null) return
        if (watcher?.isActive != true) {
            // Uygulama arka plandayken müzik başlarsa (örn. arabadan) yeniden çevrim içi ol
            watcher = scope.launch { PlayerManager.playing.collect { if (it) ensureLoop() } }
        }
        ensureLoop()
        LibrarySync.syncSoon()
    }

    /** Uygulama arka plana gidince çağrılır. Müzik çalıyorsa çevrim içi kalınır. */
    fun stop() {
        foreground = false
        lastActiveAt = System.currentTimeMillis()
        LibrarySync.flush()
    }

    @Synchronized
    private fun ensureLoop() {
        if (!enabled || token == null || loop?.isActive == true) return
        loop = scope.launch {
            val outer = this
            launch {
                var ticks = 0
                while (isActive && token != null) {
                    val now = System.currentTimeMillis()
                    if (foreground || PlayerManager.playing.value) lastActiveAt = now
                    if (now - lastActiveAt > GRACE_MS) {
                        call("/social/offline", JSONObject())
                        break
                    }
                    sendHeartbeat()
                    if (ticks++ % 12 == 0) pushTaste()   // Blend için zevk bilgisi (yalnızca arkadaşların görür)
                    delay(if (syncFriend.value != null) 1_500L else if (foreground) FG_TICK else BG_TICK)
                }
                outer.cancel()
            }
            launch {
                // Şarkı değişince / durup başlayınca hemen bildir
                combine(PlayerManager.queue, PlayerManager.index, PlayerManager.playing, showListening, PlayerManager.seekTick) { _, _, _, _, _ -> Unit }
                    .collectLatest { delay(300); sendHeartbeat() }
            }
        }
    }

    /** Çalan şarkıyı da içeren sinyal. Sunucu yanıt olarak güncel arkadaş listesini döner. */
    private suspend fun sendHeartbeat() {
        val json = JSONObject()
        if (showListening.value && PlayerManager.playing.value) {
            val s = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
            if (s != null) json.put("playing", JSONObject()
                .put("title", s.title).put("artist", s.artist).put("url", s.url).put("thumb", s.thumb ?: JSONObject.NULL)
                .put("pos", PlayerManager.position()))
        }
        val r = call("/social/heartbeat", json)
        if (r != null && r.code in 200..299) applySnapshot(r.body) else errorOf(r, "")
    }

    // ---------------------------------------------------------------- ağ

    internal class Result(val code: Int, val body: JSONObject)

    internal suspend fun call(path: String, json: JSONObject): Result? = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(SOCIAL_API_URL.trimEnd('/') + path)
                .post(json.toString().toRequestBody(JSON.toMediaType()))
            token?.let { b.header("Authorization", "Bearer $it") }
            Http.server.newCall(b.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                Result(r.code, try { JSONObject(text) } catch (e: Exception) { JSONObject() })
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    private fun errorOf(r: Result?, fallback: String): String? = when {
        r == null -> "Sunucuya bağlanılamadı. İnternetini kontrol et; sunucu uykudaysa 1 dakika sonra tekrar dene."
        r.code in 200..299 -> null
        r.code == 401 -> { // anahtar sunucuda yok (sunucu sıfırlanmış olabilir)
            token = null; username.value = null; myAvatar.value = null
            prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
            "Sosyal hesabın sunucuda bulunamadı. Yeniden kullanıcı adı al."
        }
        else -> r.body.optString("error").ifBlank { if (r.code >= 500) "Sunucu hatası. Biraz sonra tekrar dene." else fallback }
    }

    private fun avatarOf(o: JSONObject): String? = if (o.isNull("avatar")) null else o.optString("avatar").ifBlank { null }

    /** Sunucudan gelen özeti (ben, arkadaşlar, istekler) ekrana yansıtır. */
    private suspend fun applySnapshot(b: JSONObject) {
        b.optJSONObject("me")?.let { m ->
            val n = m.optString("username")
            if (n.isNotBlank() && n != username.value) {
                username.value = n
                prefs?.edit()?.putString("social_name", n)?.apply()
            }
            myAvatar.value = avatarOf(m)
            displayName.value = m.optString("name").ifBlank { null } ?: n.ifBlank { null }
            myProfileSong.value = parseSong(m.optJSONObject("profileSong"))
            myStatus.value = parseStatus(m.optJSONObject("status"))
        }
        friends.value = b.optJSONArray("friends").toList { o ->
            val l = o.optJSONObject("listening")
            // Sunucu "ne kadar önce" bilgisini yollar: telefon saati yanlış olsa da son görülme doğru çıkar
            val ago = o.optLong("seenAgo", -1L)
            val seen = if (ago >= 0) System.currentTimeMillis() - ago else o.optLong("lastSeen")
            SocialFriend(
                o.getString("username"), o.optBoolean("online"), seen, avatarOf(o),
                l?.let { Song(it.optString("title"), it.optString("artist"), it.optString("url"),
                    if (it.isNull("thumb")) null else it.optString("thumb").ifBlank { null }) },
                o.optString("name").ifBlank { o.getString("username") },
                profileSong = parseSong(o.optJSONObject("profileSong")),
                status = parseStatus(o.optJSONObject("status")),
                listenPos = o.optLong("listenPos", -1L),
                listenAgo = o.optLong("listenAgo", 0L)
            )
        }.sortedWith(compareByDescending<SocialFriend> { it.listening != null }
            .thenByDescending { it.online }.thenBy { it.username.lowercase() })
        incoming.value = b.optJSONArray("incoming").toList { SocialPerson(it.getString("username"), avatarOf(it), it.optString("name").ifBlank { it.getString("username") }) }
        outgoing.value = b.optJSONArray("outgoing").toList { SocialPerson(it.getString("username"), avatarOf(it), it.optString("name").ifBlank { it.getString("username") }) }
        val n = b.optInt("inbox", -1)
        if (n >= 0 && n != inbox.value.size) fetchInbox()

        val sf = syncFriend.value
        if (sf != null) {
            val f = friends.value.firstOrNull { it.username == sf }
            val fl = f?.listening
            val cur = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
            withContext(Dispatchers.Main) {
                if (fl != null && fl.url != cur?.url) {
                    PlayerManager.playQueue(listOf(fl), 0)
                } else if (fl != null && f != null) {
                    // Aynı şarkı: duraklama/devam ve ileri-geri sarmayı arkadaşla eşle
                    if (!PlayerManager.playing.value) PlayerManager.togglePlay()
                    if (f.listenPos >= 0) {
                        val expected = f.listenPos + f.listenAgo
                        val dur = PlayerManager.duration()
                        val target = if (dur > 0) expected.coerceAtMost(dur - 500) else expected
                        if (Math.abs(PlayerManager.position() - target) > 2500) PlayerManager.seekTo(target)
                    }
                } else if (f != null && f.online && PlayerManager.playing.value) {
                    PlayerManager.togglePlay()   // arkadaş durdurdu
                }
            }
        }
    }

    private suspend fun fetchInbox() {
        val ib = call("/social/inbox", JSONObject())
        if (ib != null && ib.code in 200..299) {
            inbox.value = ib.body.optJSONArray("items").toList { o ->
                val sa = o.optJSONArray("songs") ?: JSONArray()
                SharedList(
                    o.getString("id"), o.optString("from"), o.optString("name"),
                    (0 until sa.length()).map { j ->
                        val s = sa.getJSONObject(j)
                        Song(s.optString("title"), s.optString("artist"), s.optString("url"),
                            if (s.isNull("thumb")) null else s.optString("thumb").ifBlank { null })
                    }
                )
            }
        }
    }

    // ---------------------------------------------------------------- işlemler

    /** Kullanıcı adı alır. Hesaba giriş yapılmışsa kullanıcı adı hesaba bağlanır. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun join(name: String): String? {
        val clean = name.trim().removePrefix("@")
        val session = AuthStore.session
        if (session != null) {
            val (err, uname, tok) = AuthApi.socialJoin(session, clean)
            if (err != null) return err
            val un = uname ?: return "Hesap oluşturulamadı."
            val tk = tok ?: return "Hesap oluşturulamadı."
            restore(un, tk)
            return null
        }
        val r = call("/social/join", JSONObject().put("username", clean))
        val err = errorOf(r, "Hesap oluşturulamadı.")
        if (err != null) return err
        val b = r?.body ?: return "Hesap oluşturulamadı."
        token = b.optString("token")
        username.value = b.optString("username")
        prefs?.edit()?.putString("social_token", token)?.putString("social_name", username.value)?.apply()
        start()
        return null
    }

    /** Görünen adı değiştirir (herkes istediği adı yazabilir). Hata varsa mesajı, başarılıysa null döner. */
    suspend fun setDisplayName(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Ad boş olamaz."
        val r = call("/social/display-name", JSONObject().put("name", n.take(30)))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        displayName.value = n.take(30)
        refresh()
        return null
    }

    /** Kullanıcı adını değiştirir. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun rename(name: String): String? {
        val r = call("/social/rename", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        username.value = r?.body?.optString("username").orEmpty()
        prefs?.edit()?.putString("social_name", username.value)?.apply()
        refresh()
        return null
    }

    suspend fun refresh() {
        if (token == null) return
        val r = call("/social/friends", JSONObject())
        if (r != null && r.code in 200..299) applySnapshot(r.body) else errorOf(r, "")
    }

    /** Seçilen resmi kare kırpıp 256x256 JPEG yaparak profil fotoğrafı olarak yükler. */
    suspend fun setAvatar(ctx: Context, uri: Uri): String? {
        if (token == null) return "Önce kullanıcı adı al."
        val bytes: ByteArray = withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@withContext null
                val side = minOf(bmp.width, bmp.height)
                val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
                var q = 90
                var out = ByteArray(0)
                do {
                    val bos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, q, bos)
                    out = bos.toByteArray()
                    q -= 5
                } while (out.size > 150_000 && q > 50)
                out
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { null }
        } ?: return "Fotoğraf okunamadı."
        val r = call("/social/avatar-set", JSONObject().put("image", Base64.encodeToString(bytes, Base64.NO_WRAP)))
        val err = errorOf(r, "Fotoğraf yüklenemedi.")
        if (err != null) return err
        myAvatar.value = r?.body?.optString("avatar").orEmpty().ifBlank { null }
        refresh()
        return null
    }

    suspend fun clearAvatar(): String? {
        val err = errorOf(call("/social/avatar-clear", JSONObject()), "Fotoğraf kaldırılamadı.")
        if (err == null) { myAvatar.value = null; refresh() }
        return err
    }

    /** Arkadaşlık için paylaşılan profil linki; tıklanınca uygulama açılır ve o kişinin profili görünür. */
    fun profileLink(username: String): String = "$SOCIAL_API_URL/add-friend/${Uri.encode(username)}"

    /** Profil linkini WhatsApp'a (yüklü değilse paylaşım menüsüne) gönderir. */
    fun shareProfileLink(ctx: Context, username: String, toWhatsApp: Boolean = true) {
        val text = "Beni Sounddeep'te arkadaş olarak ekle 🎵\n" + profileLink(username)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            if (toWhatsApp) {
                val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
                    try { ctx.packageManager.getPackageInfo(it, 0); true } catch (e: Exception) { false }
                }
                if (pkg != null) {
                    ctx.startActivity(Intent(send).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return
                }
            }
            ctx.startActivity(Intent.createChooser(send, "Profil linkini paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(ctx, "Paylaşım açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    /** Profil linkiyle gelen kişinin özeti. (hata, özet) döner; relation: self | friend | incoming | outgoing | none */
    suspend fun userProfile(username: String): Pair<String?, Pair<SocialFriend, String>?> {
        val r = call("/social/user-profile", JSONObject().put("username", username.trim().removePrefix("@")))
        val err = errorOf(r, "Profil yüklenemedi.")
        if (err != null || r == null) return (err ?: "Profil yüklenemedi.") to null
        val b = r.body
        val u = b.optString("username").ifBlank { username }
        val f = SocialFriend(
            username = u, online = false, lastSeen = 0L,
            avatar = b.optString("avatar").takeIf { it.isNotBlank() && it != "null" },
            name = b.optString("name").ifBlank { u }
        )
        return null to (f to b.optString("relation", "none"))
    }

    suspend fun sendRequest(name: String): String? {
        val n = name.trim().removePrefix("@")
        if (!Regex("^[A-Za-z0-9_.]{3,20}$").matches(n)) return "Kullanıcı adı 3-20 karakter olmalı (harf, rakam, _ ve .)."
        return errorOf(call("/social/friend-request", JSONObject().put("username", n)), "İstek gönderilemedi.").also { refresh() }
    }

    // ---------------------------------------------------------------- Blend (uyum oranı)

    private var lastTaste = ""

    /** En çok dinlenen sanatçılarımı sunucuya yollar; yalnızca arkadaşlar Blend'de görür. */
    suspend fun pushTaste(force: Boolean = false) {
        if (token == null) return
        try {
            val top = withContext(Dispatchers.Main) { TasteProfile.topArtistsWeighted(25) }
            if (top.isEmpty()) return
            val arr = JSONArray()
            top.forEach { arr.put(JSONObject().put("n", it.first).put("w", it.second)) }
            val sig = arr.toString()
            if (!force && sig == lastTaste) return
            val r = call("/social/taste-set", JSONObject().put("artists", arr))
            if (r != null && r.code in 200..299) lastTaste = sig
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { }
    }

    /** Arkadaşımla iki tarafın zevkini getirir. Hata varsa (mesaj, null), başarılıysa (null, veri) döner. */
    suspend fun blendWith(friend: String): Pair<String?, BlendPair?> {
        pushTaste(force = true)
        val r = call("/social/blend", JSONObject().put("username", friend))
        val err = errorOf(r, "Blend yüklenemedi.")
        if (err != null) return err to null
        val b = r?.body ?: return "Blend verisi alınamadı." to null
        fun parse(o: JSONObject?): List<WArtist> =
            o?.optJSONArray("artists").toList { WArtist(it.optString("n"), it.optInt("w", 1)) }.filter { it.name.isNotBlank() }
        return null to BlendPair(parse(b.optJSONObject("me")), parse(b.optJSONObject("friend")))
    }

    suspend fun respond(name: String, accept: Boolean): String? =
        errorOf(call("/social/friend-respond", JSONObject().put("username", name).put("accept", accept)), "İşlem yapılamadı.").also { refresh() }

    suspend fun remove(name: String): String? =
        errorOf(call("/social/friend-remove", JSONObject().put("username", name)), "Silinemedi.").also { refresh() }

    /** Listeyi seçilen arkadaşlara gönderir. Cihazdan yüklenen şarkılar atlanır. */
    suspend fun share(to: List<String>, name: String, songs: List<Song>): String? {
        val arr = JSONArray()
        songs.filterNot { Uploads.isLocal(it) }.forEach {
            arr.put(JSONObject().put("title", it.title).put("artist", it.artist).put("url", it.url).put("thumb", it.thumb ?: JSONObject.NULL))
        }
        if (arr.length() == 0) return "Paylaşılacak şarkı yok. Cihazdan yüklenen şarkılar paylaşılamaz."
        val r = call("/social/share", JSONObject().put("to", JSONArray(to)).put("name", name).put("songs", arr))
        return errorOf(r, "Paylaşılamadı.")
    }

    suspend fun dismiss(id: String) {
        call("/social/inbox-dismiss", JSONObject().put("id", id))
        refresh()
    }

    suspend fun setProfileSong(s: Song): String? {
        val r = call("/social/profile-song-set", JSONObject().put("song", s.toJson()))
        val err = errorOf(r, "Profil müziği ayarlanamadı.")
        if (err == null) {
            myProfileSong.value = s
            refresh()
        }
        return err
    }

    suspend fun clearProfileSong(): String? {
        val r = call("/social/profile-song-clear", JSONObject())
        val err = errorOf(r, "Profil müziği kaldırılamadı.")
        if (err == null) {
            myProfileSong.value = null
            refresh()
        }
        return err
    }

    suspend fun setStatus(text: String, s: Song? = null): String? {
        val obj = JSONObject().put("text", text)
        if (s != null) obj.put("song", s.toJson())
        val r = call("/social/status-set", obj)
        val err = errorOf(r, "Durum paylaşılamadı.")
        if (err == null) {
            myStatus.value = StatusItem(text, s, System.currentTimeMillis())
            refresh()
        }
        return err
    }

    suspend fun clearStatus(): String? {
        val r = call("/social/status-clear", JSONObject())
        val err = errorOf(r, "Durum kaldırılamadı.")
        if (err == null) {
            myStatus.value = null
            refresh()
        }
        return err
    }

    fun parseSong(o: JSONObject?): Song? {
        if (o == null) return null
        val t = o.optString("title").ifEmpty { o.optString("t") }
        val a = o.optString("artist").ifEmpty { o.optString("a") }
        val u = o.optString("url").ifEmpty { o.optString("u") }
        val i = if (o.isNull("thumb")) o.optString("i").ifEmpty { null } else o.optString("thumb").ifEmpty { null }
        if (t.isEmpty() && u.isEmpty()) return null
        return Song(t, a, u, i)
    }

    fun parseStatus(o: JSONObject?): StatusItem? {
        if (o == null) return null
        val text = o.optString("text")
        val song = parseSong(o.optJSONObject("song"))
        val created = o.optLong("createdAt", System.currentTimeMillis())
        return StatusItem(text, song, created)
    }

    private fun <T> JSONArray?.toList(f: (JSONObject) -> T): List<T> =
        if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }
}







// ====================================================================== ARAYÜZ

private val SMuted = Color(0xFF9A9A9A)
private val OnlineGreen = Color(0xFF3DDC84)
private val OfflineGrey = Color(0xFF5A5A5A)
private val avatarColors = listOf(0xFF6C5CE7, 0xFF00B894, 0xFFE17055, 0xFF0984E3, 0xFFD63031, 0xFFE84393, 0xFFB7791F, 0xFF00A8B5).map { Color(it) }

/** Kullanıcının son görülme durumunu akıllı ve net şekilde biçimlendirir (az önce, 5 dk önce, bugün 14:32 vb.). */
fun lastSeenText(f: SocialFriend): String {
    if (f.online) return "Çevrim içi"
    val now = System.currentTimeMillis()
    val ts = if (f.lastSeen > 0) f.lastSeen else (now - 5 * 60 * 1000L)
    val diffMs = (now - ts).coerceAtLeast(0L)
    val diffMinutes = diffMs / (60 * 1000L)

    if (diffMinutes < 1) return "Son görülme az önce"
    if (diffMinutes < 60) return "Son görülme $diffMinutes dk önce"

    val seen = java.time.Instant.ofEpochMilli(ts).atZone(java.time.ZoneId.systemDefault())
    val today = java.time.LocalDate.now()
    val clock = String.format(java.util.Locale.US, "%02d:%02d", seen.hour, seen.minute)
    return when (seen.toLocalDate()) {
        today -> "Son görülme bugün $clock"
        today.minusDays(1) -> "Son görülme dün $clock"
        else -> "Son görülme " + String.format(java.util.Locale.US, "%02d.%02d.%d", seen.dayOfMonth, seen.monthValue, seen.year) + " $clock"
    }
}

/** Yeşil (çevrim içi) veya gri (çevrim dışı) durum noktası, yanında varsa yazı. */
@Composable
private fun StatusDot(online: Boolean, text: String = "", modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(if (online) OnlineGreen else OfflineGrey))
        if (text.isNotEmpty()) {
            Spacer(Modifier.width(6.dp))
            Text(text, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Yuvarlak profil resmi. Fotoğraf yoksa isme göre renkli baş harf gösterir; online verilirse köşede durum noktası olur. */
@Composable
fun UserAvatar(name: String, avatarId: String?, size: Dp, online: Boolean? = null, modifier: Modifier = Modifier) {
    val url = Social.avatarUrl(avatarId)
    Box(modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape)
                .background(avatarColors[(name.lowercase().hashCode() and 0x7fffffff) % avatarColors.size]),
            contentAlignment = Alignment.Center
        ) {
            Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
            if (url != null) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        if (online != null) {
            val dot = (size.value * 0.28f).coerceAtLeast(10f).dp
            Box(
                Modifier.align(Alignment.BottomEnd).size(dot).clip(CircleShape).background(Bg).padding(2.dp)
                    .clip(CircleShape).background(if (online) OnlineGreen else OfflineGrey)
            )
        }
    }
}

/**
 * "Müzik çalıyor" çubukları. Her çubuk kendi hızında ve kendi yükseklik dizisiyle oynar; böylece düz bir
 * ileri-geri gidiş yerine gerçek bir ekolayzır gibi düzensiz, canlı görünür. [playing] false ise çubuklar
 * yumuşakça en alta iner (müzik duraklatıldı).
 */
@Composable
private fun EqualizerBars(color: Color, playing: Boolean = true) {
    val t = rememberInfiniteTransition(label = "eq")
    val a = t.animateFloat(0.30f, 0.30f, infiniteRepeatable(keyframes {
        durationMillis = 820
        0.30f at 0; 1.00f at 150; 0.45f at 310; 0.85f at 470; 0.25f at 640; 0.30f at 820
    }, RepeatMode.Restart), label = "eqA")
    val b = t.animateFloat(0.55f, 0.55f, infiniteRepeatable(keyframes {
        durationMillis = 980
        0.55f at 0; 0.25f at 190; 0.95f at 380; 0.40f at 600; 1.00f at 780; 0.55f at 980
    }, RepeatMode.Restart), label = "eqB")
    val c = t.animateFloat(0.40f, 0.40f, infiniteRepeatable(keyframes {
        durationMillis = 700
        0.40f at 0; 0.90f at 120; 0.30f at 280; 1.00f at 430; 0.35f at 570; 0.40f at 700
    }, RepeatMode.Restart), label = "eqC")
    // 1 = çalıyor (dalgalanır), 0 = duraklatıldı (hepsi alçak ve eşit)
    val live by animateFloatAsState(if (playing) 1f else 0f, label = "eqLive")
    val rest = 0.18f
    Row(Modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.5.dp), verticalAlignment = Alignment.Bottom) {
        listOf(a, b, c).forEach { h ->
            val f = (rest + (h.value - rest) * live).coerceIn(rest, 1f)
            Box(Modifier.width(3.5.dp).fillMaxHeight(f).clip(RoundedCornerShape(1.5.dp)).background(color))
        }
    }
}

@Composable
private fun SectionTitle(t: String, count: Int? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            t.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = SMuted,
            letterSpacing = 1.1.sp
        )
    }
}

/** "● 3" gibi: yeşil / gri nokta ve kişi sayısı (çevrim içi / dışı yazısı yerine). */
@Composable
private fun DotSectionTitle(online: Boolean, count: Int) {
    Row(Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        StatusDot(online)
        Spacer(Modifier.width(8.dp))
        Text("$count", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SMuted)
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        color = Card,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        content = { Column(content = content) }
    )
}

@Composable
private fun FriendMenu(onRemove: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton({ menu = true }, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Filled.MoreVert, "Menü", tint = SMuted, modifier = Modifier.size(18.dp))
        }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(
                text = { Text("Arkadaşlıktan çıkar") },
                leadingIcon = { Icon(Icons.Filled.PersonRemove, null, tint = Color(0xFFFF5252)) },
                onClick = { menu = false; onRemove() }
            )
        }
    }
}

/** Şu an müzik dinleyen arkadaş kartı: kapak, şarkı adı ve "sen de dinle" düğmesi. */
@Composable
private fun ListeningCard(f: SocialFriend, onOpen: () -> Unit, onRemove: () -> Unit) {
    val l = f.listening ?: return
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        shape = RoundedCornerShape(22.dp),
        color = Card,
        border = BorderStroke(1.dp, OnlineGreen.copy(alpha = 0.22f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onOpen() }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                UserAvatar(f.username, f.avatar, 46.dp, online = true)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EqualizerBars(OnlineGreen)
                        Spacer(Modifier.width(6.dp))
                        Text("Şu an dinliyor", color = OnlineGreen, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
                BlendHint()
                FriendMenu(onRemove)
            }
            Spacer(Modifier.height(10.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Bg.copy(alpha = 0.55f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.04f))
            ) {
                Row(
                    Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Accent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.MusicNote, null, tint = Accent, modifier = Modifier.size(24.dp))
                        if (l.thumb != null) {
                            AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            l.title,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                        )
                        if (l.artist.isNotBlank()) {
                            Text(
                                l.artist,
                                color = SMuted,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                            )
                        }
                    }
                    if (l.url.isNotBlank()) {
                        val syncUser by Social.syncFriend.collectAsState()
                        val isSyncing = syncUser == f.username
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSyncing) Color(0xFFE84393) else Accent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    if (isSyncing) {
                                        Social.stopSync()
                                    } else {
                                        Social.startSync(f.username)
                                        PlayerManager.playQueue(listOf(l), 0)
                                    }
                                }
                        ) {
                            Row(
                                Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (isSyncing) Icons.Filled.Headphones else Icons.Filled.PlayArrow,
                                    null,
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    if (isSyncing) "Bağlı" else "Birlikte Dinle",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Arkadaş satırlarında profili açan ok işareti. */
@Composable
private fun BlendHint() {
    Icon(
        Icons.Filled.ChevronRight,
        "Profili aç",
        tint = SMuted.copy(alpha = 0.5f),
        modifier = Modifier.size(18.dp).padding(end = 2.dp)
    )
}

@Composable
private fun FriendRow(f: SocialFriend, onOpen: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        UserAvatar(f.username, f.avatar, 44.dp, online = f.online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (f.online) {
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(OnlineGreen))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Çevrim içi",
                        color = OnlineGreen.copy(alpha = 0.9f),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        BlendHint()
        FriendMenu(onRemove)
    }
}

/** Arkadaşlar sekmesi: profilin, arkadaş ekleme, arkadaş listesi (dokununca profili açılır), istekler ve gelen paylaşımlar. */
@Composable
fun FriendsTab(onOpenProfile: (SocialFriend) -> Unit = {}, onOpenAuth: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    val myDisplayName by Social.displayName.collectAsState()
    val myName = me ?: ""
    val myShown = myDisplayName ?: myName
    val clipboard = LocalClipboardManager.current
    val myAvatar by Social.myAvatar.collectAsState()
    val friends by Social.friends.collectAsState()
    val incoming by Social.incoming.collectAsState()
    val outgoing by Social.outgoing.collectAsState()
    val inbox by Social.inbox.collectAsState()
    val showListening by Social.showListening.collectAsState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var removeTarget by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var avatarMenu by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    var openedPub by remember { mutableStateOf<PubList?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            uploading = true
            val e = ProfilePhoto.set(ctx, uri)
            uploading = false
            Toast.makeText(ctx, e ?: "Profil fotoğrafın güncellendi", Toast.LENGTH_SHORT).show()
        }
    }

    // Sekme açılınca hemen güncelle; sonrası sinyal döngüsü her 5 sn'de yeniler
    LaunchedEffect(me) { if (me != null) { Social.start(); Social.refresh(); ProfilePhoto.syncUp(ctx) } }

    Column(Modifier.fillMaxSize()) {
        if (!Social.enabled) {
            Text(
                "Sosyal özellikler henüz ayarlanmadı. Sunucuyu yayınlayıp Social.kt dosyasındaki SOCIAL_API_URL değerine adresini yaz (backend/README.md).",
                color = SMuted, modifier = Modifier.padding(20.dp)
            )
            return@Column
        }

        if (me == null) {
            val signedIn = AuthStore.session != null
            // Giriş yapılmışsa arkadaş kimliği e-postadan otomatik oluşur; kullanıcı isim aramak zorunda kalmaz
            LaunchedEffect(signedIn) { if (signedIn) { busy = true; error = Social.join(""); busy = false } }
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(Accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.People, null, tint = Accent, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("Arkadaşlarınla Dinle", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (signedIn) {
                    Text("Hesabın hazırlanıyor...", color = SMuted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    if (busy) CircularProgressIndicator(color = Accent)
                    else {
                        error?.let { Text(it, color = Accent, textAlign = TextAlign.Center) }
                        Spacer(Modifier.height(8.dp))
                        Button(
                            { scope.launch { busy = true; error = Social.join(""); busy = false } },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                        ) { Text("Tekrar dene") }
                    }
                } else {
                    Text("Giriş yap, arkadaşlarını ekle. Beğendiklerin ve listelerin de hesabına kaydedilir.", color = SMuted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        { onOpenAuth() }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) { Text("Giriş yap / Hesap oluştur") }
                }
            }
            return@Column
        }

        openedPub?.let { ol ->
            BackHandler { openedPub = null }
            FriendListScreen(ol) { openedPub = null }
            return@Column
        }

        val listening = friends.filter { it.listening != null }
        val onlineRest = friends.filter { it.online && it.listening == null }
        val offline = friends.filter { !it.online }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
            // ---- Modern Üst Başlık & Ekleme Butonu ----
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Arkadaşlar",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // ---- Profil kartı (Yalnızca Simge + Tek Tıkla Arkadaşlık Linki Gönderme Butonu) ----
            item {
                var editMenu by remember { mutableStateOf(false) }
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(22.dp),
                    color = Card,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .clickable { editMenu = true }
                            ) {
                                Avatar(54.dp)
                                if (uploading) {
                                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                    }
                                }
                            }
                            Spacer(Modifier.width(14.dp))
                            // Profil resminin yanında kullanıcının kendi oluşturduğu isim ve profil butonu
                            Column(Modifier.weight(1f)) {
                                Text(
                                    myShown,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.06f),
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .clickable { Social.shareProfileLink(ctx, myName) }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.Share, "Profil linkini paylaş", tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                            Spacer(Modifier.width(8.dp))

                            Box {
                                Surface(
                                    shape = CircleShape,
                                    color = Color.White.copy(alpha = 0.06f),
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .clickable { editMenu = true }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.Edit, "Profili düzenle", tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                }
                                DropdownMenu(editMenu, { editMenu = false }) {
                                    DropdownMenuItem(
                                        text = { Text("Fotoğrafı değiştir") },
                                        leadingIcon = { Icon(Icons.Filled.PhotoCamera, null) },
                                        onClick = {
                                            editMenu = false
                                            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Görünen adı değiştir") },
                                        leadingIcon = { Icon(Icons.Filled.Edit, null) },
                                        onClick = { editMenu = false; renaming = true }
                                    )
                                    if (myAvatar != null || AuthStore.photo.value != null) {
                                        DropdownMenuItem(
                                            text = { Text("Fotoğrafı kaldır") },
                                            leadingIcon = { Icon(Icons.Filled.Delete, null, tint = Color(0xFFFF5252)) },
                                            onClick = {
                                                editMenu = false
                                                scope.launch { ProfilePhoto.clear()?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        // Ne Dinlediğimi Göster (Alt açıklama kaldırıldı)
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.04f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(30.dp).clip(CircleShape).background(Accent.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.Headphones, null, tint = Accent, modifier = Modifier.size(16.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Text("Ne dinlediğimi göster", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Switch(
                                    checked = showListening,
                                    onCheckedChange = { Social.setShowListening(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Accent,
                                        uncheckedThumbColor = Color(0xFFA0A0A0),
                                        uncheckedTrackColor = Color.White.copy(alpha = 0.1f),
                                        uncheckedBorderColor = Color.Transparent
                                    ),
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }
                    }
                }
            }

            // ---- Profilimi ve listelerimi gör (profil kartının hemen altında) ----
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable {
                            onOpenProfile(SocialFriend(username = myName, online = true, lastSeen = System.currentTimeMillis(), avatar = myAvatar, name = myShown))
                        },
                    shape = RoundedCornerShape(18.dp),
                    color = Accent.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Accent.copy(alpha = 0.25f))
                ) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AccountCircle, null, tint = Accent, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Text("Profilimi ve listelerimi gör", color = Accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.ChevronRight, null, tint = Accent, modifier = Modifier.size(20.dp))
                    }
                }
            }

            // ---- Arkadaş ekle Kartı ----
            item {
                val canSend = !busy && input.removePrefix("@").length >= 3
                AnimatedVisibility(
                    addOpen,
                    enter = expandVertically(tween(250)) + fadeIn(tween(250)),
                    exit = shrinkVertically(tween(200)) + fadeOut(tween(150))
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(22.dp),
                        color = Card,
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
                    ) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Arkadaş Ekle", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "Arkadaşının kullanıcı adını girerek bağlantı kurabilirsin.",
                                color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp)
                            )
                            Spacer(Modifier.height(14.dp))
                            OutlinedTextField(
                                value = input,
                                onValueChange = { input = it.filterNot { c -> c.isWhitespace() }.take(30); error = null },
                                singleLine = true,
                                leadingIcon = { Text("@", color = Accent, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                                shape = RoundedCornerShape(16.dp),
                                isError = error != null,
                                supportingText = error?.let { { Text(it) } },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    scope.launch {
                                        busy = true
                                        val e = Social.sendRequest(input)
                                        busy = false
                                        error = e
                                        if (e == null) {
                                            Toast.makeText(ctx, "İstek gönderildi", Toast.LENGTH_SHORT).show()
                                            input = ""
                                            addOpen = false
                                        }
                                    }
                                },
                                enabled = canSend,
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                            ) {
                                if (busy) {
                                    CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Filled.PersonAdd, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("İstek Gönder", fontWeight = FontWeight.SemiBold)
                                }
                            }

                            // Kullanıcı adı/kod yerine profil linki: WhatsApp'tan gönderilir, açan kişi profilde "Arkadaş Ekle"ye basar
                            val myUsernameStr = Social.username.value ?: myName
                            if (myUsernameStr.isNotBlank()) {
                                Spacer(Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { Social.shareProfileLink(ctx, myUsernameStr) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, Color(0xFF25D366).copy(alpha = 0.6f))
                                ) {
                                    WhatsAppLogo(sizeDp = 22.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text("Profil linkimi WhatsApp'tan paylaş", color = Color.White, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }

            // ---- Gelen paylaşımlar ----
            if (inbox.isNotEmpty()) {
                item { SectionTitle("Sana Gönderilen Listeler", inbox.size) }
                item {
                    SectionCard {
                        inbox.forEachIndexed { idx, l ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.LibraryMusic, null, tint = Accent)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(l.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${l.from} · ${l.songs.size} şarkı", color = SMuted, fontSize = 12.sp)
                                }
                                TextButton({
                                    Playlists.create("${l.name} (${l.from})", l.songs)
                                    scope.launch { Social.dismiss(l.id) }
                                    Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                                }) { Text("Kaydet", color = Accent, fontWeight = FontWeight.SemiBold) }
                                IconButton({ scope.launch { Social.dismiss(l.id) } }, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Filled.Close, "Yoksay", tint = SMuted, modifier = Modifier.size(18.dp))
                                }
                            }
                            if (idx < inbox.lastIndex) {
                                Box(Modifier.fillMaxWidth().height(1.dp).padding(start = 70.dp, end = 14.dp).background(Color.White.copy(alpha = 0.05f)))
                            }
                        }
                    }
                }
            }

            // ---- Arkadaşlık istekleri ----
            if (incoming.isNotEmpty()) {
                item { SectionTitle("Arkadaşlık İstekleri", incoming.size) }
                item {
                    SectionCard {
                        incoming.forEachIndexed { idx, p ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(p.username, p.avatar, 44.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("Arkadaş olmak istiyor", color = SMuted, fontSize = 12.sp)
                                }
                                Surface(
                                    shape = CircleShape,
                                    color = Accent,
                                    modifier = Modifier.size(36.dp).clip(CircleShape).clickable { scope.launch { Social.respond(p.username, true) } }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.Check, "Kabul et", tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                }
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    shape = CircleShape,
                                    color = Color.White.copy(alpha = 0.06f),
                                    modifier = Modifier.size(36.dp).clip(CircleShape).clickable { scope.launch { Social.respond(p.username, false) } }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.Close, "Reddet", tint = SMuted, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                            if (idx < incoming.lastIndex) {
                                Box(Modifier.fillMaxWidth().height(1.dp).padding(start = 70.dp, end = 14.dp).background(Color.White.copy(alpha = 0.05f)))
                            }
                        }
                    }
                }
            }

            // ---- Şimdi dinleyenler ----
            if (listening.isNotEmpty()) {
                item { SectionTitle("Şimdi Dinliyor", listening.size) }
                items(listening, key = { "ls" + it.username }) { f ->
                    ListeningCard(f, { onOpenProfile(f) }) { removeTarget = f.username }
                }
            }

            // ---- Çevrim içi ----
            if (onlineRest.isNotEmpty()) {
                item { SectionTitle("Çevrim İçi", onlineRest.size) }
                item {
                    SectionCard {
                        onlineRest.forEachIndexed { idx, f ->
                            FriendRow(f, { onOpenProfile(f) }) { removeTarget = f.username }
                            if (idx < onlineRest.lastIndex) {
                                Box(Modifier.fillMaxWidth().height(1.dp).padding(start = 70.dp, end = 14.dp).background(Color.White.copy(alpha = 0.05f)))
                            }
                        }
                    }
                }
            }

            // ---- Çevrim dışı ----
            if (offline.isNotEmpty()) {
                item { Spacer(Modifier.height(12.dp)) }
                item {
                    SectionCard {
                        offline.forEachIndexed { idx, f ->
                            FriendRow(f, { onOpenProfile(f) }) { removeTarget = f.username }
                            if (idx < offline.lastIndex) {
                                Box(Modifier.fillMaxWidth().height(1.dp).padding(start = 70.dp, end = 14.dp).background(Color.White.copy(alpha = 0.05f)))
                            }
                        }
                    }
                }
            }

            // ---- Henüz arkadaş yoksa Soft Empty State ----
            if (friends.isEmpty()) {
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp, bottom = 20.dp, start = 32.dp, end = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(Accent.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.People, null, tint = Accent, modifier = Modifier.size(38.dp))
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Henüz Arkadaşın Yok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Arkadaşlarının ne dinlediğini görmek, anlık senkron müzik dinlemek ve ortak Blend listeleri oluşturmak için arkadaş ekle.",
                            color = SMuted, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, lineHeight = 18.sp
                        )
                        Spacer(Modifier.height(18.dp))
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Accent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { addOpen = true }
                        ) {
                            Row(
                                Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.PersonAdd, null, tint = Color.White, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Arkadaş Ekle", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // ---- Bekleyen istekler ----
            if (outgoing.isNotEmpty()) {
                item { SectionTitle("Bekleyen İstekler", outgoing.size) }
                item {
                    SectionCard {
                        outgoing.forEachIndexed { idx, p ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(p.username, p.avatar, 36.dp)
                                Spacer(Modifier.width(12.dp))
                                Text(p.name, Modifier.weight(1f), color = SMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                TextButton({ scope.launch { Social.remove(p.username) } }) {
                                    Text("İptal", color = SMuted, fontSize = 12.sp)
                                }
                            }
                            if (idx < outgoing.lastIndex) {
                                Box(Modifier.fillMaxWidth().height(1.dp).padding(start = 62.dp, end = 14.dp).background(Color.White.copy(alpha = 0.05f)))
                            }
                        }
                    }
                }
            }
        }
    }

    removeTarget?.let { n ->
        AlertDialog(
            onDismissRequest = { removeTarget = null }, containerColor = Card, title = { Text("@$n") },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ scope.launch { Social.remove(n) }; removeTarget = null }) { Text("Çıkar", color = Color(0xFFFF5252)) } },
            dismissButton = { TextButton({ removeTarget = null }) { Text("Vazgeç") } }
        )
    }

    if (renaming) {
        var text by remember { mutableStateOf(myDisplayName ?: me ?: "") }
        var err by remember { mutableStateOf<String?>(null) }
        var saving by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!saving) renaming = false }, containerColor = Card, title = { Text("Görünen Adını Değiştir") },
            text = {
                OutlinedTextField(
                    text, { text = it.take(30); err = null },
                    singleLine = true, shape = RoundedCornerShape(14.dp), isError = err != null,
                    supportingText = { Text(err ?: "İstediğin adı yazabilirsin. Kullanıcı adın (@${me ?: ""}) değişmez.") }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            saving = true
                            val e = Social.setDisplayName(text)
                            saving = false
                            err = e
                            if (e == null) {
                                if (AuthStore.email.value != null) AuthStore.setName(text)
                                renaming = false
                                Toast.makeText(ctx, "Görünen adın değişti", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = !saving && text.isNotBlank() && text.trim() != (myDisplayName ?: "")
                ) { Text("Kaydet") }
            },
            dismissButton = { TextButton({ renaming = false }, enabled = !saving) { Text("Vazgeç") } }
        )
    }
}


/** Profil linkinden açılan, henüz arkadaş olunmayan kişinin profili: fotoğraf, ad ve "Arkadaş Ekle" butonu. */
@Composable
private fun StrangerProfile(username: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val outgoing by Social.outgoing.collectAsState()
    val incoming by Social.incoming.collectAsState()
    var loading by remember(username) { mutableStateOf(true) }
    var error by remember(username) { mutableStateOf<String?>(null) }
    var info by remember(username) { mutableStateOf<SocialFriend?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(username) {
        loading = true
        val (err, res) = Social.userProfile(username)
        error = err
        info = res?.first
        loading = false
    }
    val u = info
    val isFriend = friends.any { it.username.equals(username, true) }
    val sent = outgoing.any { it.username.equals(username, true) }
    val theyAsked = incoming.any { it.username.equals(username, true) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
        }
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(top = 80.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
            u == null -> Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.PersonOff, null, tint = SMuted, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(12.dp))
                Text(error ?: "Profil bulunamadı.", color = SMuted, textAlign = TextAlign.Center)
            }
            else -> Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                UserAvatar(u.name, u.avatar, 110.dp)
                Spacer(Modifier.height(14.dp))
                Text(u.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                when {
                    isFriend -> Text("Zaten arkadaşsınız", color = OnlineGreen, fontWeight = FontWeight.SemiBold)
                    theyAsked -> Button(
                        onClick = {
                            scope.launch {
                                busy = true
                                val e = Social.respond(u.username, true)
                                busy = false
                                Toast.makeText(ctx, e ?: "Artık arkadaşsınız", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) {
                        Icon(Icons.Filled.Check, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("İsteği Kabul Et", fontWeight = FontWeight.SemiBold)
                    }
                    else -> Button(
                        onClick = {
                            scope.launch {
                                busy = true
                                val e = Social.sendRequest(u.username)
                                busy = false
                                Toast.makeText(ctx, e ?: "Arkadaşlık isteği gönderildi", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = !busy && !sent,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Accent, contentColor = Color.White,
                            disabledContainerColor = Color.White.copy(alpha = 0.10f), disabledContentColor = SMuted
                        )
                    ) {
                        if (busy) {
                            CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(if (sent) Icons.Filled.Check else Icons.Filled.PersonAdd, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (sent) "İstek Gönderildi" else "Arkadaş Ekle", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

/** Arkadaşın profili: fotoğraf, ad, durum, ne dinlediği ve tek tuşla Blend. */
@Composable
fun FriendProfileScreen(username: String, onBack: () -> Unit, onOpenList: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val myId by Social.username.collectAsState()
    val myDisp by Social.displayName.collectAsState()
    val myAvatar by Social.myAvatar.collectAsState()
    val playingSong by PlayerManager.queue.collectAsState()
    val playIdx by PlayerManager.index.collectAsState()
    val curListening = playingSong.getOrNull(playIdx)
    val isPlayingNow by PlayerManager.playing.collectAsState()
    val myName = myDisp ?: myId ?: "Sen"

    val isMe = myId != null && username.equals(myId, ignoreCase = true)
    val friend = friends.firstOrNull { it.username.equals(username, ignoreCase = true) } ?: if (isMe) {
        SocialFriend(
            username = myId ?: username,
            online = true,
            lastSeen = System.currentTimeMillis(),
            avatar = myAvatar,
            listening = curListening,
            name = myDisp ?: myId ?: "Sen"
        )
    } else null

    var building by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var compat by remember { mutableStateOf<Compat?>(null) }
    var resultId by remember { mutableStateOf<String?>(null) }
    var resultSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var menu by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    var openedList by remember { mutableStateOf<PubList?>(null) }

    if (friend == null) {
        StrangerProfile(username, onBack)
        return
    }
    openedList?.let { ol ->
        BackHandler { openedList = null }
        FriendListScreen(ol) { openedList = null }
        return
    }
    val l = friend.listening

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
            var confirmSelfDelete by remember { mutableStateOf(false) }
            if (isMe) {
                Text("Profilim", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
            }
            Spacer(Modifier.weight(1f))
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                DropdownMenu(menu, { menu = false }) {
                    if (!isMe) {
                        DropdownMenuItem(text = { Text("Arkadaşlıktan çıkar") }, leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                            onClick = { menu = false; confirmRemove = true })
                    } else {
                        DropdownMenuItem(text = { Text("Sosyal hesabı sil", color = Color(0xFFD32F2F)) }, leadingIcon = { Icon(Icons.Filled.DeleteForever, null, tint = Color(0xFFD32F2F)) },
                            onClick = { menu = false; confirmSelfDelete = true })
                    }
                }
            }
            if (confirmSelfDelete) {
                AlertDialog(
                    onDismissRequest = { confirmSelfDelete = false },
                    containerColor = Card,
                    title = { Text("Sosyal hesabı sil?") },
                    text = { Text("Profilin, arkadaşların ve paylaştığın listeler silinir. Dilediğin zaman yeniden kullanıcı adı alabilirsin.") },
                    confirmButton = {
                        TextButton({
                            confirmSelfDelete = false
                            scope.launch {
                                Social.deleteAccount()
                                Toast.makeText(ctx, "Sosyal hesabın silindi. Yeniden başlayabilirsin.", Toast.LENGTH_SHORT).show()
                                onBack()
                            }
                        }) { Text("Hesabı Sil", color = Color(0xFFD32F2F)) }
                    },
                    dismissButton = { TextButton({ confirmSelfDelete = false }) { Text("Vazgeç") } }
                )
            }
        }

        // ---- Profil ----


        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .clip(CircleShape)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                UserAvatar(friend.name, friend.avatar, 110.dp)
            }
            Spacer(Modifier.height(14.dp))
            Text(friend.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            StatusDot(friend.online, if (isMe) "Çevrim içi" else lastSeenText(friend))


        }



        // ---- Şu an dinlediği ----
        if (l != null) {
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.MusicNote, null, tint = Accent)
                    if (l.thumb != null) AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EqualizerBars(OnlineGreen, playing = !isMe || isPlayingNow)
                        Spacer(Modifier.width(6.dp))
                        Text(if (isMe && !isPlayingNow) "Duraklatıldı" else "Şu an dinliyor", color = OnlineGreen, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(
                        l.title,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                    )
                    if (l.artist.isNotBlank()) {
                        Text(
                            l.artist,
                            color = SMuted,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                        )
                    }
                }
                if (l.url.isNotBlank()) {
                    IconButton({ PlayerManager.playQueue(listOf(l), 0) }, Modifier.clip(CircleShape).background(Accent)) {
                        Icon(Icons.Filled.PlayArrow, "Sen de dinle", tint = Color.White)
                    }
                }
            }
        }

        if (!isMe) {
        // ---- Beraber Şarkı Dinleme (Zengin Tasarım) ----
        val syncUser by Social.syncFriend.collectAsState()
        val isSyncing = syncUser == friend.username
        Spacer(Modifier.height(14.dp))
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(22.dp),
            color = Card,
            border = BorderStroke(1.dp, if (isSyncing) Color(0xFFE84393).copy(alpha = 0.5f) else Color(0xFF6C5CE7).copy(alpha = 0.35f))
        ) {
            Column(
                Modifier
                    .background(
                        Brush.horizontalGradient(
                            if (isSyncing) listOf(Color(0xFFE84393).copy(alpha = 0.22f), Color(0xFF1E1528), Card)
                            else listOf(Color(0xFF6C5CE7).copy(alpha = 0.22f), Color(0xFF151E33), Card)
                        )
                    )
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (isSyncing) Color(0xFFE84393) else Accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Headphones, null, tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isSyncing) {
                                EqualizerBars(Color(0xFFE84393))
                                Spacer(Modifier.width(6.dp))
                                Text("CANLI SENKRON", color = Color(0xFFE84393), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            } else {
                                Text("BİRLİKTE DİNLE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }
                        if (l != null) {
                            Spacer(Modifier.height(3.dp))
                            Text(
                                "${l.title} • ${l.artist}",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                            )
                        } else {
                            Spacer(Modifier.height(3.dp))
                            Text(
                                if (isSyncing) "${friend.name} ile aynı anda dinliyorsunuz" else "${friend.name} ile aynı anda dinle",
                                color = SMuted,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                            )
                        }
                    }
                    Button(
                        onClick = {
                            if (isSyncing) {
                                Social.stopSync()
                                Toast.makeText(ctx, "Birlikte dinleme sonlandırıldı", Toast.LENGTH_SHORT).show()
                            } else {
                                Social.startSync(friend.username)
                                if (l != null) {
                                    PlayerManager.playQueue(listOf(l), 0)
                                    Toast.makeText(ctx, "${friend.name} ile birlikte dinleme başladı!", Toast.LENGTH_SHORT).show()
                                } else {
                                    val cur = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
                                    if (cur != null) {
                                        scope.launch {
                                            Social.share(listOf(friend.username), "Birlikte Dinleyelim: ${cur.title}", listOf(cur))
                                            Toast.makeText(ctx, "${friend.name} kullanıcısına dinleme daveti gönderildi!", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        Toast.makeText(ctx, "Önce bir şarkı aç veya arkadaşının müzik başlatmasını bekle.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSyncing) Color(0xFFE84393) else Accent,
                            contentColor = Color.White
                        )
                    ) {
                        Text(if (isSyncing) "Ayrıl" else "Başlat", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ---- Tek tuşla Zengin Blend (Arayüzle Uyumlu Zarif Kart) ----
        val allUserLists by Playlists.lists.collectAsState()
        val existingBlend = remember(allUserLists, friend.name, friend.username) {
            allUserLists.firstOrNull {
                it.name.contains("Blend:", ignoreCase = true) &&
                (it.name.contains(friend.name, ignoreCase = true) || it.name.contains(friend.username, ignoreCase = true))
            }
        }

        Spacer(Modifier.height(16.dp))
        Column(Modifier.padding(horizontal = 16.dp)) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(enabled = !building) {
                        error = null; compat = null; resultId = null; building = true
                        scope.launch {
                            val (err, pair) = Social.blendWith(friend.username)
                            when {
                                err != null || pair == null -> error = err ?: "Blend oluşturulamadı."
                                pair.me.isEmpty() -> error = "Önce birkaç şarkı dinle veya beğen, sonra tekrar dene."
                                pair.friend.isEmpty() -> error = "${friend.name} henüz yeterince müzik dinlememiş. O birkaç şarkı dinleyince tekrar dene."
                                else -> {
                                    val songs = Blend.make(pair.me.map { it.name }, pair.friend.map { it.name })
                                    if (songs.isEmpty()) error = "Şarkı bulunamadı. İnternetini kontrol edip tekrar dene."
                                    else {
                                        val cmp = Blend.compat(pair.me, pair.friend)
                                        compat = cmp
                                        if (existingBlend != null) {
                                            Playlists.replaceSongs(existingBlend.id, songs)
                                            resultId = existingBlend.id
                                        } else {
                                            val pl = Playlists.create("Blend: $myName + ${friend.name}", songs)
                                            resultId = pl.id
                                        }
                                        resultSongs = songs
                                    }
                                }
                            }
                            building = false
                        }
                    },
                shape = RoundedCornerShape(20.dp),
                color = Card,
                border = BorderStroke(1.dp, Accent.copy(alpha = 0.28f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Accent.copy(alpha = 0.16f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Accent.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (building) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Accent,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = Accent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Ortak Blend",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                if (building) "Zevkleriniz analiz ediliyor..." else "${friend.name} ile müzik zevkinizi birleştirin",
                                style = MaterialTheme.typography.bodySmall,
                                color = SMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Accent.copy(alpha = 0.20f),
                            border = BorderStroke(1.dp, Accent.copy(alpha = 0.40f))
                        ) {
                            Text(
                                if (existingBlend != null) "Yenile" else "Oluştur",
                                color = Accent,
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            error?.let { Text(it, color = Accent, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) }

            val rid = resultId
            val c = compat
            if (rid != null && c != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    shape = RoundedCornerShape(20.dp),
                    color = Card,
                    border = BorderStroke(1.dp, Accent.copy(alpha = 0.35f))
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Brush.verticalGradient(listOf(Accent.copy(alpha = 0.14f), Color.Transparent)))
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("%${c.percent}", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
                            Spacer(Modifier.width(10.dp))
                            Text(c.label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = Color.White, modifier = Modifier.weight(1f))
                        }
                        Box(Modifier.fillMaxWidth().padding(top = 8.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.10f))) {
                            Box(Modifier.fillMaxWidth(c.percent / 100f).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(Accent))
                        }

                        if (c.shared.isNotEmpty()) {
                            Text("Ortak sanatçılar: " + c.shared.take(8).joinToString(", "), color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                        }
                        Text("${resultSongs.size} şarkı • Kitaplık > Listelerim'e kaydedildi", color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                { PlayerManager.playQueue(resultSongs, 0) },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                            ) {
                                Icon(Icons.Filled.PlayArrow, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Çal")
                            }
                            OutlinedButton(
                                { onOpenList(rid) },
                                shape = RoundedCornerShape(14.dp)
                            ) { Text("Listeyi aç") }
                        }
                    }
                }
            }
        }
        }
        // ---- Kullanıcının Paylaştığı Listeler (Blend altında) ----
        FriendListsSection(friend) { openedList = it }
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false }, containerColor = Card, title = { Text(friend.name) },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ confirmRemove = false; scope.launch { Social.remove(friend.username) }; onBack() }) { Text("Çıkar") } },
            dismissButton = { TextButton({ confirmRemove = false }) { Text("Vazgeç") } }
        )
    }
}

/** Bir listeyi seçilen arkadaşlara gönderir. */
@Composable
fun ShareListDialog(pl: UserPlaylist, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { Social.refresh() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card, title = { Text("\"${pl.name}\" paylaş") },
        text = {
            when {
                !Social.enabled || !Social.joined -> Text("Paylaşmak için önce Arkadaşlar sekmesinden kullanıcı adı al.")
                friends.isEmpty() -> Text("Henüz arkadaşın yok.")
                else -> LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(friends, key = { it.username }) { f ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if (f.username in selected) selected.remove(f.username) else selected.add(f.username)
                        }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.username in selected, { if (it) selected.add(f.username) else selected.remove(f.username) })
                            UserAvatar(f.username, f.avatar, 34.dp, online = f.online)
                            Spacer(Modifier.width(10.dp))
                            Text(f.name)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    busy = true
                    val e = Social.share(selected.toList(), pl.name, pl.songs)
                    busy = false
                    Toast.makeText(ctx, e ?: "Gönderildi", Toast.LENGTH_SHORT).show()
                    if (e == null) onDismiss()
                }
            }, enabled = selected.isNotEmpty() && !busy) { Text("Gönder") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}

/** Arkadaşın profilinde, onun herkese açık ve paylaştığı çalma listeleri. */
@Composable
private fun FriendListsSection(friend: SocialFriend, onOpen: (PubList) -> Unit) {
    var state by remember(friend.username) { mutableStateOf<List<PubList>?>(null) }
    var loading by remember(friend.username) { mutableStateOf(false) }
    var errorMsg by remember(friend.username) { mutableStateOf<String?>(null) }
    var retryCount by remember(friend.username) { mutableStateOf(0) }
    var expanded by remember { mutableStateOf(true) }
    val myUsername by Social.username.collectAsState()
    val allUserLists by Playlists.lists.collectAsState()
    val inbox by Social.inbox.collectAsState()
    val isMe = friend.username.equals(myUsername, ignoreCase = true)

    LaunchedEffect(friend.username, isMe, allUserLists, retryCount) {
        if (isMe) {
            val myPubs = allUserLists.filter { it.public }.map { pl ->
                PubList(
                    owner = friend.username,
                    ownerName = friend.name,
                    avatar = friend.avatar,
                    id = pl.id,
                    name = pl.name,
                    songs = pl.songs,
                    count = pl.songs.size,
                    cover = pl.coverUri ?: pl.songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb,
                    likes = 0,
                    liked = false
                )
            }
            state = myPubs
            loading = false
            errorMsg = null
        } else {
            loading = true
            errorMsg = null
            val (err, data) = Social.userLists(friend.username, friend.name, friend.avatar)
            loading = false
            if (err != null && data == null) {
                errorMsg = err
            } else {
                state = data
            }
        }
    }

    val inboxPubs = remember(inbox, friend.username, friend.name) {
        if (isMe) emptyList()
        else inbox.filter {
            it.from.equals(friend.name, ignoreCase = true) || it.from.equals(friend.username, ignoreCase = true)
        }.map { sl ->
            PubList(
                owner = friend.username,
                ownerName = friend.name,
                avatar = friend.avatar,
                id = sl.id,
                name = sl.name,
                songs = sl.songs,
                count = sl.songs.size,
                cover = sl.songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb,
                likes = 0,
                liked = false
            )
        }
    }

    val serverPubs = state ?: emptyList()
    val st = remember(serverPubs, inboxPubs) {
        (serverPubs + inboxPubs).distinctBy { it.id }
    }

    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable { expanded = !expanded }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.QueueMusic, null, tint = Accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                if (loading && st.isEmpty()) "Çalma Listeleri" else "Çalma Listeleri (${st.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.weight(1f)
            )
            Icon(
                if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                contentDescription = if (expanded) "Listeyi Gizle" else "Listeyi Göster",
                tint = SMuted,
                modifier = Modifier.size(24.dp)
            )
        }
        AnimatedVisibility(expanded) {
            when {
                loading && st.isEmpty() -> {
                    Surface(
                        color = Card,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Accent,
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(10.dp))
                            Text("Listeler yükleniyor...", color = SMuted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                errorMsg != null && st.isEmpty() -> {
                    Surface(
                        color = Card,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "Listeler alınamadı: $errorMsg",
                                color = SMuted,
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(8.dp))
                            TextButton({ retryCount++ }) {
                                Icon(Icons.Filled.Refresh, null, Modifier.size(16.dp), tint = Accent)
                                Spacer(Modifier.width(6.dp))
                                Text("Tekrar dene", color = Accent)
                            }
                        }
                    }
                }
                st.isEmpty() -> {
                    Surface(
                        color = Card,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Text(
                            if (isMe) "Henüz herkese açık bir listen yok. Kitaplık > Listelerim'den bir listeni 'Herkese açık' yaparak profilinde arkadaşlarının görmesini sağlayabilirsin."
                            else "${friend.name} henüz herkese açık bir çalma listesi paylaşmadı.",
                            color = SMuted,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                else -> {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(20.dp)).background(Card)) {
                        st.forEachIndexed { i, l ->
                            PubListRow(l) { onOpen(l) }
                            if (i < st.size - 1) HorizontalDivider(Modifier.padding(start = 76.dp), color = Color(0x14FFFFFF))
                        }
                    }
                }
            }
        }
    }
}

/** Herkese açık liste satırı: albüm kapağı, ad, şarkı sayısı ve beğeni sayısı. */
@Composable
private fun PubListRow(l: PubList, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        PlaylistCover(listOf(Song(l.name, "", "", l.cover ?: l.songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb)), 52.dp, l.cover)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(l.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${l.ownerName} · ${l.count} şarkı", color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(if (l.liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, Modifier.size(16.dp), tint = if (l.liked) Accent else SMuted)
        Spacer(Modifier.width(4.dp))
        Text("${l.likes}", color = SMuted, style = MaterialTheme.typography.bodySmall)
    }
}

/** Keşfet'te yatay kaydırılan herkese açık liste kartı: büyük albüm kapağı, ad ve sahibi. */
@Composable
private fun PubListCard(l: PubList, onClick: () -> Unit) {
    val tint = tintFor(l.name)
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(Modifier.size(150.dp).clip(RoundedCornerShape(14.dp)).background(Card), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LibraryMusic, null, tint = SMuted, modifier = Modifier.size(52.dp))
            val cover = l.cover ?: l.songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb
            if (cover != null) AsyncImage(hiRes(cover, 400), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = 0.45f)))))
            Row(
                Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Favorite, null, Modifier.size(12.dp), tint = if (l.liked) Accent else Color.White)
                Spacer(Modifier.width(4.dp))
                Text("${l.likes}", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
        Text(l.name, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text("${l.ownerName} · ${l.count} şarkı", color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Herkese açık listeler (en çok beğenilenler önde). [horizontal] true ise Keşfet'te kartlar yatay kayar,
 * değilse Arkadaşlar sekmesinde satır satır görünür. Dokununca liste açılır; açılamazsa nedeni söylenir.
 */
@Composable
fun PublicListsSection(horizontal: Boolean = false, onOpen: (PubList) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var lists by remember { mutableStateOf<List<PubList>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var opening by remember { mutableStateOf(false) }
    LaunchedEffect(reload) {
        loading = true; error = null
        val (e, data) = Social.publicLists()
        error = e; lists = data; loading = false
    }
    val open: (PubList) -> Unit = open@{ l ->
        if (opening) return@open
        opening = true
        scope.launch {
            val (err, full) = Social.publicList(l)
            opening = false
            if (full != null) onOpen(full) else Toast.makeText(ctx, err ?: "Liste açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }
    Column(Modifier.fillMaxWidth().padding(top = if (horizontal) 14.dp else 8.dp)) {
        if (horizontal) Text("Herkese açık listeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        else Text("HERKESE AÇIK LİSTELER", color = SMuted, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 6.dp))
        val st = lists
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Accent, strokeWidth = 2.dp)
            }
            error != null -> Column(Modifier.padding(horizontal = 20.dp)) {
                Text(error ?: "", color = Accent, style = MaterialTheme.typography.bodySmall)
                TextButton({ reload++ }) { Text("Tekrar dene") }
            }
            st.isNullOrEmpty() -> Text("Henüz herkese açık liste yok. Kendi listeni açıp ⋮ menüsünden \"Herkese açık yap\" ile paylaşabilirsin.",
                color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 20.dp))
            horizontal -> LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(st, key = { it.owner + "/" + it.id }) { l -> PubListCard(l) { open(l) } }
            }
            else -> Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card)) {
                st.forEachIndexed { i, l ->
                    PubListRow(l) { open(l) }
                    if (i < st.size - 1) HorizontalDivider(Modifier.padding(start = 76.dp), color = Color(0x14FFFFFF))
                }
            }
        }
    }
}

/** Herkese açık bir liste: kapak, çal / karıştır, beğen ve kendi kitaplığına kaydet. */
@Composable
fun FriendListScreen(list: PubList, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    var curList by remember(list.id) { mutableStateOf(list) }
    var saved by remember(list.id) { mutableStateOf(false) }
    var liked by remember(list.id) { mutableStateOf(list.liked) }
    var likes by remember(list.id) { mutableIntStateOf(list.likes) }
    var shareDialog by remember { mutableStateOf(false) }
    val own = me != null && me.equals(curList.owner, ignoreCase = true)
    // Liste açılınca şarkılar boşsa sunucudan yüklenir, ardından ilk şarkılar hazırlanır
    LaunchedEffect(list.id) {
        if (curList.songs.isEmpty()) {
            val (_, fetched) = Social.publicList(list)
            if (fetched != null) curList = fetched
        }
        if (curList.songs.isNotEmpty()) {
            MusicRepository.prefetchAll(curList.songs, 12)
        }
    }
    SongList(curList.songs, header = {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
                Spacer(Modifier.weight(1f))
                IconButton({ shareDialog = true }) { Icon(Icons.Filled.Share, "WhatsApp veya Instagram'da Paylaş", tint = Color.White) }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                PlaylistCover(curList.songs, 180.dp, curList.cover)
                Spacer(Modifier.height(14.dp))
                Text(curList.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${curList.ownerName} · ${curList.songs.size} şarkı", color = SMuted, style = MaterialTheme.typography.bodyMedium)
                if (!own) Row(
                    Modifier.padding(top = 10.dp).clip(RoundedCornerShape(50)).background(if (liked) Accent.copy(alpha = 0.22f) else Card)
                        .clickable {
                            val want = !liked
                            liked = want; likes += if (want) 1 else -1
                            scope.launch {
                                val (e, n) = Social.likeList(curList.owner, curList.id, want)
                                if (e != null) { liked = !want; likes += if (want) -1 else 1; Toast.makeText(ctx, e, Toast.LENGTH_SHORT).show() }
                                else if (n != null) likes = n
                            }
                        }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", Modifier.size(20.dp), tint = if (liked) Accent else Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text(if (likes > 0) "$likes beğeni" else "Beğen")
                } else Text("$likes beğeni", color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        { PlayerManager.playQueue(curList.songs, 0) }, Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal") }
                    OutlinedButton({ PlayerManager.playQueue(curList.songs.shuffled(), 0) }, Modifier.weight(1f)) {
                        Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
                    }
                }
                OutlinedButton(
                    {
                        Playlists.create("${curList.name} (${curList.ownerName})", curList.songs)
                        saved = true
                        Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                    },
                    enabled = !saved, modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(if (saved) Icons.Filled.Check else Icons.Filled.PlaylistAdd, null); Spacer(Modifier.width(6.dp))
                    Text(if (saved) "Kitaplığına kaydedildi" else "Kitaplığıma kaydet")
                }
            }
        }
    })
    if (shareDialog) {
        SharePlaylistDialog(PlaylistShareInfo(title = list.name, subtitle = "${list.ownerName} • ${list.songs.size} şarkı", cover = list.cover, id = list.id, user = list.owner)) {
            shareDialog = false
        }
    }
}
