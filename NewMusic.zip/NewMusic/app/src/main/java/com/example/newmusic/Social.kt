package com.example.newmusic

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/*
 * SOSYAL ÖZELLİKLER (arkadaşlar, çevrim içi/dışı, ne dinlediği, profil fotoğrafı, liste paylaşımı)
 * Sunucu: backend/ klasörü (Render). Adres boşsa sosyal özellikler gizlenir.
 */
const val SOCIAL_API_URL = "https://new-music-cpzw.onrender.com"

data class StatusItem(val text: String, val song: Song? = null, val createdAt: Long = System.currentTimeMillis())
data class SocialPerson(val username: String, val avatar: String?, val name: String = username)
data class SocialFriend(
    val username: String,
    val online: Boolean,
    val lastSeen: Long,
    val avatar: String? = null,
    val listening: Song? = null,
    val name: String = username,
    val profileSong: Song? = null,
    val status: StatusItem? = null
)
data class SharedList(val id: String, val from: String, val name: String, val songs: List<Song>)
/** Herkese açık bir çalma listesi (keşfette özet, açılınca şarkılarla). */
data class PubList(
    val owner: String, val ownerName: String, val avatar: String?, val id: String, val name: String,
    val songs: List<Song>, val count: Int, val cover: String?, val likes: Int, val liked: Boolean
)

object Social {
    /** Benzersiz arkadaş kimliği (e-postadan otomatik üretilir, değişmez). */
    val username = MutableStateFlow<String?>(null)
    /** Görünen ad: istenildiği gibi yazılır, benzersiz olmak zorunda değil. */
    val displayName = MutableStateFlow<String?>(null)
    val myAvatar = MutableStateFlow<String?>(null)
    val friends = MutableStateFlow<List<SocialFriend>>(emptyList())
    val incoming = MutableStateFlow<List<SocialPerson>>(emptyList())
    val outgoing = MutableStateFlow<List<SocialPerson>>(emptyList())
    val inbox = MutableStateFlow<List<SharedList>>(emptyList())
    /** Açıkken çevrim içi arkadaşların şu an çalan şarkını görür. */
    val showListening = MutableStateFlow(true)
    val myProfileSong = MutableStateFlow<Song?>(null)
    val myStatus = MutableStateFlow<StatusItem?>(null)

    val enabled: Boolean get() = SOCIAL_API_URL.isNotBlank()
    val joined: Boolean get() = token != null

    private var prefs: SharedPreferences? = null
    private var token: String? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var loop: Job? = null
    private var watcher: Job? = null
    private const val JSON = "application/json; charset=utf-8"

    // Uygulama görünürken 5 sn, arka planda müzik çalarken 15 sn'de bir sinyal gönderilir.
    private const val FG_TICK = 5_000L
    private const val BG_TICK = 15_000L
    // Arka plana geçip müzik de çalmıyorsa bu süre sonra çevrim dışı olunur (haritaya kısa bakmak vb. için tolerans).
    private const val GRACE_MS = 60_000L
    @Volatile private var joining = false
    @Volatile private var foreground = false
    @Volatile private var lastActiveAt = 0L

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        token = p.getString("social_token", null)
        username.value = p.getString("social_name", null)
        showListening.value = p.getBoolean("social_show_listening", true)
        // Render ücretsiz sunucusu uykudaysa 30-60 sn'de uyanır; uygulama açılır açılmaz uyandır
        if (enabled) scope.launch {
            try { Http.server.newCall(Request.Builder().url(SOCIAL_API_URL).get().build()).execute().close() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { }
        }
    }

    /** Hesaba giriş yapılınca sunucudaki kullanıcı adı ve anahtar bu cihaza gelir (yeniden kurulumdan sonra arkadaşlar kaybolmaz). */
    fun restore(name: String, tok: String) {
        token = tok
        username.value = name
        prefs?.edit()?.putString("social_token", tok)?.putString("social_name", name)?.apply()
        start()
        scope.launch { refresh() }
        LibrarySync.syncSoon(force = true)   // beğeniler ve listeler hesaptan geri gelir
    }

    /** Hesaptan çıkınca bu cihazdaki sosyal oturum kapanır; sunucudaki hesap ve arkadaşlar silinmez. */
    fun signOutLocal() {
        loop?.cancel(); loop = null
        watcher?.cancel(); watcher = null
        token = null
        username.value = null; displayName.value = null; myAvatar.value = null
        friends.value = emptyList(); incoming.value = emptyList(); outgoing.value = emptyList(); inbox.value = emptyList()
        myProfileSong.value = null; myStatus.value = null
        prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
    }

    fun setShowListening(on: Boolean) {
        showListening.value = on
        prefs?.edit()?.putBoolean("social_show_listening", on)?.apply()
    }

    private fun parseSongsArr(sa: JSONArray?): List<Song> =
        (if (sa == null) emptyList() else (0 until sa.length()).mapNotNull { j -> try { sa.getJSONObject(j).toSong() } catch (e: Exception) { null } }).noAi()

    /** Bir kullanıcının HERKESE AÇIK çalma listeleri. Hata varsa (mesaj, null), başarılıysa (null, liste) döner. */
    suspend fun userLists(username: String, ownerName: String = username, avatar: String? = null): Pair<String?, List<PubList>?> {
        val r = call("/social/user-lists", JSONObject().put("username", username))
        val err = errorOf(r, "Listeler yüklenemedi.")
        if (err != null) return err to null
        val arr = r!!.body.optJSONArray("lists")
        val lists = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                val songs = parseSongsArr(o.optJSONArray("songs"))
                if (songs.isEmpty()) null else PubList(username, ownerName, avatar, o.optString("id"), o.optString("name").ifBlank { "Liste" },
                    songs, songs.size, songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb, o.optInt("likes"), o.optBoolean("liked"))
            } catch (e: Exception) { null }
        }
        return null to lists
    }

    /**
     * Herkese açık tek bir listeyi şarkılarıyla getirir (Keşfet'ten açılırken).
     * Hata varsa (mesaj, null), başarılıysa (null, liste) döner.
     */
    suspend fun publicList(summary: PubList): Pair<String?, PubList?> {
        val r = call("/social/public-list", JSONObject().put("username", summary.owner).put("id", summary.id))
        val err = errorOf(r, "Liste açılamadı.")
        if (err != null) return err to null
        val o = r!!.body.optJSONObject("list") ?: return "Liste artık herkese açık değil." to null
        val songs = parseSongsArr(o.optJSONArray("songs"))
        if (songs.isEmpty()) return "Bu listede çalınabilir şarkı yok." to null
        return null to summary.copy(
            name = o.optString("name").ifBlank { summary.name }, songs = songs, count = songs.size,
            cover = songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb ?: summary.cover,
            likes = o.optInt("likes", summary.likes), liked = o.optBoolean("liked", summary.liked)
        )
    }

    /** Keşfet: herkese açık listeler, en çok beğenilenler önde. Şarkılar liste açılınca yüklenir. */
    suspend fun publicLists(): Pair<String?, List<PubList>?> {
        val r = call("/social/public-lists", JSONObject())
        val err = errorOf(r, "Herkese açık listeler yüklenemedi.")
        if (err != null) return err to null
        val arr = r!!.body.optJSONArray("lists")
        val lists = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                PubList(o.optString("owner"), o.optString("ownerName").ifBlank { o.optString("owner") }, avatarOf(o), o.optString("id"),
                    o.optString("name").ifBlank { "Liste" }, emptyList(), o.optInt("count"),
                    if (o.isNull("cover")) null else o.optString("cover").ifBlank { null }, o.optInt("likes"), o.optBoolean("liked"))
            } catch (e: Exception) { null }
        }
        return null to lists
    }

    /** Herkese açık bir listeyi beğen / vazgeç. Başarılıysa (null, yeni beğeni sayısı). */
    suspend fun likeList(owner: String, id: String, like: Boolean): Pair<String?, Int?> {
        val r = call("/social/list-like", JSONObject().put("username", owner).put("id", id).put("like", like))
        val err = errorOf(r, "Beğenilemedi.")
        return if (err != null) err to null else null to r!!.body.optInt("likes")
    }

    fun avatarUrl(id: String?): String? =
        if (id.isNullOrBlank() || !enabled) null else SOCIAL_API_URL.trimEnd('/') + "/social/avatar/" + id

    // ---------------------------------------------------------------- çevrim içi sinyali

    /** Uygulama öne gelince çağrılır. */
    fun start() {
        foreground = true
        lastActiveAt = System.currentTimeMillis()
        // Giriş yapılmış ama arkadaş kimliği henüz bu cihaza gelmediyse (eski sürüm, ağ hatası) şimdi alınır;
        // böylece beğeniler ve herkese açık listeler hesaba yüklenebilir.
        if (enabled && token == null && AuthStore.session != null && !joining) {
            joining = true
            scope.launch { try { join("") } finally { joining = false } }
        }
        if (!enabled || token == null) return
        if (watcher?.isActive != true) {
            // Uygulama arka plandayken müzik başlarsa (örn. arabadan) yeniden çevrim içi ol
            watcher = scope.launch { PlayerManager.playing.collect { if (it) ensureLoop() } }
        }
        ensureLoop()
        LibrarySync.syncSoon()
    }

    /** Uygulama arka plana gidince çağrılır. Müzik çalıyorsa çevrim içi kalınır. */
    fun stop() {
        foreground = false
        lastActiveAt = System.currentTimeMillis()
        LibrarySync.flush()
    }

    @Synchronized
    private fun ensureLoop() {
        if (!enabled || token == null || loop?.isActive == true) return
        loop = scope.launch {
            val outer = this
            launch {
                var ticks = 0
                while (isActive && token != null) {
                    val now = System.currentTimeMillis()
                    if (foreground || PlayerManager.playing.value) lastActiveAt = now
                    if (now - lastActiveAt > GRACE_MS) {
                        call("/social/offline", JSONObject())
                        break
                    }
                    sendHeartbeat()
                    if (ticks++ % 12 == 0) pushTaste()   // Blend için zevk bilgisi (yalnızca arkadaşların görür)
                    delay(if (foreground) FG_TICK else BG_TICK)
                }
                outer.cancel()
            }
            launch {
                // Şarkı değişince / durup başlayınca hemen bildir
                combine(PlayerManager.queue, PlayerManager.index, PlayerManager.playing, showListening) { _, _, _, _ -> Unit }
                    .collectLatest { delay(300); sendHeartbeat() }
            }
        }
    }

    /** Çalan şarkıyı da içeren sinyal. Sunucu yanıt olarak güncel arkadaş listesini döner. */
    private suspend fun sendHeartbeat() {
        val json = JSONObject()
        if (showListening.value && PlayerManager.playing.value) {
            val s = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
            if (s != null) json.put("playing", JSONObject()
                .put("title", s.title).put("artist", s.artist).put("url", s.url).put("thumb", s.thumb ?: JSONObject.NULL))
        }
        val r = call("/social/heartbeat", json)
        if (r != null && r.code in 200..299) applySnapshot(r.body) else errorOf(r, "")
    }

    // ---------------------------------------------------------------- ağ

    internal class Result(val code: Int, val body: JSONObject)

    internal suspend fun call(path: String, json: JSONObject): Result? = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(SOCIAL_API_URL.trimEnd('/') + path)
                .post(json.toString().toRequestBody(JSON.toMediaType()))
            token?.let { b.header("Authorization", "Bearer $it") }
            Http.server.newCall(b.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                Result(r.code, try { JSONObject(text) } catch (e: Exception) { JSONObject() })
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { null }
    }

    private fun errorOf(r: Result?, fallback: String): String? = when {
        r == null -> "Sunucuya bağlanılamadı. İnternetini kontrol et; sunucu uykudaysa 1 dakika sonra tekrar dene."
        r.code in 200..299 -> null
        r.code == 401 -> { // anahtar sunucuda yok (sunucu sıfırlanmış olabilir)
            token = null; username.value = null; myAvatar.value = null
            prefs?.edit()?.remove("social_token")?.remove("social_name")?.apply()
            "Sosyal hesabın sunucuda bulunamadı. Yeniden kullanıcı adı al."
        }
        else -> r.body.optString("error").ifBlank { if (r.code >= 500) "Sunucu hatası. Biraz sonra tekrar dene." else fallback }
    }

    private fun avatarOf(o: JSONObject): String? = if (o.isNull("avatar")) null else o.optString("avatar").ifBlank { null }

    /** Sunucudan gelen özeti (ben, arkadaşlar, istekler) ekrana yansıtır. */
    private suspend fun applySnapshot(b: JSONObject) {
        b.optJSONObject("me")?.let { m ->
            val n = m.optString("username")
            if (n.isNotBlank() && n != username.value) {
                username.value = n
                prefs?.edit()?.putString("social_name", n)?.apply()
            }
            myAvatar.value = avatarOf(m)
            displayName.value = m.optString("name").ifBlank { null } ?: n.ifBlank { null }
            myProfileSong.value = parseSong(m.optJSONObject("profileSong"))
            myStatus.value = parseStatus(m.optJSONObject("status"))
        }
        friends.value = b.optJSONArray("friends").toList { o ->
            val l = o.optJSONObject("listening")
            // Sunucu "ne kadar önce" bilgisini yollar: telefon saati yanlış olsa da son görülme doğru çıkar
            val ago = o.optLong("seenAgo", -1L)
            val seen = if (ago >= 0) System.currentTimeMillis() - ago else o.optLong("lastSeen")
            SocialFriend(
                o.getString("username"), o.optBoolean("online"), seen, avatarOf(o),
                l?.let { Song(it.optString("title"), it.optString("artist"), it.optString("url"),
                    if (it.isNull("thumb")) null else it.optString("thumb").ifBlank { null }) },
                o.optString("name").ifBlank { o.getString("username") },
                profileSong = parseSong(o.optJSONObject("profileSong")),
                status = parseStatus(o.optJSONObject("status"))
            )
        }.sortedWith(compareByDescending<SocialFriend> { it.listening != null }
            .thenByDescending { it.online }.thenBy { it.username.lowercase() })
        incoming.value = b.optJSONArray("incoming").toList { SocialPerson(it.getString("username"), avatarOf(it), it.optString("name").ifBlank { it.getString("username") }) }
        outgoing.value = b.optJSONArray("outgoing").toList { SocialPerson(it.getString("username"), avatarOf(it), it.optString("name").ifBlank { it.getString("username") }) }
        val n = b.optInt("inbox", -1)
        if (n >= 0 && n != inbox.value.size) fetchInbox()
    }

    private suspend fun fetchInbox() {
        val ib = call("/social/inbox", JSONObject())
        if (ib != null && ib.code in 200..299) {
            inbox.value = ib.body.optJSONArray("items").toList { o ->
                val sa = o.optJSONArray("songs") ?: JSONArray()
                SharedList(
                    o.getString("id"), o.optString("from"), o.optString("name"),
                    (0 until sa.length()).map { j ->
                        val s = sa.getJSONObject(j)
                        Song(s.optString("title"), s.optString("artist"), s.optString("url"),
                            if (s.isNull("thumb")) null else s.optString("thumb").ifBlank { null })
                    }
                )
            }
        }
    }

    // ---------------------------------------------------------------- işlemler

    /** Kullanıcı adı alır. Hesaba giriş yapılmışsa kullanıcı adı hesaba bağlanır. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun join(name: String): String? {
        val clean = name.trim().removePrefix("@")
        val session = AuthStore.session
        if (session != null) {
            val (err, uname, tok) = AuthApi.socialJoin(session, clean)
            if (err != null) return err
            val un = uname ?: return "Hesap oluşturulamadı."
            val tk = tok ?: return "Hesap oluşturulamadı."
            restore(un, tk)
            return null
        }
        val r = call("/social/join", JSONObject().put("username", clean))
        val err = errorOf(r, "Hesap oluşturulamadı.")
        if (err != null) return err
        token = r!!.body.optString("token")
        username.value = r.body.optString("username")
        prefs?.edit()?.putString("social_token", token)?.putString("social_name", username.value)?.apply()
        start()
        return null
    }

    /** Görünen adı değiştirir (herkes istediği adı yazabilir). Hata varsa mesajı, başarılıysa null döner. */
    suspend fun setDisplayName(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Ad boş olamaz."
        val r = call("/social/display-name", JSONObject().put("name", n.take(30)))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        displayName.value = n.take(30)
        refresh()
        return null
    }

    /** Kullanıcı adını değiştirir. Hata varsa mesajı, başarılıysa null döner. */
    suspend fun rename(name: String): String? {
        val r = call("/social/rename", JSONObject().put("username", name.trim()))
        val err = errorOf(r, "Ad değiştirilemedi.")
        if (err != null) return err
        username.value = r!!.body.optString("username")
        prefs?.edit()?.putString("social_name", username.value)?.apply()
        refresh()
        return null
    }

    suspend fun refresh() {
        if (token == null) return
        val r = call("/social/friends", JSONObject())
        if (r != null && r.code in 200..299) applySnapshot(r.body) else errorOf(r, "")
    }

    /** Seçilen resmi kare kırpıp 256x256 JPEG yaparak profil fotoğrafı olarak yükler. */
    suspend fun setAvatar(ctx: Context, uri: Uri): String? {
        if (token == null) return "Önce kullanıcı adı al."
        val bytes: ByteArray = withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: return@withContext null
                val side = minOf(bmp.width, bmp.height)
                val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
                val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)
                var q = 85
                var out = ByteArray(0)
                do {
                    val bos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, q, bos)
                    out = bos.toByteArray()
                    q -= 10
                } while (out.size > 55_000 && q > 30)
                out
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { null }
        } ?: return "Fotoğraf okunamadı."
        val r = call("/social/avatar-set", JSONObject().put("image", Base64.encodeToString(bytes, Base64.NO_WRAP)))
        val err = errorOf(r, "Fotoğraf yüklenemedi.")
        if (err != null) return err
        myAvatar.value = r!!.body.optString("avatar").ifBlank { null }
        refresh()
        return null
    }

    suspend fun clearAvatar(): String? {
        val err = errorOf(call("/social/avatar-clear", JSONObject()), "Fotoğraf kaldırılamadı.")
        if (err == null) { myAvatar.value = null; refresh() }
        return err
    }

    suspend fun sendRequest(name: String): String? {
        val n = name.trim().removePrefix("@")
        if (!Regex("^[A-Za-z0-9_.]{3,20}$").matches(n)) return "Kullanıcı adı 3-20 karakter olmalı (harf, rakam, _ ve .)."
        return errorOf(call("/social/friend-request", JSONObject().put("username", n)), "İstek gönderilemedi.").also { refresh() }
    }

    // ---------------------------------------------------------------- Blend (uyum oranı)

    private var lastTaste = ""

    /** En çok dinlenen sanatçılarımı sunucuya yollar; yalnızca arkadaşlar Blend'de görür. */
    suspend fun pushTaste(force: Boolean = false) {
        if (token == null) return
        try {
            val top = withContext(Dispatchers.Main) { TasteProfile.topArtistsWeighted(25) }
            if (top.isEmpty()) return
            val arr = JSONArray()
            top.forEach { arr.put(JSONObject().put("n", it.first).put("w", it.second)) }
            val sig = arr.toString()
            if (!force && sig == lastTaste) return
            val r = call("/social/taste-set", JSONObject().put("artists", arr))
            if (r != null && r.code in 200..299) lastTaste = sig
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { }
    }

    /** Arkadaşımla iki tarafın zevkini getirir. Hata varsa (mesaj, null), başarılıysa (null, veri) döner. */
    suspend fun blendWith(friend: String): Pair<String?, BlendPair?> {
        pushTaste(force = true)
        val r = call("/social/blend", JSONObject().put("username", friend))
        val err = errorOf(r, "Blend yüklenemedi.")
        if (err != null) return err to null
        val b = r!!.body
        fun parse(o: JSONObject?): List<WArtist> =
            o?.optJSONArray("artists").toList { WArtist(it.optString("n"), it.optInt("w", 1)) }.filter { it.name.isNotBlank() }
        return null to BlendPair(parse(b.optJSONObject("me")), parse(b.optJSONObject("friend")))
    }

    suspend fun respond(name: String, accept: Boolean): String? =
        errorOf(call("/social/friend-respond", JSONObject().put("username", name).put("accept", accept)), "İşlem yapılamadı.").also { refresh() }

    suspend fun remove(name: String): String? =
        errorOf(call("/social/friend-remove", JSONObject().put("username", name)), "Silinemedi.").also { refresh() }

    /** Listeyi seçilen arkadaşlara gönderir. Cihazdan yüklenen şarkılar atlanır. */
    suspend fun share(to: List<String>, name: String, songs: List<Song>): String? {
        val arr = JSONArray()
        songs.filterNot { Uploads.isLocal(it) }.forEach {
            arr.put(JSONObject().put("title", it.title).put("artist", it.artist).put("url", it.url).put("thumb", it.thumb ?: JSONObject.NULL))
        }
        if (arr.length() == 0) return "Paylaşılacak şarkı yok. Cihazdan yüklenen şarkılar paylaşılamaz."
        val r = call("/social/share", JSONObject().put("to", JSONArray(to)).put("name", name).put("songs", arr))
        return errorOf(r, "Paylaşılamadı.")
    }

    suspend fun dismiss(id: String) {
        call("/social/inbox-dismiss", JSONObject().put("id", id))
        refresh()
    }

    suspend fun setProfileSong(s: Song): String? {
        val r = call("/social/profile-song-set", JSONObject().put("song", s.toJson()))
        val err = errorOf(r, "Profil müziği ayarlanamadı.")
        if (err == null) {
            myProfileSong.value = s
            refresh()
        }
        return err
    }

    suspend fun clearProfileSong(): String? {
        val r = call("/social/profile-song-clear", JSONObject())
        val err = errorOf(r, "Profil müziği kaldırılamadı.")
        if (err == null) {
            myProfileSong.value = null
            refresh()
        }
        return err
    }

    suspend fun setStatus(text: String, s: Song? = null): String? {
        val obj = JSONObject().put("text", text)
        if (s != null) obj.put("song", s.toJson())
        val r = call("/social/status-set", obj)
        val err = errorOf(r, "Durum paylaşılamadı.")
        if (err == null) {
            myStatus.value = StatusItem(text, s, System.currentTimeMillis())
            refresh()
        }
        return err
    }

    suspend fun clearStatus(): String? {
        val r = call("/social/status-clear", JSONObject())
        val err = errorOf(r, "Durum kaldırılamadı.")
        if (err == null) {
            myStatus.value = null
            refresh()
        }
        return err
    }

    fun parseSong(o: JSONObject?): Song? {
        if (o == null) return null
        val t = o.optString("title").ifEmpty { o.optString("t") }
        val a = o.optString("artist").ifEmpty { o.optString("a") }
        val u = o.optString("url").ifEmpty { o.optString("u") }
        val i = if (o.isNull("thumb")) o.optString("i").ifEmpty { null } else o.optString("thumb").ifEmpty { null }
        if (t.isEmpty() && u.isEmpty()) return null
        return Song(t, a, u, i)
    }

    fun parseStatus(o: JSONObject?): StatusItem? {
        if (o == null) return null
        val text = o.optString("text")
        val song = parseSong(o.optJSONObject("song"))
        val created = o.optLong("createdAt", System.currentTimeMillis())
        return StatusItem(text, song, created)
    }

    private fun <T> JSONArray?.toList(f: (JSONObject) -> T): List<T> =
        if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }
}


@Composable
fun AvatarZoomDialog(avatarId: String?, name: String, onDismiss: () -> Unit) {
    val url = Social.avatarUrl(avatarId)
    Dialog(onDismissRequest = onDismiss) {
        Box(
            Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .clip(RoundedCornerShape(26.dp))
                .background(Card)
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Color.White)
                    }
                }
                Box(
                    Modifier
                        .size(260.dp)
                        .clip(CircleShape)
                        .background(avatarColors[(name.lowercase().hashCode() and 0x7fffffff) % avatarColors.size]),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        name.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 84.sp
                    )
                    if (url != null) {
                        AsyncImage(
                            model = url,
                            contentDescription = name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun CreateStatusDialog(
    currentSong: Song?,
    onDismiss: () -> Unit,
    onPost: (String, Song?) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var attachSong by remember { mutableStateOf(currentSong != null) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .padding(20.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Durum Paylaş", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Kapat", tint = SMuted) }
            }
            Text("Durumun 24 saat boyunca arkadaşlarına görünür.", color = SMuted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { if (it.length <= 150) text = it },
                placeholder = { Text("Aklından ne geçiyor?", color = SMuted) },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                shape = RoundedCornerShape(16.dp)
            )
            if (currentSong != null) {
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.25f))
                        .clickable { attachSong = !attachSong }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.MusicNote, null, tint = Accent)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(currentSong.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(currentSong.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    Checkbox(checked = attachSong, onCheckedChange = { attachSong = it })
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { onPost(text.trim(), if (attachSong) currentSong else null) },
                enabled = text.isNotBlank() || (attachSong && currentSong != null),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
            ) {
                Text("Paylaş")
            }
        }
    }
}

@Composable
fun ViewStatusDialog(
    person: SocialPerson,
    status: StatusItem,
    isMe: Boolean,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(person.name, person.avatar, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(person.name, fontWeight = FontWeight.Bold, color = Color.White)
                    val mins = ((System.currentTimeMillis() - status.createdAt) / 60000).coerceAtLeast(1)
                    val timeStr = if (mins < 60) "$mins dk önce" else "${mins / 60} saat önce"
                    Text(timeStr, color = SMuted, style = MaterialTheme.typography.bodySmall)
                }
                if (isMe && onDelete != null) {
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Durumu Sil", tint = Color(0xFFE84393)) }
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Kapat", tint = SMuted) }
            }
            Spacer(Modifier.height(16.dp))
            if (status.text.isNotBlank()) {
                Text(status.text, style = MaterialTheme.typography.bodyLarge, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp))
            }
            if (status.song != null) {
                val s = status.song
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.horizontalGradient(listOf(Accent.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.3f))))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(10.dp)).background(Accent.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.MusicNote, null, tint = Accent)
                        if (s.thumb != null) AsyncImage(model = s.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    IconButton(
                        onClick = { PlayerManager.playQueue(listOf(s), 0) },
                        modifier = Modifier.clip(CircleShape).background(Accent)
                    ) {
                        Icon(Icons.Filled.PlayArrow, "Çal", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun PickProfileSongDialog(
    favorites: List<Song>,
    currentSong: Song?,
    onDismiss: () -> Unit,
    onPick: (Song) -> Unit
) {
    val songs = listOfNotNull(currentSong) + favorites.filter { it.url != currentSong?.url }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 480.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .padding(20.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Profil Müziği Seç", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Kapat", tint = SMuted) }
            }
            Text("Profilini ziyaret edenlerin dinlemesi için bir şarkı seç:", color = SMuted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp))
            if (songs.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                    Text("Henüz bir şarkı çalmadın veya beğenmedin.", color = SMuted)
                }
            } else {
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    items(songs) { s ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onPick(s) }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(Accent.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.MusicNote, null, tint = Accent)
                                if (s.thumb != null) AsyncImage(model = s.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusStoriesRow(
    friends: List<SocialFriend>,
    myAvatar: String?,
    myName: String,
    myStatus: StatusItem?,
    onAddStatus: () -> Unit,
    onViewStatus: (SocialPerson, StatusItem) -> Unit
) {
    val activeFriends = friends.filter { it.status != null }
    LazyRow(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable {
                    if (myStatus != null) onViewStatus(SocialPerson(myName, myAvatar, myName), myStatus)
                    else onAddStatus()
                }
            ) {
                Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
                    if (myStatus != null) {
                        Box(
                            Modifier.fillMaxSize().clip(CircleShape)
                                .border(2.5.dp, Brush.sweepGradient(listOf(Accent, Color(0xFF00B894), Accent)), CircleShape)
                        )
                    }
                    UserAvatar(myName, myAvatar, 52.dp)
                    if (myStatus == null) {
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(Accent),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Add, "Durum Ekle", tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(if (myStatus != null) "Durumum" else "Durum ekle", style = MaterialTheme.typography.labelSmall, maxLines = 1, color = Color.White)
            }
        }

        items(activeFriends, key = { "st_" + it.username }) { f ->
            val st = f.status ?: return@items
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable {
                    onViewStatus(SocialPerson(f.username, f.avatar, f.name), st)
                }
            ) {
                Box(Modifier.size(62.dp), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.fillMaxSize().clip(CircleShape)
                            .border(2.5.dp, Brush.sweepGradient(listOf(Accent, Color(0xFF00B894), Accent)), CircleShape)
                    )
                    UserAvatar(f.name, f.avatar, 52.dp)
                }
                Spacer(Modifier.height(4.dp))
                Text(f.name.split(" ").firstOrNull() ?: f.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = Color.White)
            }
        }
    }
}
// ====================================================================== ARAYÜZ

private val SMuted = Color(0xFF9A9A9A)
private val OnlineGreen = Color(0xFF3DDC84)
private val OfflineGrey = Color(0xFF5A5A5A)
private val avatarColors = listOf(0xFF6C5CE7, 0xFF00B894, 0xFFE17055, 0xFF0984E3, 0xFFD63031, 0xFFE84393, 0xFFB7791F, 0xFF00A8B5).map { Color(it) }

/** Çevrim içiyken yazı yok (yeşil nokta yeter); çevrim dışıyken saatle: "Son görülme · bugün 14:32" (gri nokta ile). */
private fun lastSeenText(f: SocialFriend): String {
    if (f.online) return ""
    if (f.lastSeen <= 0) return "Son görülme · bilinmiyor"
    val seen = java.time.Instant.ofEpochMilli(f.lastSeen).atZone(java.time.ZoneId.systemDefault())
    val today = java.time.LocalDate.now()
    val clock = String.format(java.util.Locale.US, "%02d:%02d", seen.hour, seen.minute)
    return when (seen.toLocalDate()) {
        today -> "Son görülme · bugün $clock"
        today.minusDays(1) -> "Son görülme · dün $clock"
        else -> "Son görülme · " + String.format(java.util.Locale.US, "%02d.%02d.%d", seen.dayOfMonth, seen.monthValue, seen.year) + " $clock"
    }
}

/** Yeşil (çevrim içi) veya gri (çevrim dışı) durum noktası, yanında varsa yazı. */
@Composable
private fun StatusDot(online: Boolean, text: String = "", modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(if (online) OnlineGreen else OfflineGrey))
        if (text.isNotEmpty()) {
            Spacer(Modifier.width(6.dp))
            Text(text, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Yuvarlak profil resmi. Fotoğraf yoksa isme göre renkli baş harf gösterir; online verilirse köşede durum noktası olur. */
@Composable
fun UserAvatar(name: String, avatarId: String?, size: Dp, online: Boolean? = null, modifier: Modifier = Modifier) {
    val url = Social.avatarUrl(avatarId)
    Box(modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape)
                .background(avatarColors[(name.lowercase().hashCode() and 0x7fffffff) % avatarColors.size]),
            contentAlignment = Alignment.Center
        ) {
            Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
            if (url != null) AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
        if (online != null) {
            val dot = (size.value * 0.28f).coerceAtLeast(10f).dp
            Box(
                Modifier.align(Alignment.BottomEnd).size(dot).clip(CircleShape).background(Bg).padding(2.dp)
                    .clip(CircleShape).background(if (online) OnlineGreen else OfflineGrey)
            )
        }
    }
}

/** Küçük "müzik çalıyor" çubukları. */
@Composable
private fun EqualizerBars(color: Color) {
    val t = rememberInfiniteTransition(label = "eq")
    val bars = listOf(420, 560, 700).map { ms ->
        t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Reverse), label = "bar$ms")
    }
    Row(Modifier.height(14.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        bars.forEach { h -> Box(Modifier.width(3.dp).fillMaxHeight(h.value).clip(RoundedCornerShape(1.dp)).background(color)) }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SMuted,
        modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp))
}

/** "● 3" gibi: yeşil / gri nokta ve kişi sayısı (çevrim içi / dışı yazısı yerine). */
@Composable
private fun DotSectionTitle(online: Boolean, count: Int) {
    Row(Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        StatusDot(online)
        Spacer(Modifier.width(8.dp))
        Text("$count", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SMuted)
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card), content = content)
}

@Composable
private fun FriendMenu(onRemove: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü", tint = SMuted) }
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem(text = { Text("Arkadaşlıktan çıkar") }, leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                onClick = { menu = false; onRemove() })
        }
    }
}

/** Şu an müzik dinleyen arkadaş kartı: kapak, şarkı adı ve "sen de dinle" düğmesi. */
@Composable
private fun ListeningCard(f: SocialFriend, onOpen: () -> Unit, onRemove: () -> Unit) {
    val l = f.listening ?: return
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(22.dp)).background(Card).padding(12.dp)) {
        Row(Modifier.clip(RoundedCornerShape(16.dp)).clickable { onOpen() }, verticalAlignment = Alignment.CenterVertically) {
            UserAvatar(f.username, f.avatar, 46.dp, online = true)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EqualizerBars(OnlineGreen)
                    Spacer(Modifier.width(6.dp))
                    Text("şu an dinliyor", color = OnlineGreen, style = MaterialTheme.typography.bodySmall)
                }
            }
            BlendHint()
            FriendMenu(onRemove)
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Bg.copy(alpha = 0.55f)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.MusicNote, null, tint = Accent)
                if (l.thumb != null) AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(l.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (l.artist.isNotBlank()) Text(l.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (l.url.isNotBlank()) {
                IconButton({ PlayerManager.playQueue(listOf(l), 0) }, Modifier.clip(CircleShape).background(Accent)) {
                    Icon(Icons.Filled.PlayArrow, "Sen de dinle", tint = Color.White)
                }
            }
        }
    }
}

/** Arkadaş satırlarında profili açan ok işareti. */
@Composable
private fun BlendHint() {
    Icon(Icons.Filled.ChevronRight, "Profili aç", tint = SMuted, modifier = Modifier.padding(end = 4.dp))
}

@Composable
private fun FriendRow(f: SocialFriend, onOpen: () -> Unit, onRemove: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onOpen() }.padding(start = 14.dp, end = 2.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        UserAvatar(f.username, f.avatar, 44.dp, online = f.online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            StatusDot(f.online, lastSeenText(f))
        }
        BlendHint()
        FriendMenu(onRemove)
    }
}

/** Arkadaşlar sekmesi: profilin, arkadaş ekleme, arkadaş listesi (dokununca profili açılır), istekler ve gelen paylaşımlar. */
@Composable
fun FriendsTab(onOpenProfile: (SocialFriend) -> Unit = {}, onOpenAuth: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    val myDisplayName by Social.displayName.collectAsState()
    val myName = me ?: ""
    val myShown = myDisplayName ?: myName
    val clipboard = LocalClipboardManager.current
    val myAvatar by Social.myAvatar.collectAsState()
    val friends by Social.friends.collectAsState()
    val incoming by Social.incoming.collectAsState()
    val outgoing by Social.outgoing.collectAsState()
    val inbox by Social.inbox.collectAsState()
    val showListening by Social.showListening.collectAsState()
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var removeTarget by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var avatarMenu by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    var openedPub by remember { mutableStateOf<PubList?>(null) }
    var zoomAvatar by remember { mutableStateOf<Pair<String?, String>?>(null) }
    var statusDialogOpen by remember { mutableStateOf(false) }
    var viewStatus by remember { mutableStateOf<Pair<SocialPerson, StatusItem>?>(null) }
    var profileSongPickerOpen by remember { mutableStateOf(false) }
    val myProfileSong by Social.myProfileSong.collectAsState()
    val myStatus by Social.myStatus.collectAsState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            uploading = true
            val e = ProfilePhoto.set(ctx, uri)
            uploading = false
            Toast.makeText(ctx, e ?: "Profil fotoğrafın güncellendi", Toast.LENGTH_SHORT).show()
        }
    }

    // Sekme açılınca hemen güncelle; sonrası sinyal döngüsü her 5 sn'de yeniler
    LaunchedEffect(me) { if (me != null) { Social.start(); Social.refresh(); ProfilePhoto.syncUp(ctx) } }

    Column(Modifier.fillMaxSize()) {
        if (!Social.enabled) {
            Text("Sosyal özellikler henüz ayarlanmadı. Sunucuyu yayınlayıp Social.kt dosyasındaki SOCIAL_API_URL değerine adresini yaz (backend/README.md).",
                color = SMuted, modifier = Modifier.padding(20.dp))
            return@Column
        }

        if (me == null) {
            val signedIn = AuthStore.session != null
            // Giriş yapılmışsa arkadaş kimliği e-postadan otomatik oluşur; kullanıcı isim aramak zorunda kalmaz
            LaunchedEffect(signedIn) { if (signedIn) { busy = true; error = Social.join(""); busy = false } }
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(84.dp).clip(CircleShape).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.People, null, tint = Accent, modifier = Modifier.size(42.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("Arkadaşlarınla dinle", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (signedIn) {
                    Text("Hesabın hazırlanıyor...", color = SMuted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    if (busy) CircularProgressIndicator(color = Accent)
                    else {
                        error?.let { Text(it, color = Accent, textAlign = TextAlign.Center) }
                        Spacer(Modifier.height(8.dp))
                        Button(
                            { scope.launch { busy = true; error = Social.join(""); busy = false } },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                        ) { Text("Tekrar dene") }
                    }
                } else {
                    Text("Giriş yap, arkadaşlarını ekle. Beğendiklerin ve listelerin de hesabına kaydedilir.", color = SMuted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        { onOpenAuth() }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) { Text("Giriş yap / Hesap oluştur") }
                }
            }
            return@Column
        }

        openedPub?.let { ol ->
            BackHandler { openedPub = null }
            FriendListScreen(ol) { openedPub = null }
            return@Column
        }

        val listening = friends.filter { it.listening != null }
        val onlineRest = friends.filter { it.online && it.listening == null }
        val offline = friends.filter { !it.online }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Arkadaşlar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("${friends.size} arkadaş", color = SMuted, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 2.dp))
                        if (friends.isNotEmpty()) Text("Profilini görmek için bir arkadaşına dokun.", color = SMuted, style = MaterialTheme.typography.bodySmall)
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(if (addOpen) Accent else Card).clickable { addOpen = !addOpen; error = null },
                        contentAlignment = Alignment.Center
                    ) { Icon(if (addOpen) Icons.Filled.Close else Icons.Filled.PersonAdd, "Arkadaş ekle", tint = Color.White, modifier = Modifier.size(22.dp)) }
                }
            }

            // ---- 24 Saatlik Durumlar (Stories) ----
            item {
                StatusStoriesRow(
                    friends = friends,
                    myAvatar = myAvatar,
                    myName = myShown,
                    myStatus = myStatus,
                    onAddStatus = { statusDialogOpen = true },
                    onViewStatus = { person, st -> viewStatus = person to st }
                )
            }

            // ---- Profil kartı ----
            item {
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Accent.copy(alpha = 0.6f), Card)))
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                Box(Modifier.clip(CircleShape).clickable { zoomAvatar = myAvatar to myShown }) { Avatar(78.dp) }
                                if (uploading) Box(Modifier.size(78.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(Modifier.size(28.dp), color = Color.White, strokeWidth = 3.dp)
                                }
                                Box(Modifier.align(Alignment.BottomEnd).size(28.dp).clip(CircleShape).background(Accent).clickable { avatarMenu = true }, contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.CameraAlt, "Fotoğraf", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                DropdownMenu(avatarMenu, { avatarMenu = false }) {
                                    DropdownMenuItem(text = { Text("Fotoğraf seç") }, leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null) },
                                        onClick = { avatarMenu = false; picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
                                    if (myAvatar != null || AuthStore.photo.value != null) DropdownMenuItem(text = { Text("Fotoğrafı kaldır") }, leadingIcon = { Icon(Icons.Filled.Delete, null) },
                                        onClick = {
                                            avatarMenu = false
                                            scope.launch { ProfilePhoto.clear()?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() } }
                                        })
                                }
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(myShown, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Row(Modifier.clickable {
                                    clipboard.setText(AnnotatedString(myName))
                                    Toast.makeText(ctx, "Kullanıcı adın kopyalandı", Toast.LENGTH_SHORT).show()
                                }, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Kullanıcı adın: @$myName", color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                    Spacer(Modifier.width(4.dp))
                                    Icon(Icons.Filled.ContentCopy, "Kopyala", tint = SMuted, modifier = Modifier.size(14.dp))
                                }
                                StatusDot(true, "Aktif", Modifier.padding(top = 2.dp))
                            }
                            IconButton({
                                val link = "https://new-music-cpzw.onrender.com/add-friend/$myName"
                                val shareMsg = "Beni New Music'te arkadaş olarak ekle:\n$link\n\n(Kullanıcı adım: @$myName)"
                                ctx.startActivity(Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, shareMsg)
                                    }, "Arkadaşını Davet Et"))
                            }) { Icon(Icons.Filled.Share, "WhatsApp ile arkadaş linki paylaş") }
                            IconButton({ renaming = true }) { Icon(Icons.Filled.Edit, "Görünen adı değiştir") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.Black.copy(alpha = 0.2f)).padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Headphones, null, tint = Accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Ne dinlediğimi göster", fontWeight = FontWeight.Medium)
                                Text("Arkadaşların şu an çalan şarkını görür", color = SMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(showListening, { Social.setShowListening(it) })
                        }

                        // ---- Profil Müziği (Instagram Tarzı) ----
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                .background(Color.Black.copy(alpha = 0.25f)).padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.MusicNote, null, tint = Accent)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Profil Müziği", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                                if (myProfileSong != null) {
                                    Text("${myProfileSong!!.title} • ${myProfileSong!!.artist}", color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                } else {
                                    Text("Profilini ziyaret edenler bu şarkıyı dinler", color = SMuted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            if (myProfileSong != null) {
                                IconButton(onClick = { PlayerManager.playQueue(listOf(myProfileSong!!), 0) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Filled.PlayArrow, "Çal", tint = Color.White)
                                }
                                Spacer(Modifier.width(4.dp))
                                IconButton(onClick = { scope.launch { Social.clearProfileSong() } }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Filled.Close, "Kaldır", tint = SMuted)
                                }
                            } else {
                                TextButton(onClick = { profileSongPickerOpen = true }) {
                                    Text("Ekle", color = Accent, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // ---- Arkadaş ekle ----
            item {
                val canSend = !busy && input.removePrefix("@").length >= 3
                AnimatedVisibility(addOpen, enter = expandVertically(tween(250)) + fadeIn(tween(250)), exit = shrinkVertically(tween(200)) + fadeOut(tween(150))) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(22.dp)).background(Card).padding(16.dp)
                ) {
                    Text("Arkadaş ekle", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Arkadaşının kullanıcı adını yaz. Onun kullanıcı adı, kendi profil kartında görünür.",
                        color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        input, { input = it.filterNot { c -> c.isWhitespace() }.take(30); error = null },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp), isError = error != null,
                        supportingText = error?.let { { Text(it) } },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        {
                            scope.launch {
                                busy = true
                                val e = Social.sendRequest(input)
                                busy = false
                                error = e
                                if (e == null) { Toast.makeText(ctx, "İstek gönderildi", Toast.LENGTH_SHORT).show(); input = ""; addOpen = false }
                            }
                        },
                        enabled = canSend, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                        else { Icon(Icons.Filled.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("İstek gönder") }
                    }
                }
                }
            }

            // Herkese açık listeler şimdilik gizli (PublicListsSection)

            // ---- Gelen paylaşımlar ----
            if (inbox.isNotEmpty()) {
                item { SectionTitle("SANA GÖNDERİLEN LİSTELER") }
                item {
                    SectionCard {
                        inbox.forEach { l ->
                            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.LibraryMusic, null, tint = Accent)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(l.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${l.from} · ${l.songs.size} şarkı", color = SMuted, style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton({
                                    Playlists.create("${l.name} (${l.from})", l.songs)
                                    scope.launch { Social.dismiss(l.id) }
                                    Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                                }) { Text("Kaydet", color = Accent) }
                                IconButton({ scope.launch { Social.dismiss(l.id) } }) { Icon(Icons.Filled.Close, "Yoksay", tint = SMuted) }
                            }
                        }
                    }
                }
            }

            // ---- Arkadaşlık istekleri ----
            if (incoming.isNotEmpty()) {
                item { SectionTitle("ARKADAŞLIK İSTEKLERİ") }
                item {
                    SectionCard {
                        incoming.forEach { p ->
                            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                UserAvatar(p.username, p.avatar, 44.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("@${p.username} · Arkadaş olmak istiyor", color = SMuted, style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton({ scope.launch { Social.respond(p.username, true) } }, Modifier.clip(CircleShape).background(Accent)) {
                                    Icon(Icons.Filled.Check, "Kabul et", tint = Color.White)
                                }
                                Spacer(Modifier.width(6.dp))
                                IconButton({ scope.launch { Social.respond(p.username, false) } }) { Icon(Icons.Filled.Close, "Reddet", tint = SMuted) }
                            }
                        }
                    }
                }
            }

            // ---- Şimdi dinleyenler ----
            if (listening.isNotEmpty()) {
                item { SectionTitle("ŞİMDİ DİNLİYOR (${listening.size})") }
                items(listening, key = { "ls" + it.username }) { f -> ListeningCard(f, { onOpenProfile(f) }) { removeTarget = f.username } }
            }

            // ---- Çevrim içi ----
            if (onlineRest.isNotEmpty()) {
                item { SectionTitle("ÇEVRİM İÇİ (${onlineRest.size})") }
                item { SectionCard { onlineRest.forEach { f -> FriendRow(f, { onOpenProfile(f) }) { removeTarget = f.username } } } }
            }

            // ---- Çevrim dışı ----
            if (offline.isNotEmpty()) {
                item { SectionTitle("ÇEVRİM DIŞI (${offline.size})") }
                item { SectionCard { offline.forEach { f -> FriendRow(f, { onOpenProfile(f) }) { removeTarget = f.username } } } }
            }

            if (friends.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(top = 36.dp, start = 32.dp, end = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.People, null, tint = SMuted, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Henüz arkadaşın yok", fontWeight = FontWeight.Bold)
                    Text("Yukarıya arkadaşının kullanıcı adını yazıp istek gönder. Sen de kendi kullanıcı adını paylaş butonuyla ona yollayabilirsin.", color = SMuted, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                }
            }

            // ---- Bekleyen istekler ----
            if (outgoing.isNotEmpty()) {
                item { SectionTitle("BEKLEYEN İSTEKLER") }
                item {
                    SectionCard {
                        outgoing.forEach { p ->
                            Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                UserAvatar(p.username, p.avatar, 36.dp)
                                Spacer(Modifier.width(12.dp))
                                Text("${p.name} (@${p.username})", Modifier.weight(1f), color = SMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                TextButton({ scope.launch { Social.remove(p.username) } }) { Text("İptal", color = SMuted) }
                            }
                        }
                    }
                }
            }
        }
    }

    removeTarget?.let { n ->
        AlertDialog(
            onDismissRequest = { removeTarget = null }, containerColor = Card, title = { Text("@$n") },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ scope.launch { Social.remove(n) }; removeTarget = null }) { Text("Çıkar") } },
            dismissButton = { TextButton({ removeTarget = null }) { Text("Vazgeç") } }
        )
    }

    if (renaming) {
        var text by remember { mutableStateOf(myDisplayName ?: me ?: "") }
        var err by remember { mutableStateOf<String?>(null) }
        var saving by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!saving) renaming = false }, containerColor = Card, title = { Text("Görünen adını değiştir") },
            text = {
                OutlinedTextField(text, { text = it.take(30); err = null }, singleLine = true, shape = RoundedCornerShape(14.dp), isError = err != null,
                    supportingText = { Text(err ?: "İstediğin adı yazabilirsin. Kullanıcı adın (@${me ?: ""}) değişmez.") })
            },
            confirmButton = {
                TextButton({
                    scope.launch {
                        saving = true
                        val e = Social.setDisplayName(text)
                        saving = false
                        err = e
                        if (e == null) {
                            if (AuthStore.email.value != null) AuthStore.setName(text)
                            renaming = false
                            Toast.makeText(ctx, "Görünen adın değişti", Toast.LENGTH_SHORT).show()
                        }
                    }
                }, enabled = !saving && text.isNotBlank() && text.trim() != (myDisplayName ?: "")) { Text("Kaydet") }
            },
            dismissButton = { TextButton({ renaming = false }, enabled = !saving) { Text("Vazgeç") } }
        )
    }

    zoomAvatar?.let { (aid, aname) ->
        AvatarZoomDialog(aid, aname) { zoomAvatar = null }
    }

    if (statusDialogOpen) {
        val curPlaying = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
        CreateStatusDialog(
            currentSong = curPlaying,
            onDismiss = { statusDialogOpen = false },
            onPost = { txt, sg ->
                scope.launch { Social.setStatus(txt, sg) }
                statusDialogOpen = false
            }
        )
    }

    viewStatus?.let { (person, st) ->
        val isMe = (myName.isNotBlank() && person.username.equals(myName, ignoreCase = true)) || (myShown.isNotBlank() && person.username.equals(myShown, ignoreCase = true))
        ViewStatusDialog(
            person = person,
            status = st,
            isMe = isMe,
            onDismiss = { viewStatus = null },
            onDelete = if (isMe) {
                {
                    scope.launch { Social.clearStatus() }
                    viewStatus = null
                }
            } else null
        )
    }

    if (profileSongPickerOpen) {
        val favs by PlayerManager.favorites.collectAsState()
        val curPlaying = PlayerManager.queue.value.getOrNull(PlayerManager.index.value)
        PickProfileSongDialog(
            favorites = favs,
            currentSong = curPlaying,
            onDismiss = { profileSongPickerOpen = false },
            onPick = { sg ->
                scope.launch { Social.setProfileSong(sg) }
                profileSongPickerOpen = false
            }
        )
    }
}

/** Arkadaşın profili: fotoğraf, ad, durum, ne dinlediği ve tek tuşla Blend. */
@Composable
fun FriendProfileScreen(username: String, onBack: () -> Unit, onOpenList: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val friend = friends.firstOrNull { it.username == username }
    val myId by Social.username.collectAsState()
    val myDisp by Social.displayName.collectAsState()
    val myName = myDisp ?: myId ?: "Sen"
    var building by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var compat by remember { mutableStateOf<Compat?>(null) }
    var resultId by remember { mutableStateOf<String?>(null) }
    var resultSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var menu by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    var openedList by remember { mutableStateOf<PubList?>(null) }

    if (friend == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    openedList?.let { ol ->
        BackHandler { openedList = null }
        FriendListScreen(ol) { openedList = null }
        return
    }
    val l = friend.listening

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
            Spacer(Modifier.weight(1f))
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Arkadaşlıktan çıkar") }, leadingIcon = { Icon(Icons.Filled.PersonRemove, null) },
                        onClick = { menu = false; confirmRemove = true })
                }
            }
        }

        // ---- Profil ----
        var zoomAvatar by remember { mutableStateOf<Pair<String?, String>?>(null) }

        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.clickable { zoomAvatar = friend.avatar to friend.name }) {
                UserAvatar(friend.name, friend.avatar, 112.dp, online = friend.online)
            }
            Spacer(Modifier.height(14.dp))
            Text(friend.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Text("@${friend.username}", color = SMuted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            StatusDot(friend.online, lastSeenText(friend))

            // ---- Profil Müziği (Instagram Tarzı) ----
            val ps = friend.profileSong
            if (ps != null) {
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.horizontalGradient(listOf(Accent.copy(alpha = 0.35f), Card)))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.MusicNote, null, tint = Accent)
                        if (ps.thumb != null) AsyncImage(model = ps.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Profil Müziği", color = Accent, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Text(ps.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (ps.artist.isNotBlank()) Text(ps.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(
                        onClick = { PlayerManager.playQueue(listOf(ps), 0) },
                        modifier = Modifier.clip(CircleShape).background(Accent)
                    ) {
                        Icon(Icons.Filled.PlayArrow, "Dinle", tint = Color.White)
                    }
                }
            }

            // ---- 24 Saatlik Durum ----
            val fst = friend.status
            if (fst != null) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Card)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.ChatBubbleOutline, null, tint = Color(0xFF00B894))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(fst.text, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        val mins = ((System.currentTimeMillis() - fst.createdAt) / 60000).coerceAtLeast(1)
                        val timeStr = if (mins < 60) "$mins dk önce" else "${mins / 60} saat önce"
                        Text("Durum • $timeStr", color = SMuted, style = MaterialTheme.typography.labelSmall)
                    }
                    if (fst.song != null) {
                        IconButton(
                            onClick = { PlayerManager.playQueue(listOf(fst.song), 0) },
                            modifier = Modifier.size(32.dp).clip(CircleShape).background(Accent)
                        ) {
                            Icon(Icons.Filled.PlayArrow, "Durum Şarkısını Dinle", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        zoomAvatar?.let { (aid, aname) ->
            AvatarZoomDialog(aid, aname) { zoomAvatar = null }
        }

        // ---- Şu an dinlediği ----
        if (l != null) {
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Accent.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.MusicNote, null, tint = Accent)
                    if (l.thumb != null) AsyncImage(model = l.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EqualizerBars(OnlineGreen)
                        Spacer(Modifier.width(6.dp))
                        Text("Şu an dinliyor", color = OnlineGreen, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(l.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (l.artist.isNotBlank()) Text(l.artist, color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (l.url.isNotBlank()) {
                    IconButton({ PlayerManager.playQueue(listOf(l), 0) }, Modifier.clip(CircleShape).background(Accent)) {
                        Icon(Icons.Filled.PlayArrow, "Sen de dinle", tint = Color.White)
                    }
                }
            }
        }

        // ---- Tek tuşla Blend ----
        Spacer(Modifier.height(20.dp))
        Column(Modifier.padding(horizontal = 16.dp)) {
            Button(
                onClick = {
                    error = null; compat = null; resultId = null; building = true
                    scope.launch {
                        val (err, pair) = Social.blendWith(friend.username)
                        when {
                            err != null || pair == null -> error = err ?: "Blend oluşturulamadı."
                            pair.me.isEmpty() -> error = "Önce birkaç şarkı dinle veya beğen, sonra tekrar dene."
                            pair.friend.isEmpty() -> error = "${friend.name} henüz yeterince müzik dinlememiş. O birkaç şarkı dinleyince tekrar dene."
                            else -> {
                                val songs = Blend.make(pair.me.map { it.name }, pair.friend.map { it.name })
                                if (songs.isEmpty()) error = "Şarkı bulunamadı. İnternetini kontrol edip tekrar dene."
                                else {
                                    val pl = Playlists.create("Blend: $myName + ${friend.name}", songs)
                                    compat = Blend.compat(pair.me, pair.friend)
                                    resultId = pl.id; resultSongs = songs
                                }
                            }
                        }
                        building = false
                    }
                },
                enabled = !building, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
            ) {
                if (building) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else { Icon(Icons.Filled.Group, null); Spacer(Modifier.width(8.dp)); Text("Blend oluştur", fontWeight = FontWeight.SemiBold) }
            }
            if (resultId == null && error == null && !building) {
                Text("İkinizin zevkine göre karışık bir liste hazırlanır.", color = SMuted, style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            error?.let { Text(it, color = Accent, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) }

            val rid = resultId
            val c = compat
            if (rid != null && c != null) {
                Column(Modifier.fillMaxWidth().padding(top = 16.dp).clip(RoundedCornerShape(22.dp)).background(Accent.copy(alpha = 0.16f)).padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("%${c.percent}", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, color = Accent)
                        Spacer(Modifier.width(10.dp))
                        Text(c.label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.12f))) {
                        Box(Modifier.fillMaxWidth(c.percent / 100f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(Accent))
                    }
                    if (c.shared.isNotEmpty()) {
                        Text("Ortak sanatçılar: " + c.shared.take(8).joinToString(", "), color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
                    }
                    Text("${resultSongs.size} şarkı • Kitaplık > Listelerim'e kaydedildi", color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ PlayerManager.playQueue(resultSongs, 0) }, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)) {
                            Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal")
                        }
                        OutlinedButton({ onOpenList(rid) }) { Text("Listeyi aç") }
                    }
                }
            }
        }
        // Herkese açık listeler şimdilik gizli (FriendListsSection)
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false }, containerColor = Card, title = { Text(friend.name) },
            text = { Text("Bu kişiyi arkadaşlarından çıkarmak istiyor musun?") },
            confirmButton = { TextButton({ confirmRemove = false; scope.launch { Social.remove(friend.username) }; onBack() }) { Text("Çıkar") } },
            dismissButton = { TextButton({ confirmRemove = false }) { Text("Vazgeç") } }
        )
    }
}

/** Bir listeyi seçilen arkadaşlara gönderir. */
@Composable
fun ShareListDialog(pl: UserPlaylist, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val friends by Social.friends.collectAsState()
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { Social.refresh() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card, title = { Text("\"${pl.name}\" paylaş") },
        text = {
            when {
                !Social.enabled || !Social.joined -> Text("Paylaşmak için önce Arkadaşlar sekmesinden kullanıcı adı al.")
                friends.isEmpty() -> Text("Henüz arkadaşın yok.")
                else -> LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(friends, key = { it.username }) { f ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if (f.username in selected) selected.remove(f.username) else selected.add(f.username)
                        }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.username in selected, { if (it) selected.add(f.username) else selected.remove(f.username) })
                            UserAvatar(f.username, f.avatar, 34.dp, online = f.online)
                            Spacer(Modifier.width(10.dp))
                            Text(f.name)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    busy = true
                    val e = Social.share(selected.toList(), pl.name, pl.songs)
                    busy = false
                    Toast.makeText(ctx, e ?: "Gönderildi", Toast.LENGTH_SHORT).show()
                    if (e == null) onDismiss()
                }
            }, enabled = selected.isNotEmpty() && !busy) { Text("Gönder") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}

/** Arkadaşın profilinde, onun herkese açık çalma listeleri. */
@Composable
private fun FriendListsSection(friend: SocialFriend, onOpen: (PubList) -> Unit) {
    var state by remember(friend.username) { mutableStateOf<List<PubList>?>(null) }
    var error by remember(friend.username) { mutableStateOf<String?>(null) }
    var loading by remember(friend.username) { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(friend.username, reload) {
        loading = true; error = null
        val (e, data) = Social.userLists(friend.username, friend.name, friend.avatar)
        error = e; state = data; loading = false
    }
    Column(Modifier.fillMaxWidth().padding(top = 24.dp)) {
        Text("Herkese açık listeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        val st = state
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(24.dp), color = Accent, strokeWidth = 2.dp)
            }
            error != null -> Column(Modifier.padding(horizontal = 16.dp)) {
                Text(error ?: "", color = Accent, style = MaterialTheme.typography.bodySmall)
                TextButton({ reload++ }) { Text("Tekrar dene") }
            }
            st == null -> Unit
            st.isEmpty() -> Text("${friend.name} henüz herkese açık liste paylaşmamış.", color = SMuted, style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 16.dp))
            else -> Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card)) {
                st.forEachIndexed { i, l ->
                    PubListRow(l) { onOpen(l) }
                    if (i < st.size - 1) HorizontalDivider(Modifier.padding(start = 76.dp), color = Color(0x14FFFFFF))
                }
            }
        }
    }
}

/** Herkese açık liste satırı: albüm kapağı, ad, şarkı sayısı ve beğeni sayısı. */
@Composable
private fun PubListRow(l: PubList, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        PlaylistCover(listOf(Song(l.name, "", "", l.cover ?: l.songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb)), 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(l.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${l.ownerName} · ${l.count} şarkı", color = SMuted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(if (l.liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, Modifier.size(16.dp), tint = if (l.liked) Accent else SMuted)
        Spacer(Modifier.width(4.dp))
        Text("${l.likes}", color = SMuted, style = MaterialTheme.typography.bodySmall)
    }
}

/** Keşfet'te yatay kaydırılan herkese açık liste kartı: büyük albüm kapağı, ad ve sahibi. */
@Composable
private fun PubListCard(l: PubList, onClick: () -> Unit) {
    val tint = tintFor(l.name)
    Column(Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(Modifier.size(150.dp).clip(RoundedCornerShape(14.dp)).background(Card), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.LibraryMusic, null, tint = SMuted, modifier = Modifier.size(52.dp))
            val cover = l.cover ?: l.songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb
            if (cover != null) AsyncImage(hiRes(cover, 400), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, tint.copy(alpha = 0.45f)))))
            Row(
                Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Favorite, null, Modifier.size(12.dp), tint = if (l.liked) Accent else Color.White)
                Spacer(Modifier.width(4.dp))
                Text("${l.likes}", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
        Text(l.name, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text("${l.ownerName} · ${l.count} şarkı", color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/**
 * Herkese açık listeler (en çok beğenilenler önde). [horizontal] true ise Keşfet'te kartlar yatay kayar,
 * değilse Arkadaşlar sekmesinde satır satır görünür. Dokununca liste açılır; açılamazsa nedeni söylenir.
 */
@Composable
fun PublicListsSection(horizontal: Boolean = false, onOpen: (PubList) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var lists by remember { mutableStateOf<List<PubList>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var opening by remember { mutableStateOf(false) }
    LaunchedEffect(reload) {
        loading = true; error = null
        val (e, data) = Social.publicLists()
        error = e; lists = data; loading = false
    }
    val open: (PubList) -> Unit = open@{ l ->
        if (opening) return@open
        opening = true
        scope.launch {
            val (err, full) = Social.publicList(l)
            opening = false
            if (full != null) onOpen(full) else Toast.makeText(ctx, err ?: "Liste açılamadı.", Toast.LENGTH_SHORT).show()
        }
    }
    Column(Modifier.fillMaxWidth().padding(top = if (horizontal) 14.dp else 8.dp)) {
        if (horizontal) Text("Herkese açık listeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        else Text("HERKESE AÇIK LİSTELER", color = SMuted, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 6.dp))
        val st = lists
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Accent, strokeWidth = 2.dp)
            }
            error != null -> Column(Modifier.padding(horizontal = 20.dp)) {
                Text(error ?: "", color = Accent, style = MaterialTheme.typography.bodySmall)
                TextButton({ reload++ }) { Text("Tekrar dene") }
            }
            st.isNullOrEmpty() -> Text("Henüz herkese açık liste yok. Kendi listeni açıp ⋮ menüsünden \"Herkese açık yap\" ile paylaşabilirsin.",
                color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 20.dp))
            horizontal -> LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(st, key = { it.owner + "/" + it.id }) { l -> PubListCard(l) { open(l) } }
            }
            else -> Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)).background(Card)) {
                st.forEachIndexed { i, l ->
                    PubListRow(l) { open(l) }
                    if (i < st.size - 1) HorizontalDivider(Modifier.padding(start = 76.dp), color = Color(0x14FFFFFF))
                }
            }
        }
    }
}

/** Herkese açık bir liste: kapak, çal / karıştır, beğen ve kendi kitaplığına kaydet. */
@Composable
fun FriendListScreen(list: PubList, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by Social.username.collectAsState()
    var saved by remember(list.id) { mutableStateOf(false) }
    var liked by remember(list.id) { mutableStateOf(list.liked) }
    var likes by remember(list.id) { mutableIntStateOf(list.likes) }
    val own = me != null && me.equals(list.owner, ignoreCase = true)
    // Liste açılınca ilk şarkılar hazırlanır: dokununca anında çalar
    LaunchedEffect(list.id) { MusicRepository.prefetchAll(list.songs, 6) }
    SongList(list.songs, header = {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                PlaylistCover(list.songs, 180.dp)
                Spacer(Modifier.height(14.dp))
                Text(list.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${list.ownerName} · ${list.songs.size} şarkı", color = SMuted, style = MaterialTheme.typography.bodyMedium)
                if (!own) Row(
                    Modifier.padding(top = 10.dp).clip(RoundedCornerShape(50)).background(if (liked) Accent.copy(alpha = 0.22f) else Card)
                        .clickable {
                            val want = !liked
                            liked = want; likes += if (want) 1 else -1
                            scope.launch {
                                val (e, n) = Social.likeList(list.owner, list.id, want)
                                if (e != null) { liked = !want; likes += if (want) -1 else 1; Toast.makeText(ctx, e, Toast.LENGTH_SHORT).show() }
                                else if (n != null) likes = n
                            }
                        }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Beğen", Modifier.size(20.dp), tint = if (liked) Accent else Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text(if (likes > 0) "$likes beğeni" else "Beğen")
                } else Text("$likes beğeni", color = SMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        { PlayerManager.playQueue(list.songs, 0) }, Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                    ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal") }
                    OutlinedButton({ PlayerManager.playQueue(list.songs.shuffled(), 0) }, Modifier.weight(1f)) {
                        Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
                    }
                }
                OutlinedButton(
                    {
                        Playlists.create("${list.name} (${list.ownerName})", list.songs)
                        saved = true
                        Toast.makeText(ctx, "Listelerine eklendi", Toast.LENGTH_SHORT).show()
                    },
                    enabled = !saved, modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(if (saved) Icons.Filled.Check else Icons.Filled.PlaylistAdd, null); Spacer(Modifier.width(6.dp))
                    Text(if (saved) "Kitaplığına kaydedildi" else "Kitaplığıma kaydet")
                }
            }
        }
    })
}
