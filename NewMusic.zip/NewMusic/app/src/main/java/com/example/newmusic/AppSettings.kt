package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

val QualityNames = listOf("Otomatik", "Yüksek", "Normal", "Düşük")
val QualityDescs = listOf(
    "En iyi kaliteyi seçer",
    "Mümkün olan en yüksek ses kalitesi, daha fazla veri kullanır",
    "Dengeli kalite (yaklaşık 128 kbps)",
    "En düşük kalite, veri tasarrufu sağlar"
)
val ContentNames = listOf("Türkçe + İngilizce", "Sadece Türkçe", "Sadece İngilizce")

/** Kalıcı kullanıcı ayarları: ses kalitesi, içerik dili ve otomatik devam. */
object AppSettings {
    /** 0 otomatik, 1 yüksek, 2 normal, 3 düşük */
    val quality = MutableStateFlow(0)
    /** 0 Türkçe + İngilizce, 1 Türkçe, 2 İngilizce */
    val content = MutableStateFlow(0)
    /** Liste bitince benzer şarkılarla devam et */
    val autoplay = MutableStateFlow(true)

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        prefs = p
        quality.value = p.getInt("quality", 0).coerceIn(QualityNames.indices)
        content.value = p.getInt("content", 0).coerceIn(ContentNames.indices)
        autoplay.value = p.getBoolean("autoplay", true)
    }

    fun setQuality(i: Int) {
        quality.value = i
        prefs?.edit()?.putInt("quality", i)?.apply()
        MusicRepository.clearStreams() // yeni kalite bir sonraki şarkıdan itibaren geçerli olsun
        CloudSync.changed()
    }

    fun setContent(i: Int) {
        content.value = i
        prefs?.edit()?.putInt("content", i)?.apply()
        CloudSync.changed()
    }

    fun setAutoplay(v: Boolean) {
        autoplay.value = v
        prefs?.edit()?.putBoolean("autoplay", v)?.apply()
        CloudSync.changed()
    }

    /** Hesap yedeğinden gelen ayarlar (yedeği tekrar tetiklemez). */
    fun applyRemote(q: Int, c: Int, auto: Boolean) {
        quality.value = q.coerceIn(QualityNames.indices)
        content.value = c.coerceIn(ContentNames.indices)
        autoplay.value = auto
        prefs?.edit()?.putInt("quality", quality.value)?.putInt("content", content.value)?.putBoolean("autoplay", auto)?.apply()
        MusicRepository.clearStreams()
    }
}
