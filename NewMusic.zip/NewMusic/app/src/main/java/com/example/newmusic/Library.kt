package com.example.newmusic

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private val Muted = Color(0xFF9A9A9A)

/** Listenin kapağı: ilk şarkının resmi, yoksa müzik simgesi. */
@Composable
private fun PlaylistCover(songs: List<Song>, coverSize: Dp) {
    Box(
        Modifier.size(coverSize).clip(RoundedCornerShape(10.dp)).background(Card),
        contentAlignment = Alignment.Center
    ) {
        val t = songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb
        if (t != null) AsyncImage(hiRes(t, 300), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Filled.LibraryMusic, null, tint = Muted, modifier = Modifier.size(coverSize * 0.45f))
    }
}

@Composable
fun NewPlaylistDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card,
        title = { Text("Yeni çalma listesi") },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(40) }, singleLine = true,
                label = { Text("Liste adı") }, shape = RoundedCornerShape(14.dp)
            )
        },
        confirmButton = { TextButton({ onCreate(name) }) { Text("Oluştur") } },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}

/** Şarkıyı seçilen listeye ekler veya yeni liste oluşturur. */
@Composable
fun AddToPlaylistDialog(song: Song, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val lists by Playlists.lists.collectAsState()
    var creating by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card,
        title = { Text("Listeye ekle") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { creating = true }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Add, null, tint = Accent)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("Yeni liste oluştur", fontWeight = FontWeight.Medium)
                }
                lists.forEach { pl ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                            Playlists.add(pl.id, song)
                            Toast.makeText(ctx, "\"${pl.name}\" listesine eklendi", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlaylistCover(pl.songs, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(pl.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${pl.songs.size} şarkı", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Kapat") } }
    )
    if (creating) NewPlaylistDialog({ creating = false }) { name ->
        val pl = Playlists.create(name, listOf(song))
        Toast.makeText(ctx, "\"${pl.name}\" listesi oluşturuldu", Toast.LENGTH_SHORT).show()
        creating = false
        onDismiss()
    }
}

/** Şarkı satırındaki "⋮" menüsü. */
@Composable
fun SongMenu(s: Song, onRemove: (() -> Unit)? = null) {
    var open by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }) { Icon(Icons.Filled.MoreVert, "Daha fazla", tint = Color.Gray) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Listeye ekle") },
                leadingIcon = { Icon(Icons.Filled.PlaylistAdd, null) },
                onClick = { open = false; addDialog = true }
            )
            if (onRemove != null) DropdownMenuItem(
                text = { Text("Listeden çıkar") },
                leadingIcon = { Icon(Icons.Filled.RemoveCircleOutline, null) },
                onClick = { open = false; onRemove() }
            )
            if (Uploads.isLocal(s)) DropdownMenuItem(
                text = { Text("Yüklemeyi sil") },
                leadingIcon = { Icon(Icons.Filled.Delete, null) },
                onClick = { open = false; Uploads.remove(s) }
            )
        }
    }
    if (addDialog) AddToPlaylistDialog(s) { addDialog = false }
}

/** Kitaplık: beğendiklerim, indirilenler, kendi listelerim ve yüklediğim müzikler. */
@Composable
fun LibraryTab(onOpenList: (String) -> Unit, onBlend: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val favs by PlayerManager.favorites.collectAsState()
    val downloaded by Downloads.songs.collectAsState()
    val uploads by Uploads.songs.collectAsState()
    val lists by Playlists.lists.collectAsState()
    var section by remember { mutableIntStateOf(0) }
    var newList by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            importing = true
            val n = Uploads.importFiles(ctx, uris)
            importing = false
            Toast.makeText(ctx, if (n > 0) "$n şarkı eklendi" else "Şarkı eklenemedi", Toast.LENGTH_SHORT).show()
        }
    }
    val names = listOf("Beğendiklerim", "İndirilenler", "Listelerim", "Yüklediklerim")
    Column(Modifier.fillMaxSize()) {
        Text("Kitaplık", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> FilterChip(section == i, { section = i }, label = { Text(n) }) }
        }
        when (section) {
            2 -> LazyColumn(Modifier.fillMaxSize()) {
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            { newList = true }, Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                        ) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Yeni liste") }
                        OutlinedButton({ onBlend() }, Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Filled.Group, null); Spacer(Modifier.width(6.dp)); Text("Blend yap")
                        }
                    }
                }
                if (lists.isEmpty()) item {
                    Text("Henüz listen yok. \"Yeni liste\" ile oluştur, şarkıların yanındaki ⋮ menüsünden şarkı ekle.",
                        color = Color.Gray, modifier = Modifier.padding(16.dp))
                }
                items(lists, key = { it.id }) { pl ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpenList(pl.id) }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlaylistCover(pl.songs, 56.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pl.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${pl.songs.size} şarkı", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = Muted)
                    }
                }
            }
            else -> {
                val list = when (section) { 0 -> favs; 1 -> downloaded; else -> uploads }
                SongList(list, header = {
                    if (section == 3) item {
                        Button(
                            { picker.launch(arrayOf("audio/*")) },
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), enabled = !importing,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                        ) {
                            if (importing) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            else { Icon(Icons.Filled.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("Müzik yükle") }
                        }
                    }
                    if (list.isEmpty()) item {
                        Text(
                            when (section) {
                                0 -> "Henüz beğendiğin şarkı yok. Kalp simgesine dokun."
                                1 -> "Henüz indirilen şarkı yok. Şarkının yanındaki indirme simgesine dokun."
                                else -> "Henüz yüklediğin müzik yok. \"Müzik yükle\" ile telefonundan ses dosyası ekle."
                            },
                            modifier = Modifier.padding(16.dp), color = Color.Gray
                        )
                    } else item { PlayAllButton("Hepsini çal") { PlayerManager.playQueue(list, 0) } }
                })
            }
        }
    }
    if (newList) NewPlaylistDialog({ newList = false }) { name ->
        val pl = Playlists.create(name)
        newList = false
        onOpenList(pl.id)
    }
}

/** Kullanıcının kendi çalma listesi. */
@Composable
fun UserPlaylistScreen(id: String, onBack: () -> Unit) {
    val lists by Playlists.lists.collectAsState()
    val pl = lists.firstOrNull { it.id == id }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    var share by remember { mutableStateOf(false) }
    if (pl == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    SongList(pl.songs, onRemove = { Playlists.removeSong(pl.id, it.url) }, header = {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Yeniden adlandır") }, leadingIcon = { Icon(Icons.Filled.Edit, null) },
                            onClick = { menu = false; rename = true })
                        if (Social.enabled) DropdownMenuItem(text = { Text("Arkadaşlara gönder") }, leadingIcon = { Icon(Icons.Filled.Share, null) },
                            onClick = { menu = false; share = true })
                        DropdownMenuItem(text = { Text("Listeyi sil") }, leadingIcon = { Icon(Icons.Filled.Delete, null) },
                            onClick = { menu = false; delete = true })
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                PlaylistCover(pl.songs, 180.dp)
                Spacer(Modifier.height(14.dp))
                Text(pl.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${pl.songs.size} şarkı", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (pl.songs.isNotEmpty()) item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    { PlayerManager.playQueue(pl.songs, 0) }, Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal") }
                OutlinedButton({ PlayerManager.playQueue(pl.songs.shuffled(), 0) }, Modifier.weight(1f)) {
                    Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
                }
            }
        } else item {
            Text("Bu liste boş. Şarkıların yanındaki ⋮ menüsünden \"Listeye ekle\" de.", color = Color.Gray, modifier = Modifier.padding(24.dp))
        }
    })
    if (share) ShareListDialog(pl) { share = false }
    if (rename) {
        var text by remember { mutableStateOf(pl.name) }
        AlertDialog(
            onDismissRequest = { rename = false }, containerColor = Card, title = { Text("Yeniden adlandır") },
            text = { OutlinedTextField(text, { text = it.take(40) }, singleLine = true, shape = RoundedCornerShape(14.dp)) },
            confirmButton = { TextButton({ Playlists.rename(pl.id, text); rename = false }) { Text("Kaydet") } },
            dismissButton = { TextButton({ rename = false }) { Text("Vazgeç") } }
        )
    }
    if (delete) AlertDialog(
        onDismissRequest = { delete = false }, containerColor = Card, title = { Text("Liste silinsin mi?") },
        text = { Text("\"${pl.name}\" listesi silinecek. Şarkılar cihazdan silinmez.") },
        confirmButton = { TextButton({ Playlists.delete(pl.id); delete = false; onBack() }) { Text("Sil") } },
        dismissButton = { TextButton({ delete = false }) { Text("Vazgeç") } }
    )
}
