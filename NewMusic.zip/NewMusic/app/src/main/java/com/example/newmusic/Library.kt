package com.example.newmusic

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private val Muted = Color(0xFF9A9A9A)

/** Listenin kapağı: ilk şarkının resmi, yoksa müzik simgesi. */
@Composable
fun PlaylistCover(songs: List<Song>, coverSize: Dp, customCover: String? = null) {
    Box(
        Modifier.size(coverSize).clip(RoundedCornerShape(10.dp)).background(Card),
        contentAlignment = Alignment.Center
    ) {
        val t = customCover ?: songs.firstOrNull { !it.thumb.isNullOrBlank() }?.thumb
        if (!t.isNullOrBlank()) {
            AsyncImage(
                model = if (t.startsWith("content://") || t.startsWith("file://")) t else (hiRes(t, 400) ?: t),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(Icons.Filled.LibraryMusic, null, tint = Muted, modifier = Modifier.size(coverSize * 0.45f))
        }
    }
}

@Composable
fun NewPlaylistDialog(onDismiss: () -> Unit, onCreate: (String, Boolean, String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var isPub by remember { mutableStateOf(false) }
    var coverUri by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        coverUri = uri?.toString()
    }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card,
        title = { Text("Yeni çalma listesi") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(88.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Accent.copy(alpha = 0.15f))
                        .clickable { picker.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (coverUri != null) {
                        AsyncImage(coverUri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.AddPhotoAlternate, null, tint = Accent, modifier = Modifier.size(32.dp))
                            Spacer(Modifier.height(4.dp))
                            Text("Kapak seç", fontSize = 11.sp, color = Accent, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(40) }, singleLine = true,
                    label = { Text("Liste adı") }, shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.05f),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { isPub = !isPub }
                ) {
                    Row(
                        Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(if (isPub) Icons.Filled.Public else Icons.Filled.Lock, null, tint = if (isPub) Accent else Muted, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (isPub) "Herkese açık liste" else "Gizli liste", fontWeight = FontWeight.Medium)
                            Text(if (isPub) "Profilinde görünür" else "Yalnızca sen görürsün", style = MaterialTheme.typography.bodySmall, color = Muted)
                        }
                        Switch(
                            checked = isPub,
                            onCheckedChange = { isPub = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Accent)
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton({ onCreate(name, isPub, coverUri) }) { Text("Oluştur") } },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } }
    )
}

/** Şarkıyı seçilen listeye ekler veya yeni liste oluşturur. */
@Composable
fun AddToPlaylistDialog(song: Song, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val lists by Playlists.lists.collectAsState()
    var creating by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Card,
        title = { Text("Listeye ekle") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { creating = true }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Add, null, tint = Accent)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("Yeni liste oluştur", fontWeight = FontWeight.Medium)
                }
                lists.forEach { pl ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                            Playlists.add(pl.id, song)
                            Toast.makeText(ctx, "\"${pl.name}\" listesine eklendi", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlaylistCover(pl.songs, 40.dp, pl.coverUri)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(pl.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${pl.songs.size} şarkı", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Kapat") } }
    )
    if (creating) NewPlaylistDialog({ creating = false }) { name, isPub, cov ->
        val pl = Playlists.create(name, listOf(song), isPub, cov)
        Toast.makeText(ctx, "\"${pl.name}\" listesi oluşturuldu", Toast.LENGTH_SHORT).show()
        creating = false
        onDismiss()
    }
}

/** Şarkı satırındaki "⋮" menüsü. */
@Composable
fun SongMenu(s: Song, onRemove: (() -> Unit)? = null) {
    var open by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var shareDialog by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }) { Icon(Icons.Filled.MoreVert, "Daha fazla", tint = Color.Gray) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Listeye ekle") },
                leadingIcon = { Icon(Icons.Filled.PlaylistAdd, null) },
                onClick = { open = false; addDialog = true }
            )
            if (ShareSong.canShare(s)) DropdownMenuItem(
                text = { Text("Paylaş") },
                leadingIcon = { Icon(Icons.Filled.Share, null) },
                onClick = { open = false; shareDialog = true }
            )
            if (onRemove != null) DropdownMenuItem(
                text = { Text("Listeden çıkar") },
                leadingIcon = { Icon(Icons.Filled.RemoveCircleOutline, null) },
                onClick = { open = false; onRemove() }
            )
            if (Uploads.isLocal(s)) DropdownMenuItem(
                text = { Text("Yüklemeyi sil") },
                leadingIcon = { Icon(Icons.Filled.Delete, null) },
                onClick = { open = false; Uploads.remove(s) }
            )
        }
    }
    if (addDialog) AddToPlaylistDialog(s) { addDialog = false }
    if (shareDialog) ShareSongDialog(s) { shareDialog = false }
}

/** Kitaplık: beğendiklerim, indirilenler, kendi listelerim ve yüklediğim müzikler. */
@Composable
fun LibraryTab(onOpenList: (String) -> Unit, onOpenAuth: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val favs by PlayerManager.favorites.collectAsState()
    val downloaded by Downloads.songs.collectAsState()
    val lists by Playlists.lists.collectAsState()
    val signedInMail by AuthStore.email.collectAsState()
    var section by remember { mutableIntStateOf(0) }
    var newList by remember { mutableStateOf(false) }
    val names = listOf("Beğendiklerim", "İndirilenler", "Listelerim")
    Column(Modifier.fillMaxSize()) {
        Text("Kitaplık", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp))
        // Giriş yapılmadıysa beğeniler ve listeler yalnızca bu telefonda durur; uygulama silinince gider
        if (signedInMail == null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Card)
                    .clickable { onOpenAuth() }.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Info, null, tint = Accent)
                Spacer(Modifier.width(10.dp))
                Text(
                    "Beğendiklerin ve listelerin şu an sadece bu telefonda. Kaybolmaması için giriş yap.",
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall
                )
                TextButton({ onOpenAuth() }) { Text("Giriş yap", color = Accent) }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> FilterChip(section == i, { section = i }, label = { Text(n) }) }
        }
        when (section) {
            2 -> LazyColumn(Modifier.fillMaxSize()) {
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            { newList = true }, Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                        ) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Yeni liste") }
                    }
                }
                if (lists.isEmpty()) item {
                    Text("Henüz oluşturulan liste yok.",
                        color = Color.Gray, modifier = Modifier.padding(16.dp))
                }
                items(lists, key = { it.id }) { pl ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpenList(pl.id) }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlaylistCover(pl.songs, 56.dp, pl.coverUri)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pl.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${pl.songs.size} şarkı", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = Muted)
                    }
                }
            }
            else -> {
                val list = if (section == 0) favs else downloaded
                SongList(list, header = {
                    if (list.isEmpty()) item {
                        Text(
                            if (section == 0) "Henüz beğendiğin şarkı yok."
                            else "Henüz indirilen şarkı yok.",
                            modifier = Modifier.padding(16.dp), color = Color.Gray
                        )
                    } else item { PlayAllButton("Hepsini çal") { PlayerManager.playQueue(list, 0) } }
                })
            }
        }
    }
    if (newList) NewPlaylistDialog({ newList = false }) { name, isPub, cov ->
        val pl = Playlists.create(name, emptyList(), isPub, cov)
        newList = false
        onOpenList(pl.id)
    }
}

/** Listeyi herkese açık / gizli yapar. Hesaba giriş yapılmamışsa (herkes göremez) nedenini söyler. */
private fun togglePublic(ctx: android.content.Context, pl: UserPlaylist) {
    if (!Social.joined) {
        Toast.makeText(ctx, "Listeyi herkese açık yapmak için önce hesabına giriş yap.", Toast.LENGTH_LONG).show()
        Social.start()   // giriş yapılmış ama kimlik gelmemişse şimdi alınır
        return
    }
    Playlists.setPublic(pl.id, !pl.public)
    LibrarySync.flush()   // beklemeden sunucuya gönder
    Toast.makeText(
        ctx,
        when {
            pl.public -> "Liste gizlendi"
            pl.songs.isEmpty() -> "Liste herkese açık oldu. Şarkı ekleyince herkes görebilir."
            else -> "Liste herkese açık oldu"
        },
        Toast.LENGTH_SHORT
    ).show()
}

/** Kullanıcının kendi çalma listesi. */
@Composable
fun UserPlaylistScreen(id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lists by Playlists.lists.collectAsState()
    val pl = lists.firstOrNull { it.id == id }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    var share by remember { mutableStateOf(false) }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            Playlists.setCover(id, uri.toString())
            Toast.makeText(ctx, "Kapak fotoğrafı güncellendi", Toast.LENGTH_SHORT).show()
        }
    }
    if (pl == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    SongList(pl.songs, onRemove = { Playlists.removeSong(pl.id, it.url) }, header = {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Geri") }
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menü") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Yeniden adlandır") }, leadingIcon = { Icon(Icons.Filled.Edit, null) },
                            onClick = { menu = false; rename = true })
                        DropdownMenuItem(text = { Text("Kapağı değiştir") }, leadingIcon = { Icon(Icons.Filled.PhotoCamera, null) },
                            onClick = { menu = false; coverPicker.launch("image/*") })
                        if (pl.coverUri != null) DropdownMenuItem(
                            text = { Text("Özel kapağı kaldır") }, leadingIcon = { Icon(Icons.Filled.HideImage, null) },
                            onClick = { menu = false; Playlists.setCover(pl.id, null); Toast.makeText(ctx, "Kapak kaldırıldı", Toast.LENGTH_SHORT).show() })
                        if (Social.enabled) DropdownMenuItem(text = { Text("Arkadaşlara gönder") }, leadingIcon = { Icon(Icons.Filled.Share, null) },
                            onClick = { menu = false; share = true })
                        DropdownMenuItem(
                            text = { Text(if (pl.public) "Gizli yap" else "Herkese açık yap") },
                            leadingIcon = { Icon(if (pl.public) Icons.Filled.Lock else Icons.Filled.Public, null) },
                            onClick = { menu = false; togglePublic(ctx, pl) })
                        DropdownMenuItem(text = { Text("Listeyi sil") }, leadingIcon = { Icon(Icons.Filled.Delete, null) },
                            onClick = { menu = false; delete = true })
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { coverPicker.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    PlaylistCover(pl.songs, 180.dp, pl.coverUri)
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Accent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.CameraAlt, "Kapağı değiştir", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(pl.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${pl.songs.size} şarkı", color = Muted, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Card,
                    border = BorderStroke(1.dp, if (pl.public) Accent.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { togglePublic(ctx, pl) }
                ) {
                    Row(
                        Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(if (pl.public) Icons.Filled.Public else Icons.Filled.Lock, null, tint = if (pl.public) Accent else Muted, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (pl.public) "Herkese açık liste" else "Gizli liste", fontWeight = FontWeight.SemiBold, color = if (pl.public) Accent else Color.White)
                            Text(if (pl.public) "Arkadaşların profilinde görebilir" else "Yalnızca sen görebilirsin", style = MaterialTheme.typography.bodySmall, color = Muted)
                        }
                        Switch(
                            checked = pl.public,
                            onCheckedChange = { togglePublic(ctx, pl) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Accent)
                        )
                    }
                }
            }
        }
        if (pl.songs.isNotEmpty()) item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    { PlayerManager.playQueue(pl.songs, 0) }, Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)
                ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Çal") }
                OutlinedButton({ PlayerManager.playQueue(pl.songs.shuffled(), 0) }, Modifier.weight(1f)) {
                    Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Karıştır")
                }
            }
        } else item {
            Text("Bu liste boş. Şarkıların yanındaki ⋮ menüsünden \"Listeye ekle\" de.", color = Color.Gray, modifier = Modifier.padding(24.dp))
        }
    })
    if (share) ShareListDialog(pl) { share = false }
    if (rename) {
        var text by remember { mutableStateOf(pl.name) }
        AlertDialog(
            onDismissRequest = { rename = false }, containerColor = Card, title = { Text("Yeniden adlandır") },
            text = { OutlinedTextField(text, { text = it.take(40) }, singleLine = true, shape = RoundedCornerShape(14.dp)) },
            confirmButton = { TextButton({ Playlists.rename(pl.id, text); rename = false }) { Text("Kaydet") } },
            dismissButton = { TextButton({ rename = false }) { Text("Vazgeç") } }
        )
    }
    if (delete) AlertDialog(
        onDismissRequest = { delete = false }, containerColor = Card, title = { Text("Liste silinsin mi?") },
        text = { Text("\"${pl.name}\" listesi silinecek. Şarkılar cihazdan silinmez.") },
        confirmButton = { TextButton({ Playlists.delete(pl.id); delete = false; onBack() }) { Text("Sil") } },
        dismissButton = { TextButton({ delete = false }) { Text("Vazgeç") } }
    )
}
