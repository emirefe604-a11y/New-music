package com.example.newmusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Song(val title: String, val artist: String, val url: String, val thumb: String?)

object MusicRepository {
    private var ready = false
    private val yt get() = ServiceList.YouTube

    fun init() {
        if (!ready) { NewPipe.init(AppDownloader()); ready = true }
    }

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val handler = yt.searchQHFactory.fromQuery(
            query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), ""
        )
        SearchInfo.getInfo(yt, handler).relatedItems
            .filterIsInstance<StreamInfoItem>()
            .map { Song(it.name, it.uploaderName ?: "", it.url, it.thumbnails.firstOrNull()?.url) }
    }

    suspend fun audioUrl(pageUrl: String): String? = withContext(Dispatchers.IO) {
        StreamInfo.getInfo(yt, pageUrl).audioStreams
            .maxByOrNull { it.averageBitrate }?.content
    }
}
