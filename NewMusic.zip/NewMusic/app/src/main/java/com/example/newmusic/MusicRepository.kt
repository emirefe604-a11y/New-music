package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.ConcurrentHashMap

data class Song(val title: String, val artist: String, val url: String, val thumb: String?)

/** YouTube Music çalma listesi (Keşfet sekmesinde kart olarak gösterilir). */
data class PlaylistRef(val title: String, val owner: String, val url: String, val thumb: String?, val count: Long)

// ---- Song <-> JSON (favoriler, indirilenler, önbellek hep aynı biçimi kullanır) ----

fun Song.toJson(): JSONObject =
    JSONObject().put("t", title).put("a", artist).put("u", url).put("i", thumb ?: "")

fun JSONObject.toSong(): Song =
    Song(getString("t"), getString("a"), getString("u"), optString("i").ifEmpty { null })

fun List<Song>.toJsonArray(): JSONArray = JSONArray().also { a -> forEach { a.put(it.toJson()) } }

fun JSONArray.toSongs(): List<Song> = (0 until length()).map { getJSONObject(it).toSong() }

// ---- Kapak kalitesi ----

private val sizeWh = Regex("=w\\d+-h\\d+")
private val sizeS = Regex("=s\\d+")
private val lowResYt = Regex("/vi(?:_webp)?/([A-Za-z0-9_-]{11})/(?:default|mqdefault|hqdefault)\\.(?:jpg|webp)")

/**
 * YouTube / Google kapak adreslerindeki küçük boyutu büyütür.
 * lh3 / ggpht adreslerinde boyut parametresi (=w226-h226) değiştirilir;
 * düşük çözünürlüklü i.ytimg.com küçük resimleri hqdefault'a yükseltilir.
 */
fun hiRes(url: String?, size: Int = 600): String? {
    if (url.isNullOrBlank()) return null
    return when {
        "googleusercontent.com" in url || "ggpht.com" in url -> when {
            sizeWh.containsMatchIn(url) -> url.replace(sizeWh, "=w$size-h$size")
            sizeS.containsMatchIn(url) -> url.replace(sizeS, "=s$size")
            else -> url
        }
        "ytimg.com" in url && "sqp=" !in url ->
            lowResYt.find(url)?.let { "https://i.ytimg.com/vi/${it.groupValues[1]}/hqdefault.jpg" } ?: url
        else -> url
    }
}

/**
 * YouTube verisi için tek giriş noktası. Hız için iki katmanlı önbellek tutar:
 *  - arama sonuçları (bellek + isteğe bağlı disk): ana sayfa uygulama açılır açılmaz dolar
 *  - ses akışı adresleri (bellek): şarkıya basınca beklemeden çalar, sıradaki şarkı önceden hazırlanır
 */
object MusicRepository {
    private const val SEARCH_TTL = 10 * 60_000L
    private const val STREAM_TTL = 90 * 60_000L

    private class Timed<T>(val value: T, val at: Long = System.currentTimeMillis()) {
        fun fresh(ttl: Long) = System.currentTimeMillis() - at < ttl
    }

    private val yt get() = ServiceList.YouTube
    private val searchCache = ConcurrentHashMap<String, Timed<List<Song>>>()
    private val streamCache = ConcurrentHashMap<String, Timed<List<String>>>()
    private val playlistCache = ConcurrentHashMap<String, Timed<List<PlaylistRef>>>()
    private val playlistSongCache = ConcurrentHashMap<String, Timed<List<Song>>>()
    private val inflight = ConcurrentHashMap.newKeySet<String>()
    private val background = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var prefs: SharedPreferences? = null
    private var ready = false

    fun init(ctx: Context) {
        if (ready) return
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        NewPipe.init(AppDownloader())
        ready = true
    }

    /** music.youtube.com / youtu.be / shorts bağlantılarını standart watch?v= biçimine çevirir. */
    private fun normalize(url: String): String {
        val m = Regex("""(?:[?&]v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})""").find(url)
        return if (m != null) "https://www.youtube.com/watch?v=${m.groupValues[1]}" else url
    }

    private fun StreamInfoItem.toSong() = Song(
        name, uploaderName ?: "", normalize(url),
        thumbnails.maxByOrNull { it.height }?.url
    )

    // ---- Arama ----

    /** Varsa (bayat olsa bile) önbellekteki sonucu hemen verir; ağ beklemez. */
    fun cachedSearch(query: String): List<Song>? =
        searchCache[query]?.value ?: loadSearchFromDisk(query)

    /** Önbellek tazeyse ağa gitmez. [persist] true ise sonuç diske de yazılır (ana sayfa için). */
    suspend fun search(query: String, persist: Boolean = false): List<Song> {
        searchCache[query]?.takeIf { it.fresh(SEARCH_TTL) }?.let { return it.value }
        val songs = withContext(Dispatchers.IO) {
            val handler = yt.searchQHFactory.fromQuery(
                query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), ""
            )
            SearchInfo.getInfo(yt, handler).relatedItems
                .filterIsInstance<StreamInfoItem>().map { it.toSong() }
        }
        if (songs.isNotEmpty()) {
            searchCache[query] = Timed(songs)
            if (persist) prefs?.edit()?.putString("sc_$query", songs.toJsonArray().toString())?.apply()
        }
        return songs
    }

    private fun loadSearchFromDisk(query: String): List<Song>? = try {
        prefs?.getString("sc_$query", null)?.let { JSONArray(it).toSongs() }?.takeIf { it.isNotEmpty() }
    } catch (e: Exception) { null }

    /** Şarkı bitince "radyo" gibi devam etmek için benzer parçalar. */
    suspend fun related(pageUrl: String): List<Song> = withContext(Dispatchers.IO) {
        StreamInfo.getInfo(yt, normalize(pageUrl)).relatedItems
            .filterIsInstance<StreamInfoItem>().map { it.toSong() }
    }

    // ---- YouTube Music çalma listeleri (Keşfet) ----

    /** Varsa önbellekteki çalma listelerini hemen verir. */
    fun cachedPlaylists(query: String): List<PlaylistRef>? = playlistCache[query]?.value

    /** YouTube Music'te çalma listesi arar. */
    suspend fun searchPlaylists(query: String): List<PlaylistRef> {
        playlistCache[query]?.takeIf { it.fresh(SEARCH_TTL * 3) }?.let { return it.value }
        val lists = withContext(Dispatchers.IO) {
            val handler = yt.searchQHFactory.fromQuery(
                query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_PLAYLISTS), ""
            )
            SearchInfo.getInfo(yt, handler).relatedItems
                .filterIsInstance<PlaylistInfoItem>()
                .map {
                    PlaylistRef(
                        it.name, it.uploaderName ?: "YouTube Music", it.url,
                        it.thumbnails.maxByOrNull { t -> t.height }?.url, it.streamCount
                    )
                }
        }
        if (lists.isNotEmpty()) playlistCache[query] = Timed(lists)
        return lists
    }

    /** Bir çalma listesindeki şarkıları getirir. */
    suspend fun playlistSongs(url: String): List<Song> {
        playlistSongCache[url]?.takeIf { it.fresh(SEARCH_TTL) }?.let { return it.value }
        val songs = withContext(Dispatchers.IO) {
            PlaylistInfo.getInfo(yt, url).relatedItems
                .filterIsInstance<StreamInfoItem>().map { it.toSong() }
        }
        if (songs.isNotEmpty()) playlistSongCache[url] = Timed(songs)
        return songs
    }

    // ---- Ses akışı ----

    /** Çalınabilir ses bağlantıları, en iyiden başlayarak (hata olursa sıradakine geçilir). */
    suspend fun audioUrls(pageUrl: String): List<String> {
        val key = normalize(pageUrl)
        streamCache[key]?.takeIf { it.fresh(STREAM_TTL) }?.let { return it.value }
        val urls = withContext(Dispatchers.IO) {
            val streams = StreamInfo.getInfo(yt, key).audioStreams
                .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.content.isNotBlank() }
                .sortedByDescending { it.averageBitrate }
            (streams.filter { it.format?.suffix == "m4a" } + streams.filter { it.format?.suffix != "m4a" })
                .map { it.content }.distinct()
        }
        if (urls.isNotEmpty()) streamCache[key] = Timed(urls)
        return urls
    }

    /** Şarkının akış adresini arka planda önceden hazırlar; basıldığında çalma gecikmesiz başlar. */
    fun prefetch(pageUrl: String) {
        val key = normalize(pageUrl)
        if (streamCache[key]?.fresh(STREAM_TTL) == true || !inflight.add(key)) return
        background.launch {
            try { audioUrls(key) } catch (_: Exception) { } finally { inflight.remove(key) }
        }
    }

    /** Bağlantı reddedilirse önbellekteki adresler atılır, bir sonraki deneme taze adres alır. */
    fun invalidate(pageUrl: String) { streamCache.remove(normalize(pageUrl)) }
}
