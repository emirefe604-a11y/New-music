@file:OptIn(UnstableApi::class)

package com.example.newmusic

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.CancellationException
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheWriter
import java.util.concurrent.ConcurrentHashMap

data class Song(val title: String, val artist: String, val url: String, val thumb: String?)

/** YouTube Music çalma listesi (Keşfet sekmesinde kart olarak gösterilir). */
data class PlaylistRef(val title: String, val owner: String, val url: String, val thumb: String?, val count: Long)

// ---- Song <-> JSON (favoriler, indirilenler, önbellek hep aynı biçimi kullanır) ----

fun Song.toJson(): JSONObject =
    JSONObject().put("t", title).put("a", artist).put("u", url).put("i", thumb ?: "")

fun JSONObject.toSong(): Song {
    val t = optString("t").ifBlank { optString("title") }
    val a = optString("a").ifBlank { optString("artist") }
    val u = optString("u").ifBlank { optString("url") }
    val thumb = optString("i").ifBlank { optString("thumb") }.ifEmpty { null }
    return Song(t, a, u, thumb)
}

fun List<Song>.toJsonArray(): JSONArray = JSONArray().also { a -> forEach { a.put(it.toJson()) } }

fun JSONArray.toSongs(): List<Song> = (0 until length()).map { getJSONObject(it).toSong() }

// ---- Kapak kalitesi ----

private val sizeWh = Regex("=w\\d+-h\\d+")
private val sizeS = Regex("=s\\d+")
private val lowResYt = Regex("/vi(?:_webp)?/([A-Za-z0-9_-]{11})/[a-z0-9_]+\\.(?:jpg|webp)")

/**
 * YouTube / Google kapak adreslerindeki küçük boyutu büyütür.
 * lh3 / ggpht adreslerinde boyut parametresi (=w226-h226) değiştirilir;
 * düşük çözünürlüklü i.ytimg.com küçük resimleri hqdefault'a yükseltilir.
 */
fun hiRes(url: String?, size: Int = 600): String? {
    if (url.isNullOrBlank()) return null
    return when {
        "googleusercontent.com" in url || "ggpht.com" in url -> when {
            sizeWh.containsMatchIn(url) -> url.replace(sizeWh, "=w$size-h$size")
            sizeS.containsMatchIn(url) -> url.replace(sizeS, "=s$size")
            else -> url
        }
        // Video küçük resimleri: büyük boyutta 1280x720 (hq720), diğerlerinde 480x360 (hqdefault)
        "ytimg.com" in url ->
            lowResYt.find(url)?.let { "https://i.ytimg.com/vi/${it.groupValues[1]}/${if (size >= 700) "hq720" else "hqdefault"}.jpg" } ?: url
        else -> url
    }
}

/**
 * YouTube verisi için tek giriş noktası. Hız için iki katmanlı önbellek tutar:
 *  - arama sonuçları (bellek + isteğe bağlı disk): ana sayfa uygulama açılır açılmaz dolar
 *  - ses akışı adresleri (bellek): şarkıya basınca beklemeden çalar, sıradaki şarkı önceden hazırlanır
 */
object MusicRepository {
    private const val SEARCH_TTL = 10 * 60_000L
    private const val STREAM_TTL = 4 * 60 * 60_000L // 4 saat (YouTube imzalı akış bağlantıları geçerlilik süresi)

    private class Timed<T>(val value: T, val at: Long = System.currentTimeMillis()) {
        fun fresh(ttl: Long) = System.currentTimeMillis() - at < ttl
    }

    private val yt get() = ServiceList.YouTube
    private val searchCache = ConcurrentHashMap<String, Timed<List<Song>>>()
    private val streamCache = ConcurrentHashMap<String, Timed<List<String>>>()
    private val playlistCache = ConcurrentHashMap<String, Timed<List<PlaylistRef>>>()
    private val playlistSongCache = ConcurrentHashMap<String, Timed<List<Song>>>()
    private val inflight = ConcurrentHashMap.newKeySet<String>()
    private val streamJobs = ConcurrentHashMap<String, Deferred<List<String>>>()
    private val prefetchJobs = ConcurrentHashMap<String, Job>()
    private val background = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var prefs: SharedPreferences? = null
    private var appCtx: Context? = null
    private var ready = false
    private var lastNet: android.net.Network? = null
    private val expireRe = Regex("[?&]expire=(\\d+)")
    private val itagRe = Regex("[?&]itag=(\\d+)")
    private val bytesGate = kotlinx.coroutines.sync.Semaphore(1)
    private val bytesInflight = ConcurrentHashMap.newKeySet<String>()

    fun init(ctx: Context) {
        if (ready) return
        appCtx = ctx.applicationContext
        prefs = ctx.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
        watchNetwork(ctx.applicationContext)
        NewPipe.init(AppDownloader(), Localization("tr", "TR"), ContentCountry("TR")) // Türkçe ağırlıklı sonuçlar
        ready = true
        warmUp()
    }

    /**
     * YouTube akış adresleri IP'ye bağlıdır: Wi-Fi <-> mobil veri geçişinde eski adresler 403 verir ve
     * şarkı birkaç saniye sonra durur. Ağ değişince saklanan tüm adresler atılır.
     */
    private fun watchNetwork(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            cm.registerDefaultNetworkCallback(object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: android.net.Network) {
                    val prev = lastNet
                    lastNet = network
                    if (prev != null && prev != network) clearStreams()
                }
                override fun onLost(network: android.net.Network) {
                    clearStreams()
                }
            })
        } catch (_: Exception) {}
    }

    /**
     * Disk önbelleği anahtarı: videoId + itag. Yalnızca videoId kullanılırsa farklı biçimlerin (m4a / webm)
     * ya da kalitelerin baytları aynı kayda karışır ve çalma ortada bozulur/durur.
     */
    fun cacheKey(pageUrl: String, streamUrl: String): String {
        val key = normalize(pageUrl)
        val itag = itagRe.find(streamUrl)?.groupValues?.get(1) ?: return key
        return "${key}_$itag"
    }

    /** Adresin `expire=` süresine 10 dakika kalmadıysa artık güvenilmez. */
    private fun stillValid(urls: List<String>): Boolean {
        val first = urls.firstOrNull() ?: return false
        val exp = expireRe.find(first)?.groupValues?.get(1)?.toLongOrNull()?.times(1000) ?: return true
        return System.currentTimeMillis() < exp - 10 * 60_000L
    }

    /** Uygulama açılırken oynatıcı betiğini önceden yükler; ilk şarkı çok daha hızlı başlar. */
    private fun warmUp() {
        background.launch {
            try {
                val req = okhttp3.Request.Builder()
                    .url("https://www.youtube.com/generate_204")
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0")
                    .build()
                Http.client.newCall(req).execute().close()
            } catch (_: Exception) {}
            try { audioUrls("https://www.youtube.com/watch?v=jNQXAC9IVRw") } catch (_: Exception) { }
        }
    }

    /** music.youtube.com / youtu.be / shorts bağlantılarını standart watch?v= biçimine çevirir. */
    private fun normalize(url: String): String {
        val m = Regex("""(?:[?&]v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})""").find(url)
        return if (m != null) "https://www.youtube.com/watch?v=${m.groupValues[1]}" else url
    }

    private fun StreamInfoItem.toSong() = Song(
        name, uploaderName ?: "", normalize(url),
        thumbnails.maxByOrNull { it.height }?.url
    )

    /** Yapay zeka ve uzun dakikalı (10+ dk, albüm/konser/loop) müzikler listede gösterilmez. */
    private fun List<StreamInfoItem>.songsNoAi(): List<Song> =
        filterNot { item ->
            try { item.duration > 600L || item.duration in 1..25L } catch (_: Throwable) { false } ||
                LongMusicFilter.isLong(item.name) ||
                NonMusicFilter.isNonMusic(item.name, item.uploaderName ?: "")
        }
        .map { it.toSong() }
        .noAi()
        .noLong()
        .noNonMusic()

    // ---- Arama ----

    /** Varsa (bayat olsa bile) önbellekteki sonucu hemen verir; ağ beklemez. */
    fun cachedSearch(query: String): List<Song>? =
        (searchCache[query]?.value ?: loadSearchFromDisk(query))?.noAi()?.noLong()?.noNonMusic()

    /** Önbellek tazeyse ağa gitmez. [persist] true ise sonuç diske de yazılır (ana sayfa için). */
    suspend fun search(query: String, persist: Boolean = false): List<Song> {
        searchCache[query]?.takeIf { it.fresh(SEARCH_TTL) }?.let { return it.value }
        val songs = withContext(Dispatchers.IO) {
            val handler = yt.searchQHFactory.fromQuery(
                query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), ""
            )
            SearchInfo.getInfo(yt, handler).relatedItems
                .filterIsInstance<StreamInfoItem>().songsNoAi()
        }
        if (songs.isNotEmpty()) {
            searchCache[query] = Timed(songs)
            if (persist) prefs?.edit()?.putString("sc_$query", songs.toJsonArray().toString())?.putString("sc_day_$query", todayKey())?.apply()
            prefetchAll(songs, 3)
        }
        return songs
    }

    private fun todayKey(): String = java.time.LocalDate.now().toString()

    /** Gün değişiminde dünden kalan tüm geçici önbellekleri temizler; her gün taze veri sağlar. */
    fun clearDailyCaches() {
        searchCache.clear()
        playlistCache.clear()
        playlistSongCache.clear()
        prefs?.let { p ->
            val curDay = todayKey()
            val edit = p.edit()
            for (k in p.all.keys) {
                if (k.startsWith("sc_day_") && p.getString(k, "") != curDay) {
                    val q = k.removePrefix("sc_day_")
                    edit.remove(k)
                    edit.remove("sc_$q")
                }
                if (k.startsWith("pl_day_") && p.getString(k, "") != curDay) {
                    val q = k.removePrefix("pl_day_")
                    edit.remove(k)
                    edit.remove("pl_$q")
                }
            }
            edit.apply()
        }
    }

    private fun loadSearchFromDisk(query: String): List<Song>? = try {
        val savedDay = prefs?.getString("sc_day_$query", null)
        if (savedDay != todayKey()) null
        else prefs?.getString("sc_$query", null)?.let { JSONArray(it).toSongs() }?.takeIf { it.isNotEmpty() }
    } catch (e: Exception) { null }

    /** Şarkı bitince "radyo" gibi devam etmek için benzer parçalar. */
    suspend fun related(pageUrl: String): List<Song> = withContext(Dispatchers.IO) {
        StreamInfo.getInfo(yt, normalize(pageUrl)).relatedItems
            .filterIsInstance<StreamInfoItem>().songsNoAi()
    }

    // ---- YouTube Music çalma listeleri (Keşfet) ----

    /** Varsa önbellekteki çalma listelerini hemen verir. */
    fun cachedPlaylists(query: String): List<PlaylistRef>? {
        playlistCache[query]?.value?.let { return it }
        val savedDay = prefs?.getString("pl_day_$query", null)
        if (savedDay != todayKey()) return null
        return try {
            prefs?.getString("pl_$query", null)?.let { raw ->
                val arr = org.json.JSONArray(raw)
                (0 until arr.length()).mapNotNull { i ->
                    val o = arr.getJSONObject(i)
                    PlaylistRef(o.getString("t"), o.getString("s"), o.getString("u"), o.optString("m").takeIf { it.isNotEmpty() }, o.optLong("c", 0L))
                }
            }?.takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }

    /** YouTube Music'te çalma listesi arar. */
    suspend fun searchPlaylists(query: String): List<PlaylistRef> {
        playlistCache[query]?.takeIf { it.fresh(SEARCH_TTL * 3) }?.let { return it.value }
        val lists = withContext(Dispatchers.IO) {
            val handler = yt.searchQHFactory.fromQuery(
                query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_PLAYLISTS), ""
            )
            SearchInfo.getInfo(yt, handler).relatedItems
                .filterIsInstance<PlaylistInfoItem>()
                .filterNot { AiFilter.isAi(it.name, it.uploaderName ?: "") }
                .map {
                    PlaylistRef(
                        Charts.cleanPlaylistTitle(it.name),
                        Charts.genreFor(it.name, it.uploaderName ?: ""),
                        it.url,
                        it.thumbnails.maxByOrNull { t -> t.height }?.url,
                        it.streamCount
                    )
                }
        }
        if (lists.isNotEmpty()) {
            playlistCache[query] = Timed(lists)
            try {
                val arr = org.json.JSONArray()
                for (p in lists) {
                    arr.put(org.json.JSONObject().put("t", p.title).put("s", p.owner).put("u", p.url).put("m", p.thumb ?: "").put("c", p.count))
                }
                prefs?.edit()?.putString("pl_$query", arr.toString())?.putString("pl_day_$query", todayKey())?.apply()
            } catch (_: Exception) {}
        }
        return lists
    }

    /** Bir çalma listesindeki şarkıları getirir. */
    suspend fun playlistSongs(url: String): List<Song> {
        playlistSongCache[url]?.takeIf { it.fresh(SEARCH_TTL) }?.let { return it.value }
        val songs = withContext(Dispatchers.IO) {
            PlaylistInfo.getInfo(yt, url).relatedItems
                .filterIsInstance<StreamInfoItem>().songsNoAi()
        }
        if (songs.isNotEmpty()) playlistSongCache[url] = Timed(songs)
        return songs
    }

    // ---- Arama önerileri ve önbellek ----

    /** Arama kutusuna yazarken YouTube'un önerdiği muhtemel aramalar. */
    /** Müzik dışı öneriler (oyun, haber, dizi, ders vb.) listeden çıkarılır. */
    private val nonMusicSuggestion = Regex(
        "(?i)\\b(?:izle|oyun|oyunu|haber\\w*|mac|maci|dizi|film|fragman\\w*|ders|nasil|nasıl|tarif\\w*|hava\\s*durumu|" +
            "dolar|euro|altin|altın|fiyat\\w*|sinav|sınav|kpss|yks|vlog|gameplay|walkthrough|minecraft|roblox|pubg|fifa|" +
            "podcast|bolum|bölüm|sezon|canli\\s*yayin|canlı\\s*yayın|porno|sex|seks)\\b"
    )

    /** Arama önerileri müzikle ilgili olur: hem yazılan metin hem müziğe yönlendirilmiş sorgular (şarkı / music) sorulur, müzik dışı olanlar elenir. */
    suspend fun suggestions(query: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val q = query.trim()
            val lists = coroutineScope {
                listOf(q, "$q şarkı", "$q music").map { qq ->
                    async { try { yt.suggestionExtractor.suggestionList(qq) } catch (e: CancellationException) { throw e } catch (e: Exception) { emptyList<String>() } }
                }.awaitAll()
            }
            // Sıra: müziğe yönlendirilmiş sorguların önerileri önce, düz öneriler sonra; tekrarlar atılır
            val merged = (lists[1].take(4) + lists[0] + lists[2].take(3) + lists[1].drop(4))
                .map { it.trim() }.filter { it.isNotEmpty() }
                .distinctBy { it.lowercase() }
                .filter { !nonMusicSuggestion.containsMatchIn(it) && !NonMusicFilter.isNonMusic(it) }
            merged.take(8)
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { emptyList() }
    }

    /** Kalite ayarı değişince eski akış adresleri atılır. */
    fun clearStreams() { streamCache.clear(); removeDiskStreams() }

    private fun removeDiskStreams(onlyKey: String? = null) {
        prefs?.let { p ->
            val e = p.edit()
            if (onlyKey != null) e.remove("st_$onlyKey")
            else p.all.keys.filter { it.startsWith("st_") }.forEach { k -> e.remove(k) }
            e.apply()
        }
    }

    /** Arama, çalma listesi ve akış önbelleğini (diskteki dahil) temizler. */
    /** Tek bir şarkının güncel başlık, sanatçı ve kapak bilgilerini alır */
    suspend fun songInfo(url: String): Song? = withContext(Dispatchers.IO) {
        try {
            val key = normalize(url)
            val info = org.schabi.newpipe.extractor.stream.StreamInfo.getInfo(yt, key)
            Song(
                title = info.name,
                artist = info.uploaderName ?: "",
                url = key,
                thumb = info.thumbnails.maxByOrNull { it.height }?.url
            )
        } catch (_: Exception) { null }
    }

    fun clearCache() {
        searchCache.clear(); playlistCache.clear(); playlistSongCache.clear(); clearStreams()
        prefs?.let { p ->
            val e = p.edit()
            p.all.keys.filter { it.startsWith("sc_") }.forEach { e.remove(it) }
            e.apply()
        }
    }

    // ---- Disk tabanlı ses akışı önbelleği ve bağlantı ısıtma (Modern ) ----

    private fun currentNetworkKey(): String {
        val app = appCtx ?: return "NET"
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return "NET"
        val net = cm.activeNetwork ?: return "NONE"
        val caps = cm.getNetworkCapabilities(net) ?: return "NONE"
        return when {
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
            else -> "OTHER"
        }
    }

    private fun loadStreamFromDisk(key: String): List<String>? = try {
        prefs?.getString("st_$key", null)?.let { raw ->
            val parts = raw.split("|||")
            if (parts.size >= 2) {
                val time = parts[0].toLongOrNull() ?: 0L
                val savedNet = if (parts.size >= 3) parts[1] else ""
                val jsonStr = if (parts.size >= 3) parts[2] else parts[1]
                val curNet = currentNetworkKey()
                // Wi-Fi iken kaydedilen IP bazlı YouTube adresleri mobil veride 403 verir; ağ türü değiştiyse taze adres çek
                if (savedNet.isNotEmpty() && savedNet != curNet && curNet != "NONE") {
                    null
                } else if (System.currentTimeMillis() - time < STREAM_TTL) {
                    val arr = org.json.JSONArray(jsonStr)
                    (0 until arr.length()).map { arr.getString(it) }.takeIf { stillValid(it) }
                } else null
            } else null
        }
    } catch (_: Exception) { null }

    private fun saveStreamToDisk(key: String, urls: List<String>) {
        try {
            if (urls.isEmpty()) return
            val arr = org.json.JSONArray()
            urls.forEach { arr.put(it) }
            val net = currentNetworkKey()
            val raw = "${System.currentTimeMillis()}|||$net|||$arr"
            prefs?.edit()?.putString("st_$key", raw)?.apply()
        } catch (_: Exception) {}
    }

    /**
     * HTTP soketini ve TLS el sıkışmasını arka planda önceden tamamlar.
     * Kullanıcı şarkıya dokunduğunda bağlantı zaten açıktır; ilk bayt 0 ms'ye yakın gecikmeyle gelir.
     */
    fun warmConnection(url: String?) {
        if (url.isNullOrBlank() || !url.startsWith("http")) return
        background.launch {
            try {
                val req = okhttp3.Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; rv:128.0) Gecko/20100101 Firefox/128.0")
                    .header("Range", "bytes=0-8192")
                    .build()
                Http.client.newCall(req).execute().use { r ->
                    r.body?.byteStream()?.read(ByteArray(1024))
                }
            } catch (_: Exception) {}
        }
    }

    // ---- Ses akışı ----

    /**
     * Çalınabilir ses bağlantıları, en iyiden başlayarak (hata olursa sıradakine geçilir).
     * Aynı şarkı için çözümleme zaten sürüyorsa (örn. önceden hazırlama) onu bekler; baştan başlamaz.
     */
    suspend fun audioUrls(pageUrl: String, highPriority: Boolean = false): List<String> {
        val key = normalize(pageUrl)
        // 1. Bellek önbelleği (0 ms anında dönüş)
        streamCache[key]?.takeIf { it.fresh(STREAM_TTL) && stillValid(it.value) }?.let { return it.value }

        // 2. Disk önbelleği (Uygulama yeniden açılsa bile anında dönüş: 0.2 ms)
        loadStreamFromDisk(key)?.let {
            streamCache[key] = Timed(it)
            warmConnection(it.firstOrNull())
            return it
        }

        // 3. Halihazırda bu şarkı için devam eden bir çözümleme işi varsa onu bekle (çift istek atıp bant genişliğini tüketme)
        val inFlight = streamJobs[key]
        if (inFlight != null && inFlight.isActive) {
            try {
                val urls = inFlight.await()
                if (urls.isNotEmpty()) return urls
            } catch (_: Exception) {}
        }

        if (highPriority) {
            // Kullanıcı şarkıya dokundu: Bu şarkı HARİÇ diğer arka plan yüklemelerini durdur
            // Tıklanan şarkı zaten çözümleniyorsa kesintiye uğramaz, tüm ağ gücü ona aktarılır
            cancelOtherPrefetches(key)
        }

        // 4. Yeni bir çözümleme başlat ve streamJobs'a kaydet (aynı anda tek istek)
        val fresh = background.async {
            try {
                fetchAudioUrls(key).also { urls ->
                    if (urls.isNotEmpty()) {
                        streamCache[key] = Timed(urls)
                        saveStreamToDisk(key, urls)
                        warmConnection(urls.firstOrNull())
                    }
                }
            } finally {
                streamJobs.remove(key)
            }
        }
        val running = streamJobs.putIfAbsent(key, fresh) ?: fresh
        return running.await()
    }

    private fun fetchAudioUrls(key: String): List<String> {
        // Yalnızca akış bilgisi alınır (ilgili videolar vb. atlanır): şarkı daha hızlı başlar
        val extractor = yt.getStreamExtractor(key)
        extractor.fetchPage()
        var streams = extractor.audioStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.content.isNotBlank() }
            .sortedByDescending { it.averageBitrate }
        if (streams.isEmpty()) {
            streams = extractor.audioStreams.filter { it.content.isNotBlank() }.sortedByDescending { it.averageBitrate }
        }
        // Ayarlardaki ses kalitesine göre sırala: 2 normal (~128 kbps), 3 düşük, diğerleri en yüksek
        val ordered = when (AppSettings.quality.value) {
            2 -> streams.sortedBy { kotlin.math.abs(it.averageBitrate - 128) }
            3 -> streams.sortedBy { if (it.averageBitrate > 0) it.averageBitrate else Int.MAX_VALUE }
            else -> streams
        }
        return (ordered.filter { it.format?.suffix == "m4a" } + ordered.filter { it.format?.suffix != "m4a" })
            .map { it.content }.distinct()
    }

    /** Önceden hazırlama en fazla 3 şarkıyı aynı anda çözer; arayüz ve çalan şarkı yavaşlamaz. */
    private val prefetchGate = kotlinx.coroutines.sync.Semaphore(4) // Modern  paralel önden yükleme

    /** Bekleyen ve devam eden diğer arka plan ön yüklemelerini durdurur (tıklanan şarkı hariç). */
    fun cancelOtherPrefetches(exceptKey: String? = null) {
        prefetchJobs.forEach { (k, j) ->
            if (k != exceptKey) {
                j.cancel()
                prefetchJobs.remove(k)
                inflight.remove(k)
            }
        }
    }

    /** Şarkının akış adresini arka planda önceden hazırlar; basıldığında çalma gecikmesiz başlar. */
    fun prefetch(pageUrl: String) {
        if (pageUrl.startsWith("local://")) return
        val key = normalize(pageUrl)
        if (streamCache[key]?.let { it.fresh(STREAM_TTL) && stillValid(it.value) } == true || loadStreamFromDisk(key) != null || !inflight.add(key)) return
        val job = background.launch {
            try { prefetchGate.withPermit { audioUrls(key) } } catch (_: Exception) { } finally { inflight.remove(key); prefetchJobs.remove(key) }
        }
        prefetchJobs[key] = job
    }

    /** Listedeki ilk [count] şarkıyı hazırlar (dokununca anında çalsın). */
    fun prefetchAll(songs: List<Song>, count: Int = 3) {
        songs.take(count).forEach { prefetch(it.url) }
    }

    /** Ekrana gelen şarkı için: 50 ms bekleme sonrası hazırlar (Modern  anında hazır). */
    suspend fun prefetchWhenIdle(song: Song) {
        kotlinx.coroutines.delay(50)
        prefetch(song.url)
    }

    /** Bağlantı reddedilirse önbellekteki adresler atılır, bir sonraki deneme taze adres alır. */
    fun invalidate(pageUrl: String) {
        val key = normalize(pageUrl)
        streamCache.remove(key)
        removeDiskStreams(key) // diskte kalan ölü adres yeniden denemede tekrar verilmesin
    }

    /**
     * Sıradaki şarkının ilk ~[bytes] baytını diske (SimpleCache) indirir: şarkıya geçildiğinde
     * ağ beklemeden hemen çalar. Aynı anda en fazla bir indirme çalışır, çalan şarkının bant genişliğini yemez.
     */
    suspend fun prefetchBytes(pageUrl: String, bytes: Long = 512_000L) {
        val ctx = appCtx ?: return
        if (pageUrl.startsWith("local://")) return
        val key = normalize(pageUrl)
        if (!bytesInflight.add(key)) return
        try {
            bytesGate.withPermit {
                withContext(Dispatchers.IO) {
                    val url = audioUrls(key).firstOrNull() ?: return@withContext
                    val ck = cacheKey(key, url)
                    val cache = AudioCache.get(ctx)
                    if (cache.isCached(ck, 0, bytes)) return@withContext
                    val spec = DataSpec.Builder().setUri(url).setKey(ck).setPosition(0).setLength(bytes).build()
                    CacheWriter(AudioCache.factory(ctx).createDataSource(), spec, null, null).cache()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        } finally {
            bytesInflight.remove(key)
        }
    }
}
