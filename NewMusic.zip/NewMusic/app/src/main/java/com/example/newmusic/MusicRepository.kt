package com.example.newmusic

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class Song(val title: String, val artist: String, val url: String, val thumb: String?)

object MusicRepository {
    private var ready = false
    private val yt get() = ServiceList.YouTube

    fun init() {
        if (!ready) { NewPipe.init(AppDownloader()); ready = true }
    }

    /** music.youtube.com / youtu.be / shorts bağlantılarını standart watch?v= biçimine çevirir. */
    private fun normalize(url: String): String {
        val m = Regex("""(?:[?&]v=|youtu\.be/|/shorts/|/embed/)([A-Za-z0-9_-]{11})""").find(url)
        return if (m != null) "https://www.youtube.com/watch?v=${m.groupValues[1]}" else url
    }

    private fun StreamInfoItem.toSong() = Song(
        name, uploaderName ?: "", normalize(url),
        thumbnails.maxByOrNull { it.height }?.url
    )

    suspend fun search(query: String): List<Song> = withContext(Dispatchers.IO) {
        val handler = yt.searchQHFactory.fromQuery(
            query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), ""
        )
        SearchInfo.getInfo(yt, handler).relatedItems
            .filterIsInstance<StreamInfoItem>().map { it.toSong() }
    }

    /** Şarkı bitince "radyo" gibi devam etmek için benzer parçalar. */
    suspend fun related(pageUrl: String): List<Song> = withContext(Dispatchers.IO) {
        StreamInfo.getInfo(yt, normalize(pageUrl)).relatedItems
            .filterIsInstance<StreamInfoItem>().map { it.toSong() }
    }

    /** Çalınabilir ses bağlantıları, en iyiden başlayarak (hata olursa sıradakine geçilir). */
    suspend fun audioUrls(pageUrl: String): List<String> = withContext(Dispatchers.IO) {
        val streams = StreamInfo.getInfo(yt, normalize(pageUrl)).audioStreams
            .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.content.isNotBlank() }
            .sortedByDescending { it.averageBitrate }
        (streams.filter { it.format?.suffix == "m4a" } + streams.filter { it.format?.suffix != "m4a" })
            .map { it.content }.distinct()
    }
}
