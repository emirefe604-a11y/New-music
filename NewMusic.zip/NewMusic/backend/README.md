# Sounddeep sunucusu

Hesaplar (kullanıcı adı + e-posta + şifre), şifre sıfırlama, arkadaşlar, çevrim içi bilgisi, liste/beğeni yedeği, Blend ve liste paylaşımı bu sunucuda çalışır.

## 1) Yayınla (örnek: Render.com, ücretsiz)
1. Bu projeyi GitHub'a yükle.
2. Render'da **New > Web Service** seç, repoyu bağla.
3. Root Directory: `backend` (repoda `NewMusic/backend` ise onu yaz), Build Command: `npm install`, Start Command: `npm start`.
4. Yayınlanınca bir adres alırsın (örn. `https://new-music-xxxx.onrender.com`).
5. `app/src/main/java/com/example/newmusic/Social.kt` içindeki `SOCIAL_API_URL` değerine bu adresi yaz.

## 2) Kalıcı veri: Upstash Redis (ücretsiz) — ÖNEMLİ
Render ücretsiz pakette disk silinir. Hesaplar, şifreler, arkadaşlar ve **listeler/beğeniler yedeği** kaybolmasın diye:
1. https://upstash.com adresinde ücretsiz hesap aç, **Create Database** (Redis) de.
2. **REST API** bölümünden `UPSTASH_REDIS_REST_URL` ve `UPSTASH_REDIS_REST_TOKEN` değerlerini kopyala.
3. Render'da servisin **Environment** bölümüne bu iki değişkeni aynı adlarla ekle.

Bu iki değişken yoksa veriler dosyaya (`DATA_FILE`, varsayılan `./social-data.json`) yazılır; Render'da bu dosya silinir.

## 3) E-posta (şifre sıfırlama kodları için)
Hesap açarken e-postaya 6 haneli kod gider; şifreni unutursan "Şifremi unuttum" ile hesabına bağlı e-postaya kod gelir ve yeni şifre belirlersin.
Sunucunun e-posta gönderebilmesi için **birini** ayarla (Render > Environment):

**A) Brevo (önerilen, ücretsiz: günde 300 e-posta)** — Render ücretsiz pakette SMTP portları kapalı olduğu için HTTPS ile gönderen bu yol daha güvenilirdir.
1. https://brevo.com adresinde ücretsiz hesap aç, **SMTP & API > API Keys** bölümünden bir API anahtarı oluştur.
2. **Senders & IP > Senders** bölümünde gönderen e-posta adresini ekleyip doğrula (kendi Gmail adresin olabilir).
3. Render'a ekle: `BREVO_API_KEY` = anahtar, `MAIL_FROM` = doğruladığın gönderen adres.

**B) SMTP (Gmail uygulama şifresi)** — `SMTP_USER`, `SMTP_PASS` (16 haneli uygulama şifresi). Hosting sağlayıcın SMTP'ye izin veriyorsa çalışır.

Hiçbiri ayarlı değilse sunucu açılır ama e-posta kapalı kalır: hesaplar e-postasız açılır ve şifre sıfırlama çalışmaz.
Denemek için `MAIL_MODE=console` yazarsan kodlar e-posta yerine sunucu loguna yazılır (canlıda kullanma).

## Nasıl çalışır
- **Hesap:** kullanıcı adı + doğrulanmış e-posta + şifre. Şifre sunucuda scrypt ile tuzlanıp saklanır. Bir e-posta yalnızca bir hesaba bağlanır.
  Şifre sıfırlanınca tüm cihazların oturumu kapanır. Kodlar 10 dakika geçerlidir, 5 yanlış denemede iptal olur, tek kullanımlıktır. Uygulamayı silsen ya da telefon değiştirsen
  "Giriş yap" ile aynı bilgilerle girersin. Bir hesapta en fazla 5 cihaz oturumu açık kalır.
- **Yedek:** beğenilen şarkılar, çalma listeleri, zevk profili ve ayarlar sıkıştırılıp sunucuda saklanır (`/social/data-put`, `/social/data-get`).
  Uygulama silinince bile girişte geri gelir. Cihazdan yüklenen/indirilen müzik dosyaları yedeklenmez (yalnızca şarkı bilgisi).
- **Çevrim içi:** uygulama açıkken veya arka planda müzik çalarken 25 sn'de bir sinyal gönderir; 100 sn sinyal gelmezse çevrim dışı görünür.
- **Blend:** uygulama en çok dinlenen sanatçılarını hesabına yazar (`/social/taste`); arkadaşını seçince onun sanatçıları
  çekilir (`/social/blend`, yalnızca arkadaşlar) ve ortak liste oluşturulur.
- **Profil resmi:** 256 px'lik JPEG (en fazla 60 KB), giriş yapmış kullanıcılar görebilir.
- Çevrim içi/dışı bilgisi bellekte tutulur; sunucu yeniden başlayınca birkaç saniye herkes "çevrim dışı" görünür.

## Güvenlik notları
- Şifre en az 4 karakter (uygulama 6 ister). Yanlış girişler hız sınırlıdır (hesap başına ve IP başına).
- Eski (e-postasız / şifresiz) hesaplar **Ayarlar > Profil** bölümünden e-posta bağlar ve şifre koyar; yoksa şifre unutulunca hesap kurtarılamaz.
