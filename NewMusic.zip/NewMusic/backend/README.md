# Sounddeep e-posta kodu sunucusu

Uygulama, hesap oluştururken kullanıcının e-postasına 6 haneli bir kod gönderir.
E-posta göndermek için gizli bir şifre gerekir; bu şifre telefondaki uygulamaya konmamalı.
Bu yüzden küçük bir sunucu kullanılır (bu klasör).

## 1) Gmail "uygulama şifresi" al
1. Gönderici olarak kullanacağın Gmail hesabında **2 adımlı doğrulamayı** aç.
2. Google Hesabı > Güvenlik > **Uygulama şifreleri** bölümünden bir şifre oluştur (16 haneli).

## 2) Sunucuyu yayınla (örnek: Render.com, ücretsiz)
1. Bu `backend` klasörünü GitHub'a yükle (repoda `backend/` olarak kalabilir).
2. Render'da **New > Web Service** seç, repoyu bağla.
3. Root Directory: `NewMusic/backend` (repodaki konuma göre), Build Command: `npm install`, Start Command: `npm start`.
4. Environment (ortam değişkenleri):
   - `SMTP_USER` = gönderen Gmail adresin
   - `SMTP_PASS` = 16 haneli uygulama şifresi
5. Yayınlanınca bir adres alırsın, örn. `https://sounddeep-auth.onrender.com`.

## 3) Uygulamaya adresi yaz
`app/src/main/java/com/example/newmusic/AuthStore.kt` dosyasında:

```kotlin
const val AUTH_API_URL = "https://sounddeep-auth.onrender.com"
```

Sonra projeyi yeniden derle. Artık girilen e-postaya kod gider.

## Güvenlik notları
- Kod 10 dakika geçerli, 5 yanlış denemeden sonra iptal olur.
- Aynı adrese 30 saniyede bir kod gönderilir; IP başına istek sınırı vardır.
- Kodlar sunucu belleğinde hash olarak tutulur; sunucu yeniden başlarsa bekleyen kodlar silinir.
- Gmail ile günlük gönderim sınırı vardır (yaklaşık 500 e-posta). Çok kullanıcı olursa
  bir e-posta servisi (Resend, SendGrid, Brevo) kullanmak daha uygundur.
- Şu an hesap yalnızca cihazda saklanır; sunucu bir oturum anahtarı üretmez.
