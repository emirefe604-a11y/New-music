# Sounddeep e-posta kodu sunucusu

Uygulama, hesap oluştururken kullanıcının e-postasına 6 haneli bir kod gönderir.
E-posta göndermek için gizli bir şifre gerekir; bu şifre telefondaki uygulamaya konmamalı.
Bu yüzden küçük bir sunucu kullanılır (bu klasör).

## 1) Gmail "uygulama şifresi" al
1. Gönderici olarak kullanacağın Gmail hesabında **2 adımlı doğrulamayı** aç.
2. Google Hesabı > Güvenlik > **Uygulama şifreleri** bölümünden bir şifre oluştur (16 haneli).

## 2) Sunucuyu yayınla (örnek: Render.com, ücretsiz)
1. Bu `backend` klasörünü GitHub'a yükle (repoda `backend/` olarak kalabilir).
2. Render'da **New > Web Service** seç, repoyu bağla.
3. Root Directory: `NewMusic/backend` (repodaki konuma göre), Build Command: `npm install`, Start Command: `npm start`.
4. Environment (ortam değişkenleri):
   - `SMTP_USER` = gönderen Gmail adresin
   - `SMTP_PASS` = 16 haneli uygulama şifresi
5. Yayınlanınca bir adres alırsın, örn. `https://sounddeep-auth.onrender.com`.

## 3) Uygulamaya adresi yaz
`app/src/main/java/com/example/newmusic/AuthStore.kt` dosyasında:

```kotlin
const val AUTH_API_URL = "https://sounddeep-auth.onrender.com"
```

Sonra projeyi yeniden derle. Artık girilen e-postaya kod gider.

## Güvenlik notları
- Kod 10 dakika geçerli, 5 yanlış denemeden sonra iptal olur.
- Aynı adrese 30 saniyede bir kod gönderilir; IP başına istek sınırı vardır.
- Kodlar sunucu belleğinde hash olarak tutulur; sunucu yeniden başlarsa bekleyen kodlar silinir.
- Gmail ile günlük gönderim sınırı vardır (yaklaşık 500 e-posta). Çok kullanıcı olursa
  bir e-posta servisi (Resend, SendGrid, Brevo) kullanmak daha uygundur.
- Şu an hesap yalnızca cihazda saklanır; sunucu bir oturum anahtarı üretmez.

## Sosyal özellikler (arkadaşlar, çevrim içi bilgisi, liste paylaşımı)

`social.js` aynı sunucuda çalışır; ek kurulum gerekmez. E-posta ayarları (`SMTP_*`) yoksa sunucu yine açılır,
yalnızca e-posta kodu kapalı kalır.

- **Kalıcı ve ücretsiz depolama: Upstash Redis.** Render ücretsiz pakette disk kalıcı değildir, bu yüzden veriler Upstash'ta tutulur:
  1. https://upstash.com adresinde ücretsiz hesap aç, **Create Database** (Redis) de, bölge olarak sana yakın birini seç.
  2. Veritabanı sayfasında **REST API** bölümünden `UPSTASH_REDIS_REST_URL` ve `UPSTASH_REDIS_REST_TOKEN` değerlerini kopyala.
  3. Render'da servisin **Environment** bölümüne bu iki değişkeni aynı adlarla ekle, servis yeniden başlasın.
  Bu iki değişken yoksa veriler dosyaya (`DATA_FILE`, varsayılan `./social-data.json`) yazılır; Render'da bu dosya silinir.
- Çevrim içi/dışı bilgisi (son sinyal zamanı) veritabanına yazılmaz, bellekte tutulur. Sunucu yeniden başlayınca herkes
  birkaç saniye "çevrim dışı" görünür, uygulamalar sinyal gönderince düzelir.
- Çevrim içi sayılma: uygulama açıkken 5 sn'de bir, arka planda müzik çalarken 15 sn'de bir sinyal gönderir; 50 sn sinyal
  gelmezse çevrim dışı görünür. Arka plandayken müzik çalmıyorsa uygulama 60 sn sonra kendini çevrim dışı yapar.
- Profil fotoğrafları (256x256 JPEG, en fazla 64 KB) Upstash'ta saklanır; Upstash yoksa `AVATAR_DIR` klasörüne yazılır.
  Fotoğraf adresi tahmin edilemeyen rastgele bir kimliktir ve yalnızca arkadaşların listesinde görünür.
- Sosyal hesap, kullanıcı adı + cihazda saklanan gizli anahtardan oluşur. Uygulama silinip yeniden kurulursa
  anahtar kaybolur ve yeni bir kullanıcı adı alınması gerekir.
