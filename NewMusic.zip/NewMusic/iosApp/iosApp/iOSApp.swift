import SwiftUI

@main
struct iOSApp: App {
    @StateObject private var player = AudioPlayer.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(player)
                .preferredColorScheme(.dark)
        }
    }
}
