import Foundation
import AVFoundation
import MediaPlayer
import Combine

public struct SongItem: Identifiable, Codable, Equatable {
    public var id: String { url }
    public let title: String
    public let artist: String
    public let url: String
    public let thumb: String?

    public init(title: String, artist: String, url: String, thumb: String? = nil) {
        self.title = title
        self.artist = artist
        self.url = url
        self.thumb = thumb
    }
}

public class AudioPlayer: ObservableObject {
    public static let shared = AudioPlayer()

    private var player: AVPlayer?
    private var timeObserverToken: Any?
    private var cancellables = Set<AnyCancellable>()

    @Published public var queue: [SongItem] = []
    @Published public var currentIndex: Int = 0
    @Published public var currentSong: SongItem? = nil
    @Published public var isPlaying: Bool = false
    @Published public var currentTime: Double = 0.0
    @Published public var duration: Double = 0.0
    @Published public var isBuffering: Bool = false

    private init() {
        setupAudioSession()
        setupRemoteCommands()
    }

    private func setupAudioSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [])
            try session.setActive(true)
        } catch {
            print("Audio session setup error: \(error.localizedDescription)")
        }
    }

    private func setupRemoteCommands() {
        let commandCenter = MPRemoteCommandCenter.shared()

        commandCenter.playCommand.isEnabled = true
        commandCenter.playCommand.addTarget { [weak self] _ in
            self?.resume()
            return .success
        }

        commandCenter.pauseCommand.isEnabled = true
        commandCenter.pauseCommand.addTarget { [weak self] _ in
            self?.pause()
            return .success
        }

        commandCenter.togglePlayPauseCommand.isEnabled = true
        commandCenter.togglePlayPauseCommand.addTarget { [weak self] _ in
            self?.togglePlayPause()
            return .success
        }

        commandCenter.nextTrackCommand.isEnabled = true
        commandCenter.nextTrackCommand.addTarget { [weak self] _ in
            self?.next()
            return .success
        }

        commandCenter.previousTrackCommand.isEnabled = true
        commandCenter.previousTrackCommand.addTarget { [weak self] _ in
            self?.previous()
            return .success
        }

        commandCenter.changePlaybackPositionCommand.isEnabled = true
        commandCenter.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let self = self, let positionEvent = event as? MPChangePlaybackPositionCommandEvent else {
                return .commandFailed
            }
            self.seek(to: positionEvent.positionTime)
            return .success
        }
    }

    public func playQueue(_ songs: [SongItem], startIndex: Int = 0) {
        guard !songs.isEmpty else { return }
        self.queue = songs
        self.currentIndex = min(max(0, startIndex), songs.count - 1)
        playCurrentSong()
    }

    public func playSingle(_ song: SongItem) {
        self.queue = [song]
        self.currentIndex = 0
        playCurrentSong()
    }

    private func playCurrentSong() {
        guard queue.indices.contains(currentIndex) else { return }
        let song = queue[currentIndex]
        self.currentSong = song

        guard let songUrl = URL(string: song.url) else { return }

        // Temizle
        if let token = timeObserverToken {
            player?.removeTimeObserver(token)
            timeObserverToken = nil
        }
        NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: nil)

        let playerItem = AVPlayerItem(url: songUrl)
        player = AVPlayer(playerItem: playerItem)
        player?.automaticallyWaitsToMinimizeStalling = false

        // Bildirim: Şarkı bitince sonrakine geç
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playerItemDidReachEnd),
            name: .AVPlayerItemDidPlayToEndTime,
            object: playerItem
        )

        // Zaman gözlemcisi
        let interval = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        timeObserverToken = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self = self else { return }
            self.currentTime = time.seconds
            if let currentItem = self.player?.currentItem {
                let dur = currentItem.duration.seconds
                if !dur.isNaN && dur > 0 {
                    self.duration = dur
                }
            }
            self.updateNowPlayingPlaybackInfo()
        }

        player?.play()
        self.isPlaying = true
        updateNowPlayingMetadata(song: song)
    }

    @objc private func playerItemDidReachEnd() {
        next()
    }

    public func togglePlayPause() {
        if isPlaying {
            pause()
        } else {
            resume()
        }
    }

    public func resume() {
        player?.play()
        isPlaying = true
        updateNowPlayingPlaybackInfo()
    }

    public func pause() {
        player?.pause()
        isPlaying = false
        updateNowPlayingPlaybackInfo()
    }

    public func next() {
        if currentIndex + 1 < queue.count {
            currentIndex += 1
            playCurrentSong()
        } else {
            // Liste bitti, başa dön veya durdur
            pause()
            seek(to: 0)
        }
    }

    public func previous() {
        if currentTime > 3.0 {
            seek(to: 0)
        } else if currentIndex > 0 {
            currentIndex -= 1
            playCurrentSong()
        } else {
            seek(to: 0)
        }
    }

    public func seek(to seconds: Double) {
        let time = CMTime(seconds: seconds, preferredTimescale: 1000)
        player?.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
        currentTime = seconds
        updateNowPlayingPlaybackInfo()
    }

    // Kilit Ekranı Bilgilerini Güncelleme
    private func updateNowPlayingMetadata(song: SongItem) {
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: song.title,
            MPMediaItemPropertyArtist: song.artist,
            MPNowPlayingInfoPropertyPlaybackRate: 1.0,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: 0.0
        ]

        if let thumbUrl = song.thumb, let url = URL(string: thumbUrl) {
            URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
                guard let data = data, let image = UIImage(data: data) else { return }
                DispatchQueue.main.async {
                    var currentInfo = MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:]
                    let artwork = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
                    currentInfo[MPMediaItemPropertyArtwork] = artwork
                    MPNowPlayingInfoCenter.default().nowPlayingInfo = currentInfo
                }
            }.resume()
        }

        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func updateNowPlayingPlaybackInfo() {
        guard var info = MPNowPlayingInfoCenter.default().nowPlayingInfo else { return }
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = currentTime
        if duration > 0 {
            info[MPMediaItemPropertyPlaybackDuration] = duration
        }
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1.0 : 0.0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}
