import SwiftUI

struct ContentView: View {
    @EnvironmentObject var player: AudioPlayer
    @State private var selectedTab: Int = 0
    @State private var showFullPlayer: Bool = false

    var body: some View {
        ZStack(alignment: .bottom) {
            Color(hex: "070B14").ignoresSafeArea()

            TabView(selection: $selectedTab) {
                HomeView()
                    .tabItem {
                        Label("Keşfet", systemImage: "music.note.house")
                    }
                    .tag(0)

                FriendsView()
                    .tabItem {
                        Label("Arkadaşlar", systemImage: "person.2.fill")
                    }
                    .tag(1)

                LibraryView()
                    .tabItem {
                        Label("Kitaplık", systemImage: "music.note.list")
                    }
                    .tag(2)
            }
            .accentColor(Color(hex: "4D8DFF"))

            // Mini Oynatıcı
            if let song = player.currentSong {
                MiniPlayerView(song: song, onTap: {
                    showFullPlayer = true
                })
                .padding(.bottom, 54)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .fullScreenCover(isPresented: $showFullPlayer) {
            if let song = player.currentSong {
                FullPlayerView(song: song, isPresented: $showFullPlayer)
                    .environmentObject(player)
            }
        }
    }
}

// MARK: - Mini Oynatıcı
struct MiniPlayerView: View {
    @EnvironmentObject var player: AudioPlayer
    let song: SongItem
    let onTap: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            // Kapak
            AsyncImage(url: URL(string: song.thumb ?? "")) { image in
                image.resizable().aspectRatio(contentMode: .fill)
            } placeholder: {
                Color.gray.opacity(0.3)
                    .overlay(Image(systemName: "music.note").foregroundColor(.white))
            }
            .frame(width: 44, height: 44)
            .clipShape(RoundedRectangle(cornerRadius: 10))

            // Şarkı bilgisi
            VStack(alignment: .leading, spacing: 2) {
                Text(song.title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                Text(song.artist)
                    .font(.system(size: 12))
                    .foregroundColor(Color(hex: "9A9A9A"))
                    .lineLimit(1)
            }

            Spacer()

            // Oynat/Durdur
            Button(action: { player.togglePlayPause() }) {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 18))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
            }

            // Sonraki şarkı
            Button(action: { player.next() }) {
                Image(systemName: "forward.fill")
                    .font(.system(size: 16))
                    .foregroundColor(.white)
                    .frame(width: 36, height: 36)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(hex: "151E33").opacity(0.95))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                )
        )
        .padding(.horizontal, 12)
        .onTapGesture { onTap() }
    }
}

// MARK: - Tam Ekran Oynatıcı (Aşağı kaydırınca küçülen, şarkı sözü destekli)
struct FullPlayerView: View {
    @EnvironmentObject var player: AudioPlayer
    let song: SongItem
    @Binding var isPresented: Bool
    @State private var dragOffset: CGFloat = 0
    @State private var showLyrics: Bool = false
    @State private var lyrics: [LyricLine] = []

    var body: some View {
        ZStack {
            Color(hex: "070B14").ignoresSafeArea()

            VStack(spacing: 0) {
                // Sürükleme tutamacı
                Capsule()
                    .fill(Color.white.opacity(0.3))
                    .frame(width: 40, height: 5)
                    .padding(.top, 12)
                    .padding(.bottom, 16)

                // Üst Bar
                HStack {
                    Button(action: { isPresented = false }) {
                        Image(systemName: "chevron.down")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    Spacer()
                    Text("ŞU AN ÇALIYOR")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(Color(hex: "9A9A9A"))
                        .tracking(1.2)
                    Spacer()
                    Button(action: { showLyrics.toggle() }) {
                        Image(systemName: showLyrics ? "quote.bubble.fill" : "quote.bubble")
                            .font(.system(size: 18))
                            .foregroundColor(showLyrics ? Color(hex: "4D8DFF") : .white)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)

                if showLyrics {
                    // Akan Şarkı Sözleri Alanı
                    ScrollViewReader { proxy in
                        ScrollView {
                            VStack(spacing: 16) {
                                if lyrics.isEmpty {
                                    Text("Şarkı sözleri yükleniyor veya bulunamadı...")
                                        .foregroundColor(Color(hex: "9A9A9A"))
                                        .padding(.top, 60)
                                } else {
                                    ForEach(lyrics) { line in
                                        let isCurrent = player.currentTime >= line.time &&
                                            (lyrics.first(where: { $0.time > line.time })?.time ?? Double.infinity) > player.currentTime
                                        Text(line.text)
                                            .font(.system(size: isCurrent ? 22 : 18, weight: isCurrent ? .bold : .medium))
                                            .foregroundColor(isCurrent ? .white : Color.white.opacity(0.4))
                                            .multilineTextAlignment(.center)
                                            .id(line.id)
                                            .scaleEffect(isCurrent ? 1.05 : 1.0)
                                            .animation(.spring(), value: isCurrent)
                                    }
                                }
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 30)
                        }
                    }
                    .frame(maxHeight: .infinity)
                } else {
                    // Albüm Kapağı
                    AsyncImage(url: URL(string: song.thumb ?? "")) { image in
                        image.resizable().aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Color.gray.opacity(0.3)
                            .overlay(Image(systemName: "music.note").font(.system(size: 60)).foregroundColor(.white))
                    }
                    .frame(width: 280, height: 280)
                    .clipShape(RoundedRectangle(cornerRadius: 24))
                    .shadow(color: Color(hex: "4D8DFF").opacity(0.25), radius: 25, x: 0, y: 10)
                    .padding(.vertical, 30)
                }

                Spacer()

                // Başlık & Sanatçı
                VStack(alignment: .leading, spacing: 6) {
                    Text(song.title)
                        .font(.system(size: 22, weight: .bold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Text(song.artist)
                        .font(.system(size: 16))
                        .foregroundColor(Color(hex: "9A9A9A"))
                        .lineLimit(1)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 28)

                // İlerleme Çubuğu
                VStack(spacing: 6) {
                    Slider(
                        value: Binding(
                            get: { player.currentTime },
                            set: { player.seek(to: $0) }
                        ),
                        in: 0...max(player.duration, 1.0)
                    )
                    .accentColor(Color(hex: "4D8DFF"))

                    HStack {
                        Text(formatTime(player.currentTime))
                            .font(.system(size: 12))
                            .foregroundColor(Color(hex: "9A9A9A"))
                        Spacer()
                        Text(formatTime(player.duration))
                            .font(.system(size: 12))
                            .foregroundColor(Color(hex: "9A9A9A"))
                    }
                }
                .padding(.horizontal, 28)
                .padding(.top, 10)

                // Oynatıcı Kontrolleri
                HStack(spacing: 36) {
                    Button(action: { player.previous() }) {
                        Image(systemName: "backward.fill")
                            .font(.system(size: 26))
                            .foregroundColor(.white)
                    }

                    Button(action: { player.togglePlayPause() }) {
                        ZStack {
                            Circle()
                                .fill(Color(hex: "4D8DFF"))
                                .frame(width: 68, height: 68)
                            Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                                .font(.system(size: 28))
                                .foregroundColor(.white)
                        }
                    }

                    Button(action: { player.next() }) {
                        Image(systemName: "forward.fill")
                            .font(.system(size: 26))
                            .foregroundColor(.white)
                    }
                }
                .padding(.top, 16)
                .padding(.bottom, 40)
            }
        }
        .offset(y: max(0, dragOffset))
        .gesture(
            DragGesture()
                .onChanged { gesture in
                    if gesture.translation.height > 0 {
                        dragOffset = gesture.translation.height
                    }
                }
                .onEnded { gesture in
                    if gesture.translation.height > 120 {
                        isPresented = false
                    } else {
                        withAnimation(.spring()) {
                            dragOffset = 0
                        }
                    }
                }
        )
        .onAppear {
            fetchLyrics(for: song)
        }
    }

    private func formatTime(_ seconds: Double) -> String {
        let s = Int(seconds)
        let m = s / 60
        let sec = s % 60
        return String(format: "%02d:%02d", m, sec)
    }

    private func fetchLyrics(for song: SongItem) {
        guard let url = URL(string: "https://lrclib.net/api/get?track_name=\(song.title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")&artist_name=\(song.artist.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")") else { return }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let syncedLyrics = json["syncedLyrics"] as? String else { return }

            var parsed: [LyricLine] = []
            let lines = syncedLyrics.components(separatedBy: "\n")
            for l in lines {
                if let open = l.firstIndex(of: "["), let close = l.firstIndex(of: "]") {
                    let timeStr = String(l[l.index(after: open)..<close])
                    let text = String(l[l.index(after: close)...]).trimmingCharacters(in: .whitespaces)
                    let parts = timeStr.components(separatedBy: ":")
                    if parts.count == 2, let m = Double(parts[0]), let s = Double(parts[1]) {
                        parsed.append(LyricLine(time: m * 60 + s, text: text))
                    }
                }
            }
            DispatchQueue.main.async {
                self.lyrics = parsed
            }
        }.resume()
    }
}

struct LyricLine: Identifiable {
    var id: Double { time }
    let time: Double
    let text: String
}

// MARK: - Arkadaşlar Sekmesi (Soft & Modern Tasarım)
struct FriendsView: View {
    @EnvironmentObject var player: AudioPlayer

    var body: some View {
        NavigationView {
            ZStack {
                Color(hex: "070B14").ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        // Profil Kartı
                        VStack(spacing: 14) {
                            HStack(spacing: 14) {
                                Circle()
                                    .fill(Color(hex: "4D8DFF").opacity(0.3))
                                    .frame(width: 52, height: 52)
                                    .overlay(
                                        Image(systemName: "person.fill")
                                            .foregroundColor(.white)
                                            .font(.system(size: 24))
                                    )

                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Sen")
                                        .font(.system(size: 16, weight: .bold))
                                        .foregroundColor(.white)
                                    Text("@kullanici")
                                        .font(.system(size: 12))
                                        .foregroundColor(Color(hex: "9A9A9A"))
                                }

                                Spacer()

                                Button(action: {}) {
                                    Circle()
                                        .fill(Color.white.opacity(0.06))
                                        .frame(width: 38, height: 38)
                                        .overlay(Image(systemName: "square.and.arrow.up").foregroundColor(.white).font(.system(size: 15)))
                                }
                            }

                            // Ne dinlediğimi göster
                            HStack {
                                Image(systemName: "headphones")
                                    .foregroundColor(Color(hex: "4D8DFF"))
                                Text("Ne dinlediğimi göster")
                                    .font(.system(size: 13))
                                    .foregroundColor(.white)
                                Spacer()
                                Toggle("", isOn: .constant(true))
                                    .labelsHidden()
                                    .toggleStyle(SwitchToggleStyle(tint: Color(hex: "4D8DFF")))
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.04))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                        }
                        .padding(16)
                        .background(Color(hex: "151E33"))
                        .clipShape(RoundedRectangle(cornerRadius: 22))
                        .overlay(
                            RoundedRectangle(cornerRadius: 22)
                                .stroke(Color.white.opacity(0.06), lineWidth: 1)
                        )
                        .padding(.horizontal, 16)

                        // Bölüm Başlığı
                        HStack {
                            Text("ARKADAŞLAR")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(Color(hex: "9A9A9A"))
                                .tracking(1.1)
                            Spacer()
                        }
                        .padding(.horizontal, 20)

                        // Arkadaş Listesi Örnek Kartı
                        VStack(spacing: 0) {
                            HStack(spacing: 12) {
                                Circle()
                                    .fill(Color(hex: "6C5CE7"))
                                    .frame(width: 44, height: 44)
                                    .overlay(Text("E").foregroundColor(.white).bold())

                                VStack(alignment: .leading, spacing: 3) {
                                    Text("Emir")
                                        .font(.system(size: 15, weight: .semibold))
                                        .foregroundColor(.white)
                                    HStack(spacing: 6) {
                                        Circle().fill(Color(hex: "3DDC84")).frame(width: 7, height: 7)
                                        Text("Çevrim içi").font(.system(size: 12)).foregroundColor(Color(hex: "3DDC84"))
                                    }
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14))
                                    .foregroundColor(Color(hex: "9A9A9A").opacity(0.5))
                            }
                            .padding(14)
                        }
                        .background(Color(hex: "151E33"))
                        .clipShape(RoundedRectangle(cornerRadius: 22))
                        .overlay(
                            RoundedRectangle(cornerRadius: 22)
                                .stroke(Color.white.opacity(0.05), lineWidth: 1)
                        )
                        .padding(.horizontal, 16)
                    }
                    .padding(.top, 12)
                    .padding(.bottom, 100)
                }
            }
            .navigationTitle("Arkadaşlar")
        }
    }
}

// MARK: - Keşfet / Ana Sayfa
struct HomeView: View {
    @EnvironmentObject var player: AudioPlayer

    var body: some View {
        NavigationView {
            ZStack {
                Color(hex: "070B14").ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text("Popüler Şarkılar")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 16)

                        // Örnek şarkı listesi
                        VStack(spacing: 8) {
                            ForEach(sampleSongs) { song in
                                HStack(spacing: 12) {
                                    AsyncImage(url: URL(string: song.thumb ?? "")) { img in
                                        img.resizable().aspectRatio(contentMode: .fill)
                                    } placeholder: {
                                        Color.gray.opacity(0.3)
                                    }
                                    .frame(width: 48, height: 48)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))

                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(song.title)
                                            .font(.system(size: 14, weight: .semibold))
                                            .foregroundColor(.white)
                                            .lineLimit(1)
                                        Text(song.artist)
                                            .font(.system(size: 12))
                                            .foregroundColor(Color(hex: "9A9A9A"))
                                            .lineLimit(1)
                                    }
                                    Spacer()
                                    Button(action: {
                                        player.playSingle(song)
                                    }) {
                                        Image(systemName: "play.circle.fill")
                                            .font(.system(size: 32))
                                            .foregroundColor(Color(hex: "4D8DFF"))
                                    }
                                }
                                .padding(10)
                                .background(Color(hex: "151E33").opacity(0.6))
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                    .padding(.top, 12)
                    .padding(.bottom, 100)
                }
            }
            .navigationTitle("Keşfet")
        }
    }

    private var sampleSongs: [SongItem] {
        [
            SongItem(title: "Starboy", artist: "The Weeknd, Daft Punk", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", thumb: "https://i.scdn.co/image/ab67616d0000b2734718e2b124f79258be7bc452"),
            SongItem(title: "Blinding Lights", artist: "The Weeknd", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", thumb: "https://i.scdn.co/image/ab67616d0000b2738863bc11d2aa12b54f5aeb36"),
            SongItem(title: "Mockingbird", artist: "Eminem", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3", thumb: "https://i.scdn.co/image/ab67616d0000b2730f146a47ea79ef08b5066914")
        ]
    }
}

// MARK: - Kitaplık
struct LibraryView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color(hex: "070B14").ignoresSafeArea()
                VStack(spacing: 16) {
                    Image(systemName: "music.note.list")
                        .font(.system(size: 54))
                        .foregroundColor(Color(hex: "9A9A9A"))
                    Text("Çalma Listelerin")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                    Text("Beğendiğin şarkılar ve oluşturduğun Blend listeleri burada listelenir.")
                        .font(.system(size: 14))
                        .foregroundColor(Color(hex: "9A9A9A"))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                }
            }
            .navigationTitle("Kitaplık")
        }
    }
}

// MARK: - Renk Yardımcısı
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
