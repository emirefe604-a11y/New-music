# Sounddeep: e-posta ile giriş kurulumu

Uygulama, hesap oluşturmak veya giriş yapmak için kullanıcının e-postasına 6 haneli bir kod gönderir.
E-posta göndermek için bir servis gerekir; aşağıdaki iki yoldan birini seç.

## Yol 1: EmailJS (sunucu gerekmez, önerilen)

1. https://www.emailjs.com adresinde ücretsiz hesap aç.
2. **Email Services** bölümünden **Add New Service** > **Gmail** seç, gönderici Gmail hesabını bağla.
   Oluşan **Service ID** değerini not al.
3. **Email Templates** bölümünden yeni şablon oluştur:
   - **To Email**: `{{to_email}}`
   - **Subject**: `{{app_name}} doğrulama kodun: {{code}}`
   - **Content**: `Doğrulama kodun: {{code}} (10 dakika geçerli)`
   Şablonun **Template ID** değerini not al.
4. **Account** sayfasından **Public Key** değerini not al.
5. Aynı hesap ayarlarında (Security) **API çağrılarına / non-browser uygulamalara izin ver** seçeneğini aç.
   Bu kapalıysa uygulama 403 hatası alır.
6. `app/src/main/java/com/example/newmusic/AuthStore.kt` dosyasında üç değeri doldur:
   ```kotlin
   const val EMAILJS_SERVICE_ID = "service_xxxxxx"
   const val EMAILJS_TEMPLATE_ID = "template_xxxxxx"
   const val EMAILJS_PUBLIC_KEY = "xxxxxxxxxxxxxxxx"
   ```
7. Projeyi yeniden derle.

Notlar:
- Ücretsiz pakette aylık e-posta sayısı sınırlıdır (yaklaşık 200).
- Public Key uygulamanın içinde durur; EmailJS bunun için tasarlanmıştır ama kötü niyetli biri
  kotanı tüketebilir. Kullanıcı sayın artarsa Yol 2'ye geç.
- Bu yolda kod uygulamada üretilip doğrulanır; hesap yalnızca o telefonda saklanır.

## Yol 2: Kendi sunucun

`backend/README.md` dosyasında anlatılıyor. Sunucuyu yayınladıktan sonra
`AuthStore.kt` içindeki `AUTH_API_URL` değerine adresini yaz. Bu doluysa EmailJS kullanılmaz.
